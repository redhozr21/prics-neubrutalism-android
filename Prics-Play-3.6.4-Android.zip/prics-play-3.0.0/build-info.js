window.MURIEL_BUILD = {"sha":"dev","version":"3.6.4","run":0,"repo":"redhozr21/prics-neubrutalism-android","builtAt":"2026-11-03T07:15:00.000Z","channel":""};
