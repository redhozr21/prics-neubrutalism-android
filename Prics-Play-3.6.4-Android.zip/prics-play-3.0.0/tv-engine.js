// =====================================================================
// PRICS PLAY — SMART TV / ANDROID TV CONTROLLER & SPATIAL ENGINE
// 10-Foot Navigation, D-Pad Remote Control & Fullscreen TV Karaoke
// =====================================================================

(() => {
  'use strict';

  // Strict Singleton Guard — physically prevents duplicate execution!
  if (window.__PRICS_TV_ENGINE_INITIALIZED__) {
    console.warn('[PricsTV] TV engine already initialized. Skipping duplicate.');
    return;
  }
  window.__PRICS_TV_ENGINE_INITIALIZED__ = true;

  function isTVMode() {
    if (typeof window === 'undefined') return false;
    const saved = localStorage.getItem('prics_tv_mode');
    if (saved === 'true') return true;
    if (saved === 'false') return false;

    // Native Android TV bridge check
    if (window.PricsAndroidDevice && typeof window.PricsAndroidDevice.isTelevision === 'function') {
      if (window.PricsAndroidDevice.isTelevision()) return true;
    }

    const ua = (typeof navigator !== 'undefined' && navigator.userAgent) || '';
    if (/PricsTV|Android TV|GoogleTV|SmartTV|Leanback/i.test(ua)) {
      return true;
    }

    // Android device in 16:9 widescreen landscape without touchscreen
    const isLandscape = window.innerWidth > window.innerHeight;
    const isLargeScreen = window.innerWidth >= 960;
    const isNoTouch = !('ontouchstart' in window) || (navigator.maxTouchPoints === 0);
    if (/Android/i.test(ua) && isLandscape && isLargeScreen && isNoTouch) {
      return true;
    }

    return false;
  }

  if (!isTVMode()) {
    return; // Leave mobile phone layout 100% untouched
  }

  // Activate TV styling on html root
  const rootEl = document.documentElement;
  rootEl.classList.add('is-tv', 'is-desktop');
  rootEl.classList.remove('is-mobile');

  let currentView = 'home';
  let focusedEl = null;
  let isKaraokeOpen = false;
  let activeLyricIndex = -1;
  let lastBackPressTime = 0;
  let lastNavTime = 0;
  let lastSelectTime = 0;
  const NAV_THROTTLE_MS = 130;

  function safeEscape(str) {
    if (typeof str !== 'string') return '';
    return str.replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m]);
  }

  function getCore() {
    return window.MurielCore || null;
  }

  // =====================================================================
  // Single Focus Manager (Strict single-source-of-truth)
  // tabIndex="-1" on all elements except the single active focused element
  // completely stops native Chromium from finding adjacent targets!
  // =====================================================================
  function clearAllFocus() {
    document.querySelectorAll('.tv-focusable').forEach((el) => {
      el.classList.remove('tv-focused');
      el.tabIndex = -1;
    });
  }

  function setFocus(el) {
    if (!el) return;
    clearAllFocus();
    focusedEl = el;
    el.tabIndex = 0;
    el.classList.add('tv-focused');

    try {
      el.focus({ preventScroll: true });
    } catch (_) {
      el.focus();
    }

    try {
      el.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'nearest' });
    } catch (_) {}
  }

  // =====================================================================
  // TV Root DOM Scaffolding (10-Foot Widescreen Layout)
  // =====================================================================
  function createTVLayout() {
    if (document.getElementById('tv-root')) return;

    const tvRoot = document.createElement('div');
    tvRoot.id = 'tv-root';
    tvRoot.innerHTML = `
      <!-- TV Sidebar Rail -->
      <aside class="tv-rail" aria-label="Smart TV Navigation">
        <div>
          <div class="tv-rail-brand">
            <div class="tv-rail-logo">
              <img src="assets/prics-pa-play.png" alt="Prics" onerror="this.outerHTML='P'">
            </div>
            <div class="tv-rail-title-group">
              <span class="tv-rail-title">Prics Play</span>
              <span class="tv-rail-badge">Smart TV Edition</span>
            </div>
          </div>
          <nav class="tv-rail-menu">
            <button type="button" class="tv-rail-item tv-focusable active" data-tv-tab="home" tabindex="0">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/></svg>
              <span>Beranda</span>
            </button>
            <button type="button" class="tv-rail-item tv-focusable" data-tv-tab="search" tabindex="-1">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.5" y2="16.5"/></svg>
              <span>Pencarian</span>
            </button>
            <button type="button" class="tv-rail-item tv-focusable" data-tv-tab="library" tabindex="-1">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M4 4v16M9 4v16M14 4v16M19 4v16"/></svg>
              <span>Koleksi</span>
            </button>
            <button type="button" class="tv-rail-item tv-focusable" data-tv-tab="settings" tabindex="-1">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
              <span>Setelan</span>
            </button>
          </nav>
        </div>
        <div class="tv-rail-footer">
          <div class="tv-clock-pill" id="tv-clock">--:--</div>
          <div class="tv-fps-pill" id="tv-fps-indicator">120Hz Ultra</div>
        </div>
      </aside>

      <!-- TV Main Viewport -->
      <main class="tv-main" id="tv-main">
        <!-- Home View -->
        <section class="tv-view" id="tv-view-home">
          <!-- Spotlight Hero -->
          <div class="tv-spotlight" id="tv-spotlight">
            <img class="tv-spotlight-art" id="tv-spotlight-art" src="assets/prics-pa-play.png" alt="Spotlight Art">
            <div class="tv-spotlight-info">
              <span class="tv-spotlight-tag" id="tv-spotlight-tag">SEDANG DIPUTAR</span>
              <h1 class="tv-spotlight-title" id="tv-spotlight-title">Prics Play TV</h1>
              <p class="tv-spotlight-artist" id="tv-spotlight-artist">Pilih lagu untuk memulai hiburan di layar TV Anda</p>
              <div class="tv-spotlight-actions">
                <button type="button" class="tv-btn-primary tv-focusable" id="tv-btn-hero-play" tabindex="-1">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                  <span>Putar Sekarang</span>
                </button>
                <button type="button" class="tv-btn-secondary tv-focusable" id="tv-btn-hero-lyrics" tabindex="-1">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/></svg>
                  <span>Lirik TV (Karaoke)</span>
                </button>
              </div>
            </div>
          </div>

          <!-- Shelf 1: Terakhir Diputar -->
          <div class="tv-shelf" id="tv-shelf-recent-wrap">
            <div class="tv-shelf-header">
              <h2 class="tv-shelf-title">Terakhir Diputar</h2>
            </div>
            <div class="tv-shelf-scroll" id="tv-shelf-recent"></div>
          </div>

          <!-- Shelf 2: Lagu Disukai -->
          <div class="tv-shelf" id="tv-shelf-favorites-wrap">
            <div class="tv-shelf-header">
              <h2 class="tv-shelf-title">Lagu Disukai</h2>
            </div>
            <div class="tv-shelf-scroll" id="tv-shelf-favorites"></div>
          </div>

          <!-- Shelf 3: Playlist Kamu -->
          <div class="tv-shelf" id="tv-shelf-playlists-wrap">
            <div class="tv-shelf-header">
              <h2 class="tv-shelf-title">Playlist Kamu</h2>
            </div>
            <div class="tv-shelf-scroll" id="tv-shelf-playlists"></div>
          </div>
        </section>

        <!-- Search View -->
        <section class="tv-view hidden" id="tv-view-search">
          <div class="tv-search-header">
            <div class="tv-search-input-wrap tv-focusable" id="tv-search-input-box" tabindex="-1">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.5" y2="16.5"/></svg>
              <input type="text" class="tv-search-input" id="tv-search-input" placeholder="Ketik judul lagu atau artis..." autocomplete="off">
            </div>
            <div class="tv-platform-pills">
              <button type="button" class="tv-platform-pill tv-focusable active" data-platform="ytmusic" tabindex="-1">YouTube Music</button>
              <button type="button" class="tv-platform-pill tv-focusable" data-platform="youtube" tabindex="-1">YouTube</button>
            </div>
          </div>
          <div class="tv-search-results-grid" id="tv-search-results">
            <div class="tv-empty-hint">Ketik judul lagu di atas untuk mencari musik...</div>
          </div>
        </section>

        <!-- Library View -->
        <section class="tv-view hidden" id="tv-view-library">
          <div class="tv-view-header">
            <h1 class="tv-view-title">Koleksi Musik Anda</h1>
          </div>
          <div class="tv-library-grid" id="tv-library-grid">
            <div class="tv-empty-hint">Koleksi lagu disukai dan playlist Anda akan tampil di sini.</div>
          </div>
        </section>

        <!-- Settings View -->
        <section class="tv-view hidden" id="tv-view-settings">
          <div class="tv-view-header">
            <h1 class="tv-view-title">Setelan Layar & Audio</h1>
          </div>
          <div class="tv-settings-container">
            <!-- Setting 1: Refresh Rate -->
            <div class="tv-settings-group">
              <h2 class="tv-setting-group-title">Kecepatan Layar (Refresh Rate)</h2>
              <div class="tv-settings-cards">
                <div class="tv-setting-card tv-focusable" id="tv-set-fps-60" data-fps="60" tabindex="-1">
                  <div class="tv-setting-card-icon">⚡</div>
                  <h3 class="tv-setting-card-title">60 Hz (Hemat Daya)</h3>
                  <p class="tv-setting-card-desc">Sangat stabil, menghemat konsumsi daya prosesor Smart TV.</p>
                </div>
                <div class="tv-setting-card tv-focusable active" id="tv-set-fps-120" data-fps="120" tabindex="-1">
                  <div class="tv-setting-card-icon">🚀</div>
                  <h3 class="tv-setting-card-title">120 Hz (Ultra Halus)</h3>
                  <p class="tv-setting-card-desc">Animasi dan pergerakan remote D-pad responsif maksimal.</p>
                </div>
              </div>
            </div>

            <!-- Setting 2: Kualitas Audio -->
            <div class="tv-settings-group">
              <h2 class="tv-setting-group-title">Kualitas Audio Streaming</h2>
              <div class="tv-settings-cards">
                <div class="tv-setting-card tv-focusable" id="tv-set-audio-low" data-quality="low" tabindex="-1">
                  <div class="tv-setting-card-icon">📶</div>
                  <h3 class="tv-setting-card-title">Hemat Kuota (~64 kbps)</h3>
                  <p class="tv-setting-card-desc">Pemuatan instan saat koneksi internet lambat.</p>
                </div>
                <div class="tv-setting-card tv-focusable active" id="tv-set-audio-normal" data-quality="normal" tabindex="-1">
                  <div class="tv-setting-card-icon">🎵</div>
                  <h3 class="tv-setting-card-title">Standar Rekomendasi (~128 kbps)</h3>
                  <p class="tv-setting-card-desc">Keseimbangan terbaik antara kualitas jernih dan bandwidth.</p>
                </div>
                <div class="tv-setting-card tv-focusable" id="tv-set-audio-high" data-quality="high" tabindex="-1">
                  <div class="tv-setting-card-icon">✨</div>
                  <h3 class="tv-setting-card-title">Kualitas Tinggi (~160 kbps)</h3>
                  <p class="tv-setting-card-desc">Suara detail vokal dan bass optimal untuk speaker TV.</p>
                </div>
              </div>
            </div>

            <!-- Setting 3: Mode Tema -->
            <div class="tv-settings-group">
              <h2 class="tv-setting-group-title">Tampilan Visual</h2>
              <div class="tv-settings-cards">
                <div class="tv-setting-card tv-focusable" id="tv-set-theme-light" data-theme="light" tabindex="-1">
                  <div class="tv-setting-card-icon">☀️</div>
                  <h3 class="tv-setting-card-title">Mode Terang (Warm Paper)</h3>
                  <p class="tv-setting-card-desc">Nuansa retro neubrutalism khas Prics Play.</p>
                </div>
                <div class="tv-setting-card tv-focusable" id="tv-set-theme-dark" data-theme="dark" tabindex="-1">
                  <div class="tv-setting-card-icon">🌙</div>
                  <h3 class="tv-setting-card-title">Mode Malam (OLED Dark)</h3>
                  <p class="tv-setting-card-desc">Latar gelap nyaman di mata untuk menonton bioskop malam.</p>
                </div>
              </div>
            </div>

            <!-- Setting 4: Informasi Versi -->
            <div class="tv-settings-group">
              <h2 class="tv-setting-group-title">Tentang Aplikasi</h2>
              <div class="tv-setting-card" style="cursor: default;">
                <h3 class="tv-setting-card-title">Prics Play Smart TV Edition v3.6.4</h3>
                <p class="tv-setting-card-desc">Dioptimalkan khusus untuk Android TV & Xiaomi Smart TV (D-Pad 10-Foot UI).</p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <!-- TV Bottom Player Bar (Persistent) -->
      <footer class="tv-player-bar" id="tv-player-bar">
        <div class="tv-bar-track-info">
          <img class="tv-bar-art" id="tv-bar-art" src="assets/prics-pa-play.png" alt="Album Art">
          <div class="tv-bar-text">
            <span class="tv-bar-title" id="tv-bar-title">Tidak ada lagu diputar</span>
            <span class="tv-bar-artist" id="tv-bar-artist">Pilih lagu dari beranda atau pencarian</span>
          </div>
        </div>
        <div class="tv-bar-controls">
          <button type="button" class="tv-control-btn tv-focusable" id="tv-btn-prev" tabindex="-1" title="Sebelumnya">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><polygon points="19 20 9 12 19 4 19 20"/><line x1="5" y1="19" x2="5" y2="5" stroke="currentColor" stroke-width="2.5"/></svg>
          </button>
          <button type="button" class="tv-control-btn primary tv-focusable" id="tv-btn-play" tabindex="-1" title="Putar / Jeda">
            <svg class="tv-icon-play" id="tv-icon-play" width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><polygon points="6 4 20 12 6 20 6 4"/></svg>
            <svg class="tv-icon-pause hidden" id="tv-icon-pause" width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
          </button>
          <button type="button" class="tv-control-btn tv-focusable" id="tv-btn-next" tabindex="-1" title="Berikutnya">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 4 15 12 5 20 5 4"/><line x1="19" y1="5" x2="19" y2="19" stroke="currentColor" stroke-width="2.5"/></svg>
          </button>
          <button type="button" class="tv-control-btn tv-focusable" id="tv-btn-karaoke-bar" tabindex="-1" title="Lirik Karaoke">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="22"/></svg>
          </button>
        </div>
      </footer>

      <!-- Fullscreen TV Karaoke Overlay -->
      <div class="tv-karaoke-overlay hidden" id="tv-karaoke-overlay">
        <div class="tvk-back-hint">Tekan [Kembali] pada remote untuk menutup</div>
        <div class="tvk-left-stage">
          <img class="tvk-disc-art" id="tvk-disc-art" src="assets/prics-pa-play.png" alt="Vinyl Disc">
          <h2 class="tvk-track-title" id="tvk-title">Pilih Lagu</h2>
          <span class="tvk-track-artist" id="tvk-artist">Prics Play TV</span>
        </div>
        <div class="tvk-right-lyrics" id="tvk-lyrics-box">
          <div class="tvk-line active">Pilih lagu untuk bernyanyi karaoke...</div>
        </div>
      </div>
    `;

    document.body.appendChild(tvRoot);

    const homeBtn = tvRoot.querySelector('.tv-rail-item[data-tv-tab="home"]');
    if (homeBtn) setFocus(homeBtn);

    initClock();
    setupTabSwitching();
    setupPlaybackControls();
    setupSettingsCards();
    setupSearch();
    hydrateHomeContent();
  }

  // =====================================================================
  // Clock and FPS indicator
  // =====================================================================
  function initClock() {
    const clockEl = document.getElementById('tv-clock');
    if (!clockEl) return;
    const updateTime = () => {
      const now = new Date();
      const h = String(now.getHours()).padStart(2, '0');
      const m = String(now.getMinutes()).padStart(2, '0');
      clockEl.textContent = `${h}:${m}`;
    };
    updateTime();
    setInterval(updateTime, 30000);

    const fpsEl = document.getElementById('tv-fps-indicator');
    if (fpsEl) {
      const prefHz = localStorage.getItem('prics_preferred_fps') || '120';
      fpsEl.textContent = prefHz === '60' ? '60Hz Hemat' : '120Hz Ultra';
    }
  }

  // =====================================================================
  // Tab Switching (Immediate and Synchronous)
  // =====================================================================
  function switchTVTab(tabName) {
    closeTVKaraoke();
    currentView = tabName;

    document.querySelectorAll('.tv-rail-item').forEach((item) => {
      const isActive = item.dataset.tvTab === tabName;
      item.classList.toggle('active', isActive);
    });

    const views = ['home', 'search', 'library', 'settings'];
    views.forEach((v) => {
      const el = document.getElementById(`tv-view-${v}`);
      if (el) el.classList.toggle('hidden', v !== tabName);
    });

    if (tabName === 'home') hydrateHomeContent();
    else if (tabName === 'library') hydrateLibraryContent();
  }

  function setupTabSwitching() {
    document.querySelectorAll('.tv-rail-item').forEach((item) => {
      item.addEventListener('click', () => {
        const tab = item.dataset.tvTab;
        if (tab) {
          switchTVTab(tab);
          setFocus(item);
        }
      });
    });
  }

  // =====================================================================
  // TV Karaoke Fullscreen Mode & Real-time Synced Lyrics
  // =====================================================================
  function openTVKaraoke() {
    const overlay = document.getElementById('tv-karaoke-overlay');
    if (!overlay) return;
    overlay.classList.remove('hidden');
    isKaraokeOpen = true;

    syncNowPlayingUI();
    renderTVLyrics();

    const core = getCore();
    if (core && core.audio && !core.audio.paused) {
      document.documentElement.classList.add('playing');
    }
  }

  function closeTVKaraoke() {
    const overlay = document.getElementById('tv-karaoke-overlay');
    if (!overlay) return;
    overlay.classList.add('hidden');
    isKaraokeOpen = false;
  }

  function renderTVLyrics() {
    const box = document.getElementById('tvk-lyrics-box');
    if (!box) return;

    const core = getCore();
    const track = core && core.state && core.state.currentTrack;
    if (!track) {
      box.innerHTML = '<div class="tvk-line active">Pilih lagu untuk bernyanyi karaoke...</div>';
      return;
    }

    const lyricsList = (core.state && core.state.syncedLyrics) || [];
    const lyricsContainer = document.getElementById('lyrics-container');
    const isLyricsEmpty = lyricsContainer && lyricsContainer.classList.contains('lyrics-empty');
    if (!Array.isArray(lyricsList) || !lyricsList.length) {
      box.innerHTML = isLyricsEmpty
        ? '<div class="tvk-line active">Lirik tidak tersedia untuk lagu ini</div>'
        : '<div class="tvk-line active">Memuat lirik dari server...</div>';
      return;
    }

    activeLyricIndex = -1;
    box.replaceChildren();

    lyricsList.forEach((line, idx) => {
      const lineEl = document.createElement('div');
      lineEl.className = 'tvk-line' + (idx === 0 ? ' active' : '');
      lineEl.dataset.idx = String(idx);
      lineEl.dataset.time = String(typeof line.time === 'number' ? line.time : -1);
      lineEl.textContent = line.text || '...';
      box.appendChild(lineEl);
    });

    updateTVActiveLyric();
  }

  function updateTVActiveLyric() {
    if (!isKaraokeOpen) return;
    const box = document.getElementById('tvk-lyrics-box');
    if (!box) return;

    const core = getCore();
    const audio = core && core.audio;
    if (!audio) return;

    const currentTime = audio.currentTime || 0;
    const lyricsList = (core.state && core.state.syncedLyrics) || [];
    if (!lyricsList.length) return;

    let foundIdx = -1;
    for (let i = 0; i < lyricsList.length; i++) {
      const item = lyricsList[i];
      if (typeof item.time === 'number' && item.time >= 0 && item.time <= currentTime + 0.25) {
        foundIdx = i;
      } else if (typeof item.time === 'number' && item.time > currentTime + 0.25) {
        break;
      }
    }

    if (foundIdx === -1 && currentTime > 0 && lyricsList[0].time < 0) {
      foundIdx = 0;
    } else if (foundIdx === -1 && currentTime >= (lyricsList[lyricsList.length - 1].time || 0)) {
      foundIdx = lyricsList.length - 1;
    }

    if (foundIdx !== -1 && foundIdx !== activeLyricIndex) {
      activeLyricIndex = foundIdx;
      const allLines = box.querySelectorAll('.tvk-line');
      allLines.forEach((el, idx) => {
        el.classList.toggle('active', idx === foundIdx);
      });
      const activeEl = allLines[foundIdx];
      if (activeEl) {
        activeEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }

  // =====================================================================
  // Search & Play Immediately (Starter & Smart Play)
  // =====================================================================
  async function searchAndPlay(query) {
    const core = getCore();
    if (!core) return;
    if (core.toast) core.toast(`Mencari: ${query}...`, 'info');

    try {
      const base = (typeof core.base === 'function') ? core.base() : 'http://127.0.0.1:3000';
      const res = await fetch(`${base}/api/search?q=${encodeURIComponent(query)}&platform=ytmusic&limit=10`);
      const data = await res.json();
      const tracks = (data && data.tracks) || (Array.isArray(data) ? data : []);
      if (tracks.length > 0) {
        core.playTrack(tracks[0], tracks, 0);
        if (core.toast) core.toast(`Memutar: ${tracks[0].title}`, 'info');
      } else {
        const resYt = await fetch(`${base}/api/search?q=${encodeURIComponent(query)}&platform=youtube&limit=10`);
        const dataYt = await resYt.json();
        const tracksYt = (dataYt && dataYt.tracks) || (Array.isArray(dataYt) ? dataYt : []);
        if (tracksYt.length > 0) {
          core.playTrack(tracksYt[0], tracksYt, 0);
          if (core.toast) core.toast(`Memutar: ${tracksYt[0].title}`, 'info');
        }
      }
    } catch (err) {
      console.error('[PricsTV] searchAndPlay failed:', err);
    }
  }

  // =====================================================================
  // Hydrate Shelves & Cards
  // =====================================================================
  function createTVCard(track, tracksList, index) {
    const card = document.createElement('div');
    card.className = 'tv-card tv-focusable';
    card.tabIndex = -1;

    let thumb = 'assets/prics-pa-play.png';
    const core = getCore();
    if (core && typeof core.thumb === 'function') {
      thumb = core.thumb(track) || thumb;
    } else if (track.thumbnail) {
      thumb = track.thumbnail;
    }

    const title = safeEscape(track.title || 'Unknown Track');
    const artist = safeEscape(track.artist || 'Unknown Artist');

    card.innerHTML = `
      <img class="tv-card-art" src="${thumb}" alt="${title}" loading="lazy" decoding="async">
      <h3 class="tv-card-title">${title}</h3>
      <span class="tv-card-desc">${artist}</span>
    `;

    card.addEventListener('click', () => {
      if (core && typeof core.playTrack === 'function') {
        core.playTrack(track, tracksList, index);
        if (core.toast) core.toast(`Memutar: ${track.title || 'Lagu'}`, 'info');
      }
    });

    return card;
  }

  function syncSpotlightHero() {
    const core = getCore();
    const track = core && core.state && core.state.currentTrack;

    const heroArt = document.getElementById('tv-spotlight-art');
    const heroTitle = document.getElementById('tv-spotlight-title');
    const heroArtist = document.getElementById('tv-spotlight-artist');
    const heroTag = document.getElementById('tv-spotlight-tag');

    if (track) {
      const thumb = (core.thumb && core.thumb(track)) || track.thumbnail || 'assets/prics-pa-play.png';
      if (heroArt) heroArt.src = thumb;
      if (heroTitle) heroTitle.textContent = track.title || 'Unknown Track';
      if (heroArtist) heroArtist.textContent = track.artist || 'Unknown Artist';
      if (heroTag) heroTag.textContent = 'SEDANG DIPUTAR';
    } else {
      if (heroArt) heroArt.src = 'assets/prics-pa-play.png';
      if (heroTitle) heroTitle.textContent = 'Prics Play TV';
      if (heroArtist) heroArtist.textContent = 'Pilih lagu untuk memulai hiburan di layar TV Anda';
      if (heroTag) heroTag.textContent = 'REKOMENDASI';
    }
  }

  function hydrateHomeContent() {
    const core = getCore();
    if (!core || !core.state) return;

    // 1. Shelf: Terakhir Diputar
    const recentShelf = document.getElementById('tv-shelf-recent');
    const recentWrap = document.getElementById('tv-shelf-recent-wrap');
    if (recentShelf && recentWrap) {
      recentShelf.replaceChildren();
      const history = Array.isArray(core.state.history) ? core.state.history.slice(0, 15) : [];
      if (!history.length) {
        recentWrap.classList.add('hidden');
      } else {
        recentWrap.classList.remove('hidden');
        history.forEach((track, idx) => {
          recentShelf.appendChild(createTVCard(track, history, idx));
        });
      }
    }

    // 2. Shelf: Lagu Disukai
    const favShelf = document.getElementById('tv-shelf-favorites');
    const favWrap = document.getElementById('tv-shelf-favorites-wrap');
    if (favShelf && favWrap) {
      favShelf.replaceChildren();
      const favs = Array.isArray(core.state.favorites) ? core.state.favorites.slice(0, 15) : [];
      if (!favs.length) {
        favWrap.classList.add('hidden');
      } else {
        favWrap.classList.remove('hidden');
        favs.forEach((track, idx) => {
          favShelf.appendChild(createTVCard(track, favs, idx));
        });
      }
    }

    // 3. Shelf: Playlist Kamu
    const plShelf = document.getElementById('tv-shelf-playlists');
    const plWrap = document.getElementById('tv-shelf-playlists-wrap');
    if (plShelf && plWrap) {
      plShelf.replaceChildren();
      const playlists = Array.isArray(core.state.playlists) ? core.state.playlists : [];
      if (!playlists.length) {
        plWrap.classList.add('hidden');
      } else {
        plWrap.classList.remove('hidden');
        playlists.forEach((pl) => {
          const card = document.createElement('div');
          card.className = 'tv-card tv-focusable';
          card.tabIndex = -1;
          const firstTrack = pl.tracks && pl.tracks[0];
          const thumb = firstTrack && core.thumb(firstTrack) ? core.thumb(firstTrack) : 'assets/prics-pa-play.png';
          card.innerHTML = `
            <img class="tv-card-art" src="${thumb}" alt="${safeEscape(pl.name)}" loading="lazy">
            <h3 class="tv-card-title">${safeEscape(pl.name)}</h3>
            <span class="tv-card-desc">${(pl.tracks && pl.tracks.length) || 0} lagu</span>
          `;
          card.addEventListener('click', () => {
            if (pl.tracks && pl.tracks.length && core.playTrack) {
              core.playTrack(pl.tracks[0], pl.tracks, 0);
              if (core.toast) core.toast(`Memutar playlist: ${pl.name}`, 'info');
            }
          });
          plShelf.appendChild(card);
        });
      }
    }

    // Starter recommendations if fresh install (0 history)
    const hasAnyContent = (core.state.history && core.state.history.length) ||
                          (core.state.favorites && core.state.favorites.length) ||
                          (core.state.playlists && core.state.playlists.length);
    if (!hasAnyContent) {
      recentWrap.classList.remove('hidden');
      recentWrap.querySelector('.tv-shelf-title').textContent = 'Mulai Menjelajah Musik';
      recentShelf.replaceChildren();
      const starterQueries = [
        { title: 'Top Hits Indonesia', artist: 'Lagu Terpopuler' },
        { title: 'Musik Akustik Santai', artist: 'Vibe Menenangkan' },
        { title: 'Lagu Viral TikTok', artist: 'Sedang Trending' },
        { title: 'Japanese City Pop', artist: 'Klasik & Nostalgia' }
      ];
      starterQueries.forEach((q) => {
        const card = document.createElement('div');
        card.className = 'tv-card tv-focusable';
        card.tabIndex = -1;
        card.innerHTML = `
          <div class="tv-card-art" style="display:flex;align-items:center;justify-content:center;background:#FF482C;color:#FFF;font-size:32px;font-weight:900;">♫</div>
          <h3 class="tv-card-title">${q.title}</h3>
          <span class="tv-card-desc">${q.artist}</span>
        `;
        // Clicking a starter card automatically searches and plays it!
        card.addEventListener('click', () => {
          searchAndPlay(q.title);
        });
        recentShelf.appendChild(card);
      });
    }

    syncSpotlightHero();
  }

  function hydrateLibraryContent() {
    const core = getCore();
    const grid = document.getElementById('tv-library-grid');
    if (!core || !grid) return;

    grid.replaceChildren();
    const items = [];

    if (Array.isArray(core.state.favorites) && core.state.favorites.length) {
      core.state.favorites.forEach((t, i) => items.push({ track: t, list: core.state.favorites, index: i }));
    }
    if (Array.isArray(core.state.playlists) && core.state.playlists.length) {
      core.state.playlists.forEach((pl) => {
        if (pl.tracks && pl.tracks.length) {
          items.push({ track: pl.tracks[0], list: pl.tracks, index: 0, overrideTitle: pl.name });
        }
      });
    }

    if (!items.length) {
      grid.innerHTML = '<div class="tv-empty-hint">Koleksi lagu disukai dan playlist Anda akan tampil di sini. Tambahkan lagu dari pencarian!</div>';
      return;
    }

    items.forEach((item) => {
      const card = createTVCard(item.track, item.list, item.index);
      if (item.overrideTitle) {
        card.querySelector('.tv-card-title').textContent = item.overrideTitle;
      }
      grid.appendChild(card);
    });
  }

  // =====================================================================
  // Bottom Player Bar & Now Playing Synchronization
  // =====================================================================
  function syncNowPlayingUI() {
    const core = getCore();
    if (!core || !core.state) return;

    const track = core.state.currentTrack;
    const isPlaying = core.audio && !core.audio.paused;

    document.documentElement.classList.toggle('playing', !!isPlaying);

    const barArt = document.getElementById('tv-bar-art');
    const barTitle = document.getElementById('tv-bar-title');
    const barArtist = document.getElementById('tv-bar-artist');
    const iconPlay = document.getElementById('tv-icon-play');
    const iconPause = document.getElementById('tv-icon-pause');

    if (iconPlay && iconPause) {
      iconPlay.classList.toggle('hidden', isPlaying);
      iconPause.classList.toggle('hidden', !isPlaying);
    }

    if (track) {
      const thumb = (core.thumb && core.thumb(track)) || track.thumbnail || 'assets/prics-pa-play.png';
      if (barArt) barArt.src = thumb;
      if (barTitle) barTitle.textContent = track.title || 'Unknown Track';
      if (barArtist) barArtist.textContent = track.artist || 'Unknown Artist';

      const tvkDisc = document.getElementById('tvk-disc-art');
      const tvkTitle = document.getElementById('tvk-title');
      const tvkArtist = document.getElementById('tvk-artist');
      if (tvkDisc) tvkDisc.src = thumb;
      if (tvkTitle) tvkTitle.textContent = track.title || 'Unknown Track';
      if (tvkArtist) tvkArtist.textContent = track.artist || 'Unknown Artist';
    }

    syncSpotlightHero();
  }

  function handleSmartPlay() {
    const core = getCore();
    if (!core) return;

    if (core.state && core.state.currentTrack) {
      if (core.togglePlay) core.togglePlay();
      syncNowPlayingUI();
      return;
    }

    if (core.state.history && core.state.history.length) {
      core.playTrack(core.state.history[0], core.state.history, 0);
      return;
    }
    if (core.state.favorites && core.state.favorites.length) {
      core.playTrack(core.state.favorites[0], core.state.favorites, 0);
      return;
    }
    if (core.state.playlists && core.state.playlists.length) {
      for (const pl of core.state.playlists) {
        if (pl.tracks && pl.tracks.length) {
          core.playTrack(pl.tracks[0], pl.tracks, 0);
          return;
        }
      }
    }

    // Automatically search and play top hits!
    searchAndPlay('Top Hits Indonesia');
  }

  function setupPlaybackControls() {
    const core = getCore();
    const btnPlay = document.getElementById('tv-btn-play');
    const btnPrev = document.getElementById('tv-btn-prev');
    const btnNext = document.getElementById('tv-btn-next');
    const btnKaraokeToggle = document.getElementById('tv-btn-karaoke-bar');

    const heroPlay = document.getElementById('tv-btn-hero-play');
    const heroLyrics = document.getElementById('tv-btn-hero-lyrics');

    if (btnPlay) {
      btnPlay.addEventListener('click', handleSmartPlay);
    }
    if (btnPrev) {
      btnPrev.addEventListener('click', () => {
        if (core && core.prev) core.prev();
      });
    }
    if (btnNext) {
      btnNext.addEventListener('click', () => {
        if (core && core.next) core.next();
      });
    }
    if (btnKaraokeToggle) {
      btnKaraokeToggle.addEventListener('click', openTVKaraoke);
    }
    if (heroPlay) {
      heroPlay.addEventListener('click', handleSmartPlay);
    }
    if (heroLyrics) {
      heroLyrics.addEventListener('click', openTVKaraoke);
    }

    const audio = core && core.audio;
    if (audio) {
      audio.addEventListener('play', syncNowPlayingUI);
      audio.addEventListener('pause', syncNowPlayingUI);
      audio.addEventListener('timeupdate', () => {
        if (isKaraokeOpen) updateTVActiveLyric();
      });
    }

    window.addEventListener('muriel:track', () => {
      syncNowPlayingUI();
      if (isKaraokeOpen) renderTVLyrics();
    });
    window.addEventListener('muriel:lyrics', () => {
      if (isKaraokeOpen) renderTVLyrics();
    });
    window.addEventListener('muriel:library', hydrateHomeContent);
  }

  // =====================================================================
  // Settings Cards Interaction
  // =====================================================================
  function setupSettingsCards() {
    const core = getCore();

    const set60 = document.getElementById('tv-set-fps-60');
    const set120 = document.getElementById('tv-set-fps-120');
    const prefHz = localStorage.getItem('prics_preferred_fps') || '120';

    const updateHzUI = (hz) => {
      if (set60) {
        set60.classList.toggle('active', hz === '60');
        const badge = set60.querySelector('.tv-setting-badge');
        if (hz === '60') {
          if (!badge) set60.querySelector('.tv-setting-card-title').insertAdjacentHTML('beforeend', ' <span class="tv-setting-badge">Aktif</span>');
        } else if (badge) badge.remove();
      }
      if (set120) {
        set120.classList.toggle('active', hz === '120');
        const badge = set120.querySelector('.tv-setting-badge');
        if (hz === '120') {
          if (!badge) set120.querySelector('.tv-setting-card-title').insertAdjacentHTML('beforeend', ' <span class="tv-setting-badge">Aktif</span>');
        } else if (badge) badge.remove();
      }
      const fpsEl = document.getElementById('tv-fps-indicator');
      if (fpsEl) fpsEl.textContent = hz === '60' ? '60Hz Hemat' : '120Hz Ultra';
    };
    updateHzUI(prefHz);

    if (set60) {
      set60.addEventListener('click', () => {
        localStorage.setItem('prics_preferred_fps', '60');
        updateHzUI('60');
        window.dispatchEvent(new CustomEvent('prics:fps-hz-changed', { detail: { hz: 60 } }));
        if (core && core.toast) core.toast('Kecepatan layar: 60 Hz (Hemat Daya)', 'info');
      });
    }
    if (set120) {
      set120.addEventListener('click', () => {
        localStorage.setItem('prics_preferred_fps', '120');
        updateHzUI('120');
        window.dispatchEvent(new CustomEvent('prics:fps-hz-changed', { detail: { hz: 120 } }));
        if (core && core.toast) core.toast('Kecepatan layar: 120 Hz (Ultra Halus)', 'info');
      });
    }

    const audioCards = document.querySelectorAll('[id^="tv-set-audio-"]');
    const curQuality = localStorage.getItem('prics_audio_quality') || 'normal';
    const updateAudioUI = (q) => {
      audioCards.forEach((c) => {
        const isActive = c.dataset.quality === q;
        c.classList.toggle('active', isActive);
        const badge = c.querySelector('.tv-setting-badge');
        if (isActive) {
          if (!badge) c.querySelector('.tv-setting-card-title').insertAdjacentHTML('beforeend', ' <span class="tv-setting-badge">Aktif</span>');
        } else if (badge) badge.remove();
      });
    };
    updateAudioUI(curQuality);

    audioCards.forEach((card) => {
      card.addEventListener('click', () => {
        const q = card.dataset.quality;
        if (!q) return;
        localStorage.setItem('prics_audio_quality', q);
        updateAudioUI(q);
        window.dispatchEvent(new CustomEvent('prics:audio-quality-changed', { detail: { quality: q } }));
        if (core && core.toast) core.toast(`Kualitas audio streaming: ${q.toUpperCase()}`, 'info');
      });
    });

    const themeLight = document.getElementById('tv-set-theme-light');
    const themeDark = document.getElementById('tv-set-theme-dark');
    const curTheme = localStorage.getItem('muriel_theme_mode') || 'light';

    const updateThemeUI = (m) => {
      if (themeLight) {
        themeLight.classList.toggle('active', m === 'light');
        const badge = themeLight.querySelector('.tv-setting-badge');
        if (m === 'light') {
          if (!badge) themeLight.querySelector('.tv-setting-card-title').insertAdjacentHTML('beforeend', ' <span class="tv-setting-badge">Aktif</span>');
        } else if (badge) badge.remove();
      }
      if (themeDark) {
        themeDark.classList.toggle('active', m === 'dark');
        const badge = themeDark.querySelector('.tv-setting-badge');
        if (m === 'dark') {
          if (!badge) themeDark.querySelector('.tv-setting-card-title').insertAdjacentHTML('beforeend', ' <span class="tv-setting-badge">Aktif</span>');
        } else if (badge) badge.remove();
      }
    };
    updateThemeUI(curTheme);

    const applyThemeMode = (m) => {
      localStorage.setItem('muriel_theme_mode', m);
      updateThemeUI(m);
      document.body.classList.toggle('theme-dark', m === 'dark');
      if (core && core.toast) core.toast(`Mode tema: ${m === 'dark' ? 'Malam' : 'Terang'}`, 'info');
    };

    if (themeLight) themeLight.addEventListener('click', () => applyThemeMode('light'));
    if (themeDark) themeDark.addEventListener('click', () => applyThemeMode('dark'));
  }

  // =====================================================================
  // Search Integration
  // =====================================================================
  function setupSearch() {
    const input = document.getElementById('tv-search-input');
    const resultsContainer = document.getElementById('tv-search-results');
    const pills = document.querySelectorAll('.tv-platform-pill');
    let currentPlatform = 'ytmusic';

    pills.forEach((p) => {
      p.addEventListener('click', () => {
        pills.forEach((x) => x.classList.remove('active'));
        p.classList.add('active');
        currentPlatform = p.dataset.platform || 'ytmusic';
        if (input && input.value.trim()) {
          input.dispatchEvent(new Event('input', { bubbles: true }));
        }
      });
    });

    if (!input || !resultsContainer) return;

    let debounceTimer = null;
    input.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      const query = input.value.trim();
      if (!query) {
        resultsContainer.innerHTML = '<div class="tv-empty-hint">Ketik judul lagu di atas untuk mencari musik...</div>';
        return;
      }

      debounceTimer = setTimeout(async () => {
        resultsContainer.innerHTML = '<div class="tv-empty-hint">Mencari lagu di YouTube Music...</div>';
        try {
          const core = getCore();
          const base = (core && typeof core.base === 'function') ? core.base() : 'http://127.0.0.1:3000';
          const res = await fetch(`${base}/api/search?q=${encodeURIComponent(query)}&platform=${currentPlatform}`);
          const data = await res.json();

          const tracks = Array.isArray(data) ? data : (data.tracks || data.results || []);
          if (!tracks || !tracks.length) {
            resultsContainer.innerHTML = `<div class="tv-empty-hint">Tidak ada hasil ditemukan untuk "${safeEscape(query)}".</div>`;
            return;
          }

          resultsContainer.replaceChildren();
          tracks.slice(0, 24).forEach((track, idx) => {
            resultsContainer.appendChild(createTVCard(track, tracks, idx));
          });
        } catch (_) {
          resultsContainer.innerHTML = '<div class="tv-empty-hint">Gagal memuat hasil pencarian. Periksa koneksi internet Smart TV Anda.</div>';
        }
      }, 400);
    });
  }

  // =====================================================================
  // SMART TV REMOTE ACTIONS (Called from native Java & DOM keydown)
  // =====================================================================
  function handleTVSelect() {
    const now = Date.now();
    if (now - lastSelectTime < 250) return; // Debounce rapid repeat
    lastSelectTime = now;

    const current = focusedEl || document.querySelector('.tv-focusable.tv-focused') || document.activeElement;
    if (current && typeof current.click === 'function') {
      current.classList.add('tv-pressed');
      setTimeout(() => current.classList.remove('tv-pressed'), 150);
      current.click();
    }
  }

  function handleTVBack() {
    const now = Date.now();
    if (now - lastBackPressTime < 300) return; // Debounce rapid repeat

    // 1. Close Karaoke overlay if open
    if (isKaraokeOpen) {
      lastBackPressTime = now;
      closeTVKaraoke();
      const heroLyrics = document.getElementById('tv-btn-hero-lyrics');
      if (heroLyrics) setFocus(heroLyrics);
      return;
    }

    // 2. Return to Home tab if inside Search, Library, or Settings
    if (currentView !== 'home') {
      lastBackPressTime = now;
      switchTVTab('home');
      const homeBtn = document.querySelector('.tv-rail-item[data-tv-tab="home"]');
      if (homeBtn) setFocus(homeBtn);
      return;
    }

    // 3. Return to Left Rail if focus is inside content
    const activeRail = document.querySelector('.tv-rail-item[data-tv-tab="home"]');
    if (focusedEl !== activeRail) {
      lastBackPressTime = now;
      if (activeRail) setFocus(activeRail);
      return;
    }

    // 4. Intentional double press back to exit (requires 400ms to 2500ms between presses)
    if (now - lastBackPressTime >= 400 && now - lastBackPressTime <= 2500) {
      if (window.PricsAndroidDevice && typeof window.PricsAndroidDevice.exitApp === 'function') {
        window.PricsAndroidDevice.exitApp();
        return;
      }
    } else {
      lastBackPressTime = now;
      const core = getCore();
      if (core && core.toast) {
        core.toast('Tekan [Kembali] sekali lagi untuk keluar', 'info');
      }
    }
  }

  // Directional spatial navigation dispatcher
  function handleTVNav(dir) {
    const now = Date.now();
    if (now - lastNavTime < NAV_THROTTLE_MS) return;
    lastNavTime = now;

    const isUp = dir === 'up';
    const isDown = dir === 'down';
    const isLeft = dir === 'left';
    const isRight = dir === 'right';

    let current = focusedEl || document.querySelector('.tv-focusable.tv-focused');
    if (!current || !current.classList || !current.classList.contains('tv-focusable')) {
      const homeRail = document.querySelector('.tv-rail-item.active') || document.querySelector('.tv-rail-item');
      if (homeRail) setFocus(homeRail);
      return;
    }

    // Rule A: Currently on Left Rail
    if (current.classList.contains('tv-rail-item')) {
      const railItems = Array.from(document.querySelectorAll('.tv-rail-item'));
      const idx = railItems.indexOf(current);

      if (isDown) {
        if (idx < railItems.length - 1) {
          const nextItem = railItems[idx + 1];
          switchTVTab(nextItem.dataset.tvTab);
          setFocus(nextItem);
        }
      } else if (isUp) {
        if (idx > 0) {
          const prevItem = railItems[idx - 1];
          switchTVTab(prevItem.dataset.tvTab);
          setFocus(prevItem);
        }
      } else if (isRight) {
        const activeView = document.getElementById(`tv-view-${currentView}`);
        if (activeView) {
          let target = null;
          if (currentView === 'home') {
            target = document.getElementById('tv-btn-hero-play') || activeView.querySelector('.tv-card');
          } else if (currentView === 'search') {
            target = document.getElementById('tv-search-input-box') || document.getElementById('tv-search-input');
          } else if (currentView === 'library') {
            target = activeView.querySelector('.tv-card');
          } else if (currentView === 'settings') {
            target = document.getElementById('tv-set-fps-60');
          }
          if (!target) target = activeView.querySelector('.tv-focusable');
          if (target) setFocus(target);
        }
      }
      return;
    }

    // Rule B: Inside a Horizontal Shelf (Home Carousels)
    const currentShelf = current.closest('.tv-shelf-scroll');
    if (currentShelf) {
      const cards = Array.from(currentShelf.querySelectorAll('.tv-card'));
      const idx = cards.indexOf(current);

      if (isRight) {
        if (idx < cards.length - 1) {
          setFocus(cards[idx + 1]);
        }
      } else if (isLeft) {
        if (idx > 0) {
          setFocus(cards[idx - 1]);
        } else {
          const railItem = document.querySelector('.tv-rail-item.active') || document.querySelector('.tv-rail-item');
          if (railItem) setFocus(railItem);
        }
      } else if (isDown) {
        const allShelves = Array.from(document.querySelectorAll('#tv-view-home .tv-shelf:not(.hidden) .tv-shelf-scroll'));
        const sIdx = allShelves.indexOf(currentShelf);
        if (sIdx < allShelves.length - 1) {
          const nextShelf = allShelves[sIdx + 1];
          const nextCards = nextShelf.querySelectorAll('.tv-card');
          const target = nextCards[Math.min(idx, nextCards.length - 1)] || nextCards[0];
          if (target) setFocus(target);
        } else {
          const playBtn = document.getElementById('tv-btn-play');
          if (playBtn) setFocus(playBtn);
        }
      } else if (isUp) {
        const allShelves = Array.from(document.querySelectorAll('#tv-view-home .tv-shelf:not(.hidden) .tv-shelf-scroll'));
        const sIdx = allShelves.indexOf(currentShelf);
        if (sIdx > 0) {
          const prevShelf = allShelves[sIdx - 1];
          const prevCards = prevShelf.querySelectorAll('.tv-card');
          const target = prevCards[Math.min(idx, prevCards.length - 1)] || prevCards[0];
          if (target) setFocus(target);
        } else {
          const heroBtn = document.getElementById('tv-btn-hero-play');
          if (heroBtn) setFocus(heroBtn);
        }
      }
      return;
    }

    // Rule C: Inside Spotlight Hero
    if (current.id === 'tv-btn-hero-play' || current.id === 'tv-btn-hero-lyrics') {
      if (isLeft) {
        if (current.id === 'tv-btn-hero-lyrics') {
          setFocus(document.getElementById('tv-btn-hero-play'));
        } else {
          const railItem = document.querySelector('.tv-rail-item.active');
          if (railItem) setFocus(railItem);
        }
      } else if (isRight && current.id === 'tv-btn-hero-play') {
        setFocus(document.getElementById('tv-btn-hero-lyrics'));
      } else if (isDown) {
        const firstShelf = document.querySelector('#tv-view-home .tv-shelf:not(.hidden) .tv-shelf-scroll');
        if (firstShelf) {
          const firstCard = firstShelf.querySelector('.tv-card');
          if (firstCard) setFocus(firstCard);
          else {
            const playBtn = document.getElementById('tv-btn-play');
            if (playBtn) setFocus(playBtn);
          }
        }
      }
      return;
    }

    // Rule D: Inside Bottom Player Bar
    if (current.closest('.tv-player-bar')) {
      const barBtns = Array.from(document.querySelectorAll('.tv-player-bar .tv-control-btn'));
      const idx = barBtns.indexOf(current);
      if (isRight && idx < barBtns.length - 1) {
        setFocus(barBtns[idx + 1]);
      } else if (isLeft) {
        if (idx > 0) setFocus(barBtns[idx - 1]);
        else {
          const railItem = document.querySelector('.tv-rail-item.active');
          if (railItem) setFocus(railItem);
        }
      } else if (isUp) {
        if (currentView === 'home') {
          const activeCards = document.querySelectorAll('#tv-view-home .tv-shelf:not(.hidden) .tv-card');
          if (activeCards.length) setFocus(activeCards[0]);
          else {
            const heroBtn = document.getElementById('tv-btn-hero-play');
            if (heroBtn) setFocus(heroBtn);
          }
        } else {
          const inView = document.querySelectorAll(`#tv-view-${currentView} .tv-focusable`);
          if (inView.length) setFocus(inView[0]);
          else {
            const railItem = document.querySelector('.tv-rail-item.active');
            if (railItem) setFocus(railItem);
          }
        }
      }
      return;
    }

    // Rule E: Settings View Navigation
    if (currentView === 'settings') {
      const settingsCards = Array.from(document.querySelectorAll('#tv-view-settings .tv-focusable'));
      const idx = settingsCards.indexOf(current);
      if (idx !== -1) {
        if (isLeft) {
          if (current.id === 'tv-set-fps-60' || current.id === 'tv-set-audio-low' || current.id === 'tv-set-theme-light') {
            const railItem = document.querySelector('.tv-rail-item.active');
            if (railItem) setFocus(railItem);
          } else if (idx > 0) {
            setFocus(settingsCards[idx - 1]);
          }
        } else if (isRight) {
          if (idx < settingsCards.length - 1) setFocus(settingsCards[idx + 1]);
        } else if (isDown) {
          if (current.id === 'tv-set-fps-60' || current.id === 'tv-set-fps-120') {
            setFocus(document.getElementById('tv-set-audio-normal') || document.getElementById('tv-set-audio-low'));
          } else if (current.id.startsWith('tv-set-audio-')) {
            setFocus(document.getElementById('tv-set-theme-light'));
          } else {
            const playBtn = document.getElementById('tv-btn-play');
            if (playBtn) setFocus(playBtn);
          }
        } else if (isUp) {
          if (current.id.startsWith('tv-set-theme-')) {
            setFocus(document.getElementById('tv-set-audio-normal') || document.getElementById('tv-set-audio-low'));
          } else if (current.id.startsWith('tv-set-audio-')) {
            setFocus(document.getElementById('tv-set-fps-120') || document.getElementById('tv-set-fps-60'));
          } else {
            const railItem = document.querySelector('.tv-rail-item.active');
            if (railItem) setFocus(railItem);
          }
        }
      }
      return;
    }

    // Rule F: Search View Navigation (Header vs Platform Pills vs Results)
    if (currentView === 'search') {
      const isHeader = current.id === 'tv-search-input-box' || current.id === 'tv-search-input';
      const isPill = current.classList.contains('tv-platform-pill');
      const isCard = current.classList.contains('tv-card');

      if (isHeader) {
        if (isLeft) {
          const railItem = document.querySelector('.tv-rail-item.active');
          if (railItem) setFocus(railItem);
        } else if (isDown) {
          const firstPill = document.querySelector('.tv-platform-pill');
          if (firstPill) setFocus(firstPill);
        }
        return;
      }

      if (isPill) {
        const pills = Array.from(document.querySelectorAll('.tv-platform-pill'));
        const pIdx = pills.indexOf(current);
        if (isLeft) {
          if (pIdx > 0) setFocus(pills[pIdx - 1]);
          else {
            const railItem = document.querySelector('.tv-rail-item.active');
            if (railItem) setFocus(railItem);
          }
        } else if (isRight && pIdx < pills.length - 1) {
          setFocus(pills[pIdx + 1]);
        } else if (isUp) {
          const inputWrap = document.getElementById('tv-search-input-box');
          if (inputWrap) setFocus(inputWrap);
        } else if (isDown) {
          const firstCard = document.querySelector('#tv-search-results .tv-card');
          if (firstCard) setFocus(firstCard);
        }
        return;
      }

      if (isCard) {
        const cards = Array.from(document.querySelectorAll('#tv-search-results .tv-card'));
        const cIdx = cards.indexOf(current);
        const cols = 4;
        if (isLeft) {
          if (cIdx % cols === 0 || cIdx === 0) {
            const railItem = document.querySelector('.tv-rail-item.active');
            if (railItem) setFocus(railItem);
          } else if (cIdx > 0) {
            setFocus(cards[cIdx - 1]);
          }
        } else if (isRight && cIdx < cards.length - 1) {
          setFocus(cards[cIdx + 1]);
        } else if (isDown) {
          if (cIdx + cols < cards.length) setFocus(cards[cIdx + cols]);
          else {
            const playBtn = document.getElementById('tv-btn-play');
            if (playBtn) setFocus(playBtn);
          }
        } else if (isUp) {
          if (cIdx - cols >= 0) setFocus(cards[cIdx - cols]);
          else {
            const activePill = document.querySelector('.tv-platform-pill.active') || document.querySelector('.tv-platform-pill');
            if (activePill) setFocus(activePill);
          }
        }
        return;
      }
    }

    // Rule G: Library / Collection Grid Navigation
    if (currentView === 'library') {
      const cards = Array.from(document.querySelectorAll('#tv-library-grid .tv-focusable'));
      const idx = cards.indexOf(current);
      if (idx !== -1) {
        const cols = 4;
        if (isLeft) {
          if (idx % cols === 0 || idx === 0) {
            const railItem = document.querySelector('.tv-rail-item.active');
            if (railItem) setFocus(railItem);
          } else if (idx > 0) {
            setFocus(cards[idx - 1]);
          }
        } else if (isRight && idx < cards.length - 1) {
          setFocus(cards[idx + 1]);
        } else if (isDown) {
          if (idx + cols < cards.length) setFocus(cards[idx + cols]);
          else {
            const playBtn = document.getElementById('tv-btn-play');
            if (playBtn) setFocus(playBtn);
          }
        } else if (isUp) {
          if (idx - cols >= 0) setFocus(cards[idx - cols]);
          else {
            const railItem = document.querySelector('.tv-rail-item.active');
            if (railItem) setFocus(railItem);
          }
        }
      }
    }
  }

  // Expose global bridge for MainActivity.java
  window.PricsTV = {
    handleBack: handleTVBack,
    handleSelect: handleTVSelect,
    handleNav: handleTVNav,
    handleMediaPlayPause: () => {
      const core = getCore();
      if (core && core.togglePlay) core.togglePlay();
      syncNowPlayingUI();
    },
    handleMediaNext: () => {
      const core = getCore();
      if (core && core.next) core.next();
    },
    handleMediaPrev: () => {
      const core = getCore();
      if (core && core.prev) core.prev();
    }
  };

  // =====================================================================
  // D-PAD REMOTE SPATIAL NAVIGATION ENGINE
  // =====================================================================
  function initRemoteNavigation() {
    window.addEventListener('keydown', (e) => {
      const code = e.keyCode || e.which;
      const key = e.key;

      const isUp = key === 'ArrowUp' || code === 38 || code === 19;
      const isDown = key === 'ArrowDown' || code === 40 || code === 20;
      const isLeft = key === 'ArrowLeft' || code === 37 || code === 21;
      const isRight = key === 'ArrowRight' || code === 39 || code === 22;
      const isEnter = key === 'Enter' || code === 13 || code === 23 || code === 66 || key === 'Select' || key === 'NumpadEnter';
      const isBack = key === 'Escape' || code === 27 || code === 4 || key === 'Back' || key === 'GoBack';
      const isMediaPlayPause = key === 'MediaPlayPause' || code === 179 || code === 85 || code === 126 || code === 127;
      const isMediaNext = key === 'MediaTrackNext' || code === 176 || code === 87;
      const isMediaPrev = key === 'MediaTrackPrevious' || code === 177 || code === 88;

      const isTVNavKey = isUp || isDown || isLeft || isRight || isEnter || isBack || isMediaPlayPause || isMediaNext || isMediaPrev;
      if (!isTVNavKey) return;

      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();

      if (isBack) {
        handleTVBack();
        return;
      }
      if (isMediaPlayPause) {
        window.PricsTV.handleMediaPlayPause();
        return;
      }
      if (isMediaNext) {
        window.PricsTV.handleMediaNext();
        return;
      }
      if (isMediaPrev) {
        window.PricsTV.handleMediaPrev();
        return;
      }
      if (isEnter) {
        handleTVSelect();
        return;
      }

      const dir = isUp ? 'up' : isDown ? 'down' : isLeft ? 'left' : 'right';
      handleTVNav(dir);
    }, true);
  }

  // =====================================================================
  // Initialization Lifecycle
  // =====================================================================
  function boot() {
    createTVLayout();
    initRemoteNavigation();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  window.addEventListener('load', () => {
    hydrateHomeContent();
    syncNowPlayingUI();
  });

})();
