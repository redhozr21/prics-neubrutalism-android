// Builds the Capacitor mobile web bundle into www/: Prics Play frontend + server.js running in-app.
import { build } from 'esbuild';
import { cpSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildInfoScript } from '../tools/build-info.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const out = join(root, 'www');
const shim = (n) => join(root, 'mobile', 'shims', `${n}.js`);

rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });

// server.js requires './platform', './tools', './logger' and './audio-output'; on phones those resolve to the shims.
const swapLocal = {
  name: 'muriel-mobile-swaps',
  setup(b) {
    b.onResolve({ filter: /^\.\/(platform|tools|logger|audio-output)$/ }, (a) => (a.importer.endsWith('server.js') ? { path: shim(a.path.slice(2)) } : undefined));
  },
};

await build({
  entryPoints: [join(root, 'mobile', 'bridge.js')],
  outfile: join(out, 'mobile-bridge.js'),
  bundle: true,
  format: 'iife',
  platform: 'browser',
  target: ['safari16'],
  minify: true,
  sourcemap: 'linked',
  legalComments: 'none',
  alias: {
    fs: shim('fs'), http: shim('http'), https: shim('https'), child_process: shim('child_process'),
    os: shim('os'), url: shim('url'), string_decoder: shim('string_decoder'), crypto: shim('crypto'),
    electron: shim('electron'), dns: shim('dns'), net: shim('net'), path: 'path-browserify', events: 'events', buffer: 'buffer',
  },
  inject: [join(root, 'mobile', 'globals.js')],
  define: { 'process.env.NODE_ENV': '"production"', 'require.main': 'undefined' },
  plugins: [swapLocal],
  logLevel: 'warning',
});

for (const f of ['app.js', 'styles.css', 'audio-engine.js', 'm3shapes.js', 'lyrics-rtl.js', 'track-sort.js', 'search-text.js', 'track-match.js', 'library-tools.js', 'library-pages.js', 'update-notifier.js', 'lyrics-match.js', 'encore.js', 'sync-core.js', 'sync.js', 'share-link.js', 'profiles-core.js', 'profiles.js', 'lastfm-core.js', 'lastfm.js', 'backup-core.js', 'backup.js', 'i18n.js', 'lyrics-sources.js', 'track-trim.js', 'track-audio.js']) cpSync(join(root, f), join(out, f));
// iOS or Android is read at runtime; CI fills in the commit and run number
writeFileSync(join(out, 'build-info.js'), buildInfoScript(''));
cpSync(join(root, 'assets'), join(out, 'assets'), { recursive: true });
cpSync(join(root, 'mobile', 'mobile.css'), join(out, 'mobile.css'));
cpSync(join(root, 'mobile', 'mobile-ui.js'), join(out, 'mobile-ui.js'));
cpSync(join(root, 'mobile', 'neubrutalism.js'), join(out, 'neubrutalism.js'));

// Mobile-only first-paint preparation. These changes happen while generating www/index.html,
// before WebView can render the page; the old desktop hero/nav never flash on cold start.
function replaceDivById(source, id, replacement) {
  const opening = new RegExp(`<div\\b(?=[^>]*\\bid=["']${id}["'])[^>]*>`, 'i').exec(source);
  if (!opening) return source;
  const token = /<\/?div\b[^>]*>/gi;
  token.lastIndex = opening.index;
  let depth = 0;
  let end = -1;
  let match;
  while ((match = token.exec(source))) {
    if (/^<div\b/i.test(match[0])) depth++;
    else depth--;
    if (depth === 0) { end = token.lastIndex; break; }
  }
  if (end < 0) throw new Error(`Could not find closing div for #${id}`);
  return source.slice(0, opening.index) + replacement + source.slice(end);
}

const staticBottomNav = `
      <nav class="neo-bottom-nav" aria-label="Navigasi utama">
        <button type="button" class="neo-tab active" data-tab="home" aria-label="Home" aria-current="page" aria-pressed="true">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/></svg><span>Home</span>
        </button>
        <button type="button" class="neo-tab" data-tab="search" aria-label="Search" aria-pressed="false">
          <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 5 5"/></svg><span>Search</span>
        </button>
        <button type="button" class="neo-tab" data-tab="library" aria-label="Collection" aria-pressed="false">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4v16M9 4v16M14 4v16M19 4v16"/></svg><span>Collection</span>
        </button>
      </nav>`;

// profiles-core.js stays the first script: everything after it (mobile-bridge.js too) sees the open profile's storage.
let html = readFileSync(join(root, 'index.html'), 'utf8');
html = html
  .replace('<html lang="en">', '<html lang="en" class="is-mobile neo-theme">')
  .replace('<meta name="viewport"', '<meta name="viewport-desktop"')
  .replace('<head>', '<head>\n  <script src="profiles-core.js"></script>\n  <script id="prics-visual-theme-bootstrap">(()=>{try{const t=localStorage.getItem("prics_play_visual_theme")=="liquid-glass"?"liquid-glass":"neubrutalism";const r=document.documentElement;r.classList.toggle("neo-theme",t==="neubrutalism");r.classList.toggle("liquid-glass-theme",t==="liquid-glass");}catch(e){}})();</script>\n  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover">')
  .replace('<link rel="stylesheet" href="styles.css">', '<link rel="stylesheet" href="styles.css">\n  <link rel="stylesheet" href="mobile.css">')
  .replace('<body class="no-nav-transition">', '<body class="no-nav-transition home-spotify">\n  <script id="prics-mobile-first-paint">\n  (() => {\n    const root = document.documentElement;\n    const body = document.body;\n    try {\n      if (/Android/i.test(navigator.userAgent || "")) root.classList.add("is-android");\n      const visualTheme = localStorage.getItem("prics_play_visual_theme") === "liquid-glass" ? "liquid-glass" : "neubrutalism";\n      root.classList.toggle("neo-theme", visualTheme === "neubrutalism");\n      root.classList.toggle("liquid-glass-theme", visualTheme === "liquid-glass");\n      const mode = localStorage.getItem("muriel_theme_mode") || "light";\n      const dark = mode === "dark" || (mode === "system" && matchMedia("(prefers-color-scheme: dark)").matches);\n      body.classList.toggle("theme-dark", dark);\n      const defaults = dark ? {accent:"#FF482C", background:"#171717", surface:"#242424", ink:"#FFF8EF", secondary:"#FFE568", tertiary:"#C9B4FF"} : {accent:"#FF482C", background:"#FFF8EF", surface:"#FFFFFF", ink:"#0F0F0F", secondary:"#FFE568", tertiary:"#C9B4FF"};\n      const keys = {accent:"muriel_theme_accent", background:"muriel_neo_background", surface:"muriel_neo_surface", ink:"muriel_neo_ink", secondary:"muriel_neo_secondary", tertiary:"muriel_neo_tertiary"};\n      for (const [key, fallback] of Object.entries(defaults)) {\n        const stored = localStorage.getItem(keys[key]);\n        root.style.setProperty(`--neo-${key}`, stored && /^#[0-9a-f]{6}$/i.test(stored) ? stored : fallback);\n      }\n      root.style.setProperty("--neo-paper", root.style.getPropertyValue("--neo-background") || defaults.background);\n      root.style.setProperty("--neo-border-width", "2px");\n      root.style.setProperty("--neo-shadow-size", "4px");\n    } catch (_) {}\n  })();\n  </script>')
  .replace('<button class="platform-btn active" data-platform="youtube" id="platform-yt"', '<button class="platform-btn" data-platform="youtube" id="platform-yt"')
  .replace('<button class="platform-btn" data-platform="ytmusic" id="platform-ytm"', '<button class="platform-btn active" data-platform="ytmusic" id="platform-ytm"')
  .replace('<aside class="sidebar" id="sidebar">', '<aside class="sidebar neo-sidebar" id="sidebar">')
  .replace('<nav class="sidebar-nav">', '<nav class="sidebar-nav" hidden aria-hidden="true">')
  .replace('<div class="rail-action-group">', '<div class="rail-action-group" hidden aria-hidden="true">')
  .replace('<div class="rail-divider"></div>', '<div class="rail-divider" hidden aria-hidden="true"></div>')
  .replace('    </aside>\n\n    <main class="main-content"', `${staticBottomNav}\n    </aside>\n\n    <main class="main-content"`)
  .replace('  <script src="profiles-core.js"></script>\n  <script src="i18n.js"></script>', '  <script src="i18n.js"></script>')
  .replace('<script src="audio-engine.js"></script>', '<script src="mobile-bridge.js"></script>\n  <script src="audio-engine.js"></script>')
  .replace('<script src="app.js"></script>', '<script src="app.js"></script>\n  <script src="mobile-ui.js"></script>\n  <script src="neubrutalism.js"></script>');

// The desktop carousel is obsolete on mobile. Strip its DOM at build time rather than hiding it
// after startup; keep an empty placeholder ID because app.js safely probes it during initialization.
html = replaceDivById(html, 'home-hero', '<div class="home-hero" id="home-hero" hidden aria-hidden="true"></div>');

// Defer all external body scripts in their original order. The static shell and CSS can paint first;
// profiles-core.js remains synchronous in <head> so profile-scoped storage is ready for the bootstrap.
const headEnd = html.indexOf('</head>');
if (headEnd < 0) throw new Error('Could not find </head> while preparing mobile first paint');
const splitAt = headEnd + '</head>'.length;
const headHtml = html.slice(0, splitAt);
const bodyHtml = html.slice(splitAt).replace(/<script(?![^>]*\bdefer\b)([^>]*\bsrc=["'][^"']+["'][^>]*)><\/script>/gi, '<script defer$1></script>');
html = headHtml + bodyHtml;
writeFileSync(join(out, 'index.html'), html);
console.log('www/ ready');
