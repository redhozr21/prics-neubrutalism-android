# Prics Play — startup render and mini-player swipe fixes

## Changes

- The mobile build now emits `is-mobile` and `neo-theme` on the root HTML element before first paint.
- `profiles-core.js` loads in the document head so the first-paint theme bootstrap reads the active profile's preferences.
- The first-paint bootstrap applies the stored Neo-Brutalism palette before the rest of the body is parsed/rendered.
- The mobile build removes the old `home-hero` carousel markup (including the legacy “My Wave / Play wave” UI) at build time and keeps only an empty hidden compatibility placeholder.
- The four-tab Home / Search / Library / Settings navigation is emitted in HTML. The old six-item navigation is kept hidden for compatibility with existing app.js routing handlers.
- The mobile build marks YouTube Music (middle play-circle mode) active in markup. A one-time mobile migration selects `ytmusic` for existing installs that have not received this default yet; later user selections are preserved.
- The mini player supports horizontal touch gestures: swipe right skips to the next track, swipe left goes to the previous track. A 50 px threshold, direction lock, touch-action `pan-y`, swipe animation, and synthetic-click suppression preserve vertical scrolling and tap-to-open behavior.

## Checks

- `node --check` passed for `mobile/build.mjs`, `mobile/mobile-ui.js`, `mobile/neubrutalism.js`, and `mobile/bridge.js`.
- Targeted tests passed: `node --test test/mobile-neubrutalism.test.js test/prics-library-ui.test.js` (14 tests).
- A generated-HTML transformation check confirmed that the old hero markup is removed, the original six-item nav is hidden, the four-tab nav is present, the YouTube Music mode is active, and `profiles-core.js` appears only once in the head.
- An APK has not been built or tested on a physical device as part of this source patch. Use GitHub Actions to build the APK, then verify swipe behavior on the target phone.
