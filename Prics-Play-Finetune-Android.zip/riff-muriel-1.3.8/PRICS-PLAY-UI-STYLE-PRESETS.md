# Prics Play UI Style Presets

This revision adds three selectable mobile UI styles under Settings → Theme:

- `neubrutalism` (default): bold outlines and hard offset shadows.
- `liquid-glass`: translucent large surfaces with blur limited to app chrome and major panels; individual track rows are not blurred.
- `spotify-standard`: dark surfaces with a default green accent.

The selection is stored under `prics_ui_style`. Liquid Glass and Spotify Standard accents are stored independently under `prics_ui_accent_liquid-glass` and `prics_ui_accent_spotify-standard`. The mobile build bootstrap reads `prics_ui_style` before first paint to avoid a theme flash.

## Build

Use the repository's existing GitHub Actions workflow. Upload this source archive using the ZIP filename already expected by that workflow, commit, and download the resulting APK artifact after Actions succeeds.

## Validation performed

- JavaScript syntax checks for the changed mobile files and build script.
- 21 focused Node tests covering UI style selection, persistence, first-paint bootstrap, CSS style hooks, existing mobile navigation, startup controls, and Library behavior.
- The APK was not compiled or tested on a physical Android device in this environment.
