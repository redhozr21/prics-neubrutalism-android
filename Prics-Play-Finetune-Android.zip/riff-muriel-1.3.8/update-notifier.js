// Prics Play updater: check the latest published GitHub Release and prefer its APK asset.
// The APK must be attached to a non-draft, non-prerelease release in the Prics Play repository.
(() => {
  const REPO = 'redhozr21/prics-neubrutalism-android';
  const RELEASES_API = `https://api.github.com/repos/${REPO}/releases/latest`;
  const store = {
    get(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (_) { return null; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} },
  };
  const build = window.MURIEL_BUILD || {};
  const statusEl = document.getElementById('update-status');
  const checkBtn = document.getElementById('btn-check-updates');
  let current = null;
  let checking = false;
  let pendingManualOpen = false;

  const setStatus = (message, hasRelease = false) => {
    if (statusEl) {
      statusEl.textContent = message;
      statusEl.classList.toggle('has-update', !!hasRelease);
    }
    if (checkBtn) checkBtn.textContent = hasRelease ? (current && current.apk ? 'Download APK' : 'Open release') : 'Check now';
  };

  async function latestRelease() {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12000);
    try {
      const response = await fetch(RELEASES_API, {
        headers: { Accept: 'application/vnd.github+json' },
        cache: 'no-store',
        signal: controller.signal,
      });
      if (!response.ok) return null;
      const release = await response.json();
      if (!release || release.draft || release.prerelease || !release.html_url) return null;
      return release;
    } catch (_) {
      return null;
    } finally {
      clearTimeout(timer);
    }
  }

  function describe(release) {
    const assets = Array.isArray(release.assets) ? release.assets : [];
    const apk = assets
      .filter((asset) => asset && typeof asset.name === 'string' && /\.apk$/i.test(asset.name) && asset.browser_download_url)
      .sort((a, b) => {
        const score = (name) => (/prics[-_ ]?play/i.test(name) ? 3 : /app-release/i.test(name) ? 2 : /app-debug/i.test(name) ? 1 : 0);
        return score(b.name) - score(a.name);
      })[0] || null;
    const body = String(release.body || '');
    const versionMatch = body.match(/prics-play-version:\s*([0-9][\w.-]*)/i);
    const buildMatch = body.match(/prics-play-build:\s*(\d+)/i);
    const baseVersion = String((versionMatch && versionMatch[1]) || release.tag_name || release.name || 'latest').trim();
    const version = `${baseVersion}${buildMatch ? ` · Build ${buildMatch[1]}` : ''}`;
    return {
      version,
      name: release.name || version,
      htmlUrl: release.html_url,
      url: apk ? apk.browser_download_url : release.html_url,
      apk: !!apk,
      assetName: apk ? apk.name : '',
      publishedAt: release.published_at || release.created_at || '',
    };
  }

  function openExternal(url) {
    if (!url) return;
    // Capacitor's Android shell hands external navigation to the system browser.
    if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) {
      window.location.href = url;
    } else {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  }

  async function check(manual = false) {
    if (checking) { if (manual) pendingManualOpen = true; return; }
    checking = true;
    if (manual) setStatus('Checking GitHub Releases…');
    try {
      const release = await latestRelease();
      if (!release) {
        current = null;
        setStatus('No published release found, or GitHub could not be reached.');
        if (manual) store.set('prics_play_update_last_error', Date.now());
        return;
      }
      current = describe(release);
      store.set('prics_play_latest_release', { version: current.version, url: current.url, apk: current.apk, checkedAt: Date.now() });
      if (current.apk) {
        setStatus(`Prics Play ${current.version} · APK ready to download`, true);
      } else {
        setStatus(`Prics Play ${current.version} is published, but no APK is attached yet.`, true);
      }
      if (manual || pendingManualOpen) openExternal(current.url);
    } finally {
      checking = false;
      pendingManualOpen = false;
    }
  }

  if (statusEl) {
    const version = build.version || '1.3.8';
    const run = build.run ? ` · Build ${build.run}` : '';
    const sha = build.sha && build.sha !== 'dev' ? ` · ${String(build.sha).slice(0, 7)}` : '';
    statusEl.textContent = `Prics Play ${version}${run}${sha}`;
  }
  if (checkBtn) checkBtn.addEventListener('click', () => check(true));

  // Refresh status when the app opens; this never launches a download automatically.
  setTimeout(() => check(false), 2500);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) check(false); });
  window.PricsPlayUpdates = { check: () => check(true), latestRelease };
})();
