const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');

test('mobile app defers body scripts and yields before expensive startup work', () => {
  const build = read('mobile/build.mjs');
  const app = read('app.js');
  const bridge = read('mobile/bridge.js');
  assert.match(build, /<script defer\$1><\/script>/);
  assert.match(build, /root\.classList\.add\(\"is-android\"\)/);
  assert.match(app, /await yieldStartupFrame\(\);[\s\S]*?await yieldStartupFrame\(\);/);
  assert.match(app, /deferNonCritical\(finishMobileStartupWork, 1200\)/);
  assert.match(bridge, /requestAnimationFrame\(\(\) => requestAnimationFrame/);
});

test('mini player has solid background, previous/play/next controls, and no mobile loading spinner', () => {
  const css = read('mobile/mobile.css');
  const html = read('index.html');
  const ui = read('mobile/mobile-ui.js');
  assert.match(css, /background: var\(--neo-surface\) !important;[\s\S]*?background-image: none !important/);
  assert.match(css, /html\.is-mobile #track-loading-overlay,[\s\S]*?html\.is-mobile #playbar-spinner[\s\S]*?display: none !important/);
  assert.doesNotMatch(ui, /playbar\.addEventListener\('touch(start|move|end)'/);
  for (const id of ['btn-prev', 'btn-play-pause', 'btn-next']) assert.ok(html.includes(`id=\"${id}\"`));
});
