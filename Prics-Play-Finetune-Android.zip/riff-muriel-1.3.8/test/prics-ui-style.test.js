'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');

test('Theme settings offer all three UI style presets', () => {
  const html = read('index.html');
  for (const style of ['neubrutalism', 'liquid-glass', 'spotify-standard']) {
    assert.match(html, new RegExp(`data-ui-style-choice="${style}"`));
  }
  assert.match(html, /UI Style \/ Theme Mode/);
});

test('UI style selection persists and updates the root attribute immediately', () => {
  const skin = read('mobile/neubrutalism.js');
  assert.match(skin, /localStorage\.setItem\(UI_STYLE_KEY, style\)/);
  assert.match(skin, /root\.setAttribute\('data-ui-style', style\)/);
  assert.match(skin, /root\.classList\.toggle\('neo-theme', style === 'neubrutalism'\)/);
  assert.match(skin, /button\.addEventListener\('click', \(\) => applyUiStyle\(button\.dataset\.uiStyleChoice\)\)/);
});

test('mobile first paint reads the saved UI style before the app renders', () => {
  const build = read('mobile/build.mjs');
  const bridge = read('mobile/bridge.js');
  assert.match(build, /localStorage\.getItem\("prics_ui_style"\)/);
  assert.match(build, /root\.setAttribute\("data-ui-style", uiStyle\)/);
  assert.match(bridge, /localStorage\.getItem\('prics_ui_style'\)/);
});

test('Liquid Glass and Spotify styles have separate performance-conscious CSS', () => {
  const css = read('mobile/mobile.css');
  assert.match(css, /data-ui-style="liquid-glass"/);
  assert.match(css, /backdrop-filter: blur\(16px\) saturate\(145%\)/);
  assert.match(css, /data-ui-style="spotify-standard"/);
  assert.match(css, /#1DB954/);
  assert.match(css, /html\.is-mobile\[data-ui-style="liquid-glass"\] :is\(\.neo-library-hub,\.playlist-meta,\.setting-item,\.m3-group\) \{ -webkit-backdrop-filter: none !important; backdrop-filter: none !important; \}/);
});

test('custom accent is stored per UI style for Liquid Glass and Spotify', () => {
  const skin = read('mobile/neubrutalism.js');
  assert.match(skin, /prics_ui_accent_/);
  assert.match(skin, /setStyleAccent\(style, button\.dataset\.color\)/);
  assert.match(skin, /getStyleAccent\(style, '#1DB954'\)/);
});
