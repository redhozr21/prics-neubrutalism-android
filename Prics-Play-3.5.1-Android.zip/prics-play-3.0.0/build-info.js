window.MURIEL_BUILD = {"sha":"dev","version":"3.5.1","run":0,"repo":"redhozr21/prics-neubrutalism-android","builtAt":"2026-11-02T15:00:00.000Z","channel":""};
