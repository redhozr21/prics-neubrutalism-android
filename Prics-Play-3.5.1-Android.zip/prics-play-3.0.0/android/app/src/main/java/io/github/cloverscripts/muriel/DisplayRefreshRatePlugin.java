package io.github.cloverscripts.muriel;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Manages display refresh rate (60Hz, 90Hz, 120Hz) on Android to balance
 * buttery smooth animations or maximum battery savings.
 */
@CapacitorPlugin(name = "DisplayRefreshRate")
public class DisplayRefreshRatePlugin extends Plugin {

    private static final String PREF_NAME = "prics_prefs";
    private static final String KEY_REFRESH_RATE = "display_refresh_rate";

    @Override
    public void load() {
        super.load();
        applySavedRefreshRate();
    }

    public void applySavedRefreshRate() {
        final Activity activity = getActivity();
        if (activity == null) return;
        try {
            final int savedHz = activity.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .getInt(KEY_REFRESH_RATE, 0);
            if (savedHz > 0) {
                activity.runOnUiThread(() -> setWindowRefreshRate(activity, savedHz));
            }
        } catch (Throwable ignored) {}
    }

    @PluginMethod
    public void getSupportedRefreshRates(PluginCall call) {
        Activity activity = getActivity();
        if (activity == null) {
            call.reject("Activity not available");
            return;
        }

        JSObject result = new JSObject();
        JSArray rates = new JSArray();
        Set<Integer> rateSet = new HashSet<>();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                Display display = null;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try { display = activity.getDisplay(); } catch (Throwable ignored) {}
                }
                if (display == null) {
                    display = activity.getWindowManager().getDefaultDisplay();
                }

                if (display != null) {
                    Display.Mode[] modes = display.getSupportedModes();
                    if (modes != null) {
                        for (Display.Mode m : modes) {
                            int r = Math.round(m.getRefreshRate());
                            if (r >= 50 && !rateSet.contains(r)) {
                                rateSet.add(r);
                            }
                        }
                    }
                }
            } catch (Throwable ignored) {}
        }

        if (rateSet.isEmpty()) {
            rateSet.add(60);
            rateSet.add(120);
        }

        List<Integer> sortedRates = new ArrayList<>(rateSet);
        Collections.sort(sortedRates);
        for (int r : sortedRates) {
            rates.put(r);
        }

        result.put("rates", rates);
        call.resolve(result);
    }

    @PluginMethod
    public void setRefreshRate(PluginCall call) {
        final int targetHz = call.getInt("hz", 0);
        final Activity activity = getActivity();
        if (activity == null) {
            call.reject("Activity not available");
            return;
        }

        activity.runOnUiThread(() -> {
            try {
                setWindowRefreshRate(activity, targetHz);

                // Persist preference to Android SharedPreferences
                try {
                    activity.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                            .edit()
                            .putInt(KEY_REFRESH_RATE, targetHz)
                            .apply();
                } catch (Throwable ignored) {}

                JSObject res = new JSObject();
                res.put("hz", targetHz);
                res.put("success", true);
                call.resolve(res);
            } catch (Throwable t) {
                call.reject("Failed to set refresh rate: " + t.getMessage(), t);
            }
        });
    }

    private void setWindowRefreshRate(Activity activity, int targetHz) {
        Window window = activity.getWindow();
        if (window == null) return;

        WindowManager.LayoutParams params = window.getAttributes();
        if (params == null) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (targetHz <= 0) {
                // 0 = Auto / System default
                params.preferredDisplayModeId = 0;
                params.preferredRefreshRate = 0.0f;
            } else {
                Display display = null;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try { display = activity.getDisplay(); } catch (Throwable ignored) {}
                }
                if (display == null) {
                    display = activity.getWindowManager().getDefaultDisplay();
                }

                if (display != null) {
                    Display.Mode[] modes = display.getSupportedModes();
                    Display.Mode bestMode = null;
                    float minDiff = Float.MAX_VALUE;

                    if (modes != null) {
                        for (Display.Mode m : modes) {
                            float diff = Math.abs(m.getRefreshRate() - (float) targetHz);
                            if (diff < minDiff) {
                                minDiff = diff;
                                bestMode = m;
                            }
                        }
                    }

                    if (bestMode != null && minDiff <= 3.0f) {
                        params.preferredDisplayModeId = bestMode.getModeId();
                    }
                }
                params.preferredRefreshRate = (float) targetHz;
            }
            window.setAttributes(params);
        }
    }
}
