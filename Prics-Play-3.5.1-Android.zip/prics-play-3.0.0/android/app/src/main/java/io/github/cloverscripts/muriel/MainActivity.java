package io.github.cloverscripts.muriel;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    static {
        try {
            // Prioritize IPv4 on Wi-Fi dual-stack networks (prevents DNS and TCP connection hangs
            // on ISPs like IndiHome/Biznet where broken IPv6 routes drop Google/YouTube CDN packets)
            System.setProperty("java.net.preferIPv4Stack", "true");
            System.setProperty("java.net.preferIPv6Addresses", "false");
            System.setProperty("http.keepAlive", "true");
            System.setProperty("http.maxConnections", "10");
        } catch (Throwable ignored) {}
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // plugins that live in the app itself (not in an npm package) are registered by hand
        registerPlugin(MediaControlsPlugin.class);
        registerPlugin(ExternalUrlPlugin.class);
        registerPlugin(PricsUpdatePlugin.class);
        registerPlugin(DisplayRefreshRatePlugin.class);
        super.onCreate(savedInstanceState);
    }
}
