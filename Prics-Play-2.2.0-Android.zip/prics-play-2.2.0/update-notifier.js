// Prics Play updater: checks the latest public GitHub Release and downloads its APK asset.
// Android always asks the user to confirm APK installation; apps cannot silently replace themselves.
(() => {
  const REPO = 'redhozr21/prics-neubrutalism-android';
  const RELEASES_API = `https://api.github.com/repos/${REPO}/releases/latest`;
  const store = {
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} },
  };
  const build = window.MURIEL_BUILD || {};
  const CURRENT_VERSION = String(build.version || '2.2.0');
  const CURRENT_BUILD = Number(build.run) || 0;
  const statusEl = document.getElementById('update-status');
  const checkBtn = document.getElementById('btn-check-updates');
  const aboutVersion = document.getElementById('about-version');
  let current = null;
  let checking = false;

  function versionParts(value) {
    const match = String(value || '').match(/(?:^|[^\d])(\d+)\.(\d+)\.(\d+)(?:[-+][\w.-]*)?/);
    return match ? match.slice(1, 4).map(Number) : null;
  }
  function compareVersions(a, b) {
    const left = versionParts(a), right = versionParts(b);
    if (!left || !right) return null;
    for (let i = 0; i < 3; i++) if (left[i] !== right[i]) return left[i] > right[i] ? 1 : -1;
    return 0;
  }
  function setStatus(message, hasUpdate = false) {
    if (statusEl) {
      statusEl.textContent = message;
      statusEl.classList.toggle('has-update', !!hasUpdate);
    }
    if (checkBtn) checkBtn.textContent = hasUpdate && current && current.apk ? 'Download now' : 'Check now';
  }

  async function latestRelease() {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12000);
    try {
      const response = await fetch(RELEASES_API, {
        headers: { Accept: 'application/vnd.github+json' }, cache: 'no-store', signal: controller.signal,
      });
      if (!response.ok) return null;
      const release = await response.json();
      if (!release || release.draft || release.prerelease || !release.html_url) return null;
      return release;
    } catch (_) { return null; }
    finally { clearTimeout(timer); }
  }

  function describe(release) {
    const assets = Array.isArray(release.assets) ? release.assets : [];
    const apk = assets.filter((asset) => asset && typeof asset.name === 'string' && /\.apk$/i.test(asset.name) && asset.browser_download_url)
      .sort((a, b) => {
        const score = (name) => (/prics[-_ ]?play/i.test(name) ? 3 : /app-release/i.test(name) ? 2 : /app-debug/i.test(name) ? 1 : 0);
        return score(b.name) - score(a.name);
      })[0] || null;
    const body = String(release.body || '');
    const versionMatch = body.match(/prics-play-version:\s*([0-9][\w.-]*)/i) || body.match(/Prics\s+Play\s+v?(\d+\.\d+\.\d+)/i);
    const titleMatch = String(release.name || '').match(/Prics\s+Play\s+v?(\d+\.\d+\.\d+)/i);
    const tagMatch = String(release.tag_name || '').match(/v?(\d+\.\d+\.\d+)/i);
    const buildMatch = body.match(/prics-play-build:\s*(\d+)/i) || body.match(/Build\s+(\d+)/i);
    const version = String((versionMatch && versionMatch[1]) || (titleMatch && titleMatch[1]) || (tagMatch && tagMatch[1]) || 'latest').trim();
    const comparison = compareVersions(version, CURRENT_VERSION);
    const releaseBuild = Number((buildMatch && buildMatch[1]) || 0);
    const newer = comparison === null ? !!apk : (comparison > 0 || (comparison === 0 && releaseBuild > CURRENT_BUILD));
    return { version, build: releaseBuild, htmlUrl: release.html_url, url: apk ? apk.browser_download_url : release.html_url, apk: !!apk, assetName: apk ? apk.name : '', comparison, newer };
  }

  async function openExternal(url) {
    if (!url) return;
    const platform = window.Capacitor && window.Capacitor.getPlatform ? window.Capacitor.getPlatform() : '';
    if (platform === 'android' && window.PricsExternalUrl && typeof window.PricsExternalUrl.open === 'function') {
      try { await window.PricsExternalUrl.open(url); return; } catch (_) { /* fall back to normal navigation */ }
    }
    if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) window.location.href = url;
    else window.open(url, '_blank', 'noopener,noreferrer');
  }

  async function check(manual = false) {
    if (checking) return;
    checking = true;
    if (manual) setStatus('Checking GitHub Releases…');
    try {
      const release = await latestRelease();
      if (!release) {
        current = null;
        setStatus('Unable to reach GitHub Releases. Check your connection or repository visibility.');
        if (manual) store.set('prics_play_update_last_error', Date.now());
        return;
      }
      current = describe(release);
      store.set('prics_play_latest_release', { version: current.version, build: current.build, url: current.url, apk: current.apk, checkedAt: Date.now() });
      if (!current.newer) {
        if (current.comparison === -1) setStatus(`Installed Prics Play ${CURRENT_VERSION} is newer than the published release (${current.version}).`);
        else setStatus(`Prics Play ${CURRENT_VERSION} is up to date.`);
        return;
      }
      if (!current.apk) {
        setStatus(`Prics Play ${current.version} is available, but the release has no APK attached.`);
        if (manual) await openExternal(current.htmlUrl);
        return;
      }
      setStatus(`Update available: Prics Play ${current.version} · APK ready`, true);
    } finally { checking = false; }
  }

  const versionLabel = `Version ${CURRENT_VERSION}${CURRENT_BUILD ? ` · Build ${CURRENT_BUILD}` : ''}`;
  if (aboutVersion) aboutVersion.textContent = versionLabel;
  if (statusEl) statusEl.textContent = `Prics Play ${CURRENT_VERSION}${CURRENT_BUILD ? ` · Build ${CURRENT_BUILD}` : ''}`;
  if (checkBtn) checkBtn.addEventListener('click', () => {
    if (current && current.newer && current.apk) openExternal(current.url);
    else check(true);
  });
  // Quiet check after first paint; no automatic download.
  setTimeout(() => check(false), 2500);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) check(false); });
  window.PricsPlayUpdates = { check: () => check(true), latestRelease, compareVersions };
})();
