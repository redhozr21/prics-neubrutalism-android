# Prics Play 2.2.0 — Master Implementation Plan and Status

**Target:** `2.2.0`  
**Baseline source:** `2.1.0`  
**Status:** Source implementation complete in a working copy; Android bundle/APK and device verification remain pending.  
**Repository:** https://github.com/redhozr21/prics-neubrutalism-android

This document consolidates the navigation, Music Card, Lyrics, audio quality, battery, buffering, cache, and release requirements for the 2.2.0 update. The full change list and verification limitations are in [`PRICS-PLAY-2.2.0-IMPLEMENTATION-REPORT.md`](PRICS-PLAY-2.2.0-IMPLEMENTATION-REPORT.md); user-facing changes are listed in [`PRICS-PLAY-2.2.0-RELEASE-NOTES.md`](PRICS-PLAY-2.2.0-RELEASE-NOTES.md).

## 1. Minimal-change policy

- Keep the existing framework, Capacitor integration, audio engine, server, storage model, and Android application ID.
- Do not delete previous ZIP archives, release tags, playlists, saved lyrics, or user data.
- Do not replace a complete subsystem when a targeted fix is sufficient.
- Preserve both Neubrutalism and Liquid Glass themes.
- Distinguish source-level tests from real-device verification. Do not claim a battery, data, latency, or playback improvement unless measured.

## 2. Navigation and UI

- Bottom navigation labels are Home, Search, Library, Settings.
- Settings enters at its landing/category list rather than forcing Theme.
- Back returns to the category list and clears category active styling. The last category is not persisted for visual selection.
- Library continues to use existing collection routes and data identifiers.
- Music Card titles are clamped to two lines; artist names use a dedicated ellipsis target. Card geometry, cover art, rounded corners, and carousel animation remain unchanged.

## 3. Lyrics

- Provide an independent hide/show Lyrics control that returns to cover-focused layout without closing Now Playing or changing playback state.
- Parse repeated LRC timestamps and standard `[offset:+/-milliseconds]` metadata.
- Keep untimed text untimed. Do not fabricate timestamp precision when the source provides none.
- Custom sync timestamps are used as recorded rather than shifting the first line four seconds early or borrowing the previous line's timestamp.
- Audio `currentTime` remains the synchronization clock after pause, resume, seek, and track changes.

## 4. Audio quality, battery, and buffering

- Preserve the existing streaming-quality preference and source-rendition selection. Targets are not guaranteed bitrates; no general-purpose transcoding is added.
- Keep battery-optimization exemption as an explicit Settings action, not an automatic side effect of Play.
- Preserve foreground service, notification/headset controls, and background playback.
- Mobile Opus ranges and HLS fallback are now written to cache in bounded, ordered batches rather than holding the full song and a concatenated copy in memory.
- Failed partial downloads are removed; existing retry/fallback behavior and complete-file cache semantics remain.
- Record source-resolution and cache-download timing for the last resolved stream when available.

### Known limitation

Mobile playback is still cache-first. On a cold uncached song, `/api/stream-info` waits for the full file to be cached before the audio element receives a local URL. The 2.2.0 changes reduce peak memory and improve diagnostics, but do not by themselves prove faster cold-cache time-to-first-audio. Progressive playback requires a separate streaming-path design and real-device validation.

## 5. Verification and release gate

- Baseline tests: 291/292 passed; the one failure was `test/library-import.test.js` because the `electron` dependency was unavailable.
- After source changes: 295/296 passed; the same missing-`electron` test remains the only failure. The focused suite covering navigation/version, Lyrics parser, Opus range writes, and HLS fallback passed 44/44.
- Changed JavaScript files pass `node --check`.
- Full mobile bundle build and Android APK build have not been verified because dependency installation timed out in this workspace.
- Before publishing, run `npm ci`, `node mobile/build.mjs`, `npx cap sync android`, and the CI Android build; then test both themes, Settings/Library, Music Cards, Lyrics, Play/Pause/Resume/Seek/Next/Previous/Shuffle/Repeat, network interruption, cache hit/miss, notifications, headset, and background playback on a physical Android device.
- Check APK `versionName`/`versionCode`, signing-certificate compatibility, and the immutable `v2.2.0` release. Do not delete prior releases or ZIPs.
