window.MURIEL_BUILD = {"sha":"dev","version":"3.3.0","run":0,"repo":"redhozr21/prics-neubrutalism-android","builtAt":"2026-11-02T13:10:00.000Z","channel":""};
