// Mobile-only Neubrutalism skin and Spotify-like primary navigation.
// This layer only changes presentation and navigation; the existing playback engine stays untouched.
(() => {
  const root = document.documentElement;
  if (!root.classList.contains('is-mobile')) return;

  const COLORS = {
    light: { accent: '#FFE14A', background: '#FFF8E7', surface: '#FFFFFF', ink: '#171717', secondary: '#FF8A65', tertiary: '#9BE7B5' },
    dark:  { accent: '#FFE14A', background: '#181818', surface: '#252525', ink: '#FFF8E7', secondary: '#FF8A65', tertiary: '#9BE7B5' },
  };
  const KEYS = {
    accent: 'muriel_theme_accent',
    background: 'muriel_neo_background',
    surface: 'muriel_neo_surface',
    ink: 'muriel_neo_ink',
    secondary: 'muriel_neo_secondary',
  };
  const isHex = (value) => typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value);
  const getColor = (key, fallback) => {
    try {
      const value = localStorage.getItem(KEYS[key]);
      return isHex(value) ? value : fallback;
    } catch (_) { return fallback; }
  };
  function applyPalette() {
    const mode = document.body.classList.contains('theme-dark') ? 'dark' : 'light';
    const defaults = COLORS[mode];
    const colors = {
      accent: getColor('accent', defaults.accent),
      background: getColor('background', defaults.background),
      surface: getColor('surface', defaults.surface),
      ink: getColor('ink', defaults.ink),
      secondary: getColor('secondary', defaults.secondary),
      tertiary: defaults.tertiary,
    };
    Object.entries(colors).forEach(([key, value]) => root.style.setProperty(`--neo-${key}`, value));
    root.style.setProperty('--neo-paper', colors.background);
    root.style.setProperty('--neo-border-width', '2px');
    root.style.setProperty('--neo-shadow-size', '4px');

  }


  const VISUAL_THEME_KEY = 'prics_play_visual_theme';
  const normalizeVisualTheme = (value) => value === 'liquid-glass' ? 'liquid-glass' : 'neubrutalism';

  function setVisualTheme(value) {
    const theme = normalizeVisualTheme(value);
    try { localStorage.setItem(VISUAL_THEME_KEY, theme); } catch (_) {}
    root.classList.toggle('neo-theme', theme === 'neubrutalism');
    root.classList.toggle('liquid-glass-theme', theme === 'liquid-glass');
    document.querySelectorAll('[data-prics-visual-theme]').forEach((button) => {
      const active = button.dataset.pricsVisualTheme === theme;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    applyPalette();
    window.dispatchEvent(new CustomEvent('prics:visual-theme-change', { detail: { theme } }));
  }

  function addVisualThemeSelector() {
    const section = document.querySelector('.settings-section[data-cat="theme"]');
    const group = section && section.querySelector('.m3-group[data-group="colors"]');
    if (!group || group.querySelector('.prics-visual-theme-setting')) return;
    const card = document.createElement('div');
    card.className = 'setting-item prics-visual-theme-setting';
    card.innerHTML = `
      <div class="prics-visual-theme-heading"><span class="setting-name" data-i18n>Visual theme</span><small data-i18n>Choose your Prics Play appearance</small></div>
      <div class="prics-visual-theme-options" role="group" aria-label="Visual theme" data-i18n-attr="aria-label">
        <button type="button" class="prics-visual-theme-option" data-prics-visual-theme="neubrutalism" aria-pressed="true">
          <span class="prics-theme-preview prics-preview-neo" aria-hidden="true"><i></i><b data-no-i18n>P</b><em></em></span>
          <span><strong data-i18n>Neubrutalism</strong><small data-i18n>Bold borders and hard shadows</small></span><span class="prics-theme-check" aria-hidden="true">✓</span>
        </button>
        <button type="button" class="prics-visual-theme-option" data-prics-visual-theme="liquid-glass" aria-pressed="false">
          <span class="prics-theme-preview prics-preview-glass" aria-hidden="true"><i></i><b data-no-i18n>P</b><em></em></span>
          <span><strong data-i18n>Liquid Glass</strong><small data-i18n>Translucent layers and soft blur</small></span><span class="prics-theme-check" aria-hidden="true">✓</span>
        </button>
      </div>`;
    group.prepend(card);
    card.querySelectorAll('[data-prics-visual-theme]').forEach((button) => button.addEventListener('click', () => setVisualTheme(button.dataset.pricsVisualTheme)));
    setVisualTheme(normalizeVisualTheme(localStorage.getItem(VISUAL_THEME_KEY)));
  }

  // Mobile keeps only the useful appearance controls: visual theme, light/dark mode,
  // accent colour, interface opacity and the optional cover background. The underlying
  // legacy controls stay in the DOM so existing settings code and desktop builds remain safe.
  function simplifyMobileThemeSettings() {
    const section = document.querySelector('.settings-section[data-cat="theme"]');
    if (!section) return;
    const hideRow = (selector) => {
      const control = section.querySelector(selector);
      const row = control && control.closest('.setting-item');
      if (!row) return;
      row.hidden = true;
      row.setAttribute('aria-hidden', 'true');
      row.style.setProperty('display', 'none', 'important');
    };
    [
      '#setting-palette-style', '#slider-theme-hue', '#slider-theme-intensity',
      '#btn-intensity-bg', '#slider-theme-brightness', '#btn-highlight-buttons',
      '#slider-text-alpha', '[data-adv="glass_blur"]', '#setting-glass-strength',
      '#btn-choose-custom-bg', '#slider-bg-opacity', '#slider-bg-blur',
      '#slider-cover-bg-brightness', '[data-adv="mesh_follow_intensity"]',
      '[data-adv="mesh_cover_color"]', '[data-adv="ui_alpha_auto"]',
      '#setting-home-icon-row',
    ].forEach(hideRow);

    const homeIconGroup = section.querySelector('.m3-group[data-group="home-icon"]');
    if (homeIconGroup) {
      homeIconGroup.hidden = true;
      homeIconGroup.style.setProperty('display', 'none', 'important');
      const heading = homeIconGroup.previousElementSibling;
      if (heading && heading.classList.contains('settings-group-title')) {
        heading.hidden = true;
        heading.style.setProperty('display', 'none', 'important');
      }
    }

    // Older builds allowed animated/custom app backdrops. The mobile release keeps the cover-derived
    // background only; remove the old preference and stop any already-mounted video/GIF immediately.
    try {
      localStorage.removeItem('muriel_bg_url');
      localStorage.removeItem('muriel_bg_opacity');
      localStorage.removeItem('muriel_bg_blur');
      // Older Android builds exposed separate background/surface/ink/secondary palette controls.
      // Keep the user's accent colour, but return the other palette channels to the app defaults.
      ['muriel_neo_background', 'muriel_neo_surface', 'muriel_neo_ink', 'muriel_neo_secondary'].forEach((key) => localStorage.removeItem(key));
    } catch (_) {}
    const customBackground = document.getElementById('custom-bg');
    if (customBackground) {
      customBackground.replaceChildren();
      customBackground.style.setProperty('display', 'none', 'important');
    }
    document.body.classList.remove('has-video-bg', 'glass-lite');
  }

  function addSpotifyNavigation() {
    const sidebar = document.getElementById('sidebar');
    if (!sidebar) return;
    sidebar.classList.add('neo-sidebar');

    // The mobile build emits this navigation in the HTML so it is visible on the very first
    // frame. Desktop/dev builds can still create it here when no static nav exists.
    let nav = sidebar.querySelector('.neo-bottom-nav');
    if (!nav) {
      nav = document.createElement('nav');
      nav.className = 'neo-bottom-nav';
      nav.setAttribute('aria-label', 'Main navigation'); nav.setAttribute('data-i18n-attr', 'aria-label');
      nav.innerHTML = `
      <button type="button" class="neo-tab active" data-tab="home" aria-label="Home" data-i18n-attr="aria-label">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/></svg><span data-i18n>Home</span>
      </button>
      <button type="button" class="neo-tab" data-tab="search" aria-label="Search" data-i18n-attr="aria-label">
        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 5 5"/></svg><span data-i18n>Search</span>
      </button>
      <button type="button" class="neo-tab" data-tab="library" aria-label="Library" data-i18n-attr="aria-label">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4v16M9 4v16M14 4v16M19 4v16"/></svg><span data-i18n>Library</span>
      </button>
      <button type="button" class="neo-tab" data-tab="settings" aria-label="Settings" data-i18n-attr="aria-label"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z"/><path d="m19.4 15 .1.1a1.8 1.8 0 0 1-2.5 2.5l-.1-.1a1.8 1.8 0 0 0-3 .9v.2a1.8 1.8 0 0 1-3.6 0v-.2a1.8 1.8 0 0 0-3-.9l-.1.1a1.8 1.8 0 0 1-2.5-2.5l.1-.1a1.8 1.8 0 0 0-.9-3H3.7a1.8 1.8 0 0 1 0-3.6h.2a1.8 1.8 0 0 0 .9-3l-.1-.1a1.8 1.8 0 0 1 2.5-2.5l.1.1a1.8 1.8 0 0 0 3-.9V2.8a1.8 1.8 0 0 1 3.6 0V3a1.8 1.8 0 0 0 3 .9l.1-.1a1.8 1.8 0 0 1 2.5 2.5l-.1.1a1.8 1.8 0 0 0 .9 3h.2a1.8 1.8 0 0 1 0 3.6h-.2a1.8 1.8 0 0 0-.9 2Z"/></svg><span data-i18n>Settings</span>
      </button>`;
      sidebar.appendChild(nav);
    }

    const setActive = (tab) => nav.querySelectorAll('.neo-tab').forEach((button) => {
      const active = button.dataset.tab === tab;
      button.classList.toggle('active', active);
      if (active) button.setAttribute('aria-current', 'page');
      else button.removeAttribute('aria-current');
      button.setAttribute('aria-pressed', String(active));
    });
    setActive('home');
    const clickExisting = (id) => { const button = document.getElementById(id); if (button) button.click(); };
    const searchInput = document.getElementById('search-input');
    let searchMode = false;

    nav.querySelector('[data-tab="home"]').addEventListener('click', () => {
      searchMode = false;
      if (searchInput && searchInput.value) clickExisting('search-clear-btn');
      clickExisting('nav-discover');
      setActive('home');
      if (document.activeElement === searchInput && searchInput) searchInput.blur();
    });
    nav.querySelector('[data-tab="search"]').addEventListener('click', () => {
      searchMode = true;
      clickExisting('nav-discover');
      setActive('search');
      if (searchInput) {
        try { searchInput.focus({ preventScroll: true }); } catch (_) { searchInput.focus(); }
        searchInput.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      }
    });
    nav.querySelector('[data-tab="library"]').addEventListener('click', () => {
      searchMode = false;
      // The previous handler only toggled the playlist drawer. When the drawer closed,
      // the current view (often Settings) remained underneath while Library looked selected.
      // Route to the app's real library landing view (Liked Songs/Favorites) instead.
      const drawer = document.getElementById('rail-drawer');
      if (drawer && !drawer.classList.contains('hidden')) clickExisting('btn-close-rail-drawer');
      clickExisting('nav-favorites');
      if (document.activeElement === searchInput && searchInput) searchInput.blur();
      setActive('library');
      // switchView runs on the next animation frame; scroll the newly activated view to its top
      // and expose a small Library hub so this tab is not merely an alias for Favorites.
      requestAnimationFrame(() => {
        const main = document.getElementById('main-content');
        if (main) main.scrollTop = 0;
        ensureLibraryHub();
        setActive('library');
      });
    });
    nav.querySelector('[data-tab="settings"]').addEventListener('click', () => {
      searchMode = false;
      // Settings always lands on the category list; Theme is opened only when its category is chosen.
      clickExisting('nav-settings');
      if (document.activeElement === searchInput && searchInput) searchInput.blur();
      requestAnimationFrame(() => setActive('settings'));
    });

    const drawer = document.getElementById('rail-drawer');
    if (drawer && !drawer.querySelector('.neo-library-shortcuts')) {
      const shortcuts = document.createElement('div');
      shortcuts.className = 'neo-library-shortcuts';
      shortcuts.innerHTML = `
        <button type="button" data-open-view="favorites"><span class="neo-shortcut-icon">♥</span><span><b data-i18n>Liked songs</b><small data-i18n>Saved favorites</small></span></button>
        <button type="button" data-open-view="albums"><span class="neo-shortcut-icon">▣</span><span><b data-i18n>Albums</b><small data-i18n>Saved albums</small></span></button>
        <button type="button" data-open-view="artists"><span class="neo-shortcut-icon">♫</span><span><b data-i18n>Artists</b><small data-i18n>Followed artists</small></span></button>
        <button type="button" data-open-view="local"><span class="neo-shortcut-icon">▤</span><span><b data-i18n>On this device</b><small data-i18n>Local music</small></span></button>
        <button type="button" data-open-view="history"><span class="neo-shortcut-icon">◷</span><span><b data-i18n>Recently played</b><small data-i18n>Listening history</small></span></button>`;
      const playlistSection = drawer.querySelector('#drawer-section-playlists');
      if (playlistSection) drawer.insertBefore(shortcuts, playlistSection);
      shortcuts.querySelectorAll('[data-open-view]').forEach((button) => {
        button.addEventListener('click', () => {
          const view = button.dataset.openView;
          clickExisting('btn-close-rail-drawer');
          setActive('library');
          const targetId = ({ favorites: 'nav-favorites', albums: 'nav-albums', artists: 'nav-artists', local: 'nav-local', history: 'nav-history' })[view];
          if (targetId) clickExisting(targetId);
          setActive('library');
        });
      });
    }

    // Keep the custom tab selection in sync with the app's existing view controller.
    ['nav-discover', 'nav-favorites', 'nav-albums', 'nav-artists', 'nav-local', 'nav-history', 'nav-settings'].forEach((id) => {
      const button = document.getElementById(id);
      if (!button) return;
      button.addEventListener('click', () => {
        if (id === 'nav-discover') setActive(searchMode ? 'search' : 'home');
        else if (id === 'nav-settings') setActive('settings');
        else setActive('library');
      });
    });
    if (searchInput) {
      searchInput.addEventListener('focus', () => { if (searchMode) setActive('search'); });
      searchInput.addEventListener('input', () => { if (searchInput.value.trim()) { searchMode = true; setActive('search'); } else if (searchMode && document.activeElement === searchInput) setActive('search'); });
    }
    const drawerTitle = document.getElementById('rail-drawer-title');
    const refreshDrawerTitle = () => {
      if (drawerTitle && drawer && !drawer.classList.contains('drawer-presets-mode') && !drawer.classList.contains('hidden') && drawerTitle.textContent !== 'Your Library') drawerTitle.textContent = 'Your Library';
    };
    if (drawer) new MutationObserver(refreshDrawerTitle).observe(drawer, { attributes: true, attributeFilter: ['class'] });
    if (drawerTitle) new MutationObserver(refreshDrawerTitle).observe(drawerTitle, { childList: true, characterData: true, subtree: true });
  }

  function ensureLibraryHub() {
    const view = document.getElementById('view-favorites');
    if (!view) return;
    const clickExisting = (id) => { const button = document.getElementById(id); if (button) button.click(); };
    let hub = view.querySelector('.neo-library-hub');
    if (hub) {
      hub.hidden = false;
      refreshLibraryPlaylists(hub);
      return;
    }
    hub = document.createElement('section');
    hub.className = 'neo-library-hub';
    hub.setAttribute('aria-label', 'Your Library');
    hub.setAttribute('data-i18n-attr', 'aria-label');
    hub.innerHTML = `
      <div class="neo-library-hub-head"><h2 data-i18n>Your Library</h2><span data-i18n>COLLECTIONS</span></div>
      <div class="neo-library-hub-grid">
        <button type="button" data-open-view="favorites"><span class="neo-hub-icon">♥</span><span><b data-i18n>Liked songs</b><small data-i18n>Saved favorites</small></span></button>
        <button type="button" data-open-view="albums"><span class="neo-hub-icon">▣</span><span><b data-i18n>Albums</b><small data-i18n>Saved albums</small></span></button>
        <button type="button" data-open-view="artists"><span class="neo-hub-icon">♫</span><span><b data-i18n>Artists</b><small data-i18n>Followed artists</small></span></button>
        <button type="button" data-open-view="local"><span class="neo-hub-icon">▤</span><span><b data-i18n>On this device</b><small data-i18n>Local music</small></span></button>
        <button type="button" data-open-view="history"><span class="neo-hub-icon">◷</span><span><b data-i18n>Recently played</b><small data-i18n>Listening history</small></span></button>
      </div>
      <section class="neo-library-playlists" aria-label="Your playlists" data-i18n-attr="aria-label">
        <div class="neo-library-playlists-head"><h3 data-i18n>Your playlists</h3><span class="neo-library-playlist-count">0</span></div>
        <div class="neo-library-playlist-list" aria-live="polite"></div>
      </section>`;
    const header = view.querySelector('.view-header');
    if (header) view.insertBefore(hub, header);
    else view.prepend(hub);
    hub.querySelectorAll('.neo-library-hub-grid [data-open-view]').forEach((button) => {
      button.addEventListener('click', () => {
        const viewName = button.dataset.openView;
        if (viewName === 'favorites') {
          hub.hidden = true;
          const main = document.getElementById('main-content');
          requestAnimationFrame(() => {
            const h = view.querySelector('.view-header');
            if (main && h) main.scrollTop = Math.max(0, h.offsetTop - 8);
          });
          return;
        }
        const targetId = ({ albums: 'nav-albums', artists: 'nav-artists', local: 'nav-local', history: 'nav-history' })[viewName];
        if (targetId) clickExisting(targetId);
      });
    });
    refreshLibraryPlaylists(hub);
  }

  function getUserPlaylists() {
    const core = window.MurielCore;
    if (core && core.state && Array.isArray(core.state.playlists)) {
      return core.state.playlists.filter((playlist) => playlist && typeof playlist === 'object' && playlist.id != null);
    }
    try {
      const saved = JSON.parse(localStorage.getItem('devsize_playlists') || '[]');
      return Array.isArray(saved) ? saved.filter((playlist) => playlist && typeof playlist === 'object' && playlist.id != null) : [];
    } catch (_) {
      return [];
    }
  }

  function getPlaylistArtwork(playlist) {
    const core = window.MurielCore;
    let source = typeof playlist.cover === 'string' ? playlist.cover.trim() : '';
    if (!source) {
      const track = Array.isArray(playlist.tracks) ? playlist.tracks.find(Boolean) : null;
      if (track) {
        try { source = core && typeof core.thumb === 'function' ? (core.thumb(track) || '') : (track.thumbnail || track.localThumbnail || ''); }
        catch (_) { source = track.thumbnail || track.localThumbnail || ''; }
      }
    }
    return /^(https?:|data:image\/|blob:|file:)/i.test(source) ? source : '';
  }

  function refreshLibraryPlaylists(hub = document.querySelector('.neo-library-hub')) {
    if (!hub) return;
    const list = hub.querySelector('.neo-library-playlist-list');
    const count = hub.querySelector('.neo-library-playlist-count');
    if (!list) return;
    const playlists = getUserPlaylists();
    if (count) count.textContent = String(playlists.length);
    list.replaceChildren();

    if (!playlists.length) {
      const empty = document.createElement('p');
      empty.className = 'neo-library-playlist-empty';
      if (window.MurielI18n && window.MurielI18n.text) window.MurielI18n.text(empty, 'Your playlists will appear here after you create one.');
      else empty.textContent = 'Your playlists will appear here after you create one.';
      list.appendChild(empty);
      return;
    }

    const core = window.MurielCore;
    playlists.forEach((playlist) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'neo-library-playlist-item';
      button.dataset.playlistId = String(playlist.id);
      button.setAttribute('aria-label', (window.MurielI18n && window.MurielI18n.Tf ? window.MurielI18n.Tf('Open playlist {0}', playlist.name || 'Untitled playlist') : `Open playlist ${playlist.name || 'Untitled playlist'}`));

      const artwork = document.createElement('span');
      artwork.className = 'neo-library-playlist-art';
      const source = getPlaylistArtwork(playlist);
      if (source) {
        const image = document.createElement('img');
        image.src = source;
        image.alt = '';
        image.loading = 'lazy';
        image.decoding = 'async';
        image.addEventListener('error', () => { artwork.replaceChildren(); artwork.textContent = '♫'; }, { once: true });
        artwork.appendChild(image);
      } else {
        artwork.textContent = '♫';
      }

      const info = document.createElement('span');
      info.className = 'neo-library-playlist-info';
      const name = document.createElement('b');
      name.textContent = playlist.name || 'Untitled playlist';
      const meta = document.createElement('small');
      const trackCount = Array.isArray(playlist.tracks) ? playlist.tracks.length : 0;
      if (window.MurielI18n && window.MurielI18n.text) {
        if (trackCount === 1) window.MurielI18n.text(meta, '1 track');
        else window.MurielI18n.text(meta, '{0} tracks', trackCount);
      } else meta.textContent = `${trackCount} ${trackCount === 1 ? 'track' : 'tracks'}`;
      info.append(name, meta);

      const openIcon = document.createElement('span');
      openIcon.className = 'neo-library-playlist-open';
      openIcon.setAttribute('aria-hidden', 'true');
      openIcon.textContent = '›';
      button.append(artwork, info, openIcon);
      button.addEventListener('click', () => {
        if (core && typeof core.openPlaylist === 'function') {
          core.openPlaylist(playlist.id);
        } else {
          const drawer = document.getElementById('rail-drawer');
          const existing = drawer && Array.from(drawer.querySelectorAll('.playlist-item')).find((item) => item.dataset.playlistId === String(playlist.id));
          if (existing) existing.click();
        }
      });
      list.appendChild(button);
    });
  }

  function refreshVisibleLibraryPlaylists() {
    const hub = document.querySelector('.neo-library-hub');
    if (hub) refreshLibraryPlaylists(hub);
  }

  function optimizeContentImages() {
    const critical = '#titlebar, .playbar, #right-panel, #splash, .profile-menu';
    const tune = (img) => {
      if (!(img instanceof HTMLImageElement)) return;
      if (!img.closest(critical)) {
        if (!img.hasAttribute('loading')) img.loading = 'lazy';
        if (!img.hasAttribute('decoding')) img.decoding = 'async';
        if (!img.hasAttribute('fetchpriority')) img.fetchPriority = 'low';
      } else if (!img.hasAttribute('decoding')) {
        img.decoding = 'async';
      }
    };
    document.querySelectorAll('img').forEach(tune);
    const target = document.getElementById('main-content') || document.body;
    if (!target || !('MutationObserver' in window)) return;
    const observer = new MutationObserver((records) => {
      for (const record of records) {
        for (const node of record.addedNodes) {
          if (node instanceof HTMLImageElement) tune(node);
          else if (node && node.querySelectorAll) node.querySelectorAll('img').forEach(tune);
        }
      }
    });
    observer.observe(target, { childList: true, subtree: true });
  }

  function finishInit() {
    simplifyMobileThemeSettings();
    applyPalette();
    addVisualThemeSelector();
    addSpotifyNavigation();
    optimizeContentImages();
    window.addEventListener('prics:playlists-updated', refreshVisibleLibraryPlaylists);
    window.addEventListener('muriel:library', refreshVisibleLibraryPlaylists);
    window.addEventListener('storage', (event) => {
      if (!event.key || event.key === 'devsize_playlists') refreshVisibleLibraryPlaylists();
    });

    // Existing theme controls remain compatible with the new palette.
    document.querySelectorAll('.theme-swatch').forEach((button) => button.addEventListener('click', () => setTimeout(applyPalette, 0)));
    const legacyPicker = document.getElementById('settings-custom-color-input');
    if (legacyPicker) legacyPicker.addEventListener('input', applyPalette);
    const hueSlider = document.getElementById('slider-theme-hue');
    if (hueSlider) hueSlider.addEventListener('change', () => setTimeout(applyPalette, 0));
    document.querySelectorAll('.theme-mode-btn[data-theme-mode]').forEach((button) => button.addEventListener('click', () => setTimeout(applyPalette, 0)));

    let lastMode = document.body.classList.contains('theme-dark') ? 'dark' : 'light';
    new MutationObserver(() => {
      const nextMode = document.body.classList.contains('theme-dark') ? 'dark' : 'light';
      if (nextMode !== lastMode) { lastMode = nextMode; applyPalette(); }
    }).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  }

  function init() {
    setVisualTheme(normalizeVisualTheme(localStorage.getItem(VISUAL_THEME_KEY)));
    applyPalette();
    if (window.MurielCore) finishInit();
    else window.addEventListener('muriel:ready', finishInit, { once: true });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
