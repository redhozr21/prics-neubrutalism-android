const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');

test('release version is 2.3.1 while the Android package identity remains stable', () => {
  const pkg = JSON.parse(read('package.json'));
  const lock = JSON.parse(read('package-lock.json'));
  const cap = JSON.parse(read('capacitor.config.json'));
  const gradle = read('android/app/build.gradle');
  assert.equal(pkg.version, '2.3.1');
  assert.equal(lock.version, '2.3.1');
  assert.equal(lock.packages[''].version, '2.3.1');
  assert.equal(cap.appId, 'io.github.cloverscripts.muriel');
  assert.match(gradle, /versionName pricsVersionName/);
  assert.match(gradle, /pricsVersionBaseCode/);
});

test('theme selector provides Neubrutalism by default and Liquid Glass, and persists choice', () => {
  const build = read('mobile/build.mjs');
  const bridge = read('mobile/bridge.js');
  const skin = read('mobile/neubrutalism.js');
  const css = read('mobile/mobile.css');
  assert.match(build, /prics-visual-theme-bootstrap/);
  assert.ok(build.indexOf('src="profiles-core.js"') < build.indexOf('prics-visual-theme-bootstrap'));
  assert.match(build, /prics_play_visual_theme/);
  assert.match(bridge, /prics_play_visual_theme/);
  assert.match(skin, /data-prics-visual-theme="neubrutalism"/);
  assert.match(skin, /data-prics-visual-theme="liquid-glass"/);
  assert.match(skin, /localStorage\.setItem\(VISUAL_THEME_KEY, theme\)/);
  assert.match(skin, /theme === 'neubrutalism'/);
  assert.match(skin, /theme === 'liquid-glass'/);
  assert.match(css, /html\.is-mobile\.liquid-glass-theme/);
  assert.match(css, /backdrop-filter:blur\(var\(--glass-blur\)\)/);
});

test('About updater downloads and verifies an APK in-app before opening Android installer', () => {
  const updater = read('update-notifier.js');
  const java = read('android/app/src/main/java/io/github/cloverscripts/muriel/PricsUpdatePlugin.java');
  const activity = read('android/app/src/main/java/io/github/cloverscripts/muriel/MainActivity.java');
  const manifest = read('android/app/src/main/AndroidManifest.xml');
  assert.match(updater, /api\.github\.com\/repos\/\$\{REPO\}\/releases\/latest/);
  assert.match(updater, /function compareVersions/);
  assert.match(updater, /PricsUpdate\.downloadApk/);
  assert.match(updater, /PricsUpdate\.installApk/);
  assert.match(updater, /checksumUrl/);
  assert.match(updater, /Download update/);
  assert.match(java, /MessageDigest\.getInstance\("SHA-256"\)/);
  assert.match(java, /FileProvider\.getUriForFile/);
  assert.match(java, /Intent\.ACTION_VIEW/);
  assert.match(java, /hasCompatibleSigningCertificate/);
  assert.match(activity, /registerPlugin\(PricsUpdatePlugin\.class\)/);
  assert.match(manifest, /android\.permission\.REQUEST_INSTALL_PACKAGES/);
});

test('My Wave is removed from the rendered app and no longer triggers its legacy startup request chain', () => {
  const html = read('index.html');
  const app = read('app.js');
  assert.doesNotMatch(html, /My Wave|btn-play-my-wave|section-my-wave/);
  assert.match(app, /async function loadHomePage\(\) \{[\s\S]*?loadForYou\(\);\s*return false;\s*\}/);
  assert.doesNotMatch(app, /My Wave|myWaveActive|btn-play-my-wave|home-vibe-grid/);
  assert.match(app, /prics:playback-metric/);
  assert.doesNotMatch(app.slice(app.indexOf('function renderMadeForYou()'), app.indexOf('// ---- Trending now')), /title: state\.isHotPicks[\s\S]*?My Wave/);
});

test('Android release workflow creates versioned releases without deleting old releases', () => {
  const workflow = read('.github/workflows/android.yml');
  assert.match(workflow, /tag="v\$ver"/);
  assert.match(workflow, /gh release create "\$tag"/);
  assert.doesNotMatch(workflow, /gh release delete/);
});

test('Liquid Glass nav uses a scoped convex glass surface and safe fallback', () => {
  const css = read('mobile/mobile.css');
  assert.match(css, /html\.is-mobile\.liquid-glass-theme \.sidebar\.neo-sidebar::before/);
  assert.match(css, /html\.is-mobile\.liquid-glass-theme \.neo-tab\.active::after/);
  assert.match(css, /@supports not \(\(backdrop-filter: blur\(1px\)\)/);
});


test('fourth bottom tab is Settings, third is Library, and Settings does not force-open Theme', () => {
  const build = read('mobile/build.mjs');
  const skin = read('mobile/neubrutalism.js');
  assert.match(build, /data-tab="library" aria-label="Library"/);
  assert.match(build, /<span data-i18n>Library<\/span>/);
  assert.match(build, /data-tab="settings" aria-label="Settings"/);
  assert.match(build, /<span data-i18n>Settings<\/span>/);
  assert.doesNotMatch(skin, /settings-nav-btn\[data-cat="theme"\]/);
  assert.match(skin, /clickExisting\('nav-settings'\)/);
  assert.match(read('app.js'), /function showSettingsList\(\)[\s\S]*?classList\.remove\('active'\)/);
  assert.doesNotMatch(read('app.js'), /localStorage\.setItem\('muriel_settings_cat'/);
});


test('lyrics visibility is a separate presentation state and does not close the player drawer', () => {
  const html = read('index.html');
  const app = read('app.js');
  const css = read('styles.css');
  assert.match(html, /id="btn-toggle-lyrics-visibility"/);
  assert.match(app, /panel\.classList\.toggle\('lyrics-collapsed', lyricsCollapsed\)/);
  assert.match(app, /lyricsCollapsed = !lyricsCollapsed/);
  assert.match(css, /\.right-panel\.lyrics-collapsed \.lyrics-action-btn:not\(#btn-toggle-lyrics-visibility\)/);
  assert.doesNotMatch(app, /CUSTOM_SHIFT_LEAD_SECONDS/);
  assert.doesNotMatch(app, /state\.isCustomLyrics \? 0\.25/);
});

test('mobile audio download writes bounded batches and records resolve/download timings', () => {
  const child = read('mobile/shims/child_process.js');
  const store = read('mobile/shims/store.js');
  const ui = read('mobile/mobile-ui.js');
  assert.match(child, /downloadRangesToFile/);
  assert.match(child, /for \(let start = 0; start < size; start \+= step \* 4\)/);
  assert.match(child, /downloadHlsToFile/);
  assert.match(child, /resolveMs, downloadMs/);
  assert.match(store, /async appendBytes\(vpath, bytes\)/);
  assert.match(ui, /Timing: \$\{timing\}/);
});

test('Android workflow passes a monotonic build number into versionCode', () => {
  const workflow = read('.github/workflows/android.yml');
  assert.match(workflow, /MURIEL_VERSION_NAME=.*package\.json/);
  assert.match(workflow, /MURIEL_VERSION_CODE="\$\{\{ github\.run_number \}\}"/);
});


test('CI selects a version-validated source archive and does not rely on ZIP modification time', () => {
  const selector = read('tools/select-source-archive.py');
  const workflow = read('.github/workflows/android.yml');
  assert.match(selector, /VERSIONED_ARCHIVE = re\.compile/);
  assert.match(selector, /package\.get\("version"/);
  assert.match(selector, /root_version_key > latest_archive\[0\]/);
  assert.match(workflow, /python3 tools\/select-source-archive\.py/);
  assert.match(workflow, /working-directory: \$\{\{ env\.PRICS_SOURCE_DIR \}\}/);
});
