'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');

test('Android next-track prefetch is late, disabled for Data Saver, and cancellable', () => {
  const app = read('app.js');
  assert.match(app, /mobileStreamQuality === 'data-saver'\) return false/);
  assert.match(app, /mobileStreamQuality === 'low' \? 0\.90/);
  assert.match(app, /mobileStreamQuality === 'normal' \? 0\.88/);
  assert.match(app, /mobileStreamQuality === 'high' \? 0\.85/);
  assert.match(app, /mobileStreamQuality === 'very-high' \? 0\.82/);
  assert.match(app, /fetch\(url, \{ signal: controller\.signal \}\)/);
  assert.match(app, /cancelNextTrackPrefetch\(\);[\s\S]*?pauseSmooth\(\);/);
  assert.doesNotMatch(app, /mobileStreamQuality === 'normal' \? 0\.62/);
  assert.doesNotMatch(app, /mobileStreamQuality === 'low' \? 0\.72/);
});

test('mobile render loop is capped at 15 FPS even when desktop Performance mode is active', () => {
  const app = read('app.js');
  assert.match(app, /const fpsCap = isPhoneApp \? 15 : document\.body\.classList\.contains\('perf'\) \? 30/);
});

test('Daily Mix generation and followed-artist metadata are user-demanded on Android', () => {
  const app = read('app.js');
  assert.match(app, /if \(isPhoneApp && \(!cached \|\| !mixes\.length\) && !mixesBusy\)/);
  assert.match(app, /Tap refresh to create mixes when you want them\./);
  assert.match(app, /if \(on && state\.serverPort && \(!isPhoneApp \|\| state\.currentView === 'artists'\)\) fetchFollowedMeta\(list\)/);
});


test('sleep timer does not wake the background WebView every second', () => {
  const app = read('app.js');
  const visibility = app.slice(app.indexOf('function handleVisibilityChange'), app.indexOf("document.addEventListener('visibilitychange'"));
  const timer = app.slice(app.indexOf('function syncSleepTimerSchedule'), app.indexOf('if (el.sleepTimerStatus)'));
  assert.match(visibility, /syncSleepTimerSchedule\(\)/);
  assert.match(timer, /setTimeout\(syncSleepTimerSchedule, visible \? Math\.min\(1000, remaining\) : remaining\)/);
  assert.doesNotMatch(timer, /setInterval\(/);
});

test('Android releases wake and artwork resources promptly and avoid stale artwork downloads', () => {
  const native = read('android/app/src/main/java/io/github/cloverscripts/muriel/MediaControlsPlugin.java');
  assert.match(native, /LOCK_RELEASE_MS = 3_000/);
  assert.match(native, /ART_SIZE = 256/);
  assert.match(native, /if \(!url\.equals\(artworkUrl\)\) return;/);
  assert.match(native, /4 \* 1024 \* 1024/);
  assert.doesNotMatch(native, /allowBackground|backgroundStatus|ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS/);
});

test('Android does not request battery-optimization exemption; media playback foreground service remains', () => {
  const manifest = read('android/app/src/main/AndroidManifest.xml');
  const service = read('android/app/src/main/java/io/github/cloverscripts/muriel/PlaybackService.java');
  const controls = read('mobile/media-controls.js');
  assert.doesNotMatch(manifest, /REQUEST_IGNORE_BATTERY_OPTIMIZATIONS/);
  assert.doesNotMatch(controls, /MurielBackground|allowBackground|backgroundStatus/);
  assert.match(manifest, /FOREGROUND_SERVICE_MEDIA_PLAYBACK/);
  assert.match(manifest, /android:name="\.PlaybackService"/);
  assert.match(service, /PAUSED_FOREGROUND_MS = 10 \* 60 \* 1000/);
  assert.match(service, /ACTION_NEXT/);
});

test('mobile Theme exposes only the small appearance set and removes expensive custom backdrops', () => {
  const skin = read('mobile/neubrutalism.js');
  const css = read('mobile/mobile.css');
  const html = read('index.html');
  assert.match(skin, /simplifyMobileThemeSettings\(\)/);
  assert.match(html, /id="slider-ui-alpha"/);
  assert.match(html, /data-adv="cover_bg"/);
  assert.match(skin, /muriel_bg_url/);
  assert.match(css, /html\.is-mobile :is\(\.bg-mesh-layer,[\s\S]*?#custom-bg, \.home-ambient\) \{ display: none !important; \}/);
  assert.match(css, /--glass-blur: 12px/);
  assert.doesNotMatch(skin, /data-neo-preset=/);
});

test('mobile dynamic labels participate in language switching and Prics Play is kept as a brand', () => {
  const ui = read('mobile/mobile-ui.js');
  const skin = read('mobile/neubrutalism.js');
  const build = read('mobile/build.mjs');
  const i18n = read('i18n.js');
  assert.match(ui, /<option value="\$\{value\}" data-i18n>/);
  assert.match(ui, /prics-stream-quality-status" data-i18n/);
  assert.match(skin, /data-i18n>Visual theme/);
  assert.match(skin, /data-i18n>Your Library/);
  assert.match(build, /<span data-i18n>Library<\/span>/);
  assert.match(i18n, /'prics play'/);
});
