# Prics Play 2.3.1 — Implementation Status

**Target:** `2.3.1`  
**Baseline:** `2.3.0`  
**Scope:** Android power use, mobile Theme simplification, dynamic-language coverage, and regression protection.

## Status

Source changes for 2.3.1 are implemented in this working copy. Targeted Node tests and JavaScript syntax checks pass. A full dependency install, mobile bundle build, Gradle APK build, and physical-device battery test have not been completed in this environment. Do not publish the release until GitHub Actions succeeds and the installed APK's signing certificate is confirmed compatible with the 2.3.0 installation.

## Changes

### Battery and background work

- Mobile next-track prefetch now starts near the end of the current track rather than at 50–72%: 90% Low, 88% Normal/Automatic, 85% High, and 82% Very High. Data Saver still disables speculative prefetch.
- The speculative next-track request is abortable. A user Pause or a different track selection cancels it; selecting the already-prefetched next track promotes the request instead of aborting it.
- Daily Mix generation on mobile is now user-initiated through the existing refresh control. Opening Home no longer starts multiple extractor/search jobs automatically.
- Followed-artist metadata is deferred on mobile Home and is resolved when the Artists view is opened.
- The mobile player render loop is capped at 15 FPS even when the desktop Performance mode flag is set. The loop still stops when the player sheet is closed, the page is hidden, or playback is paused.
- The sleep timer keeps its per-second countdown only while the app is visible; while backgrounded it schedules one timeout for the deadline and resumes the visible countdown when the app returns.
- The media-session wake/Wi-Fi locks are retained for active playback and buffering, but the post-Pause lock-release grace is reduced from 15 seconds to 3 seconds.
- Notification artwork is limited to 256 px and 4 MB, and stale queued artwork requests are skipped.
- Removed the optional `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` permission, its Settings row, and its native bridge methods. Android battery optimization remains enabled by default; background playback continues to use the existing media playback foreground service, `WAKE_LOCK`, and media playback permissions.
- The 10-minute paused foreground-service grace is deliberately retained because the native code documents it as protection for notification resume/next actions on Android 15+. During this paused grace, the CPU/Wi-Fi locks are released after 3 seconds; the service does not run a periodic polling loop.

### Theme simplification and GPU work

- Mobile Theme settings now expose the visual theme choice, Light/Dark/Auto mode, accent color, interface opacity, and optional cover-derived background.
- Removed the extra five-channel palette editor and preset palette UI from mobile. Existing extra palette values are reset to defaults on the mobile upgrade; the saved accent color is retained.
- Removed custom image/GIF/video app backgrounds from the mobile experience and clear their old preference keys. The cover-derived background option remains.
- Hid extra hue/intensity/brightness, text-opacity, manual glass-blur strength, mesh, automatic opacity, and custom Home icon controls on mobile. The underlying desktop controls and code paths remain intact.
- Liquid Glass remains translucent but uses a smaller mobile blur radius to reduce GPU work without changing component geometry or navigation layout.
- Disabled mobile mesh and ambient background layers; existing layout and card geometry are retained.

### Language

- Added `Prics Play` to the translation keep-list so the brand name is not translated when used alone.
- Added i18n markers to dynamic mobile quality options/status, visual-theme labels, bottom navigation, and Library shortcuts/hub.
- Library empty-state and track-count text use the live translation helper so they update when the user changes language.

### Version and updater

- `package.json`, `package-lock.json`, build metadata, About version text, updater fallback, and Android Gradle fallback now target `2.3.1`.
- The application ID remains `io.github.cloverscripts.muriel`.
- Android versionCode calculation and the existing release workflows/signing-key cache are unchanged. The workflow and source selector were not duplicated or rewritten.

## Files changed

- `app.js`
- `i18n.js`
- `index.html`
- `package.json`
- `package-lock.json`
- `build-info.js`
- `update-notifier.js`
- `android/app/build.gradle`
- `android/app/src/main/AndroidManifest.xml`
- `android/app/src/main/java/io/github/cloverscripts/muriel/MediaControlsPlugin.java`
- `mobile/build.mjs`
- `mobile/media-controls.js`
- `mobile/mobile-ui.js`
- `mobile/neubrutalism.js`
- `mobile/mobile.css`
- `README.md`
- `implementation.md`
- `PRICS-PLAY-2.3.1-IMPLEMENTATION-REPORT.md`
- `PRICS-PLAY-2.3.1-RELEASE-NOTES.md`
- `test/media-controls.test.js`
- `test/i18n.test.js`
- `test/mobile-neubrutalism.test.js`
- `test/prics-play-v231.test.js` (renamed from the 2.3.0 version test)
- `test/prics-2.3.1-power-and-simplicity.test.js` (new)

## Verification

- JavaScript syntax checks: all 129 JavaScript/MJS files passed.
- Android manifest and Android string resources: XML parse passed.
- Focused regression tests: 56 passed across the mobile resource, media controls, theme, version, updater, source-selector, and i18n test groups.
- Full test suite: 317 tests total; 316 passed and 1 could not run successfully because `test/library-import.test.js` requires the unavailable `electron` package (`Cannot find module 'electron'`).
- All tests excluding the Electron-dependent `test/library-import.test.js`: 315 passed, 0 failed.
- `npm ci`: not completed because npm registry requests failed with `EAI_AGAIN` in this environment; the missing Electron dependency is therefore an environment limitation, not a source assertion failure.
- `node mobile/build.mjs`: not run because the dependency install could not complete (`esbuild` is unavailable locally).
- Gradle APK build: not run; Android SDK is not configured in this environment.
- Battery/data measurements: not run on a physical device. The changes reduce identifiable speculative work, but no percentage battery improvement is claimed.
- Background playback, headset, notification, and Android 15+ pause/resume behavior require a physical-device regression test.

## Release gates

1. Upload `Prics-Play-2.3.1-Android.zip` to the repository root.
2. Confirm the existing Android workflow selects the 2.3.1 archive and succeeds.
3. Confirm `Prics-Play.apk` and its matching SHA-256 checksum are attached to `v2.3.1`.
4. Compare the APK signing certificate with the installed 2.3.0 certificate before attempting an in-place update.
5. Test play/pause/resume, next/previous, shuffle/repeat, seek, notification/headset controls, background playback, language switching, and both themes on a physical Android device.
6. Measure battery over the same duration and usage pattern before claiming an improvement.

Historical ZIP archives and GitHub Releases must remain intact.
