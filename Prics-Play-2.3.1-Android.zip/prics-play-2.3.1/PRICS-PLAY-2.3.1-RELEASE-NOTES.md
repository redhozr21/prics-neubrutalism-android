# Prics Play 2.3.1 — Release Notes

## Focus: lower unnecessary battery and data use

- Android downloads the next song later in the current track. Data Saver does not prefetch, and speculative downloads are cancelled when you pause or choose another song.
- Daily Mixes are generated only when you tap refresh on Android, rather than automatically running extractor/search jobs whenever Home opens.
- Followed-artist artwork/metadata is loaded when you open Artists, not automatically for the Home screen.
- The mobile player UI uses a 15 FPS update cap while the full-screen player is active. It still sleeps when the player is closed, playback is paused, or the app is hidden.
- The sleep timer no longer polls every second while the app is backgrounded; it waits for the deadline and resumes its visible countdown when the app returns.
- Playback wake/Wi-Fi locks are released 3 seconds after Pause. The Android media foreground service remains so lock-screen and background playback controls continue to work.
- Notification artwork downloads are smaller and stale artwork requests are skipped.

## Simpler Theme settings

Android Theme settings focus on:
- Neubrutalism or Liquid Glass.
- Light, Dark, or Auto mode.
- Accent color.
- Interface opacity.
- Optional cover-derived background.

Extra mobile palette presets, custom app backgrounds, mesh controls, and redundant appearance sliders have been removed from the mobile settings. Liquid Glass keeps its glass appearance with a smaller blur radius to reduce GPU work. Layout geometry is unchanged.

## Language fixes

- Dynamic mobile streaming-quality labels/status, theme selector labels, navigation labels, and Library hub text now participate in language switching.
- `Prics Play` is protected as a brand name.

## Compatibility and safety

- Application ID remains `io.github.cloverscripts.muriel`.
- Existing media playback foreground service, notification controls, headset controls, and background playback paths are retained.
- The app no longer requests exemption from Android battery optimization. Normal system battery optimization remains enabled.
- Existing versioned releases and source ZIPs are not deleted or replaced.

## Important verification note

This source package has passed targeted automated tests, but a full Android APK build and physical-device battery comparison have not been completed in the authoring environment. Do not claim a measured battery percentage improvement until the APK is built and tested on-device. In-place update from 2.3.0 also requires the same signing certificate.
