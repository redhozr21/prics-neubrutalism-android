window.MURIEL_BUILD = {"sha":"dev","version":"2.3.1","run":0,"repo":"redhozr21/prics-neubrutalism-android","builtAt":"2026-10-30T02:46:13.014Z","channel":""};
