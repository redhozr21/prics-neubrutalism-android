const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');

test('mobile defaults preserve saved preferences while enabling Spotify home and Neubrutalism', () => {
  const bridge = read('mobile/bridge.js');
  assert.match(bridge, /if \(!localStorage\.getItem\('muriel_theme_mode'\)\) localStorage\.setItem\('muriel_theme_mode', 'light'\)/);
  assert.match(bridge, /if \(!localStorage\.getItem\('muriel_theme_accent'\)\) localStorage\.setItem\('muriel_theme_accent', '#FFE14A'\)/);
  assert.match(bridge, /if \(!localStorage\.getItem\('muriel_home_layout'\)\) localStorage\.setItem\('muriel_home_layout', 'spotify'\)/);
  assert.match(bridge, /classList\.add\('is-mobile', 'neo-theme'\)/);
});

test('mobile bundle ships the Neubrutalism layer after the app and mobile behavior scripts', () => {
  const build = read('mobile/build.mjs');
  assert.match(build, /neubrutalism\.js/);
  const injection = build.slice(build.indexOf(".replace('<script src=\"app.js\""));
  assert.ok(injection.indexOf('mobile-ui.js') >= 0);
  assert.ok(injection.indexOf('mobile-ui.js') < injection.indexOf('neubrutalism.js'));
});

test('Neubrutalism supports independently saved accent, background, surface, ink, and secondary colors', () => {
  const skin = read('mobile/neubrutalism.js');
  for (const key of ['muriel_theme_accent', 'muriel_neo_background', 'muriel_neo_surface', 'muriel_neo_ink', 'muriel_neo_secondary']) {
    assert.ok(skin.includes(key), `missing palette key ${key}`);
  }
  assert.match(skin, /data-neo-preset="bubblegum"/);
  assert.match(skin, /data-neo-preset="night"/);
  assert.match(skin, /data-open-view="favorites"/);
});

test('mobile CSS styles the custom bottom navigation and hard-outline cards', () => {
  const css = read('mobile/mobile.css');
  assert.match(css, /\.neo-bottom-nav/);
  assert.match(css, /box-shadow: 4px 4px 0 var\(--neo-ink\)/);
  assert.match(css, /\.neo-theme-customizer/);
});


test('Prics Play branding and updater target the owned GitHub repository', () => {
  const html = read('index.html');
  const updater = read('update-notifier.js');
  const cap = read('capacitor.config.json');
  assert.match(html, /<title>Prics Play<\/title>/);
  assert.match(html, /logo-star prics-logo/);
  assert.match(html, /Prics Play is a free, independent player/);
  assert.match(updater, /const REPO = 'redhozr21\/prics-neubrutalism-android'/);
  assert.match(updater, /`https:\/\/api\.github\.com\/repos\/\$\{REPO\}\/releases\/latest`/);
  assert.match(updater, /\.apk\$\/i/);
  assert.match(read('mobile/neubrutalism.js'), /--neo-paper', colors\.background/);
  assert.equal(JSON.parse(cap).appName, 'Prics Play');
});

test('mobile seekbar supports pointer events and shuffle reorders the queue', () => {
  const app = read('app.js');
  const css = read('mobile/mobile.css');
  assert.match(app, /addEventListener\('pointerdown'/);
  assert.match(app, /addEventListener\('pointermove'/);
  assert.match(app, /state\.queue = current \? \[current, \.\.\.upcoming/);
  assert.match(css, /scrubber-track-container \{ touch-action: none/);
  assert.match(app, /prics_play_shuffle_queue_v1/);
});
