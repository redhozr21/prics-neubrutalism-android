// Mobile-only Neubrutalism skin and Spotify-like primary navigation.
// This layer only changes presentation and navigation; the existing playback engine stays untouched.
(() => {
  const root = document.documentElement;
  if (!root.classList.contains('is-mobile')) return;

  const COLORS = {
    light: { accent: '#FFE14A', background: '#FFF8E7', surface: '#FFFFFF', ink: '#171717', secondary: '#FF8A65', tertiary: '#9BE7B5' },
    dark:  { accent: '#FFE14A', background: '#181818', surface: '#252525', ink: '#FFF8E7', secondary: '#FF8A65', tertiary: '#9BE7B5' },
  };
  const KEYS = {
    accent: 'muriel_theme_accent',
    background: 'muriel_neo_background',
    surface: 'muriel_neo_surface',
    ink: 'muriel_neo_ink',
    secondary: 'muriel_neo_secondary',
  };
  const isHex = (value) => typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value);
  const getColor = (key, fallback) => {
    try {
      const value = localStorage.getItem(KEYS[key]);
      return isHex(value) ? value : fallback;
    } catch (_) { return fallback; }
  };
  const setStored = (key, value) => {
    try { localStorage.setItem(KEYS[key], value); } catch (_) {}
  };

  function applyPalette() {
    const mode = document.body.classList.contains('theme-dark') ? 'dark' : 'light';
    const defaults = COLORS[mode];
    const colors = {
      accent: getColor('accent', defaults.accent),
      background: getColor('background', defaults.background),
      surface: getColor('surface', defaults.surface),
      ink: getColor('ink', defaults.ink),
      secondary: getColor('secondary', defaults.secondary),
      tertiary: defaults.tertiary,
    };
    Object.entries(colors).forEach(([key, value]) => root.style.setProperty(`--neo-${key}`, value));
    root.style.setProperty('--neo-border-width', '2px');
    root.style.setProperty('--neo-shadow-size', '4px');

    const pickerIds = {
      accent: 'neo-color-accent', background: 'neo-color-background', surface: 'neo-color-surface',
      ink: 'neo-color-ink', secondary: 'neo-color-secondary',
    };
    Object.entries(pickerIds).forEach(([key, id]) => {
      const input = document.getElementById(id);
      if (input && input.value !== colors[key]) input.value = colors[key];
    });
  }

  function setAccent(value) {
    if (!isHex(value)) return;
    setStored('accent', value);
    const legacyPicker = document.getElementById('settings-custom-color-input');
    if (legacyPicker && legacyPicker.value.toLowerCase() !== value.toLowerCase()) {
      legacyPicker.value = value;
      legacyPicker.dispatchEvent(new Event('input', { bubbles: true }));
    }
    applyPalette();
  }

  function addPaletteCustomizer() {
    const section = document.querySelector('.settings-section[data-cat="theme"]');
    const group = section && section.querySelector('.m3-group[data-group="colors"]');
    if (!group || group.querySelector('.neo-theme-customizer')) return;

    const card = document.createElement('div');
    card.className = 'setting-item neo-theme-customizer';
    card.innerHTML = `
      <div class="neo-customizer-head">
        <div>
          <span class="setting-name">Neubrutalism palette</span>
          <p>Atur warna aksen, latar, kartu, teks, dan warna sekunder.</p>
        </div>
        <span class="neo-theme-chip">NEO</span>
      </div>
      <div class="neo-color-grid">
        <label class="neo-color-field" for="neo-color-accent"><span>Aksen</span><input id="neo-color-accent" data-neo-color="accent" type="color" value="#FFE14A"></label>
        <label class="neo-color-field" for="neo-color-background"><span>Latar</span><input id="neo-color-background" data-neo-color="background" type="color" value="#FFF8E7"></label>
        <label class="neo-color-field" for="neo-color-surface"><span>Kartu</span><input id="neo-color-surface" data-neo-color="surface" type="color" value="#FFFFFF"></label>
        <label class="neo-color-field" for="neo-color-ink"><span>Teks &amp; outline</span><input id="neo-color-ink" data-neo-color="ink" type="color" value="#171717"></label>
        <label class="neo-color-field" for="neo-color-secondary"><span>Aksen sekunder</span><input id="neo-color-secondary" data-neo-color="secondary" type="color" value="#FF8A65"></label>
      </div>
      <div class="neo-preset-label">Preset cepat</div>
      <div class="neo-preset-grid">
        <button type="button" class="neo-preset" data-neo-preset="pop">Pop</button>
        <button type="button" class="neo-preset" data-neo-preset="bubblegum">Bubblegum</button>
        <button type="button" class="neo-preset" data-neo-preset="lime">Lime</button>
        <button type="button" class="neo-preset" data-neo-preset="ocean">Ocean</button>
        <button type="button" class="neo-preset" data-neo-preset="night">Night</button>
      </div>
      <button type="button" class="neo-reset-palette" id="neo-reset-palette">Reset warna</button>
    `;
    group.prepend(card);

    card.querySelectorAll('[data-neo-color]').forEach((input) => {
      input.addEventListener('input', () => {
        const key = input.dataset.neoColor;
        if (key === 'accent') setAccent(input.value);
        else {
          setStored(key, input.value);
          applyPalette();
        }
      });
    });

    const presets = {
      pop:       { accent: '#FFE14A', background: '#FFF8E7', surface: '#FFFFFF', ink: '#171717', secondary: '#FF8A65' },
      bubblegum: { accent: '#FF70B8', background: '#FFF0F7', surface: '#FFFFFF', ink: '#281321', secondary: '#8DDBFF' },
      lime:      { accent: '#C7FF4A', background: '#F5FFE5', surface: '#FFFFFF', ink: '#19230B', secondary: '#A18BFF' },
      ocean:     { accent: '#59C8FF', background: '#EEF9FF', surface: '#FFFFFF', ink: '#102333', secondary: '#FFD166' },
      night:     { accent: '#FFE14A', background: '#181818', surface: '#252525', ink: '#FFF8E7', secondary: '#FF7B61' },
    };
    card.querySelectorAll('[data-neo-preset]').forEach((button) => {
      button.addEventListener('click', () => {
        const preset = presets[button.dataset.neoPreset];
        if (!preset) return;
        Object.entries(preset).forEach(([key, value]) => {
          if (key === 'accent') setStored('accent', value);
          else setStored(key, value);
        });
        const legacyPicker = document.getElementById('settings-custom-color-input');
        if (legacyPicker) {
          legacyPicker.value = preset.accent;
          legacyPicker.dispatchEvent(new Event('input', { bubbles: true }));
        }
        applyPalette();
      });
    });

    const reset = card.querySelector('#neo-reset-palette');
    reset.addEventListener('click', () => {
      ['background', 'surface', 'ink', 'secondary'].forEach((key) => {
        try { localStorage.removeItem(KEYS[key]); } catch (_) {}
      });
      setAccent(COLORS.light.accent);
      applyPalette();
    });
  }

  function addSpotifyNavigation() {
    const sidebar = document.getElementById('sidebar');
    if (!sidebar || sidebar.querySelector('.neo-bottom-nav')) return;
    sidebar.classList.add('neo-sidebar');

    const nav = document.createElement('nav');
    nav.className = 'neo-bottom-nav';
    nav.setAttribute('aria-label', 'Navigasi utama');
    nav.innerHTML = `
      <button type="button" class="neo-tab active" data-tab="home" aria-label="Home">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/></svg><span>Home</span>
      </button>
      <button type="button" class="neo-tab" data-tab="search" aria-label="Search">
        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 5 5"/></svg><span>Search</span>
      </button>
      <button type="button" class="neo-tab" data-tab="library" aria-label="Your Library">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4v16M9 4v16M14 4v16M19 4v16"/></svg><span>Library</span>
      </button>
      <button type="button" class="neo-tab" data-tab="settings" aria-label="Settings">
        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1-2.7 2.7-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5v.2h-3.8v-.2a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1-2.7-2.7.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3.5v-3.8h.2a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1 2.7-2.7.1.1a1.7 1.7 0 0 0 1.8.3 1.7 1.7 0 0 0 1-1.5V3.5h3.8v.2a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1 2.7 2.7-.1.1a1.7 1.7 0 0 0-.3 1.8 1.7 1.7 0 0 0 1.5 1h.2v3.8h-.2a1.7 1.7 0 0 0-1.5 1z"/></svg><span>Settings</span>
      </button>`;
    sidebar.appendChild(nav);

    const setActive = (tab) => nav.querySelectorAll('.neo-tab').forEach((button) => button.classList.toggle('active', button.dataset.tab === tab));
    const clickExisting = (id) => { const button = document.getElementById(id); if (button) button.click(); };
    const searchInput = document.getElementById('search-input');
    let searchMode = false;

    nav.querySelector('[data-tab="home"]').addEventListener('click', () => {
      searchMode = false;
      if (searchInput && searchInput.value) clickExisting('search-clear-btn');
      clickExisting('nav-discover');
      setActive('home');
      if (document.activeElement === searchInput && searchInput) searchInput.blur();
    });
    nav.querySelector('[data-tab="search"]').addEventListener('click', () => {
      searchMode = true;
      clickExisting('nav-discover');
      setActive('search');
      if (searchInput) setTimeout(() => searchInput.focus(), 80);
    });
    nav.querySelector('[data-tab="library"]').addEventListener('click', () => {
      searchMode = false;
      const drawer = document.getElementById('rail-drawer');
      if (!drawer || drawer.classList.contains('hidden')) clickExisting('btn-toggle-playlists-drawer');
      setActive('library');
    });
    nav.querySelector('[data-tab="settings"]').addEventListener('click', () => {
      searchMode = false;
      clickExisting('nav-settings');
      setActive('settings');
    });

    const drawer = document.getElementById('rail-drawer');
    if (drawer && !drawer.querySelector('.neo-library-shortcuts')) {
      const shortcuts = document.createElement('div');
      shortcuts.className = 'neo-library-shortcuts';
      shortcuts.innerHTML = `
        <button type="button" data-open-view="favorites"><span class="neo-shortcut-icon">♥</span><span><b>Liked songs</b><small>Favorit kamu</small></span></button>
        <button type="button" data-open-view="albums"><span class="neo-shortcut-icon">▣</span><span><b>Albums</b><small>Koleksi album</small></span></button>
        <button type="button" data-open-view="artists"><span class="neo-shortcut-icon">♫</span><span><b>Artists</b><small>Artis yang diikuti</small></span></button>
        <button type="button" data-open-view="local"><span class="neo-shortcut-icon">▤</span><span><b>On this device</b><small>Musik lokal</small></span></button>
        <button type="button" data-open-view="history"><span class="neo-shortcut-icon">◷</span><span><b>Recently played</b><small>Riwayat dengar</small></span></button>`;
      const playlistSection = drawer.querySelector('#drawer-section-playlists');
      if (playlistSection) drawer.insertBefore(shortcuts, playlistSection);
      shortcuts.querySelectorAll('[data-open-view]').forEach((button) => {
        button.addEventListener('click', () => {
          const view = button.dataset.openView;
          clickExisting('btn-close-rail-drawer');
          setActive('library');
          const targetId = ({ favorites: 'nav-favorites', albums: 'nav-albums', artists: 'nav-artists', local: 'nav-local', history: 'nav-history' })[view];
          if (targetId) clickExisting(targetId);
          setActive('library');
        });
      });
    }

    // Keep the custom tab selection in sync with the app's existing view controller.
    ['nav-discover', 'nav-favorites', 'nav-albums', 'nav-artists', 'nav-local', 'nav-history', 'nav-settings'].forEach((id) => {
      const button = document.getElementById(id);
      if (!button) return;
      button.addEventListener('click', () => {
        if (id === 'nav-discover') setActive(searchMode ? 'search' : 'home');
        else if (id === 'nav-settings') setActive('settings');
        else setActive('library');
      });
    });
    if (searchInput) {
      searchInput.addEventListener('focus', () => { if (searchMode) setActive('search'); });
      searchInput.addEventListener('input', () => { if (searchInput.value.trim()) { searchMode = true; setActive('search'); } else if (searchMode && document.activeElement === searchInput) setActive('search'); });
    }
    const drawerTitle = document.getElementById('rail-drawer-title');
    const refreshDrawerTitle = () => {
      if (drawerTitle && drawer && !drawer.classList.contains('drawer-presets-mode') && !drawer.classList.contains('hidden') && drawerTitle.textContent !== 'Your Library') drawerTitle.textContent = 'Your Library';
    };
    if (drawer) new MutationObserver(refreshDrawerTitle).observe(drawer, { attributes: true, attributeFilter: ['class'] });
    if (drawerTitle) new MutationObserver(refreshDrawerTitle).observe(drawerTitle, { childList: true, characterData: true, subtree: true });
  }

  function finishInit() {
    addPaletteCustomizer();
    addSpotifyNavigation();

    // Existing theme controls remain compatible with the new palette.
    document.querySelectorAll('.theme-swatch').forEach((button) => button.addEventListener('click', () => setTimeout(applyPalette, 0)));
    const legacyPicker = document.getElementById('settings-custom-color-input');
    if (legacyPicker) legacyPicker.addEventListener('input', applyPalette);
    const hueSlider = document.getElementById('slider-theme-hue');
    if (hueSlider) hueSlider.addEventListener('change', () => setTimeout(applyPalette, 0));
    document.querySelectorAll('.theme-mode-btn[data-theme-mode]').forEach((button) => button.addEventListener('click', () => setTimeout(applyPalette, 0)));

    let lastMode = document.body.classList.contains('theme-dark') ? 'dark' : 'light';
    new MutationObserver(() => {
      const nextMode = document.body.classList.contains('theme-dark') ? 'dark' : 'light';
      if (nextMode !== lastMode) { lastMode = nextMode; applyPalette(); }
    }).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  }

  function init() {
    applyPalette();
    if (window.MurielCore) finishInit();
    else window.addEventListener('muriel:ready', finishInit, { once: true });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
