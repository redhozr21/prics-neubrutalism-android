window.MURIEL_BUILD = {"sha":"dev","version":"3.1.1","run":0,"repo":"redhozr21/prics-neubrutalism-android","builtAt":"2026-11-01T14:40:00.000Z","channel":""};
