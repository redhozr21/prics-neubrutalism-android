# Prics Play 2.3.2 — Performance Edition

This source release keeps the Prics Play 2.3.1 mobile navigation and visual system while reducing avoidable mobile CPU, network, filesystem and GPU work.

## Performance changes

- Mobile Performance mode is enabled by default only when the user has not already saved a preference. Users can turn it off in Settings.
- The mobile Now Playing update loop uses a 12 FPS timer instead of scheduling callbacks at the display refresh rate. The gradient lyric animation loop is stopped in Performance mode.
- Daily Mix generation no longer runs automatically on mobile Home. Users can generate it explicitly; mobile generation is limited to two mixes per request. Desktop behavior is retained.
- Mobile next-track prefetch is off by default because it downloads an additional full song before the current one ends. It can be enabled in Tracks → Playback settings.
- Mobile startup scans only feature-critical app-data directories. Desktop-only `bin`, `plugins`, `logs` and temporary directory contents are not recursively scanned. User data is not deleted.
- Public Android `Music/Muriel` Downloads are indexed on demand, by direct children only. Cached songs bypass the public-download lookup.
- LRC text is loaded on first lyric request rather than all at startup.
- The YouTube/SoundCloud extractor is initialized only when a search or stream operation needs it.
- Cache-limit enforcement after downloads is debounced. Manual cache-limit enforcement remains immediate.
- Fresh Trending cache timestamps are honored across app restarts. Followed-artist artwork metadata is not fetched automatically from mobile Home and is limited to three lookups per batch on mobile.
- Repeated Liquid Glass mobile cards keep translucent fills and shadows but no longer use repeated backdrop blur.

## Preserved behavior

- Android application ID, iOS bundle ID, signing identity, deep-link scheme, update identity and persistent data paths.
- Audio engine, stream resolution, playback, queue, playlists, favorites, albums, followed artists, lyrics, local music, downloads, sync, backup, restore and integrations.
- Android foreground media service, media notification, lock-screen controls, wake-lock behavior and screen-off playback path. These were intentionally not removed because they protect background playback and need physical-device validation before changing.
- Desktop recommendation generation, desktop visualizer behavior and desktop plugin management.

## Verification

- 130 JavaScript/MJS/CJS files passed `node --check`.
- 324/324 tests passed when the Electron-dependent `test/library-import.test.js` file was excluded.
- Full `node --test`: 325 passed, 1 failed because the environment does not have the `electron` package required by `google-library.js`.
- Mobile bundle build was not completed because `esbuild` is not installed in this environment.
- Android APK build and physical-device validation were not completed because Android SDK/ADB are not configured here.

## Performance claims and remaining validation

This is a source-level optimization release, not a measured battery benchmark. No exact battery percentage, CPU reduction or temperature improvement is claimed until 2.3.2 is built and compared on the same Android device under identical test conditions. Background playback and wake-lock behavior must be checked with the screen locked before release distribution.
