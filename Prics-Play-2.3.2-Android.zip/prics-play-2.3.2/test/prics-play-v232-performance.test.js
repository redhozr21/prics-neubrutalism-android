'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');

test('mobile Daily Mix generation is user-initiated and capped at two mixes', () => {
  const app = read('app.js');
  const section = app.slice(app.indexOf('function renderMadeForYou()'), app.indexOf('// ---- Trending now'));
  assert.match(app, /max: isPhoneApp \? 2 : 5/);
  assert.match(section, /!isPhoneApp && !mixesTimer/);
  assert.match(section, /title: 'Create a Daily Mix'/);
  assert.match(section, /onClick: \(\) => \{/);
  assert.match(section, /generateDailyMixes\(true\)/);
});

test('mobile next-song prefetch is off by default and can be explicitly enabled', () => {
  const app = read('app.js');
  const ui = read('mobile/mobile-ui.js');
  assert.match(app, /localStorage\.getItem\('prics_mobile_prefetch_next'\) !== '1'/);
  assert.match(ui, /Preload next song/);
  assert.match(ui, /prics_mobile_prefetch_next/);
  assert.match(ui, /off by default/);
});

test('mobile defaults to low-power presentation without overriding an explicit user choice', () => {
  const app = read('app.js');
  assert.match(app, /isPhoneApp && localStorage\.getItem\('muriel_perf_mode'\) === null/);
  assert.match(app, /localStorage\.setItem\('muriel_perf_mode', '1'\)/);
  assert.match(app, /const initialPerfMode = localStorage\.getItem\('muriel_perf_mode'\) === '1'/);
});

test('mobile player frame work is throttled to a 12 FPS timer instead of display-refresh RAF callbacks', () => {
  const app = read('app.js');
  assert.match(app, /function scheduleVisualizerFrame\(callback\)/);
  assert.match(app, /animationFrameId = setTimeout\([\s\S]*?1000 \/ 12/);
  assert.match(app, /isPhoneApp \? 12/);
  assert.match(app, /cancelVisualizerFrame\(\)/);
});

test('Performance mode stops the animated lyric-gradient RAF loop', () => {
  const app = read('app.js');
  assert.match(app, /function startGradientLoop\(\) \{\s*if \(document\.body\.classList\.contains\('perf'\) \|\| gradientRaf\) return/);
  assert.match(app, /if \(on && gradientRaf\) \{ cancelAnimationFrame\(gradientRaf\); gradientRaf = 0; \}/);
});

test('cached tracks skip the public Downloads lookup', () => {
  const server = read('server.js');
  assert.match(server, /const cachedFile = cleanId \? await findCachedFile\(cleanId\) : null/);
  assert.match(server, /!cachedFile && \(title \|\| artist\) \? await findDownloadedFile/);
});

test('fresh Trending cache survives cold starts and avoids a repeat fetch', () => {
  const app = read('app.js');
  assert.match(app, /const cachedAt = hasCached \? Number\(cached\.at\) \|\| 0 : 0/);
  assert.match(app, /cacheAge < 3600e3/);
});

test('followed-artist metadata is not fetched automatically from mobile Home', () => {
  const app = read('app.js');
  assert.match(app, /slice\(0, isPhoneApp \? 3 : 8\)/);
  assert.match(app, /on && state\.serverPort && !isPhoneApp/);
  assert.match(app, /if \(state\.serverPort\) fetchFollowedMeta\(list\)/);
});

test('mobile startup indexes feature-critical folders and defers public Downloads enumeration', () => {
  const store = read('mobile/shims/store.js');
  const shim = read('mobile/shims/fs.js');
  assert.match(store, /scanAtStartup = new Set\(\['tracks', 'custom-lyrics', 'lyrics', 'thumbnails', 'library', 'backgrounds', 'Downloads'\]\)/);
  assert.match(store, /async listDownloads\(\)/);
  assert.match(store, /not during every cold start/);
  assert.match(shim, /ensurePublicDownloadsIndexed/);
  assert.match(shim, /await ensurePublicDownloadsIndexed\(p\)/);
});

test('lyrics file contents are loaded on demand instead of all at startup', () => {
  const shim = read('mobile/shims/fs.js');
  assert.match(shim, /entries\.filter\(\(e\) => !e\.isDir && \/\\\.\(json\|txt\)\$\/i\.test\(e\.vpath\)\)/);
  assert.match(shim, /node\.text = await store\.readText\(p\)/);
});

test('YouTube/SoundCloud extractor is required only when a search or stream request needs it', () => {
  const child = read('mobile/shims/child_process.js');
  assert.match(child, /const getExtractor = \(\) => extractor \|\| \(extractor = require\('\.\.\/extract'\)\)/);
  assert.doesNotMatch(child, /^const ex = require\('\.\.\/extract'\)/m);
});

test('cache-limit scans are debounced after downloads while manual limit enforcement remains available', () => {
  const cache = read('mobile/cache-limit.js');
  const child = read('mobile/shims/child_process.js');
  const bridge = read('mobile/bridge.js');
  assert.match(cache, /function scheduleEnforceCacheLimit\(delay = 4000\)/);
  assert.match(child, /scheduleEnforceCacheLimit\(\)/);
  assert.match(bridge, /enforceLimit: \(\) => enforceCacheLimit\(\)/);
});

test('Liquid Glass mobile cards retain translucent styling without repeated backdrop blur', () => {
  const css = read('mobile/mobile.css');
  const rule = css.slice(css.indexOf('html.is-mobile.liquid-glass-theme .prics-search-hint'), css.indexOf('html.is-mobile.liquid-glass-theme .prics-genre-card.tone-coral'));
  assert.match(rule, /backdrop-filter:none/);
  assert.match(rule, /-webkit-backdrop-filter:none/);
});
