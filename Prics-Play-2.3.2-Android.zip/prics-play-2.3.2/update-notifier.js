// Prics Play updater: checks immutable GitHub Releases and, on Android, downloads/verifies
// the APK in-app before handing it to Android's user-confirmed package installer.
(() => {
  const REPO = 'redhozr21/prics-neubrutalism-android';
  const RELEASES_API = `https://api.github.com/repos/${REPO}/releases/latest`;
  const store = {
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} },
  };
  const build = window.MURIEL_BUILD || {};
  const CURRENT_VERSION = String(build.version || '2.3.2');
  const CURRENT_BUILD = Number(build.run) || 0;
  const statusEl = document.getElementById('update-status');
  const checkBtn = document.getElementById('btn-check-updates');
  const aboutVersion = document.getElementById('about-version');
  const detailsEl = document.getElementById('update-details');
  const notesEl = document.getElementById('update-release-notes');
  const progressWrap = document.getElementById('update-progress-wrap');
  const progressEl = document.getElementById('update-progress');
  const progressLabel = document.getElementById('update-progress-label');
  const installBtn = document.getElementById('btn-install-update');
  let current = null;
  let checking = false;
  let downloading = false;
  let downloaded = null;
  let progressListener = null;

  function versionParts(value) {
    const match = String(value || '').trim().match(/^(\d+)\.(\d+)\.(\d+)$/);
    return match ? match.slice(1, 4).map(Number) : null;
  }
  function compareVersions(a, b) {
    const left = versionParts(a), right = versionParts(b);
    if (!left || !right) return null;
    for (let i = 0; i < 3; i++) if (left[i] !== right[i]) return left[i] > right[i] ? 1 : -1;
    return 0;
  }
  function setStatus(message, hasUpdate = false) {
    if (!statusEl) return;
    statusEl.textContent = message;
    statusEl.classList.toggle('has-update', !!hasUpdate);
  }
  function setCheckButton(label, disabled = false) {
    if (!checkBtn) return;
    checkBtn.textContent = label;
    checkBtn.disabled = !!disabled;
    checkBtn.setAttribute && checkBtn.setAttribute('aria-busy', downloading ? 'true' : 'false');
  }
  function showDetails(show) {
    if (detailsEl) detailsEl.hidden = !show;
  }
  function showInstall(show) {
    if (installBtn) installBtn.hidden = !show;
  }
  function cleanNotes(value) {
    return String(value || '').replace(/<!--[\s\S]*?-->/g, '').trim().slice(0, 1800);
  }
  function formatBytes(value) {
    const bytes = Number(value) || 0;
    if (bytes <= 0) return '';
    const mb = bytes / (1024 * 1024);
    return mb >= 100 ? `${Math.round(mb)} MB` : `${mb.toFixed(1)} MB`;
  }
  function isAndroidNative() {
    return !!(window.Capacitor && window.Capacitor.getPlatform && window.Capacitor.getPlatform() === 'android' &&
      window.PricsUpdate && typeof window.PricsUpdate.downloadApk === 'function' && typeof window.PricsUpdate.installApk === 'function');
  }
  function normalizeDigest(value) {
    const match = String(value || '').trim().match(/^(?:sha256:)?([a-f0-9]{64})$/i);
    return match ? match[1].toLowerCase() : '';
  }

  async function latestRelease() {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12000);
    try {
      const response = await fetch(RELEASES_API, {
        headers: { Accept: 'application/vnd.github+json' }, cache: 'no-store', signal: controller.signal,
      });
      if (!response.ok) return null;
      const release = await response.json();
      if (!release || release.draft || release.prerelease || !release.html_url) return null;
      return release;
    } catch (_) { return null; }
    finally { clearTimeout(timer); }
  }

  function describe(release) {
    const assets = Array.isArray(release.assets) ? release.assets : [];
    // The official Android workflow publishes exactly this filename. Do not silently select a
    // debug or unrelated APK if another workflow attaches one to the same GitHub release.
    const apk = assets.find((asset) => asset && typeof asset.name === 'string' &&
      asset.name.toLowerCase() === 'prics-play.apk' && asset.browser_download_url) || null;
    const checksumAsset = apk ? assets.find((asset) => asset && typeof asset.name === 'string' &&
      asset.name.toLowerCase() === 'prics-play.apk.sha256' && asset.browser_download_url) : null;
    const digest = normalizeDigest(apk && apk.digest);
    const body = String(release.body || '');
    // Stable releases must use an explicit semantic version tag; notes/title are not authoritative.
    const tagMatch = String(release.tag_name || '').match(/^v?(\d+\.\d+\.\d+)$/i);
    const version = tagMatch ? tagMatch[1] : '';
    const validVersion = !!version && !!versionParts(version);
    const buildMatch = body.match(/prics-play-build:\s*(\d+)/i) || body.match(/Build\s+(\d+)/i);
    const releaseBuild = Number((buildMatch && buildMatch[1]) || 0);
    const comparison = validVersion ? compareVersions(version, CURRENT_VERSION) : null;
    const newer = validVersion && comparison !== null && (comparison > 0 || (comparison === 0 && releaseBuild > CURRENT_BUILD));
    return {
      version, validVersion, build: releaseBuild, htmlUrl: release.html_url,
      url: apk ? apk.browser_download_url : release.html_url,
      apk: !!apk, assetName: apk ? apk.name : '', size: apk ? Number(apk.size) || 0 : 0,
      sha256: digest, checksumUrl: checksumAsset ? checksumAsset.browser_download_url : '',
      checksumAvailable: !!(digest || checksumAsset), notes: cleanNotes(body), comparison, newer,
    };
  }

  async function openExternal(url) {
    if (!url) return;
    const platform = window.Capacitor && window.Capacitor.getPlatform ? window.Capacitor.getPlatform() : '';
    if (platform === 'android' && window.PricsExternalUrl && typeof window.PricsExternalUrl.open === 'function') {
      try { await window.PricsExternalUrl.open(url); return; } catch (_) { /* fall back to normal navigation */ }
    }
    if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) window.location.href = url;
    else window.open(url, '_blank', 'noopener,noreferrer');
  }

  function renderAvailableUpdate() {
    if (!current) return;
    showDetails(true);
    if (notesEl) notesEl.textContent = current.notes || 'No release notes were provided for this version.';
    if (progressWrap) progressWrap.hidden = true;
    if (progressEl) { progressEl.value = 0; progressEl.removeAttribute && progressEl.removeAttribute('value'); }
    if (downloaded && downloaded.version === current.version) {
      setStatus(`Prics Play ${current.version} is downloaded and verified. Tap Install update to continue.`, true);
      showInstall(true);
      setCheckButton('Check now');
      return;
    }
    showInstall(false);
    if (!current.checksumAvailable) {
      setStatus(`Update ${current.version} is available, but its release has no SHA-256 checksum. Download is disabled for safety.`, true);
      setCheckButton('Check now');
      return;
    }
    const size = formatBytes(current.size);
    setStatus(`Update available: Prics Play ${current.version}${size ? ` · ${size}` : ''}`, true);
    setCheckButton('Download update');
  }

  async function check(manual = false) {
    if (checking || downloading) return;
    checking = true;
    if (manual) setStatus('Checking GitHub Releases…');
    try {
      const release = await latestRelease();
      if (!release) {
        current = null;
        showDetails(false);
        showInstall(false);
        setStatus('Unable to reach GitHub Releases. Check your connection or repository visibility.');
        setCheckButton('Check now');
        if (manual) store.set('prics_play_update_last_error', Date.now());
        return;
      }
      current = describe(release);
      if (!current.validVersion) {
        current = null;
        showDetails(false);
        showInstall(false);
        setStatus('The latest GitHub release does not use a valid X.Y.Z version tag. Update blocked for safety.');
        setCheckButton('Check now');
        return;
      }
      if (current.comparison === null) {
        current = null;
        showDetails(false);
        showInstall(false);
        setStatus('The installed app version cannot be compared safely. Update blocked for safety.');
        setCheckButton('Check now');
        return;
      }
      store.set('prics_play_latest_release', {
        version: current.version, build: current.build, url: current.url,
        apk: current.apk, sha256: current.sha256, checkedAt: Date.now(),
      });
      if (!current.newer) {
        showDetails(false);
        showInstall(false);
        if (current.comparison === -1) setStatus(`Installed Prics Play ${CURRENT_VERSION} is newer than the published release (${current.version}).`);
        else setStatus(`Prics Play ${CURRENT_VERSION} is up to date.`);
        setCheckButton('Check now');
        return;
      }
      if (!current.apk) {
        showDetails(false);
        showInstall(false);
        setStatus(`Prics Play ${current.version} is available, but the release has no APK attached.`);
        setCheckButton('Check now');
        return;
      }
      renderAvailableUpdate();
    } finally { checking = false; }
  }

  function updateProgress(progress = {}) {
    const received = Number(progress.receivedBytes) || 0;
    const total = Number(progress.totalBytes) || 0;
    const percent = Number(progress.percent);
    if (progressEl) {
      if (Number.isFinite(percent) && percent >= 0) progressEl.value = Math.max(0, Math.min(100, percent));
      else progressEl.removeAttribute && progressEl.removeAttribute('value');
    }
    if (progressLabel) {
      const receivedText = formatBytes(received) || '0 MB';
      const totalText = formatBytes(total);
      progressLabel.textContent = totalText && Number.isFinite(percent) && percent >= 0
        ? `${Math.round(percent)}% · ${receivedText} / ${totalText}`
        : `${receivedText} downloaded`;
    }
  }

  async function downloadUpdate() {
    if (downloading || !current || !current.newer || !current.apk) return;
    if (!current.checksumAvailable) {
      setStatus('This release has no verifiable SHA-256 checksum. Download was blocked.', true);
      return;
    }
    if (!isAndroidNative()) {
      const platform = window.Capacitor && window.Capacitor.getPlatform ? window.Capacitor.getPlatform() : '';
      await openExternal(platform === 'android' ? current.htmlUrl : current.url);
      return;
    }
    downloading = true;
    showDetails(true);
    showInstall(false);
    if (progressWrap) progressWrap.hidden = false;
    if (progressEl) { progressEl.value = 0; progressEl.removeAttribute && progressEl.removeAttribute('value'); }
    if (progressLabel) progressLabel.textContent = 'Preparing secure download…';
    setStatus(`Downloading Prics Play ${current.version}…`, true);
    setCheckButton('Downloading…', true);
    try {
      if (window.PricsUpdate.addListener) {
        try { progressListener = await window.PricsUpdate.addListener('downloadProgress', updateProgress); } catch (_) { progressListener = null; }
      }
      const result = await window.PricsUpdate.downloadApk({
        url: current.url,
        checksumUrl: current.checksumUrl || '',
        sha256: current.sha256 || '',
      });
      const verifiedHash = normalizeDigest(result && result.sha256);
      if (!verifiedHash) throw new Error('The native updater did not confirm APK checksum verification.');
      downloaded = { version: current.version, sha256: verifiedHash, bytes: Number(result.bytes) || current.size };
      updateProgress({ receivedBytes: downloaded.bytes, totalBytes: downloaded.bytes, percent: 100 });
      setStatus(`Prics Play ${current.version} downloaded and verified. Tap Install update to continue.`, true);
      showInstall(true);
      if (progressLabel) progressLabel.textContent = 'Download and SHA-256 verification complete.';
      setCheckButton('Check now');
    } catch (error) {
      downloaded = null;
      if (progressWrap) progressWrap.hidden = true;
      showInstall(false);
      setStatus(`Update download failed: ${String(error && error.message || error || 'unknown error')}`);
      setCheckButton('Download again');
    } finally {
      if (progressListener && typeof progressListener.remove === 'function') {
        try { await progressListener.remove(); } catch (_) {}
      }
      progressListener = null;
      downloading = false;
      if (checkBtn) checkBtn.disabled = false;
    }
  }

  async function installUpdate() {
    if (!downloaded || !isAndroidNative()) return;
    if (installBtn) installBtn.disabled = true;
    setStatus('Verifying APK and preparing Android installer…', true);
    try {
      const result = await window.PricsUpdate.installApk({ sha256: downloaded.sha256 });
      if (result && result.permissionRequired) {
        setStatus('Allow Prics Play to install unknown apps in Android Settings, return here, then tap Install update again.', true);
      } else {
        setStatus('Android installer opened. Confirm installation there to finish updating Prics Play.', true);
      }
    } catch (error) {
      setStatus(`Installation could not start: ${String(error && error.message || error || 'unknown error')}`);
    } finally {
      if (installBtn) installBtn.disabled = false;
    }
  }

  const versionLabel = `Version ${CURRENT_VERSION}${CURRENT_BUILD ? ` · Build ${CURRENT_BUILD}` : ''}`;
  if (aboutVersion) aboutVersion.textContent = versionLabel;
  if (statusEl) statusEl.textContent = `Prics Play ${CURRENT_VERSION}${CURRENT_BUILD ? ` · Build ${CURRENT_BUILD}` : ''}`;
  if (checkBtn) checkBtn.addEventListener('click', () => {
    if (current && current.newer && current.apk && current.checksumAvailable && !(downloaded && downloaded.version === current.version)) return downloadUpdate();
    return check(true);
  });
  if (installBtn) installBtn.addEventListener('click', installUpdate);

  // Quiet check after first paint; never start downloading without a user action.
  setTimeout(() => check(false), 2500);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) check(false); });
  window.PricsPlayUpdates = { check: () => check(true), latestRelease, compareVersions, downloadUpdate, installUpdate };
})();
