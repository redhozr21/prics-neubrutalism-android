# Prics Play 2.6.4 — Implementation Report

## Scope
Patch release based on the successful 2.6.3 source. This release addresses the issues shown in the latest Android Now Playing screenshot and adds the requested viral playlist shelf.

## Now Playing and Queue
- Added queue-view state to the mobile Now Playing header.
- When Queue is open, the header reads “ANTREAN PEMUTARAN”.
- The back arrow returns to Now Playing instead of dismissing the player sheet.
- The overflow menu updates its labels and disables the already-open Queue action.
- Raised the header/menu stacking context above artwork, playback controls, and the lyrics card.

## Shuffle and Repeat
- Shuffle and Repeat expose `aria-pressed`, `title`, and `data-mode`.
- Saved Shuffle state is applied through the same update path at startup and on taps.
- Shuffle active state has a clear cream fill, black outline/shadow, and coral indicator.
- Repeat-all has a coral indicator; Repeat-one has a visible “1” badge.

## Lyrics
- Genius scraper removes editorial SEO descriptions and trailing “Read More” text from lyric content.
- Lyrics provider selection continues past plain text to look for timestamped LRC lyrics, including a timed LRCLIB refresh when an older plain LRCLIB file is cached.
- Plain untimed lyrics automatically request NetEase YRC timed lines even when the user is in normal Line mode.
- NetEase lines replace plain lyrics only when at least 60% of its lines match the displayed lyric text.
- Mobile lyrics UI reports pending automatic lookup, hides manual Sync while the lookup is in progress, and exposes manual Sync only if no timed match is available.
- Timestamped lines remain tappable for seeking; current-line highlight and scroll follow the native audio clock.

## Home — Playlist Viral
- Added a shelf directly below Trending Now.
- Spotify Top 50 Indonesia and Hot Hits Indonesia are imported from their public Spotify playlist pages on demand and cached for 12 hours.
- YouTube Music Top Songs Indonesia uses the Top 15 songs from the 31 Oct 2026 YouTube Music Indonesia chart snapshot.
- Playlist tracks are opened as local Prics Play playlist views and resolved through YouTube Music search when played.
- This is metadata import and track matching, not Spotify-protected-audio playback.
- The previously removed Made for You shelf is not rendered in the Spotify-style Home.

## Card layout
- On Repeat rows use constrained columns, inner padding, and ellipsis.
- Track rows receive consistent left/right gutters and constrained title/artist/action columns.

## Preserved
- Compact Search/provider dimensions and matching shadows.
- 2.6.3 Settings spacing.
- Approved smaller header.
- Themes, integrations, About, app identity, and existing Android workflow.
- Package dependency versions are preserved; only package root app version metadata is changed.

## Validation
- JavaScript syntax checks, CSS parsing, focused regression tests, and full Node test suite are run locally.
- Full Android APK build and actual device playback/queue testing still need GitHub Actions and the target Android device.
- Compare APK signing certificates before installing over an existing version.
