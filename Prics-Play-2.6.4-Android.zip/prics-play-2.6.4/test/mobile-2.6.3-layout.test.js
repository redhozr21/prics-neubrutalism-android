const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const read = (name) => fs.readFileSync(path.join(__dirname, '..', name), 'utf8');

test('2.6.4 brand header keeps logo left and profile switch at the right', () => {
  const html = read('index.html');
  const css = read('mobile/mobile.css');
  assert.match(html, /<header class="titlebar" id="titlebar">[\s\S]*?class="app-logo"[\s\S]*?prics-header-mark[\s\S]*?prics-header-wordmark/);
  assert.match(css, /html\.is-mobile \.titlebar \.app-logo[\s\S]*?justify-content: flex-start/);
  assert.match(css, /Header: keep the new left-aligned brand[\s\S]*?html\.is-mobile \.titlebar \.profile-switch \{[\s\S]*?width: 46px/);
});

test('YouTube, YouTube Music and SoundCloud share one aligned provider card beside search', () => {
  const html = read('index.html');
  const css = read('mobile/mobile.css');
  assert.match(html, /class="platform-pill-switch"[\s\S]*?data-platform="youtube"[\s\S]*?data-platform="ytmusic"[\s\S]*?data-platform="soundcloud"/);
  assert.match(css, /html\.is-mobile\.neo-theme \.search-box,[\s\S]*?html\.is-mobile\.neo-theme \.platform-pill-switch[\s\S]*?box-shadow: 4px 4px 0/);
  assert.match(css, /PRICS PLAY 2\.6\.2[\s\S]*?height: 40px !important/);
});

test('mobile Now Playing reuses the original transport and queue controls', () => {
  const js = read('mobile/mobile-ui.js');
  assert.match(js, /playbar\.querySelector\('\.playbar-center'\)/);
  assert.match(js, /playbar\.querySelector\('\.playbar-right'\)/);
  assert.match(js, /playbackHost\.appendChild\(playbarCenter\)/);
  assert.match(js, /outputQueueSlot\.appendChild\(queueButton\)/);
  assert.doesNotMatch(js, /document\.createElement\(['"]audio['"]\)/);
});

test('lyrics preview and full lyrics are separate presentation states', () => {
  const js = read('mobile/mobile-ui.js');
  const css = read('mobile/mobile.css');
  assert.match(js, /np-lyrics-preview/);
  assert.match(js, /np-full-lyrics/);
  assert.match(js, /Lihat lirik lengkap/);
  assert.match(css, /np-layout-v260\.np-full-lyrics/);
  assert.match(css, /np-layout-v260\.np-lyrics-preview/);
});

test('package and Android project identify the 2.6.4 release', () => {
  const pkg = JSON.parse(read('package.json'));
  const lock = JSON.parse(read('package-lock.json'));
  const gradle = read('android/app/build.gradle');
  assert.equal(pkg.version, '2.6.4');
  assert.equal(lock.version, '2.6.4');
  assert.equal(lock.packages[''].version, '2.6.4');
  assert.match(gradle, /"2\.6\.4"/);
  assert.match(gradle, /applicationId "io\.github\.cloverscripts\.muriel"/);
});
