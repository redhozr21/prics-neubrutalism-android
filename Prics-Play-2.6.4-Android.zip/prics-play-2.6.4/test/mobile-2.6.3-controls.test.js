const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');

test('Search and provider controls restore the compact 40px size', () => {
  const css = read('mobile/mobile.css');
  const block = css.slice(css.lastIndexOf('PRICS PLAY 2.6.2'));
  assert.match(block, /html\.is-mobile \.search-box,[\s\S]*?height: 40px !important/);
  assert.match(block, /html\.is-mobile \.platform-switch-container \{[\s\S]*?width: 108px !important/);
  assert.match(block, /html\.is-mobile \.platform-btn \{[\s\S]*?height: 32px !important/);
  assert.match(block, /html\.is-mobile \.platform-btn svg \{[\s\S]*?width: 16px !important/);
});

test('Search and provider shadows stay matched in both visual themes', () => {
  const css = read('mobile/mobile.css');
  const block = css.slice(css.lastIndexOf('PRICS PLAY 2.6.2'));
  assert.match(block, /html\.is-mobile\.neo-theme \.search-box,[\s\S]*?html\.is-mobile\.neo-theme \.platform-pill-switch[\s\S]*?box-shadow: 4px 4px 0 var\(--neo-ink/);
  assert.match(block, /html\.is-mobile\.liquid-glass-theme \.search-box,[\s\S]*?html\.is-mobile\.liquid-glass-theme \.platform-pill-switch[\s\S]*?box-shadow: var\(--glass-shadow\)/);
});

test('2.6.4 preserves the compact Search wrapper and does not widen provider by percentage', () => {
  const css = read('mobile/mobile.css');
  const block = css.slice(css.lastIndexOf('PRICS PLAY 2.6.2'));
  assert.match(block, /flex: 0 0 108px !important/);
  assert.doesNotMatch(block, /width: 33%|width: 34%/);
});

test('2.6.4 version metadata is consistent', () => {
  const pkg = JSON.parse(read('package.json'));
  const lock = JSON.parse(read('package-lock.json'));
  const gradle = read('android/app/build.gradle');
  const html = read('index.html');
  assert.equal(pkg.version, '2.6.4');
  assert.equal(lock.version, '2.6.4');
  assert.equal(lock.packages[''].version, '2.6.4');
  assert.match(gradle, /"2\.6\.4"/);
  assert.match(html, /Version 2\.6\.4/);
});
