# Prics Play 2.6.4 — Android Build Guide

1. Upload `Prics-Play-2.6.4-Android.zip` to the repository root on `main`.
2. Commit the upload. The existing workflow that builds root-level `Prics-Play-X.Y.Z-Android.zip` archives should start automatically.
3. Alternatively, open Actions → Build Prics Play Android → Run workflow and enter `2.6.4`.
4. Wait for Install dependencies, Build mobile bundle, Sync Android project, and Build APK to finish.
5. Download the APK artifact or the `v2.6.4` release.
6. Compare the APK signing certificate with the currently installed stable APK before installation. Do not uninstall the working app or clear app data to work around a signing mismatch.

## Important behavior notes
- Spotify playlist tracks are imported as public metadata and matched to playable YouTube Music results for playback inside Prics Play; the app does not stream Spotify's protected audio.
- YouTube Music Top Songs Indonesia is a dated chart snapshot (31 Oct 2026), not a live Spotify/YouTube Music account connection.
- Lyrics attempt LRCLIB synced text and NetEase word-timed lyrics automatically. If neither source has a matching timed version, manual Sync remains available as a fallback rather than fabricating timestamps.
