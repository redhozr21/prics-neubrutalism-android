# Prics Play 2.6.4 — Now Playing, Lyrics & Viral Playlists

This source archive is the **2.6.4 patch release**, based on the successful 2.6.3 Android build.

## 2.6.4 changes
- Queue navigation now has a clear back path to Now Playing; the queue view no longer traps the listener at Clear Queue.
- The Now Playing overflow menu is layered above artwork and lyrics instead of being covered by the lyrics card.
- Shuffle and Repeat show persistent active states, including a visible Repeat-one badge and accessible pressed state.
- Lyrics first prefer timestamped LRCLIB results even when Genius is selected, then automatically try NetEase word-timed lyrics for untimed plain lyrics in normal Line mode.
- Genius editorial/SEO preview text such as the “Thriller Lyrics … Read More” paragraph is filtered out of the lyrics.
- The mobile lyrics UI shows “Mencari sinkronisasi otomatis…” while timed lyrics are being looked up; manual sync appears only if no automatic timed match is available.
- Added a Playlist Viral shelf below Trending Now: Spotify Top 50 Indonesia, Spotify Hot Hits Indonesia, and a YouTube Music Top Songs Indonesia chart snapshot (31 Oct 2026).
- Spotify public playlist metadata is imported on demand and cached for 12 hours. Tracks are resolved through YouTube Music search for playback inside Prics Play; Prics Play does not stream Spotify's protected audio.
- The YouTube Music chart card contains a dated 15-track chart snapshot and resolves the tracks through YouTube Music search.
- Removed the Made for You shelf from the Spotify-style Home render, consistent with the earlier request.
- Tightened mobile On Repeat and track-row gutters so titles and counts do not spill outside their cards.

## Preserved
- Compact Search and provider controls from 2.6.2.
- Settings category spacing from 2.6.3.
- The smaller approved brand header.
- Existing app ID `io.github.cloverscripts.muriel`.
- Themes, integrations, About, playlists, favorites, queue, offline library, and existing GitHub Actions workflow.
- Existing package dependencies; only the root app version fields are updated.

## Build
Upload `Prics-Play-2.6.4-Android.zip` to the repository root on `main`, or manually run the existing Android workflow with version `2.6.4`.

The source ZIP is not an APK. Wait for GitHub Actions to finish and compare APK signing certificates before updating an installed app.
