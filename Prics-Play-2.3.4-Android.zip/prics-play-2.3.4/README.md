# Prics Play

A lightweight desktop music player for Windows, Linux and macOS. Stream from YouTube, YouTube Music and SoundCloud, download for offline listening, and keep a local library — no account, no subscription.

Prics Play is based on [Riff](https://github.com/rootscripts/riff) by rootscripts (MIT).

> Prics Play is an independent, non-commercial open-source project and is not affiliated with YouTube, Google,
> SoundCloud, Spotify or Apple. It hosts no music. Use it for private listening and only download music you
> have the right to. See [LEGAL.md](LEGAL.md) (also for rights holders).

## Features

- **Streaming & downloads** — YouTube, YouTube Music and SoundCloud via yt-dlp and ffmpeg (installed automatically on first run)
- **Local library** — reads tags and album art, folders and playlists, original files stay untouched
- **Lyrics** — online synced lyrics, LRC files, manual timing, fullscreen karaoke
- **Audio** — EQ, presets, real-time speed, reverb, and a small editor for trimming and exporting clips
- **Compact layout** — slim navigation rail, slide-over drawer for now playing, lyrics and the queue
- **Custom background** — image, GIF or video, with optional glass blur on the interface; pauses while Prics Play is hidden
- **Performance settings** — lightweight thumbnails, blur on/off, visualizer frame-rate cap, memory trimming in the background, hardware acceleration toggle
- **Mobile UI** — Spotify-inspired Home/Search/Library navigation, Neubrutalism cards and hard shadows, customizable accent/background/card/text colors, and Android media-session controls

## Getting started

Requires Node.js 18 or newer.

```bash
git clone https://github.com/redhozr21/prics-neubrutalism-android.git
cd prics-neubrutalism-android
npm install
npm start
```

## Building

```bash
npm run dist
```

Installers land in `dist/`. Builds are unsigned: on macOS, right-click Prics Play in Applications and choose Open; if macOS says the app is damaged, run `xattr -cr /Applications/Muriel.app`.

### Android APK

With Node.js 22 and Java 21 installed, build the mobile bundle and sync the Capacitor project, then assemble the APK:

```bash
npm ci
node mobile/build.mjs
npx cap sync android
cd android
./gradlew assembleDebug
```

The debug APK is written to `android/app/build/outputs/apk/debug/app-debug.apk`. The mobile Neubrutalism palette and navigation are presentation-only; the existing audio and Android media-session code is retained.

## Data

- Windows: `%LOCALAPPDATA%\Muriel`
- macOS: `~/Library/Application Support/Muriel`
- Linux: `~/.cache/muriel` (settings in `~/.config/muriel`)

## Legal

Prics Play is a player: it doesn't host, upload or sell music, has no ads, accounts or tracking, and nobody earns
money from it. You're responsible for using it in line with copyright and the terms of the services you use.
Rights holders can reach us through a [rights holder request](https://github.com/redhozr21/prics-neubrutalism-android/issues/new?template=rights-holder-request.yml).
Details, also in German: [LEGAL.md](LEGAL.md).

## License

MIT. See [LICENSE](LICENSE). Original Riff code © rootscripts.


## Prics Play 2.3.4 — Stable-base Now Playing Edition

Version 2.3.4 is rebuilt from the known-good 2.3.3 source. Its application core, mobile bridge, Android playback service, performance changes, settings cleanup and storage behavior remain unchanged from 2.3.3. The coral Now Playing design and compact/full lyrics modes are reapplied, but their DOM changes now wait until `muriel:ready` after the core app has completed initialization. A UI-only initialization error is logged rather than interrupting the application core.

The Android debug APK workflows now restore the established signing-key cache without creating or saving a replacement key on a cache miss. A build stops if the original key is unavailable. This protects existing installations from silently receiving an incompatible signing certificate; the cache fingerprint still must be compared with the installed 2.3.3 certificate before distributing the APK.

See `PRICS-PLAY-2.3.4-REBUILD-REPORT.md` and `PRICS-PLAY-2.3.4-RELEASE-NOTES.md`. Source tests do not replace a real Android APK build and device test.
