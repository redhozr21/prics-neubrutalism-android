# Prics Play

A lightweight desktop music player for Windows, Linux and macOS. Stream from YouTube, YouTube Music and SoundCloud, download for offline listening, and keep a local library — no account, no subscription.

Prics Play is based on [Riff](https://github.com/rootscripts/riff) by rootscripts (MIT).

> Prics Play is an independent, non-commercial open-source project and is not affiliated with YouTube, Google,
> SoundCloud, Spotify or Apple. It hosts no music. Use it for private listening and only download music you
> have the right to. See [LEGAL.md](LEGAL.md) (also for rights holders).

## Features

- **Streaming & downloads** — YouTube, YouTube Music and SoundCloud via yt-dlp and ffmpeg (installed automatically on first run)
- **Local library** — reads tags and album art, folders and playlists, original files stay untouched
- **Lyrics** — online synced lyrics, LRC files, manual timing, fullscreen karaoke
- **Audio** — EQ, presets, real-time speed, reverb, and a small editor for trimming and exporting clips
- **Compact layout** — slim navigation rail, slide-over drawer for now playing, lyrics and the queue
- **Custom background** — image, GIF or video, with optional glass blur on the interface; pauses while Prics Play is hidden
- **Performance settings** — lightweight thumbnails, blur on/off, visualizer frame-rate cap, memory trimming in the background, hardware acceleration toggle
- **Mobile UI** — Spotify-inspired Home/Search/Library navigation, Neubrutalism cards and hard shadows, customizable accent/background/card/text colors, and Android media-session controls

## Getting started

Requires Node.js 18 or newer.

```bash
git clone https://github.com/redhozr21/prics-neubrutalism-android.git
cd prics-neubrutalism-android
npm install
npm start
```

## Building

```bash
npm run dist
```

Installers land in `dist/`. Builds are unsigned: on macOS, right-click Prics Play in Applications and choose Open; if macOS says the app is damaged, run `xattr -cr /Applications/Muriel.app`.

### Android APK

With Node.js 22 and Java 21 installed, build the mobile bundle and sync the Capacitor project, then assemble the APK:

```bash
npm ci
node mobile/build.mjs
npx cap sync android
cd android
./gradlew assembleDebug
```

The debug APK is written to `android/app/build/outputs/apk/debug/app-debug.apk`. The mobile Neubrutalism palette and navigation are presentation-only; the existing audio and Android media-session code is retained.

## Data

- Windows: `%LOCALAPPDATA%\Muriel`
- macOS: `~/Library/Application Support/Muriel`
- Linux: `~/.cache/muriel` (settings in `~/.config/muriel`)

## Legal

Prics Play is a player: it doesn't host, upload or sell music, has no ads, accounts or tracking, and nobody earns
money from it. You're responsible for using it in line with copyright and the terms of the services you use.
Rights holders can reach us through a [rights holder request](https://github.com/redhozr21/prics-neubrutalism-android/issues/new?template=rights-holder-request.yml).
Details, also in German: [LEGAL.md](LEGAL.md).

## License

MIT. See [LICENSE](LICENSE). Original Riff code © rootscripts.


## Prics Play 2.3.4 — Reference Now Playing Edition

The current source archive targets version **2.3.4**. Mobile Home no longer shows Made for You/Daily Mix, and mobile Settings is reduced to Theme (the approved visual-theme and Neubrutalism palette controls), Integrations, Storage, Profiles and About. Sync and desktop-only/advanced categories are not shipped in the mobile bundle; desktop source retains its Sync and Daily Mix features.

The Now Playing screen uses the coral reference design with large cover art, real transport controls, a short lyrics preview, and an expandable full-lyrics view. Mobile next-song prefetch is disabled. Previously saved source-quality preferences remain intact, and new installations use automatic quality. The mobile performance presentation is enabled, the visualizer timer stops when no visual surface is visible, and Android CPU/Wi-Fi locks are scoped to screen-off playback and background downloads. The foreground playback service, media notification, existing local library, backup/restore and updater are retained. No user media or profile data is deleted.

See [`PRICS-PLAY-2.3.4-NOW-PLAYING-REPORT.md`](PRICS-PLAY-2.3.4-NOW-PLAYING-REPORT.md) for the current UI changes and the 2.3.3 reports for the previous performance audit. The simulation is source-level only; an APK build and physical battery/thermal comparison are still required.
