# Prics Play 2.3.4 — Reference Now Playing UI

**Target:** Android/mobile source bundle 2.3.4  
**Base:** Prics Play 2.3.3 Slim & Performance Edition  
**Date:** 31 October 2026  
**Scope:** Mobile Now Playing presentation and lyrics preview/full-lyrics interaction.

## 1. Design implemented

The mobile Now Playing panel is restyled to follow the two supplied references:

- Coral/red full-player surface with a dark outer border and hard shadow.
- Top navigation row with Back, centered `SEDANG DIPUTAR` label, and More.
- Large square album artwork with a dark outline and shadow.
- Track title, artist and favorite button below the artwork.
- Existing seek/progress bar above the transport controls.
- Large circular play/pause control with previous/next, shuffle and repeat.
- Small device label and queue shortcut below the controls.
- Cream lyrics card at the bottom with a `Lirik` heading and expand chevron.

The player is mobile-only. Desktop source and desktop layout are not changed by this Now Playing redesign.

## 2. Lyrics interaction

### Compact preview (default)
- Only a short portion of the synchronized lyrics is visible in the card below the controls.
- The active lyric remains highlighted.
- The card is clipped to a compact height so it does not take over the player screen.
- Tapping the Lirik header or preview area opens the full-lyrics view.

### Full lyrics
- Album art remains visible at the top, sized for the phone viewport.
- The track title and artist move into the centered top bar.
- The lyric list becomes vertically scrollable and uses the full available space.
- The progress bar and transport controls move below the lyrics, matching the second reference.
- The Back arrow returns to the compact Now Playing view. Pressing Back again closes Now Playing.
- Changing tracks returns the lyrics presentation to compact preview automatically.

When lyrics are unavailable, the card displays `Lirik belum tersedia untuk lagu ini` and does not open an empty full-lyrics screen.

## 3. Playback and data compatibility

The redesign reuses the existing DOM elements and app.js playback handlers rather than creating a second audio player:

- Existing play/pause, previous/next, shuffle and repeat buttons are moved into the mobile Now Playing panel only while it is open.
- The original `.playbar-center` is restored to the mini player when the panel closes.
- The same scrubber, duration labels and audio seek state are reused.
- Existing lyric rendering, synchronized timestamps, word highlighting, translations, lyric editing and lyric-source logic remain in place.
- Queue, audio settings, download, edit-track and share actions remain reachable from the queue row or More menu.
- The queue pane remains switchable; Back from Queue returns to Now Playing.
- The device label adapts between iPhone and Android.

No audio engine, stream resolver, local library, cache, playlist, favorite, history or downloaded audio data is removed by this UI change.

## 4. Files changed

- `mobile/mobile-ui.js` — creates the mobile player header, moves the existing controls while the sheet is open, adds preview/full-lyrics state, restores the mini-player controls on close, and preserves the queue path.
- `mobile/mobile.css` — implements the coral player, artwork, controls, progress bar, lyrics preview card and full-lyrics layout.
- `package.json` and `package-lock.json` — version 2.3.4.
- `android/app/build.gradle` and `update-notifier.js` — version metadata 2.3.4.
- `README.md` — release summary.
- `test/prics-play-v234-now-playing.test.js` — regression tests for the new mobile layout and interactions.

## 5. Validation

| Check | Result |
|---|---:|
| JavaScript/MJS/CJS syntax checks | 133/133 pass |
| Node tests excluding Electron-only `library-import.test.js` | 340/340 pass |
| Now Playing / lyrics-specific tests | 5/5 pass |
| Previous mobile trim regression tests | 10/10 pass |
| Mobile Web bundle build | Not run; `esbuild` is not installed in the environment |
| Android APK build | Not run; Android SDK/ADB are unavailable |
| Physical Android UI / playback test | Not run |

The automated tests validate source-level behavior and structure. They do not replace a final build and installation test on an Android phone. In particular, check opening/closing Now Playing, tapping the lyric card, returning from full lyrics, seeking by tapping a lyric line, switching to Queue, Bluetooth/headset controls, and playback after the screen locks.

## 6. Recommended device acceptance test

1. Install the 2.3.4 APK as an update over the existing installation; do not uninstall the previous app.
2. Start a song that has synchronized lyrics and open Now Playing.
3. Confirm the compact layout shows only a few lyric lines beneath the controls.
4. Tap `Lirik`; confirm the full lyrics view places lyrics between artwork and transport controls.
5. Press Back once; confirm it returns to the compact player. Press Back again; confirm the sheet closes and the mini player works.
6. Switch to Queue and back using the header Back arrow.
7. Test a track without lyrics; confirm the placeholder appears and no empty full-lyrics view opens.
8. Repeat with a short/tall phone viewport and both visual theme selections.
