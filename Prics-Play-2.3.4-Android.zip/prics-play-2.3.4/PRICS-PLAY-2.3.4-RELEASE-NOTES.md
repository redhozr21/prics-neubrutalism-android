# Prics Play 2.3.4 — Release Notes

## Now Playing
- Redesigned the mobile Now Playing screen to match the supplied coral/red player references.
- Added large album artwork, track title/artist, favorite, progress, and larger transport controls.
- Moved the existing playback controls into the Now Playing screen while open; restores the mini-player layout on close.
- Added a compact lyrics preview card below the controls.
- Tapping the lyrics card opens a full-lyrics view with a scrollable lyric list between the artwork and playback controls.
- Back returns from full lyrics to compact Now Playing, then closes the player sheet.
- Preserved existing synchronized lyrics, word highlighting, translation, editing and queue behavior.
- Kept queue, audio settings, download, track edit and share actions available.

## Compatibility
- Android application ID remains `io.github.cloverscripts.muriel`.
- Existing audio playback, media session, foreground playback service and local user data are retained.
- Desktop source/layout remains unchanged by the mobile Now Playing redesign.

## Validation
- 340/340 Node tests passed when excluding the Electron-only library import test file.
- Now Playing-specific tests: 5/5 passed.
- Android APK build and physical-device acceptance testing remain outstanding in this environment.
