'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');

test('release metadata is 2.3.4 and the Android application identity is unchanged', () => {
  const pkg = JSON.parse(read('package.json'));
  const lock = JSON.parse(read('package-lock.json'));
  const gradle = read('android/app/build.gradle');
  assert.equal(pkg.version, '2.3.4');
  assert.equal(lock.version, '2.3.4');
  assert.equal(lock.packages[''].version, '2.3.4');
  assert.match(gradle, /applicationId "io\.github\.cloverscripts\.muriel"/);
  assert.match(gradle, /\?: "2\.3\.4"/);
});

test('mobile Now Playing builds a reference-style topbar and reuses the real playback controls', () => {
  const ui = read('mobile/mobile-ui.js');
  const css = read('mobile/mobile.css');
  assert.match(ui, /np-topbar-label">SEDANG DIPUTAR/);
  assert.match(ui, /playbarCenter/);
  assert.match(ui, /drawerNow\.insertBefore\(playbarCenter, utilityRow\)/);
  assert.match(ui, /playbar\.insertBefore\(playbarCenter, playbarRight\)/);
  assert.match(ui, /btn-toggle-queue/);
  assert.match(css, /#right-panel \{[\s\S]*?background: linear-gradient\(180deg, #ff4a2e 0%, #ff3b22 100%\)/);
  assert.match(css, /\.np-topbar/);
  assert.match(css, /\.playback-controls \.btn-play-pause\.playing/);
});

test('lyrics start in a compact preview and expand into a scrollable full lyrics mode', () => {
  const ui = read('mobile/mobile-ui.js');
  const css = read('mobile/mobile.css');
  assert.match(ui, /np-lyrics-toggle/);
  assert.match(ui, /setFullLyrics\(!panel\.classList\.contains\('np-full-lyrics'\)\)/);
  assert.match(ui, /Lirik Penuh/);
  assert.match(css, /\.lyrics-section[\s\S]*?max-height: 142px/);
  assert.match(css, /#right-panel\.np-full-lyrics \.lyrics-container[\s\S]*?overflow-y: auto/);
  assert.match(css, /#right-panel\.np-full-lyrics \.lyric-line\.active/);
});

test('closing Now Playing restores the original mini-player transport element', () => {
  const ui = read('mobile/mobile-ui.js');
  assert.match(ui, /if \(playbarCenter && playbarCenter\.parentElement !== playbar && playbarRight\) playbar\.insertBefore\(playbarCenter, playbarRight\)/);
  assert.match(ui, /let wasOpen = false/);
  assert.match(ui, /if \(!wasOpen\) setFullLyrics\(false\)/);
});

test('queue pane remains switchable and hidden drawer panes stay hidden', () => {
  const ui = read('mobile/mobile-ui.js');
  const css = read('mobile/mobile.css');
  assert.match(ui, /drawerQueue && !drawerQueue\.classList\.contains\('hidden'\)/);
  assert.match(ui, /drawer-tab\[data-drawer-tab="now"\]/);
  assert.match(css, /#right-panel > \.drawer-pane\.hidden \{ display: none !important; \}/);
});
