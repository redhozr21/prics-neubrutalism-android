# Prics Play 2.6.3 — Settings Spacing

This source archive is the **2.6.3 patch release**, based on the 2.6.2 compact Search / provider correction.

## What changed in 2.6.3
- Added clear 10 px vertical gaps between mobile Settings categories, including Interface, Theme, Tracks, Integrations, Storage, and About.
- Added a little more inner padding around the category list.
- Kept each category button at a consistent 52 px minimum height.
- Did not change category order, navigation behavior, settings content, or theme appearance.

## Preserved from 2.6.2
- Compact 40 px Search and provider controls.
- Fixed 108 px provider selector width.
- Matching Search / provider shadows.
- Smaller mobile brand header.
- Native audio clock and synchronized lyrics, including tap-to-seek for timestamped lyrics.
- Existing application ID `io.github.cloverscripts.muriel`.
- Existing GitHub Actions workflow.

## Build
Upload `Prics-Play-2.6.3-Android.zip` to the repository root on `main`, or manually run the existing Android workflow with version `2.6.3`.

The source ZIP is not an APK. Wait for GitHub Actions to finish and compare APK signing certificates before updating an installed app.
