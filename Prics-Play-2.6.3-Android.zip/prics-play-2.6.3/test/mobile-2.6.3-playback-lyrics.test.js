const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');
const app = read('app.js');
const mobile = read('mobile/mobile-ui.js');
const css = read('mobile/mobile.css');

test('untimed lyrics are not coerced to timestamp zero', () => {
  assert.match(app, /if \(value === null \|\| value === undefined \|\| value === ''\) return -1;/);
  assert.match(app, /div\.dataset\.timed = hasLineTimestamp \? 'true' : 'false';/);
});

test('timestamped lyric rows support tap and keyboard seek', () => {
  assert.match(app, /if \(hasLineTimestamp\) \{\s*div\.setAttribute\('role', 'button'\)/);
  assert.match(app, /el\.nativeAudio\.currentTime = seekTime;/);
  assert.match(app, /event\.key === 'Enter' \|\| event\.key === ' '/);
});

test('mobile lyrics and seek progress follow the native media clock while playing', () => {
  assert.match(app, /updatePhonePlaybackTimeline\(cur, dur\);/);
  assert.match(app, /if \(lyricsSurfaceOpen && \(isPhoneApp \|\| !state\.isPlaying\)\) updateSyncedLyricsHighlight\(cur\);/);
  assert.doesNotMatch(app, /if \(isDraggingScrubber \|\| state\.isPlaying\) return;/);
  assert.match(app, /setProperty\('--np-progress'/);
});

test('untimed lyrics expose the existing manual sync workflow', () => {
  assert.match(mobile, /Lirik belum tersinkron/);
  assert.match(mobile, /document\.getElementById\('btn-sync-lyrics'\)\?\.click\(\)/);
  assert.match(mobile, /Ketuk baris lirik untuk lompat/);
});

test('header is reduced and seekbar has a touch-friendly hit target', () => {
  assert.match(css, /height: calc\(var\(--safe-top\) \+ 68px\) !important;/);
  assert.match(css, /width: 48px !important;/);
  assert.match(css, /height: 28px !important;\s*min-height: 28px !important;/);
  assert.match(css, /left: var\(--np-progress, 0%\) !important;/);
});

test('active lyric has a clear visual highlight in the player sheet', () => {
  assert.match(css, /\.lyric-line\.active\s*\{[\s\S]*?background: rgba\(255,72,44,\.13\)/);
  assert.match(css, /border-left: 3px solid #F0442F/);
});

test('release metadata consistently identifies 2.6.3', () => {
  const pkg = JSON.parse(read('package.json'));
  const lock = JSON.parse(read('package-lock.json'));
  const html = read('index.html');
  const gradle = read('android/app/build.gradle');
  assert.equal(pkg.version, '2.6.3');
  assert.equal(lock.version, '2.6.3');
  assert.equal(lock.packages[''].version, '2.6.3');
  assert.match(html, /Version 2\.6\.3/);
  assert.match(gradle, /"2\.6\.3"/);
});
