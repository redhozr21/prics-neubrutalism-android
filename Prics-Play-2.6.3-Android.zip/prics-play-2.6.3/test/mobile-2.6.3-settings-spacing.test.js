const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');

test('mobile Settings categories have clear vertical spacing', () => {
  const css = read('mobile/mobile.css');
  const block = css.slice(css.lastIndexOf('PRICS PLAY 2.6.3'));
  assert.match(block, /html\.is-mobile \.settings-nav \{[\s\S]*?gap: 10px !important/);
  assert.match(block, /html\.is-mobile \.settings-nav \{[\s\S]*?padding: 10px !important/);
  assert.match(block, /html\.is-mobile \.settings-nav-btn \{[\s\S]*?min-height: 52px !important/);
});

test('Settings category spacing is independent of the compact Search / provider controls', () => {
  const css = read('mobile/mobile.css');
  const controls = css.slice(css.lastIndexOf('PRICS PLAY 2.6.2'));
  const settings = css.slice(css.lastIndexOf('PRICS PLAY 2.6.3'));
  assert.match(controls, /html\.is-mobile \.search-box,[\s\S]*?height: 40px !important/);
  assert.match(controls, /html\.is-mobile \.platform-switch-container \{[\s\S]*?width: 108px !important/);
  assert.match(settings, /gap: 10px !important/);
});

test('2.6.3 version metadata is consistent', () => {
  const pkg = JSON.parse(read('package.json'));
  const lock = JSON.parse(read('package-lock.json'));
  const gradle = read('android/app/build.gradle');
  const html = read('index.html');
  const updater = read('update-notifier.js');
  assert.equal(pkg.version, '2.6.3');
  assert.equal(lock.version, '2.6.3');
  assert.equal(lock.packages[''].version, '2.6.3');
  assert.match(gradle, /"2\.6\.3"/);
  assert.match(html, /Version 2\.6\.3/);
  assert.match(updater, /build\.version \|\| '2\.6\.3'/);
});
