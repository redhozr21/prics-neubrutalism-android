// Mobile-only Neubrutalism skin and Spotify-like primary navigation.
// This layer only changes presentation and navigation; the existing playback engine stays untouched.
(() => {
  if (window.__pricsNeubrutalismInitialized) return;
  window.__pricsNeubrutalismInitialized = true;

  // Override focus to always prevent horizontal scrolling
  try {
    const origFocus = HTMLElement.prototype.focus;
    HTMLElement.prototype.focus = function(options) {
      if (options && typeof options === 'object') {
        if (options.preventScroll === undefined) options.preventScroll = true;
        return origFocus.call(this, options);
      }
      return origFocus.call(this, { preventScroll: true });
    };
  } catch (_) {}

  // Global horizontal scroll lock: immediately correct any horizontal shift
  const lockScrollX = () => {
    if (window.scrollX !== 0) window.scrollTo(0, window.scrollY);
    if (document.documentElement && document.documentElement.scrollLeft !== 0) {
      document.documentElement.scrollLeft = 0;
    }
    if (document.body && document.body.scrollLeft !== 0) {
      document.body.scrollLeft = 0;
    }
    const layout = document.querySelector('.app-layout');
    if (layout && layout.scrollLeft !== 0) layout.scrollLeft = 0;
  };
  window.addEventListener('scroll', lockScrollX, { passive: true });
  window.addEventListener('resize', lockScrollX, { passive: true });

  const root = document.documentElement;
  if (!root.classList.contains('neo-theme') && !root.classList.contains('is-mobile') && !root.classList.contains('is-desktop')) return;

  const isDesktop = () => (typeof navigator !== 'undefined' && /Electron/i.test(navigator.userAgent)) || (typeof window !== 'undefined' && (window.innerWidth >= 860 || document.documentElement.classList.contains('is-desktop')));

  const COLORS = {
    light: { accent: '#FF482C', background: '#FFF8EF', surface: '#FFFFFF', ink: '#0F0F0F', secondary: '#FFE568', tertiary: '#C9B4FF' },
    dark:  { accent: '#FF482C', background: '#171717', surface: '#242424', ink: '#FFF8EF', secondary: '#FFE568', tertiary: '#C9B4FF' },
  };
  const KEYS = {
    accent: 'muriel_theme_accent',
    background: 'muriel_neo_background',
    surface: 'muriel_neo_surface',
    ink: 'muriel_neo_ink',
    secondary: 'muriel_neo_secondary',
  };
  const isHex = (value) => typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value);
  const getColor = (key, fallback) => {
    try {
      const value = localStorage.getItem(KEYS[key]);
      return isHex(value) ? value : fallback;
    } catch (_) { return fallback; }
  };
  const setStored = (key, value) => {
    try { localStorage.setItem(KEYS[key], value); } catch (_) {}
  };

  function applyPalette() {
    const mode = document.body.classList.contains('theme-dark') ? 'dark' : 'light';
    const defaults = COLORS[mode];
    const colors = {
      accent: getColor('accent', defaults.accent),
      background: getColor('background', defaults.background),
      surface: getColor('surface', defaults.surface),
      ink: getColor('ink', defaults.ink),
      secondary: getColor('secondary', defaults.secondary),
      tertiary: defaults.tertiary,
    };
    Object.entries(colors).forEach(([key, value]) => root.style.setProperty(`--neo-${key}`, value));
    root.style.setProperty('--neo-paper', colors.background);
    root.style.setProperty('--neo-border-width', '2px');
    root.style.setProperty('--neo-shadow-size', '4px');

    const pickerIds = {
      accent: 'neo-color-accent', background: 'neo-color-background', surface: 'neo-color-surface',
      ink: 'neo-color-ink', secondary: 'neo-color-secondary',
    };
    Object.entries(pickerIds).forEach(([key, id]) => {
      const input = document.getElementById(id);
      if (input && input.value !== colors[key]) input.value = colors[key];
    });
  }


  const VISUAL_THEME_KEY = 'prics_play_visual_theme';
  const normalizeVisualTheme = (value) => value === 'liquid-glass' ? 'liquid-glass' : 'neubrutalism';

  function setVisualTheme(value) {
    const theme = normalizeVisualTheme(value);
    try { localStorage.setItem(VISUAL_THEME_KEY, theme); } catch (_) {}
    root.classList.toggle('neo-theme', theme === 'neubrutalism');
    root.classList.toggle('liquid-glass-theme', theme === 'liquid-glass');
    document.querySelectorAll('[data-prics-visual-theme]').forEach((button) => {
      const active = button.dataset.pricsVisualTheme === theme;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    applyPalette();
    window.dispatchEvent(new CustomEvent('prics:visual-theme-change', { detail: { theme } }));
  }

  function addVisualThemeSelector() {
    const section = document.querySelector('.settings-section[data-cat="theme"]');
    const group = section && section.querySelector('.m3-group[data-group="colors"]');
    if (!group || group.querySelector('.prics-visual-theme-setting')) return;
    const card = document.createElement('div');
    card.className = 'setting-item prics-visual-theme-setting';
    card.innerHTML = `
      <div class="prics-visual-theme-heading"><span class="setting-name">Visual theme</span><small>Choose your Prics Play appearance</small></div>
      <div class="prics-visual-theme-options" role="group" aria-label="Visual theme">
        <button type="button" class="prics-visual-theme-option" data-prics-visual-theme="neubrutalism" aria-pressed="true">
          <span class="prics-theme-preview prics-preview-neo" aria-hidden="true"><i></i><b>P.A</b><em></em></span>
          <span><strong>Neubrutalism</strong><small>Bold borders and hard shadows</small></span><span class="prics-theme-check" aria-hidden="true">✓</span>
        </button>
        <button type="button" class="prics-visual-theme-option" data-prics-visual-theme="liquid-glass" aria-pressed="false">
          <span class="prics-theme-preview prics-preview-glass" aria-hidden="true"><i></i><b>P.A</b><em></em></span>
          <span><strong>Liquid Glass</strong><small>Translucent layers and soft blur</small></span><span class="prics-theme-check" aria-hidden="true">✓</span>
        </button>
      </div>`;
    group.prepend(card);
    card.querySelectorAll('[data-prics-visual-theme]').forEach((button) => button.addEventListener('click', () => setVisualTheme(button.dataset.pricsVisualTheme)));
    setVisualTheme(normalizeVisualTheme(localStorage.getItem(VISUAL_THEME_KEY)));
  }

  function addThemeModeSelector() {
    const section = document.querySelector('.settings-section[data-cat="theme"]');
    const group = section && section.querySelector('.m3-group[data-group="colors"]');
    if (!group || group.querySelector('.prics-theme-mode-setting')) return;
    const card = document.createElement('div');
    card.className = 'setting-item prics-theme-mode-setting';
    const currentMode = localStorage.getItem('muriel_theme_mode') || 'light';
    card.innerHTML = `
      <div class="setting-item-top" style="align-items: center; margin-bottom: 8px;">
        <span class="setting-name" style="font-weight: 800; font-size: 14px; color: var(--neo-ink, #000);">Mode Tampilan</span>
      </div>
      <div class="theme-mode-toggle" style="display: flex; gap: 8px; width: 100%;">
        <button type="button" class="theme-mode-btn ${currentMode === 'light' ? 'active' : ''}" data-theme-mode="light" style="flex: 1; min-height: 40px;">Terang</button>
        <button type="button" class="theme-mode-btn ${currentMode === 'dark' ? 'active' : ''}" data-theme-mode="dark" style="flex: 1; min-height: 40px;">Gelap</button>
        <button type="button" class="theme-mode-btn ${currentMode === 'system' ? 'active' : ''}" data-theme-mode="system" style="flex: 1; min-height: 40px;">Sistem</button>
      </div>`;
    group.prepend(card);
    card.querySelectorAll('[data-theme-mode]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const mode = btn.dataset.themeMode;
        localStorage.setItem('muriel_theme_mode', mode);
        card.querySelectorAll('[data-theme-mode]').forEach(b => b.classList.toggle('active', b === btn));
        const isDark = mode === 'dark' || (mode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
        document.body.classList.toggle('theme-dark', isDark);
        applyPalette();
      });
    });
  }

  function setAccent(value) {
    if (!isHex(value)) return;
    setStored('accent', value);
    const legacyPicker = document.getElementById('settings-custom-color-input');
    if (legacyPicker && legacyPicker.value.toLowerCase() !== value.toLowerCase()) {
      legacyPicker.value = value;
      legacyPicker.dispatchEvent(new Event('input', { bubbles: true }));
    }
    applyPalette();
  }

  function addPaletteCustomizer() {
    const section = document.querySelector('.settings-section[data-cat="theme"]');
    const group = section && section.querySelector('.m3-group[data-group="colors"]');
    if (!group || group.querySelector('.neo-theme-customizer')) return;

    const card = document.createElement('div');
    card.className = 'setting-item neo-theme-customizer';
    card.innerHTML = `
      <div class="neo-customizer-head">
        <div>
          <span class="setting-name">Neubrutalism palette</span>
          <p>Atur warna aksen, latar, kartu, teks, dan warna sekunder.</p>
        </div>
        <span class="neo-theme-chip">NEO</span>
      </div>
      <div class="neo-color-grid">
        <label class="neo-color-field" for="neo-color-accent"><span>Aksen</span><input id="neo-color-accent" data-neo-color="accent" type="color" value="#FF482C"></label>
        <label class="neo-color-field" for="neo-color-background"><span>Latar</span><input id="neo-color-background" data-neo-color="background" type="color" value="#FFF8EF"></label>
        <label class="neo-color-field" for="neo-color-surface"><span>Kartu</span><input id="neo-color-surface" data-neo-color="surface" type="color" value="#FFFFFF"></label>
        <label class="neo-color-field" for="neo-color-ink"><span>Teks &amp; outline</span><input id="neo-color-ink" data-neo-color="ink" type="color" value="#0F0F0F"></label>
        <label class="neo-color-field" for="neo-color-secondary"><span>Aksen sekunder</span><input id="neo-color-secondary" data-neo-color="secondary" type="color" value="#FFE568"></label>
      </div>
      <div class="neo-preset-label">Preset cepat</div>
      <div class="neo-preset-grid">
        <button type="button" class="neo-preset" data-neo-preset="pop">Pop</button>
        <button type="button" class="neo-preset" data-neo-preset="bubblegum">Bubblegum</button>
        <button type="button" class="neo-preset" data-neo-preset="lime">Lime</button>
        <button type="button" class="neo-preset" data-neo-preset="ocean">Ocean</button>
        <button type="button" class="neo-preset" data-neo-preset="night">Night</button>
      </div>
      <button type="button" class="neo-reset-palette" id="neo-reset-palette">Reset warna</button>
    `;
    group.prepend(card);

    card.querySelectorAll('[data-neo-color]').forEach((input) => {
      input.addEventListener('input', () => {
        const key = input.dataset.neoColor;
        if (key === 'accent') setAccent(input.value);
        else {
          setStored(key, input.value);
          applyPalette();
        }
      });
    });

    const presets = {
      pop:       { accent: '#FF482C', background: '#FFF8EF', surface: '#FFFFFF', ink: '#0F0F0F', secondary: '#FFE568' },
      bubblegum: { accent: '#FF70B8', background: '#FFF0F7', surface: '#FFFFFF', ink: '#281321', secondary: '#C9B4FF' },
      lime:      { accent: '#C7FF4A', background: '#F5FFE5', surface: '#FFFFFF', ink: '#19230B', secondary: '#C9B4FF' },
      ocean:     { accent: '#59C8FF', background: '#EEF9FF', surface: '#FFFFFF', ink: '#102333', secondary: '#FFE568' },
      night:     { accent: '#FF482C', background: '#171717', surface: '#242424', ink: '#FFF8EF', secondary: '#FFE568' },
    };
    card.querySelectorAll('[data-neo-preset]').forEach((button) => {
      button.addEventListener('click', () => {
        const preset = presets[button.dataset.neoPreset];
        if (!preset) return;
        Object.entries(preset).forEach(([key, value]) => {
          if (key === 'accent') setStored('accent', value);
          else setStored(key, value);
        });
        const legacyPicker = document.getElementById('settings-custom-color-input');
        if (legacyPicker) {
          legacyPicker.value = preset.accent;
          legacyPicker.dispatchEvent(new Event('input', { bubbles: true }));
        }
        applyPalette();
      });
    });

    const reset = card.querySelector('#neo-reset-palette');
    reset.addEventListener('click', () => {
      ['background', 'surface', 'ink', 'secondary'].forEach((key) => {
        try { localStorage.removeItem(KEYS[key]); } catch (_) {}
      });
      setAccent(COLORS.light.accent);
      applyPalette();
    });
  }


  // Keep the mobile Settings surface intentionally small. Playback, lyric and advanced controls
  // remain at their safe defaults; the underlying playback/data engines are not removed.
  function trimMobileSettings() {
    const view = document.getElementById('view-settings');
    if (!view) return;
    const search = view.querySelector('.settings-search-box');
    if (search) search.remove();

    const retired = new Set(['interface', 'advanced', 'plugins', 'sync']);
    retired.forEach((category) => {
      const navItem = view.querySelector(`#settings-nav .settings-nav-btn[data-cat="${category}"]`);
      const section = view.querySelector(`.settings-section[data-cat="${category}"]`);
      if (navItem) navItem.remove();
      if (section) section.remove();
    });

    const theme = view.querySelector('.settings-section[data-cat="theme"]');
    if (theme) {
      const colors = theme.querySelector('.m3-group[data-group="colors"]');
      if (colors) {
        Array.from(theme.children).forEach((child) => { if (child !== colors) child.remove(); });
        Array.from(colors.children).forEach((child) => {
          if (!child.classList.contains('prics-visual-theme-setting') && !child.classList.contains('neo-theme-customizer') && !child.classList.contains('prics-theme-mode-setting')) child.remove();
        });
      }
    }
    document.body.classList.add('prics-lean-settings');
  }

  function ensureMobileLandingViews() {
    const main = document.getElementById('main-content');
    if (!main) return { search: document.createElement('section'), collection: document.createElement('section') };
    let search = document.getElementById('prics-search-view');
    if (!search) {
      search = document.createElement('section');
      search.id = 'prics-search-view';
      search.className = 'content-view prics-mobile-landing';
      search.setAttribute('aria-label', 'Search music');
      search.innerHTML = `
        <div class="prics-landing-heading">
          <span class="prics-eyebrow">TEMUKAN SUARA BARU</span>
          <h1>Cari</h1>
          <p>Temukan lagu, artis, dan album yang ingin kamu dengarkan.</p>
        </div>
        <div class="prics-search-hint"><span class="prics-search-hint-icon" aria-hidden="true">⌕</span><span><b>Mulai dengan pencarian</b><small>Gunakan kolom pencarian di atas untuk mencari lagu, artis, atau album.</small></span></div>
        <div class="prics-landing-section-head"><h2>Jelajahi genre</h2><span>PUTAR SESUAI MOOD</span></div>
        <div class="prics-genre-grid">
          <button class="prics-genre-card tone-coral" type="button" data-query="Pop music"><span>01 / POP</span><b>Pop</b><i aria-hidden="true">◒</i></button>
          <button class="prics-genre-card tone-yellow" type="button" data-query="Indie music"><span>02 / INDIE</span><b>Indie</b><i aria-hidden="true">✳</i></button>
          <button class="prics-genre-card tone-purple" type="button" data-query="Rock music"><span>03 / ROCK</span><b>Rock</b><i aria-hidden="true">✦</i></button>
          <button class="prics-genre-card tone-coral" type="button" data-query="Jazz music"><span>04 / JAZZ</span><b>Jazz</b><i aria-hidden="true">♫</i></button>
          <button class="prics-genre-card tone-purple" type="button" data-query="Hip-hop music"><span>05 / HIP-HOP</span><b>Hip-hop</b><i aria-hidden="true">〽</i></button>
          <button class="prics-genre-card tone-yellow" type="button" data-query="Electronic music"><span>06 / ELECTRONIC</span><b>Elektronik</b><i aria-hidden="true">◎</i></button>
          <button class="prics-genre-card tone-yellow" type="button" data-query="R&B music"><span>07 / R&amp;B</span><b>R&amp;B</b><i aria-hidden="true">◉</i></button>
          <button class="prics-genre-card tone-coral" type="button" data-query="Classical music"><span>08 / CLASSICAL</span><b>Klasik</b><i aria-hidden="true">♬</i></button>
        </div>
        <p class="prics-landing-footnote">Genre adalah pintasan pencarian. Hasil lagu tetap berasal dari sumber musik yang kamu pilih.</p>`;
      main.insertBefore(search, main.firstChild);
    }
    let collection = document.getElementById('prics-collection-view');
    if (!collection) {
      collection = document.createElement('section');
      collection.id = 'prics-collection-view';
      collection.className = 'content-view prics-mobile-landing neo-collection-view';
      collection.setAttribute('aria-label', 'Your collection');
      collection.innerHTML = `
        <div class="prics-collection-heading">
          <div><span class="prics-eyebrow">MUSIK YANG KAMU SIMPAN</span><h1>Koleksi kamu</h1><p>Semua musik dan playlist dalam satu tempat.</p></div>
          <button class="prics-create-playlist" type="button" data-action="create-playlist" aria-label="Buat playlist">+</button>
        </div>
        <div class="prics-collection-shortcuts">
          <button type="button" data-open-view="favorites" class="prics-collection-shortcut shortcut-liked"><span class="prics-shortcut-art">♥</span><span><b>Lagu disukai</b><small>Semua favorit kamu</small></span><i>›</i></button>
          <button type="button" data-open-view="albums" class="prics-collection-shortcut shortcut-albums"><span class="prics-shortcut-art">▣</span><span><b>Album</b><small>Album tersimpan</small></span><i>›</i></button>
          <button type="button" data-open-view="artists" class="prics-collection-shortcut shortcut-artists"><span class="prics-shortcut-art">♫</span><span><b>Artis</b><small>Artis yang diikuti</small></span><i>›</i></button>
          <button type="button" data-open-view="local" class="prics-collection-shortcut shortcut-local"><span class="prics-shortcut-art">▤</span><span><b>Musik lokal</b><small>File di perangkat ini</small></span><i>›</i></button>
          <button type="button" data-open-view="history" class="prics-collection-shortcut shortcut-history"><span class="prics-shortcut-art">◷</span><span><b>Baru diputar</b><small>Riwayat mendengarkan</small></span><i>›</i></button>
        </div>
        <section class="neo-library-playlists prics-collection-playlists" aria-label="Your playlists">
          <div class="neo-library-playlists-head"><h2>Playlist kamu</h2><span class="neo-library-playlist-count">0</span></div>
          <div class="neo-library-playlist-list" aria-live="polite"></div>
        </section>`;
      main.insertBefore(collection, main.firstChild);
    }
    return { search, collection };
  }

  function hideMobileLandingViews() {
    document.body.classList.remove('neo-search-open', 'neo-collection-open');
    ['prics-search-view', 'prics-collection-view'].forEach((id) => {
      const page = document.getElementById(id);
      if (page) page.classList.remove('active');
    });
  }

  function showMobileLanding(kind) {
    if (isDesktop()) return;
    const page = document.getElementById(kind === 'search' ? 'prics-search-view' : 'prics-collection-view');
    const main = document.getElementById('main-content');
    if (!page || !main) return;
    Array.from(main.children).filter((view) => view.classList && view.classList.contains('content-view')).forEach((view) => view.classList.remove('active'));
    page.classList.add('active');
    document.body.classList.toggle('neo-search-open', kind === 'search');
    document.body.classList.toggle('neo-collection-open', kind === 'collection');
    main.scrollTop = 0;
  }

  function ensureHomeWelcome() {
    const host = document.getElementById('discover-empty');
    if (!host) return;
    let intro = host.querySelector('.prics-home-welcome');
    let recent = host.querySelector('.prics-home-recent');
    if (!intro) {
      intro = document.createElement('section');
      intro.className = 'prics-home-welcome';
      intro.innerHTML = `<div><span class="prics-eyebrow">MUSIKMU. GAYAMU.</span><h1>Putar suasana<br>hatimu.</h1><p>Temukan kembali lagu favorit dan musik baru yang cocok dengan harimu.</p></div><button type="button" class="prics-home-search" aria-label="Cari musik">⌕</button>`;
      recent = document.createElement('section');
      recent.className = 'prics-home-recent';
      recent.innerHTML = `<div class="prics-landing-section-head"><h2>Terakhir diputar</h2><span>LANJUTKAN</span></div><div class="prics-home-recent-list"></div>`;
      host.insertBefore(recent, host.querySelector('.sp-home') || host.firstChild);
      host.insertBefore(intro, recent);
    }
    const searchBtn = intro.querySelector('.prics-home-search');
    if (searchBtn && !searchBtn.dataset.wired) {
      searchBtn.dataset.wired = '1';
      searchBtn.addEventListener('click', () => {
        const tab = document.querySelector('.neo-bottom-nav [data-tab="search"]');
        if (tab) tab.click();
      });
    }
  }

  function refreshHomeRecent() {
    const host = document.querySelector('.prics-home-recent');
    const list = host && host.querySelector('.prics-home-recent-list');
    const core = window.MurielCore;
    if (!host || !list || !core || !core.state) return;
    const tracks = Array.isArray(core.state.history) ? core.state.history.slice(0, 4) : [];
    list.replaceChildren();
    host.hidden = !tracks.length;
    tracks.forEach((track, index) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'prics-recent-track';
      const art = document.createElement('span');
      art.className = 'prics-recent-art';
      let src = typeof core.thumb === 'function' ? core.thumb(track) : (track.thumbnail || '');
      if (src && /^(https?:|data:image\/|blob:|file:)/i.test(src)) {
        const yt = src.match(/^https?:\/\/i\d?\.ytimg\.com\/vi(?:_webp)?\/([\w-]{6,})\//);
        if (yt) src = `https://i.ytimg.com/vi/${yt[1]}/mqdefault.jpg`;
        else if (/(googleusercontent|ggpht)\.com/.test(src)) src = src.replace(/=w\d+-h\d+[^&?]*$/, '=w120-h120-l90-rj').replace(/=s\d+[^&?]*$/, '=s120');
        const img = document.createElement('img'); img.src = src; img.alt = ''; img.loading = 'lazy'; img.decoding = 'async'; art.appendChild(img);
      } else art.textContent = '♫';
      const meta = document.createElement('span'); meta.className = 'prics-recent-meta';
      const title = document.createElement('b'); title.textContent = track.title || 'Unknown track';
      const artist = document.createElement('small'); artist.textContent = track.artist || 'Unknown artist';
      meta.append(title, artist); button.append(art, meta);
      button.addEventListener('click', () => core.playTrack(track, tracks, index));
      list.appendChild(button);
    });
  }

  function addSpotifyNavigation() {
    const sidebar = document.getElementById('sidebar');
    if (!sidebar) return;
    sidebar.classList.add('neo-sidebar');

    let nav = sidebar.querySelector('.neo-bottom-nav');
    if (!nav) {
      nav = document.createElement('nav');
      nav.className = 'neo-bottom-nav';
      nav.setAttribute('aria-label', 'Navigasi utama');
      nav.innerHTML = `
        <div class="liquid-bubble-indicator" aria-hidden="true"><div class="liquid-bubble-core"></div></div>
        <button type="button" class="neo-tab active" data-tab="home" aria-label="Home"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/></svg><span>Home</span></button>
        <button type="button" class="neo-tab" data-tab="search" aria-label="Search"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 5 5"/></svg><span>Search</span></button>
        <button type="button" class="neo-tab" data-tab="library" aria-label="Collection"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4v16M9 4v16M14 4v16M19 4v16"/></svg><span>Collection</span></button>`;
      sidebar.appendChild(nav);
    } else if (!nav.querySelector('.liquid-bubble-indicator')) {
      const bubble = document.createElement('div');
      bubble.className = 'liquid-bubble-indicator';
      bubble.setAttribute('aria-hidden', 'true');
      bubble.innerHTML = '<div class="liquid-bubble-core"></div>';
      nav.prepend(bubble);
    }

    const pages = ensureMobileLandingViews();

    let currentTab = 'home';
    let stretchTimer = null;
    const tabOrder = ['home', 'search', 'library'];

    const updateBubblePosition = (targetTab, animateStretch = true) => {
      const indicator = nav.querySelector('.liquid-bubble-indicator');
      const core = indicator && indicator.querySelector('.liquid-bubble-core');
      const targetBtn = nav.querySelector(`.neo-tab[data-tab="${targetTab}"]`);
      if (!indicator || !targetBtn) return;

      const left = targetBtn.offsetLeft;
      const width = targetBtn.offsetWidth;
      indicator.style.transform = `translate3d(${left}px, 0, 0)`;
      indicator.style.width = `${width}px`;

      if (animateStretch && core && currentTab !== targetTab) {
        const fromIdx = tabOrder.indexOf(currentTab);
        const toIdx = tabOrder.indexOf(targetTab);
        if (fromIdx !== -1 && toIdx !== -1 && fromIdx !== toIdx) {
          const dir = toIdx > fromIdx ? 'stretch-right' : 'stretch-left';
          core.classList.remove('stretch-right', 'stretch-left');
          void core.offsetWidth;
          core.classList.add(dir);
          clearTimeout(stretchTimer);
          stretchTimer = setTimeout(() => {
            core.classList.remove('stretch-right', 'stretch-left');
          }, 360);
        }
      }
      currentTab = targetTab;
    };

    const setActive = (tab) => {
      updateBubblePosition(tab, true);
      nav.querySelectorAll('.neo-tab').forEach((button) => {
        const active = button.dataset.tab === tab;
        button.classList.toggle('active', active);
        if (active) button.setAttribute('aria-current', 'page');
        else button.removeAttribute('aria-current');
        button.setAttribute('aria-pressed', String(active));
      });
    };

    window.addEventListener('resize', () => updateBubblePosition(currentTab, false), { passive: true });
    requestAnimationFrame(() => updateBubblePosition('home', false));
    const clickExisting = (id) => { const button = document.getElementById(id); if (button) button.click(); };
    const searchInput = document.getElementById('search-input');
    const searchClear = document.getElementById('search-clear-btn');
    const searchIcon = document.getElementById('search-icon-btn');
    let searchMode = false;

    const showCoreView = (id) => {
      hideMobileLandingViews();
      clickExisting(id);
    };
    const runMobileSearch = (query) => {
      const value = String(query || '').trim();
      if (!value || !searchInput) return;
      searchMode = true;
      hideMobileLandingViews();
      clickExisting('nav-discover');
      setActive('search');
      searchInput.value = value;
      searchInput.dispatchEvent(new Event('input', { bubbles: true }));
      searchInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
    };

    nav.querySelector('[data-tab="home"]').addEventListener('click', () => {
      searchMode = false;
      if (searchInput && searchInput.value) {
        searchInput.value = '';
        if (searchClear) searchClear.click();
      }
      showCoreView('nav-discover');
      setActive('home');
      if (document.activeElement === searchInput && searchInput) searchInput.blur();
    });
    nav.querySelector('[data-tab="search"]').addEventListener('click', () => {
      searchMode = true;
      hideMobileLandingViews();
      clickExisting('nav-discover');
      setActive('search');
      if (!isDesktop()) {
        requestAnimationFrame(() => {
          showMobileLanding('search');
          if (searchInput) {
            try { searchInput.focus({ preventScroll: true }); } catch (_) { searchInput.focus(); }
          }
        });
      } else if (searchInput) {
        try { searchInput.focus({ preventScroll: true }); } catch (_) { searchInput.focus(); }
      }
    });
    nav.querySelector('[data-tab="library"]').addEventListener('click', () => {
      searchMode = false;
      const drawer = document.getElementById('rail-drawer');
      if (drawer && !drawer.classList.contains('hidden')) clickExisting('btn-close-rail-drawer');
      hideMobileLandingViews();
      clickExisting('nav-favorites');
      if (document.activeElement === searchInput && searchInput) searchInput.blur();
      setActive('library');
      if (!isDesktop()) {
        requestAnimationFrame(() => {
          showMobileLanding('collection');
          refreshLibraryPlaylists(pages.collection);
          setActive('library');
        });
      }
    });

    pages.search.querySelectorAll('[data-query]').forEach((button) => {
      button.addEventListener('click', () => runMobileSearch(button.dataset.query));
    });
    pages.collection.querySelectorAll('[data-open-view]').forEach((button) => {
      button.addEventListener('click', () => {
        const target = ({ favorites: 'nav-favorites', albums: 'nav-albums', artists: 'nav-artists', local: 'nav-local', history: 'nav-history' })[button.dataset.openView];
        if (!target) return;
        searchMode = false;
        showCoreView(target);
        setActive('library');
      });
    });
    const createPlaylist = pages.collection.querySelector('[data-action="create-playlist"]');
    if (createPlaylist) createPlaylist.addEventListener('click', () => {
      hideMobileLandingViews();
      clickExisting('btn-new-playlist');
    });

    document.addEventListener('keydown', (event) => {
      if (event.target === searchInput && event.key === 'Enter' && searchInput.value.trim()) {
        hideMobileLandingViews();
        searchMode = true;
        setActive('search');
      }
    }, true);
    if (searchIcon) searchIcon.addEventListener('click', () => {
      if (searchInput && searchInput.value.trim()) {
        hideMobileLandingViews();
        searchMode = true;
        setActive('search');
      }
    }, true);
    if (searchClear) searchClear.addEventListener('click', () => {
      if (searchMode && !isDesktop()) requestAnimationFrame(() => showMobileLanding('search'));
    });
    if (searchInput) {
      searchInput.addEventListener('focus', () => {
        if (isDesktop()) return;
        if (!searchMode) {
          searchMode = true;
          hideMobileLandingViews();
          clickExisting('nav-discover');
        }
        setActive('search');
        if (!searchInput.value.trim()) requestAnimationFrame(() => showMobileLanding('search'));
      });

      searchInput.addEventListener('input', () => {
        if (searchInput.value.trim()) {
          hideMobileLandingViews();
        } else if (searchMode && !isDesktop()) {
          requestAnimationFrame(() => showMobileLanding('search'));
        }
      });
    }

    // Core destinations close the mobile landing pages before the original view controller runs.
    ['nav-discover', 'nav-favorites', 'nav-albums', 'nav-artists', 'nav-local', 'nav-history', 'nav-settings'].forEach((id) => {
      const button = document.getElementById(id);
      if (!button) return;
      button.addEventListener('click', () => {
        hideMobileLandingViews();
        if (id === 'nav-discover') setActive(searchMode ? 'search' : 'home');
        else if (id === 'nav-settings') setActive('');
        else setActive('library');
      });
    });

    const drawer = document.getElementById('rail-drawer');
    if (drawer && !drawer.querySelector('.neo-library-shortcuts')) {
      const shortcuts = document.createElement('div');
      shortcuts.className = 'neo-library-shortcuts';
      shortcuts.innerHTML = `
        <button type="button" data-open-view="favorites"><span class="neo-shortcut-icon">♥</span><span><b>Liked songs</b><small>Favorit kamu</small></span></button>
        <button type="button" data-open-view="albums"><span class="neo-shortcut-icon">▣</span><span><b>Albums</b><small>Koleksi album</small></span></button>
        <button type="button" data-open-view="artists"><span class="neo-shortcut-icon">♫</span><span><b>Artists</b><small>Artis yang diikuti</small></span></button>
        <button type="button" data-open-view="local"><span class="neo-shortcut-icon">▤</span><span><b>On this device</b><small>Musik lokal</small></span></button>
        <button type="button" data-open-view="history"><span class="neo-shortcut-icon">◷</span><span><b>Recently played</b><small>Riwayat dengar</small></span></button>`;
      const playlistSection = drawer.querySelector('#drawer-section-playlists');
      if (playlistSection) drawer.insertBefore(shortcuts, playlistSection);
      shortcuts.querySelectorAll('[data-open-view]').forEach((button) => {
        button.addEventListener('click', () => {
          const targetId = ({ favorites: 'nav-favorites', albums: 'nav-albums', artists: 'nav-artists', local: 'nav-local', history: 'nav-history' })[button.dataset.openView];
          hideMobileLandingViews();
          if (targetId) clickExisting(targetId);
          setActive('library');
        });
      });
    }
    const drawerTitle = document.getElementById('rail-drawer-title');
    const refreshDrawerTitle = () => {
      if (drawerTitle && drawer && !drawer.classList.contains('drawer-presets-mode') && !drawer.classList.contains('hidden') && drawerTitle.textContent !== 'Your Library') drawerTitle.textContent = 'Your Library';
    };
    if (drawer) new MutationObserver(refreshDrawerTitle).observe(drawer, { attributes: true, attributeFilter: ['class'] });
    if (drawerTitle) new MutationObserver(refreshDrawerTitle).observe(drawerTitle, { childList: true, characterData: true, subtree: true });
  }

  function ensureLibraryHub() {
    const view = document.getElementById('view-favorites');
    if (!view) return;
    const clickExisting = (id) => { const button = document.getElementById(id); if (button) button.click(); };
    let hub = view.querySelector('.neo-library-hub');
    if (hub) {
      hub.hidden = false;
      refreshLibraryPlaylists(hub);
      return;
    }
    hub = document.createElement('section');
    hub.className = 'neo-library-hub';
    hub.setAttribute('aria-label', 'Your Library');
    hub.innerHTML = `
      <div class="neo-library-hub-head"><h2>Your Library</h2><span>COLLECTIONS</span></div>
      <div class="neo-library-hub-grid">
        <button type="button" data-open-view="favorites"><span class="neo-hub-icon">♥</span><span><b>Liked songs</b><small>Saved favorites</small></span></button>
        <button type="button" data-open-view="albums"><span class="neo-hub-icon">▣</span><span><b>Albums</b><small>Saved albums</small></span></button>
        <button type="button" data-open-view="artists"><span class="neo-hub-icon">♫</span><span><b>Artists</b><small>Followed artists</small></span></button>
        <button type="button" data-open-view="local"><span class="neo-hub-icon">▤</span><span><b>On this device</b><small>Local music</small></span></button>
        <button type="button" data-open-view="history"><span class="neo-hub-icon">◷</span><span><b>Recently played</b><small>Listening history</small></span></button>
      </div>
      <section class="neo-library-playlists" aria-label="Your playlists">
        <div class="neo-library-playlists-head"><h3>Your playlists</h3><span class="neo-library-playlist-count">0</span></div>
        <div class="neo-library-playlist-list" aria-live="polite"></div>
      </section>`;
    const header = view.querySelector('.view-header');
    if (header) view.insertBefore(hub, header);
    else view.prepend(hub);
    hub.querySelectorAll('.neo-library-hub-grid [data-open-view]').forEach((button) => {
      button.addEventListener('click', () => {
        const viewName = button.dataset.openView;
        if (viewName === 'favorites') {
          hub.hidden = true;
          const main = document.getElementById('main-content');
          requestAnimationFrame(() => {
            const h = view.querySelector('.view-header');
            if (main && h) main.scrollTop = Math.max(0, h.offsetTop - 8);
          });
          return;
        }
        const targetId = ({ albums: 'nav-albums', artists: 'nav-artists', local: 'nav-local', history: 'nav-history' })[viewName];
        if (targetId) clickExisting(targetId);
      });
    });
    refreshLibraryPlaylists(hub);
  }

  function getUserPlaylists() {
    const core = window.MurielCore;
    if (core && core.state && Array.isArray(core.state.playlists)) {
      return core.state.playlists.filter((playlist) => playlist && typeof playlist === 'object' && playlist.id != null);
    }
    try {
      const saved = JSON.parse(localStorage.getItem('devsize_playlists') || '[]');
      return Array.isArray(saved) ? saved.filter((playlist) => playlist && typeof playlist === 'object' && playlist.id != null) : [];
    } catch (_) {
      return [];
    }
  }

  function getPlaylistArtwork(playlist) {
    const core = window.MurielCore;
    let source = typeof playlist.cover === 'string' ? playlist.cover.trim() : '';
    if (!source) {
      const track = Array.isArray(playlist.tracks) ? playlist.tracks.find(Boolean) : null;
      if (track) {
        try { source = core && typeof core.thumb === 'function' ? (core.thumb(track) || '') : (track.thumbnail || track.localThumbnail || ''); }
        catch (_) { source = track.thumbnail || track.localThumbnail || ''; }
      }
    }
    return /^(https?:|data:image\/|blob:|file:)/i.test(source) ? source : '';
  }

  function refreshLibraryPlaylists(hub = document.querySelector('.neo-collection-view, .neo-library-hub')) {
    if (!hub) return;
    const list = hub.querySelector('.neo-library-playlist-list');
    const count = hub.querySelector('.neo-library-playlist-count');
    if (!list) return;
    const playlists = getUserPlaylists();
    const sortMode = localStorage.getItem('muriel_playlists_sort') || 'custom';
    if (sortMode === 'name') {
      playlists.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
    } else if (sortMode === 'count') {
      playlists.sort((a, b) => (Array.isArray(b.tracks) ? b.tracks.length : 0) - (Array.isArray(a.tracks) ? a.tracks.length : 0));
    }
    if (count) count.textContent = String(playlists.length);
    list.replaceChildren();

    if (!playlists.length) {
      const empty = document.createElement('p');
      empty.className = 'neo-library-playlist-empty';
      empty.textContent = 'Your playlists will appear here after you create one.';
      list.appendChild(empty);
      return;
    }

    const core = window.MurielCore;
    playlists.forEach((playlist) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'neo-library-playlist-item';
      button.dataset.playlistId = String(playlist.id);
      button.setAttribute('aria-label', `Open playlist ${playlist.name || 'Untitled playlist'}`);

      const artwork = document.createElement('span');
      artwork.className = 'neo-library-playlist-art';
      const source = getPlaylistArtwork(playlist);
      if (source) {
        const image = document.createElement('img');
        image.src = source;
        image.alt = '';
        image.loading = 'lazy';
        image.decoding = 'async';
        image.addEventListener('error', () => { artwork.replaceChildren(); artwork.textContent = '♫'; }, { once: true });
        artwork.appendChild(image);
      } else {
        artwork.textContent = '♫';
      }

      const info = document.createElement('span');
      info.className = 'neo-library-playlist-info';
      const name = document.createElement('b');
      name.textContent = playlist.name || 'Untitled playlist';
      const meta = document.createElement('small');
      const trackCount = Array.isArray(playlist.tracks) ? playlist.tracks.length : 0;
      meta.textContent = `${trackCount} ${trackCount === 1 ? 'track' : 'tracks'}`;
      info.append(name, meta);

      const openIcon = document.createElement('span');
      openIcon.className = 'neo-library-playlist-open';
      openIcon.setAttribute('aria-hidden', 'true');
      openIcon.textContent = '›';
      button.append(artwork, info, openIcon);
      button.addEventListener('click', () => {
        hideMobileLandingViews();
        if (core && typeof core.openPlaylist === 'function') {
          core.openPlaylist(playlist.id);
        } else {
          const drawer = document.getElementById('rail-drawer');
          const existing = drawer && Array.from(drawer.querySelectorAll('.playlist-item')).find((item) => item.dataset.playlistId === String(playlist.id));
          if (existing) existing.click();
        }
      });
      list.appendChild(button);
    });
  }

  function refreshVisibleLibraryPlaylists() {
    const hub = document.querySelector('.neo-collection-view, .neo-library-hub');
    if (hub) refreshLibraryPlaylists(hub);
  }

  function optimizeContentImages() {
    const critical = '#titlebar, .playbar, #right-panel, #splash, .profile-menu';
    const tune = (img) => {
      if (!(img instanceof HTMLImageElement)) return;
      if (!img.closest(critical)) {
        if (!img.hasAttribute('loading')) img.loading = 'lazy';
        if (!img.hasAttribute('decoding')) img.decoding = 'async';
        if (!img.hasAttribute('fetchpriority')) img.fetchPriority = 'low';
      } else if (!img.hasAttribute('decoding')) {
        img.decoding = 'async';
      }
    };
    document.querySelectorAll('img').forEach(tune);
    const target = document.getElementById('main-content') || document.body;
    if (!target || !('MutationObserver' in window)) return;
    const observer = new MutationObserver((records) => {
      for (const record of records) {
        for (const node of record.addedNodes) {
          if (node instanceof HTMLImageElement) tune(node);
          else if (node && node.querySelectorAll) node.querySelectorAll('img').forEach(tune);
        }
      }
    });
    observer.observe(target, { childList: true, subtree: true });
  }

  function finishInit() {
    addPaletteCustomizer();
    addThemeModeSelector();
    addVisualThemeSelector();
    trimMobileSettings();
    ensureHomeWelcome();
    refreshHomeRecent();
    addSpotifyNavigation();
    optimizeContentImages();
    window.addEventListener('prics:playlists-updated', refreshVisibleLibraryPlaylists);
    window.addEventListener('muriel:library', refreshHomeRecent);
    window.addEventListener('muriel:library', refreshVisibleLibraryPlaylists);
    window.addEventListener('storage', (event) => {
      if (!event.key || event.key === 'devsize_playlists') refreshVisibleLibraryPlaylists();
    });

    const tracksBtn = document.querySelector('#settings-nav .settings-nav-btn[data-cat="tracks"]');
    if (tracksBtn) {
      const label = tracksBtn.querySelector('.settings-nav-label, span') || tracksBtn;
      if (label) label.textContent = 'Playback & Audio';
    }

    // Existing theme controls remain compatible with the new palette.
    document.querySelectorAll('.theme-swatch').forEach((button) => button.addEventListener('click', () => setTimeout(applyPalette, 0)));
    const legacyPicker = document.getElementById('settings-custom-color-input');
    if (legacyPicker) legacyPicker.addEventListener('input', applyPalette);
    const hueSlider = document.getElementById('slider-theme-hue');
    if (hueSlider) hueSlider.addEventListener('change', () => setTimeout(applyPalette, 0));
    document.querySelectorAll('.theme-mode-btn[data-theme-mode]').forEach((button) => button.addEventListener('click', () => setTimeout(applyPalette, 0)));

    let lastMode = document.body.classList.contains('theme-dark') ? 'dark' : 'light';
    new MutationObserver(() => {
      const nextMode = document.body.classList.contains('theme-dark') ? 'dark' : 'light';
      if (nextMode !== lastMode) { lastMode = nextMode; applyPalette(); }
    }).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  }

  function init() {
    lockScrollX();
    setVisualTheme(normalizeVisualTheme(localStorage.getItem(VISUAL_THEME_KEY)));
    applyPalette();
    if (window.MurielCore) finishInit();
    else window.addEventListener('muriel:ready', finishInit, { once: true });
    requestAnimationFrame(lockScrollX);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
