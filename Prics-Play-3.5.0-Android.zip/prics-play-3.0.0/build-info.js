window.MURIEL_BUILD = {"sha":"dev","version":"3.5.0","run":0,"repo":"redhozr21/prics-neubrutalism-android","builtAt":"2026-11-02T14:00:00.000Z","channel":""};
