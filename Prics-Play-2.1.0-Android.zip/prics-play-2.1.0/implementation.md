# Prics Play 2.1.0 — Implementation Plan and Status

**Status:** Source changes implemented; automated checks run; mobile bundle/APK and physical-device validation still pending.
**Previous source version:** 2.0.0
**Target version:** `2.1.0`

## Goals

1. Make battery-optimization requests opt-in rather than triggering Android Settings when playback starts.
2. Add persistent audio-quality targets: Data Saver 24 kbps, Low 48 kbps, Normal 96 kbps, High 160 kbps, Very High 320 kbps, and Automatic.
3. Use source renditions that are actually available and report the bitrate only when provider metadata supports it.
4. Reduce unnecessary mobile prefetch and release the Wi-Fi lock during cached-file playback without removing the CPU wake lock used for background playback.
5. Preserve the application ID, prior release archives, user data, themes, navigation, and existing player controls.

## Implementation decisions

- Quality values are targets, not guarantees. The extractor selects the highest known rendition at or below the target; if none exists below the target, it uses the lowest known rendition. Automatic selects the best available rendition.
- No on-device transcoding was added. If the provider does not expose a suitable rendition or bitrate metadata, the app must disclose that limitation rather than claim an exact bitrate.
- Existing cached tracks are not deleted or re-encoded when the setting changes. They retain their existing quality and remain available offline. The preference applies when a track is newly resolved/downloaded.
- Mobile prefetch is disabled in Data Saver mode. Other modes prefetch only the immediate next track later in the current song, instead of eagerly downloading two full tracks soon after playback starts.
- Battery exemption remains available from Settings but is not requested automatically on the audio `playing` event.
- The Wi-Fi lock is used while a track is loading and released during local cached playback. The CPU wake lock and native playback service are retained to protect background playback.

## Estimated data use

These estimates are theoretical at the target bitrate, use decimal MB, and exclude network overhead:

| Mode | Target | Estimate per hour |
|---|---:|---:|
| Data Saver | 24 kbps | 10.8 MB |
| Low | 48 kbps | 21.6 MB |
| Normal | 96 kbps | 43.2 MB |
| High | 160 kbps | 72 MB |
| Very High | 320 kbps | 144 MB |
| Automatic | Provider-selected | Varies |

## Verification status

- Focused regression tests: 38/38 passed.
- Full test suite: 291/292 passed. The remaining failure is environmental: `electron` was unavailable because dependency installation timed out; no assertion failed in that test.
- Changed JavaScript files pass syntax checks.
- Mobile bundle and APK build were not completed in this environment because `npm ci` timed out before `esbuild` was available.
- Physical-device playback, screen-off playback, update signing compatibility, and real battery/data measurements remain unverified.

## Release gate

Do not mark 2.1.0 as release-ready until GitHub Actions successfully builds the APK, the signature matches the installed app, and device tests cover Play/Pause/Resume/Stop/Seek/Next/Previous/Shuffle/Repeat, playlists, headset and notification controls, background playback, audio-quality persistence, and the absence of automatic Battery Details navigation.
