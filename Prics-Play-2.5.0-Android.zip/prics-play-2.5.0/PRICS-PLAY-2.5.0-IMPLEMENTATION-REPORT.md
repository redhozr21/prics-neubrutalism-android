# Prics Play 2.5.0 — Implementation Report

## Baseline
The project was taken from the uploaded `Prics-Play-2.3.3-Android.zip` source archive (306 entries; ZIP integrity test passed). The app core and native Android project are retained from this baseline.

## Version updates
- `package.json`: 2.5.0
- `package-lock.json`: 2.5.0 at root and root package record
- Android Gradle fallback `versionName`: 2.5.0
- Update-notifier fallback: 2.5.0
- Stable application ID remains `io.github.cloverscripts.muriel`

## Now Playing changes
- The mobile Now Playing panel uses a static coral/red-orange background.
- Artwork is large and centered in preview mode.
- Track title, artist and favorite action remain visible.
- Existing playbar and native audio controls remain the only playback controls.

## Lyrics behavior
- Default state is compact preview, with a maximum visible lyric region of approximately 106 CSS pixels.
- A new accessible button toggles between preview and full lyrics.
- Full lyrics mode compacts artwork to a 68px header and allows the lyrics container to scroll.
- No audio element, playback engine, media session or playback listener is duplicated.

## Freeze prevention
The baseline 2.3.3 drawer observer observes the `class` attribute on `#right-panel` but only mirrors the state onto `document.body`. The new lyrics control changes panel state only in response to a user click. The lyrics-content observer watches `#lyrics-container` child/text changes and only updates the visibility of its own button; it does not mutate the observed lyrics container or the panel class. This avoids the self-triggering panel-class mutation pattern from the 3.4.0 experiment.

## Files changed
- `package.json`
- `package-lock.json`
- `android/app/build.gradle`
- `update-notifier.js`
- `mobile/mobile-ui.js`
- `mobile/mobile.css`
- `README.md`
- `test/prics-play-v250.test.js` (renamed from the 2.3.3 release test)
- `test/mobile-neubrutalism.test.js`
- New 2.5.0 release and implementation documentation

## Validation status
- Source ZIP integrity is checked after packaging.
- JavaScript syntax and automated Node tests are run before release packaging.
- A prior baseline run on the uploaded 2.3.3 source had 336/337 tests passing; one pre-existing unrelated YouTube-library test failed. The 2.5.0 suite must be rerun after these changes.
- No APK has been built here; no physical Android installation, thermal test or battery measurement has been performed.
- Signing compatibility is not assumed. The repository Actions cache was observed empty, so the old debug workflow may produce a new debug certificate. Verify fingerprint before installing over an existing app.
