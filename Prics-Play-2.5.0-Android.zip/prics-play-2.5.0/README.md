# Prics Play 2.5.0 — Android refresh

This source archive is the **2.5.0** update built from the stable 2.3.3 codebase.

## What's new in 2.5.0

- Keeps the stable 2.3.3 app core, Android bridge, playback engine, native media session, navigation and settings integrations.
- Refreshes the mobile Now Playing screen with a static coral/red-orange surface, large centered album artwork, track metadata and the existing playback controls.
- Shows only a short lyrics preview by default in a light card below the player information.
- Adds an explicit **Lihat lirik lengkap** action. Full lyrics open only when requested; the artwork becomes compact and the lyrics area becomes scrollable.
- Keeps the lyrics observer scoped to lyric content. The drawer visibility observer only mirrors `#right-panel` state to `body`; it does not mutate the observed panel, avoiding the observer loop seen in the 3.4.0 experiment.
- Keeps the original workflow and Android application ID. No new workflow is required.

## Version and build

- `package.json` and `package-lock.json`: `2.5.0`
- Android `versionName`: `2.5.0`
- Android application ID: `io.github.cloverscripts.muriel`
- Expected source archive name for the existing version-selecting workflow: `Prics-Play-2.5.0-Android.zip`

The existing repository workflow can select this ZIP when `2.5.0` is entered in its manual version input, or when it automatically selects the highest versioned source ZIP.

## Important signing note

A successful build does **not** prove that the APK can update an already installed copy. Android requires the same signing certificate. The repository's Actions cache was previously observed empty, so the old debug workflow may generate a new debug keystore. Before installing over the existing 2.3.3 app, compare the built APK certificate fingerprint with the currently installed release APK's certificate. Do not uninstall or clear app data merely to bypass a signature mismatch.

## Validation limits

Source syntax and Node regression tests can be run in CI. This archive has not been built or installed on a physical Android device in this environment. Battery use, device thermals, Android lifecycle behavior and touch responsiveness still require a real-device test.
