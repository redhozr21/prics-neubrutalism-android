# Prics Play 2.5.0 — Performance Notes

- The coral Now Playing background is static; no looping gradient animation or visualizer is added by this change.
- The lyrics preview clips content with CSS rather than continuously recalculating lyric layout.
- Full lyrics are scrollable only after the user explicitly opens them.
- The existing audio element and playback engine are reused.
- The lyrics observer is scoped to lyric content mutations and performs only a small visibility check on its button.
- The existing drawer observer remains a one-way state mirror from the panel to the body.

These are source-level performance safeguards, not measured battery or temperature results. Compare the same phone, same audio source, same volume and same screen conditions for a real battery test.
