# Prics Play 2.5.0 — Build Guide

## Upload to the existing repository

1. Open `https://github.com/redhozr21/prics-neubrutalism-android`.
2. Stay on the `main` branch.
3. Choose **Add file → Upload files**.
4. Upload `Prics-Play-2.5.0-Android.zip` to the repository root (same level as the previous source ZIP).
5. Commit the upload to `main`.

The existing workflow watches root-level `*.zip` files. Uploading the 2.5.0 ZIP should start the existing workflow automatically. Do not create a second workflow.

## If starting the workflow manually

1. Open **Actions**.
2. Select the existing **Build Prics Play Android** workflow.
3. Choose **Run workflow** on branch `main`.
4. Enter `2.5.0` in the version input.
5. Run the workflow.

## After the run

1. Open the newest run and check that all build steps completed.
2. Download `Prics-Play.apk` from the GitHub Release or `Prics-Play-debug-apk` artifact, depending on what the existing workflow publishes.
3. Do not install it yet.
4. Upload the newly built APK here so its signing certificate can be compared with the known stable 2.3.3/3.3.0 APK.

## Important: preserve the existing installation

The repository's Actions cache was previously shown as empty. The old workflow can still build an APK, but if Gradle generates a fresh debug keystore, Android may refuse to install it over the existing app.

A successful build is not proof of signing compatibility. Do not uninstall the currently working app and do not clear its data. First compare the newly built APK's certificate with the stable APK. If the fingerprints differ, cancel the update and recover the original signing key or plan a data-preserving migration.
