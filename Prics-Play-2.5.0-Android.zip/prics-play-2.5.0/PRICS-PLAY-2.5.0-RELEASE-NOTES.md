# Prics Play 2.5.0 — Release Notes

## Mobile Now Playing refresh
- Coral / red-orange Now Playing background.
- Large centered album artwork in the default player view.
- Track title, artist and favorite action remain available.
- Playback remains connected to the existing single audio engine and existing transport buttons.

## Lyrics
- The default view shows a compact lyrics preview only.
- The **Lihat lirik lengkap** control opens the full, scrollable lyrics view.
- Full lyrics mode reduces artwork to a compact header to give lyrics more room.
- Returning to the preview does not restart playback or create another audio element.

## Stability and performance
- Rebased on the stable 2.3.3 source instead of carrying forward the 3.4.0 UI experiment.
- No continuously animated ambient background was added.
- The lyrics observer watches lyric content only.
- The drawer observer does not modify the panel whose class it observes.

## Preserved
- Stable Android application ID.
- Existing playback engine, queue, media session and background playback implementation.
- Home, Search, Collection, Theme, Integrations, Storage, Profiles and About.
- Existing repository build workflow; no second workflow is required.

## Before installing
Verify that the APK signing certificate matches the currently installed app. If it does not match, cancel installation. Do not uninstall or clear app data without a verified backup.
