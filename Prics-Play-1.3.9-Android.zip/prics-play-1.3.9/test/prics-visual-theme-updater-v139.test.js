const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');

test('release version is 1.3.9 while the Android package identity remains stable', () => {
  const pkg = JSON.parse(read('package.json'));
  const lock = JSON.parse(read('package-lock.json'));
  const cap = JSON.parse(read('capacitor.config.json'));
  const gradle = read('android/app/build.gradle');
  assert.equal(pkg.version, '1.3.9');
  assert.equal(lock.version, '1.3.9');
  assert.equal(lock.packages[''].version, '1.3.9');
  assert.equal(cap.appId, 'io.github.cloverscripts.muriel');
  assert.match(gradle, /versionName pricsVersionName/);
  assert.match(gradle, /pricsVersionBaseCode/);
});

test('theme selector provides Neubrutalism by default and Liquid Glass, and persists choice', () => {
  const build = read('mobile/build.mjs');
  const bridge = read('mobile/bridge.js');
  const skin = read('mobile/neubrutalism.js');
  const css = read('mobile/mobile.css');
  assert.match(build, /prics-visual-theme-bootstrap/);
  assert.ok(build.indexOf('src="profiles-core.js"') < build.indexOf('prics-visual-theme-bootstrap'));
  assert.match(build, /prics_play_visual_theme/);
  assert.match(bridge, /prics_play_visual_theme/);
  assert.match(skin, /data-prics-visual-theme="neubrutalism"/);
  assert.match(skin, /data-prics-visual-theme="liquid-glass"/);
  assert.match(skin, /localStorage\.setItem\(VISUAL_THEME_KEY, theme\)/);
  assert.match(skin, /theme === 'neubrutalism'/);
  assert.match(skin, /theme === 'liquid-glass'/);
  assert.match(css, /html\.is-mobile\.liquid-glass-theme/);
  assert.match(css, /backdrop-filter:blur\(var\(--glass-blur\)\)/);
});

test('About updater checks the owned public release and opens the APK through Android external browser', () => {
  const updater = read('update-notifier.js');
  const java = read('android/app/src/main/java/io/github/cloverscripts/muriel/ExternalUrlPlugin.java');
  const activity = read('android/app/src/main/java/io/github/cloverscripts/muriel/MainActivity.java');
  assert.match(updater, /api\.github\.com\/repos\/\$\{REPO\}\/releases\/latest/);
  assert.match(updater, /function compareVersions/);
  assert.match(updater, /browser_download_url/);
  assert.match(updater, /Download APK/);
  assert.match(updater, /window\.PricsExternalUrl\.open\(url\)/);
  assert.match(java, /Intent\.ACTION_VIEW/);
  assert.match(java, /Only trusted HTTPS GitHub URLs/);
  assert.match(activity, /registerPlugin\(ExternalUrlPlugin\.class\)/);
  assert.match(updater, /is up to date/);
});


test('update button downloads a newer APK but does not reopen the same installed build', async () => {
  const updater = read('update-notifier.js');
  async function run(build, release) {
    const opened = [];
    const handlers = {};
    const statusEl = { textContent: '', classList: { toggle() {} } };
    const checkBtn = { textContent: 'Check now', addEventListener(name, fn) { handlers[name] = fn; } };
    const aboutVersion = { textContent: '' };
    const storage = new Map();
    const context = {
      window: {
        MURIEL_BUILD: build,
        Capacitor: { getPlatform: () => 'android', isNativePlatform: () => true },
        PricsExternalUrl: { open: async (url) => { opened.push(url); } },
        location: { href: '' },
        open() {},
      },
      document: {
        hidden: false,
        getElementById(id) { return id === 'update-status' ? statusEl : id === 'btn-check-updates' ? checkBtn : id === 'about-version' ? aboutVersion : null; },
        addEventListener() {},
      },
      localStorage: { getItem(k) { return storage.get(k) || null; }, setItem(k, v) { storage.set(k, v); } },
      fetch: async () => ({ ok: true, json: async () => release }),
      AbortController: class { constructor() { this.signal = {}; } abort() {} },
      setTimeout: () => 1,
      clearTimeout() {},
      Date,
      Promise,
    };
    vm.runInNewContext(updater, context);
    await context.window.PricsPlayUpdates.check();
    return { opened, statusEl, checkBtn, aboutVersion };
  }
  const asset = { name: 'Prics-Play.apk', browser_download_url: 'https://github.com/redhozr21/prics-neubrutalism-android/releases/download/prics-play-latest/Prics-Play.apk' };
  const release = (version, build) => ({
    draft: false, prerelease: false, html_url: 'https://github.com/redhozr21/prics-neubrutalism-android/releases/tag/prics-play-latest',
    tag_name: 'prics-play-latest', name: 'Prics Play for Android (latest build)',
    body: `Prics Play ${version} · Build ${build}. <!-- prics-play-version: ${version} --><!-- prics-play-build: ${build} -->`,
    assets: [asset],
  });
  const same = await run({ version: '1.3.9', run: 14 }, release('1.3.9', 14));
  assert.equal(same.opened.length, 0);
  assert.match(same.statusEl.textContent, /up to date/i);
  const newer = await run({ version: '1.3.8', run: 14 }, release('1.3.9', 15));
  assert.deepEqual(newer.opened, [asset.browser_download_url]);
  assert.match(newer.statusEl.textContent, /Update available/);
});
