package io.github.cloverscripts.muriel;

import android.app.UiModeManager;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    static {
        try {
            // Prioritize IPv4 on Wi-Fi dual-stack networks (prevents DNS and TCP connection hangs
            // on ISPs like IndiHome/Biznet where broken IPv6 routes drop Google/YouTube CDN packets)
            System.setProperty("java.net.preferIPv4Stack", "true");
            System.setProperty("java.net.preferIPv6Addresses", "false");
            System.setProperty("http.keepAlive", "true");
            System.setProperty("http.maxConnections", "10");
        } catch (Throwable ignored) {}
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // plugins that live in the app itself (not in an npm package) are registered by hand
        registerPlugin(MediaControlsPlugin.class);
        registerPlugin(ExternalUrlPlugin.class);
        registerPlugin(PricsUpdatePlugin.class);
        registerPlugin(DisplayRefreshRatePlugin.class);
        super.onCreate(savedInstanceState);

        try {
            final boolean isTelevision = isTVDevice();
            WebView webView = getBridge().getWebView();
            if (webView != null) {
                WebSettings settings = webView.getSettings();
                String ua = settings.getUserAgentString();
                if (isTelevision && !ua.contains("PricsTV")) {
                    settings.setUserAgentString(ua + " PricsTV/1.0");
                }

                // Expose reliable native bridge for web platform detection
                webView.addJavascriptInterface(new Object() {
                    @JavascriptInterface
                    public boolean isTelevision() {
                        return isTelevision;
                    }

                    @JavascriptInterface
                    public void exitApp() {
                        runOnUiThread(() -> finish());
                    }
                }, "PricsAndroidDevice");
            }
        } catch (Throwable ignored) {}
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (isTVDevice()) {
            final int keyCode = event.getKeyCode();
            final int action = event.getAction();

            // Intercept Back button so it never prematurely exits the TV app
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                if (action == KeyEvent.ACTION_UP) {
                    WebView webView = getBridge().getWebView();
                    if (webView != null) {
                        webView.evaluateJavascript("if (window.PricsTV && window.PricsTV.handleBack) { window.PricsTV.handleBack(); }", null);
                    }
                }
                return true; // Consumed!
            }

            // Direct mapping for D-Pad Center (OK button on TV remote)
            if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER) {
                if (action == KeyEvent.ACTION_UP) {
                    WebView webView = getBridge().getWebView();
                    if (webView != null) {
                        webView.evaluateJavascript("if (window.PricsTV && window.PricsTV.handleSelect) { window.PricsTV.handleSelect(); }", null);
                    }
                }
                return true; // Consumed!
            }

            // Direct mapping for TV Remote Media keys
            if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY || keyCode == KeyEvent.KEYCODE_MEDIA_PAUSE) {
                if (action == KeyEvent.ACTION_UP) {
                    WebView webView = getBridge().getWebView();
                    if (webView != null) {
                        webView.evaluateJavascript("if (window.PricsTV && window.PricsTV.handleMediaPlayPause) { window.PricsTV.handleMediaPlayPause(); }", null);
                    }
                }
                return true;
            }

            if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
                if (action == KeyEvent.ACTION_UP) {
                    WebView webView = getBridge().getWebView();
                    if (webView != null) {
                        webView.evaluateJavascript("if (window.PricsTV && window.PricsTV.handleMediaNext) { window.PricsTV.handleMediaNext(); }", null);
                    }
                }
                return true;
            }

            if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
                if (action == KeyEvent.ACTION_UP) {
                    WebView webView = getBridge().getWebView();
                    if (webView != null) {
                        webView.evaluateJavascript("if (window.PricsTV && window.PricsTV.handleMediaPrev) { window.PricsTV.handleMediaPrev(); }", null);
                    }
                }
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public void onBackPressed() {
        if (isTVDevice()) {
            WebView webView = getBridge().getWebView();
            if (webView != null) {
                webView.evaluateJavascript("if (window.PricsTV && window.PricsTV.handleBack) { window.PricsTV.handleBack(); }", null);
                return;
            }
        }
        super.onBackPressed();
    }

    private boolean isTVDevice() {
        try {
            UiModeManager uiModeManager = (UiModeManager) getSystemService(UI_MODE_SERVICE);
            if (uiModeManager != null && uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION) {
                return true;
            }
            PackageManager pm = getPackageManager();
            if (pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
                pm.hasSystemFeature("android.software.leanback") ||
                pm.hasSystemFeature("android.hardware.type.television")) {
                return true;
            }
            // Non-touch device check: Every smartphone has a touchscreen. TVs and TV boxes do not.
            if (!pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)) {
                return true;
            }
            // Display aspect check: Widescreen landscape without touchscreen
            DisplayMetrics dm = getResources().getDisplayMetrics();
            int widthDp = (int) (dm.widthPixels / dm.density);
            int heightDp = (int) (dm.heightPixels / dm.density);
            if (widthDp >= 960 && widthDp > heightDp && !pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)) {
                return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }
}
