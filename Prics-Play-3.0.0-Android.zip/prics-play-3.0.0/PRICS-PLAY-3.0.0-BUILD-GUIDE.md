# Prics Play 3.0.0 — Build Guide

1. Keep the repository's existing workflow file and its dependency lock handling.
2. Upload `Prics-Play-3.0.0-Android.zip` to the repository root on `main`, or manually dispatch the existing workflow with version `3.0.0`.
3. Wait for every build step to finish. Download the APK and SHA-256 checksum from the successful run/release.
4. Before installing, compare the APK signing certificate with the currently installed Prics Play certificate.
5. If the certificate differs, stop. Do not uninstall the installed app or clear its data. Restore the original signing key first.

The source ZIP does not itself prove the Android build, signing certificate, or on-device behavior.

## Current signing status in this project

The latest successful `Prics-Play.apk` available in the working files has certificate SHA-256 `49C30BE6AC389C889A731F2131466E8F81382CC2B12671A3CACF48CCE4D44D6A`. Android previously rejected that build as an update to the installed 2.6.3 app, which proves the installed app uses a different certificate. Do not publish/install the 3.0.0 APK as an in-place update until the exact 2.6.3 private signing key is recovered and verified. The source archive intentionally contains no new keystore and does not generate one.
