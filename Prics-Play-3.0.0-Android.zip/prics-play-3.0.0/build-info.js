window.MURIEL_BUILD = {"sha":"dev","version":"3.0.0","run":0,"repo":"redhozr21/prics-neubrutalism-android","builtAt":"2026-10-31T22:46:46.889Z","channel":""};
