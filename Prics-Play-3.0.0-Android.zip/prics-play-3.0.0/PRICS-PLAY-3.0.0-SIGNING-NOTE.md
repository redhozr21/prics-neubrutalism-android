# Prics Play 3.0.0 — Signing Compatibility Warning

The previously supplied APKs were inspected by reading their APK Signature Scheme v2 certificates. Their SHA-256 fingerprints differ:

- `Prics-Play 3.3.0.apk`: `DAD59C432B9C71753B6C0EDFFB3FF20717FFD64C71CACDA476C6E348C9748310`
- `Prics-Play 3.4.0.apk`: `A31F0FE0D1C4F95C4D368432E12AE37591998BD8172086BFFACED9B731DACC2C`
- `Prics-Play.apk` from the latest successful build: `49C30BE6AC389C889A731F2131466E8F81382CC2B12671A3CACF48CCE4D44D6A`

The project workspace contains no `.keystore`, `.jks`, or `.p12` private-key file. An APK contains the public signing certificate, not the private key needed to sign a compatible update. The installed 2.6.3 certificate has not been extracted directly from the phone in this session, so do not assume which of the above fingerprints it uses without checking the installed APK/build record.

**Do not uninstall the installed app or clear its data.** Before installing 3.0.0, recover the exact original private signing key or compare the candidate APK certificate with the installed app certificate. If the original key cannot be recovered, an update in place is cryptographically impossible; use the app's own backup/export and verify the backup before considering a fresh installation.
