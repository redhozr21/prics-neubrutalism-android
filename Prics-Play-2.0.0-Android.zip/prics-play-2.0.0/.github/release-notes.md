# Prics Play 2.0.0 — Release Notes

## Highlights
- Major visual refresh with a shared layout across Neubrutalism and Liquid Glass themes.
- Liquid Glass theme now uses scoped translucent surfaces, a floating convex bottom navigation treatment, soft specular highlights, and a reduced-cost fallback when backdrop blur is unsupported.
- Replaced the legacy star branding with the supplied P.A PLAY logo in the app header, About icon, Android launcher assets, and native splash images.
- Removed the legacy My Wave carousel from the product UI and removed its startup recommendation request path. The separate Made for You daily-mix feature remains independent.
- Delayed noncritical daily-mix requests while playback is resolving or buffering.
- Updated in-app updater to check the public GitHub Releases API and offer a separate “Download now” action when a newer APK exists.
- Changed CI publishing to use immutable versioned releases (`v2.0.0`) without deleting older releases.

## Compatibility and release notes
- Android application ID remains `io.github.cloverscripts.muriel` to preserve upgrade compatibility.
- APK upgrade compatibility still depends on the same release signing certificate and a higher Android `versionCode`.
- Android installation requires the user to confirm the system installer prompt.
- This source archive does not itself publish the GitHub release. The repository workflow must run successfully and attach the APK asset before in-app updates can download it.

## Validation
- Run `npm test` after installing dependencies.
- Run `node mobile/build.mjs`, `npx cap sync android`, and the Android Gradle release build in CI.
- Test playback, navigation, both themes, and upgrade from 1.3.9 on a real Android device before calling the release stable.
