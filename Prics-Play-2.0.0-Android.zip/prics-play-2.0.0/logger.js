const fs = require('fs');
const path = require('path');
const { DATA_DIR } = require('./platform');

const LOG_DIR = path.join(DATA_DIR, 'logs');
const LOG_PATH = path.join(LOG_DIR, 'muriel.log');
const MAX_BYTES = 1024 * 1024;

function rotate() {
  try {
    if (fs.existsSync(LOG_PATH) && fs.statSync(LOG_PATH).size > MAX_BYTES) fs.renameSync(LOG_PATH, `${LOG_PATH}.1`);
  } catch (e) {}
}

function log(level, message) {
  try {
    fs.mkdirSync(LOG_DIR, { recursive: true });
    rotate();
    fs.appendFileSync(LOG_PATH, `${new Date().toISOString()} [${level}] ${String(message).slice(0, 800)}\n`);
  } catch (e) {}
}

function tail(lines) {
  try { return fs.readFileSync(LOG_PATH, 'utf8').split('\n').filter(Boolean).slice(-lines); } catch (e) { return []; }
}

const describe = (message, err) => (err ? `${message}: ${(err && (err.stack || err.message)) || err}` : message);
const error = (message, err) => log('error', describe(message, err));
const warn = (message, err) => log('warn', describe(message, err));
const info = (message) => log('info', message);

module.exports = { log, error, warn, info, tail, LOG_DIR };
