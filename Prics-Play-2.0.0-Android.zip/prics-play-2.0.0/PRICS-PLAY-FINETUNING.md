# Prics Play Android — Fine-tuning notes

This source bundle contains the mobile UI/UX and resource-use updates.

- Compact mobile title/header and tighter spacing before the search/source controls.
- Library bottom tab now routes to a real Library hub with shortcuts to favorites, albums, artists, local tracks, and history.
- Extra inner padding and safer overflow handling for Home recommendation cards and genre chips.
- Lazy image loading/async decoding for non-critical content images.
- A six-hour local cache for recommendation responses to avoid repeated discovery requests; stale cached data remains available if refresh fails.
- New mobile audio-cache default is 512 MB for users without a saved preference; existing saved limits are preserved. Settings retain 256 MB through 10 GB choices.
- Existing seekbar pointer events and shuffle queue logic are retained.

## Build

Use the provided GitHub Actions workflow to build the APK in the cloud. The workflow accepts either `Prics-Play-Finetune-Android.zip` or `prics-neubrutalism-android.zip` at the repository root.

## Validation

- JavaScript syntax checks pass for the modified application and mobile scripts.
- Focused mobile Neubrutalism test suite: 9/9 passed.
- Full Node test suite in the current environment: 255 passed; 3 tests could not run because `electron` and `youtubei.js/web` are not installed in this environment.
- Android APK build and real-device playback/navigation still need to be run through GitHub Actions and verified on a device.

Legacy `muriel_*` local-storage keys and Android package ID are intentionally retained to avoid breaking existing user preferences, saved playlists, app updates, or local data.

- Playlist detail cards now have consistent inner padding, description spacing, safe title wrapping, and wrapped action controls so borders/shadows do not collide with content on narrow screens.
- The mobile Library hub now renders saved user playlists directly from `MurielCore.state.playlists` (with a local-storage fallback), opens a selected playlist, and refreshes after create/rename/delete/import/sync flows via `prics:playlists-updated`.
- Added focused source-wiring regression tests in `test/prics-library-ui.test.js` for the Library playlist section, update event, and mobile playlist-card spacing.
