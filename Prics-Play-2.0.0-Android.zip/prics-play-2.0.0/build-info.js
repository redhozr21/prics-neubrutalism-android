window.MURIEL_BUILD = {"sha":"dev","version":"2.0.0","run":0,"repo":"redhozr21/prics-neubrutalism-android","builtAt":"2026-10-29T00:00:00.000Z","channel":""};
