// Mobile-only Neubrutalism skin and Spotify-like primary navigation.
// This layer only changes presentation and navigation; the existing playback engine stays untouched.
(() => {
  const root = document.documentElement;
  if (!root.classList.contains('is-mobile')) return;

  const COLORS = {
    light: { accent: '#FFE14A', background: '#FFF8E7', surface: '#FFFFFF', ink: '#171717', secondary: '#FF8A65', tertiary: '#9BE7B5' },
    dark:  { accent: '#FFE14A', background: '#181818', surface: '#252525', ink: '#FFF8E7', secondary: '#FF8A65', tertiary: '#9BE7B5' },
  };
  const KEYS = {
    accent: 'muriel_theme_accent',
    background: 'muriel_neo_background',
    surface: 'muriel_neo_surface',
    ink: 'muriel_neo_ink',
    secondary: 'muriel_neo_secondary',
  };
  const isHex = (value) => typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value);
  const getColor = (key, fallback) => {
    try {
      const value = localStorage.getItem(KEYS[key]);
      return isHex(value) ? value : fallback;
    } catch (_) { return fallback; }
  };
  const setStored = (key, value) => {
    try { localStorage.setItem(KEYS[key], value); } catch (_) {}
  };

  function applyPalette() {
    const mode = document.body.classList.contains('theme-dark') ? 'dark' : 'light';
    const defaults = COLORS[mode];
    const colors = {
      accent: getColor('accent', defaults.accent),
      background: getColor('background', defaults.background),
      surface: getColor('surface', defaults.surface),
      ink: getColor('ink', defaults.ink),
      secondary: getColor('secondary', defaults.secondary),
      tertiary: defaults.tertiary,
    };
    Object.entries(colors).forEach(([key, value]) => root.style.setProperty(`--neo-${key}`, value));
    root.style.setProperty('--neo-paper', colors.background);
    root.style.setProperty('--neo-border-width', '2px');
    root.style.setProperty('--neo-shadow-size', '4px');

    const pickerIds = {
      accent: 'neo-color-accent', background: 'neo-color-background', surface: 'neo-color-surface',
      ink: 'neo-color-ink', secondary: 'neo-color-secondary',
    };
    Object.entries(pickerIds).forEach(([key, id]) => {
      const input = document.getElementById(id);
      if (input && input.value !== colors[key]) input.value = colors[key];
    });
  }


  const VISUAL_THEME_KEY = 'prics_play_visual_theme';
  const normalizeVisualTheme = (value) => value === 'liquid-glass' ? 'liquid-glass' : 'neubrutalism';

  function setVisualTheme(value) {
    const theme = normalizeVisualTheme(value);
    try { localStorage.setItem(VISUAL_THEME_KEY, theme); } catch (_) {}
    root.classList.toggle('neo-theme', theme === 'neubrutalism');
    root.classList.toggle('liquid-glass-theme', theme === 'liquid-glass');
    document.querySelectorAll('[data-prics-visual-theme]').forEach((button) => {
      const active = button.dataset.pricsVisualTheme === theme;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    applyPalette();
    window.dispatchEvent(new CustomEvent('prics:visual-theme-change', { detail: { theme } }));
  }

  function addVisualThemeSelector() {
    const section = document.querySelector('.settings-section[data-cat="theme"]');
    const group = section && section.querySelector('.m3-group[data-group="colors"]');
    if (!group || group.querySelector('.prics-visual-theme-setting')) return;
    const card = document.createElement('div');
    card.className = 'setting-item prics-visual-theme-setting';
    card.innerHTML = `
      <div class="prics-visual-theme-heading"><span class="setting-name">Visual theme</span><small>Choose your Prics Play appearance</small></div>
      <div class="prics-visual-theme-options" role="group" aria-label="Visual theme">
        <button type="button" class="prics-visual-theme-option" data-prics-visual-theme="neubrutalism" aria-pressed="true">
          <span class="prics-theme-preview prics-preview-neo" aria-hidden="true"><i></i><b>P.A</b><em></em></span>
          <span><strong>Neubrutalism</strong><small>Bold borders and hard shadows</small></span><span class="prics-theme-check" aria-hidden="true">✓</span>
        </button>
        <button type="button" class="prics-visual-theme-option" data-prics-visual-theme="liquid-glass" aria-pressed="false">
          <span class="prics-theme-preview prics-preview-glass" aria-hidden="true"><i></i><b>P.A</b><em></em></span>
          <span><strong>Liquid Glass</strong><small>Translucent layers and soft blur</small></span><span class="prics-theme-check" aria-hidden="true">✓</span>
        </button>
      </div>`;
    group.prepend(card);
    card.querySelectorAll('[data-prics-visual-theme]').forEach((button) => button.addEventListener('click', () => setVisualTheme(button.dataset.pricsVisualTheme)));
    setVisualTheme(normalizeVisualTheme(localStorage.getItem(VISUAL_THEME_KEY)));
  }

  function setAccent(value) {
    if (!isHex(value)) return;
    setStored('accent', value);
    const legacyPicker = document.getElementById('settings-custom-color-input');
    if (legacyPicker && legacyPicker.value.toLowerCase() !== value.toLowerCase()) {
      legacyPicker.value = value;
      legacyPicker.dispatchEvent(new Event('input', { bubbles: true }));
    }
    applyPalette();
  }

  function addPaletteCustomizer() {
    const section = document.querySelector('.settings-section[data-cat="theme"]');
    const group = section && section.querySelector('.m3-group[data-group="colors"]');
    if (!group || group.querySelector('.neo-theme-customizer')) return;

    const card = document.createElement('div');
    card.className = 'setting-item neo-theme-customizer';
    card.innerHTML = `
      <div class="neo-customizer-head">
        <div>
          <span class="setting-name">Neubrutalism palette</span>
          <p>Atur warna aksen, latar, kartu, teks, dan warna sekunder.</p>
        </div>
        <span class="neo-theme-chip">NEO</span>
      </div>
      <div class="neo-color-grid">
        <label class="neo-color-field" for="neo-color-accent"><span>Aksen</span><input id="neo-color-accent" data-neo-color="accent" type="color" value="#FFE14A"></label>
        <label class="neo-color-field" for="neo-color-background"><span>Latar</span><input id="neo-color-background" data-neo-color="background" type="color" value="#FFF8E7"></label>
        <label class="neo-color-field" for="neo-color-surface"><span>Kartu</span><input id="neo-color-surface" data-neo-color="surface" type="color" value="#FFFFFF"></label>
        <label class="neo-color-field" for="neo-color-ink"><span>Teks &amp; outline</span><input id="neo-color-ink" data-neo-color="ink" type="color" value="#171717"></label>
        <label class="neo-color-field" for="neo-color-secondary"><span>Aksen sekunder</span><input id="neo-color-secondary" data-neo-color="secondary" type="color" value="#FF8A65"></label>
      </div>
      <div class="neo-preset-label">Preset cepat</div>
      <div class="neo-preset-grid">
        <button type="button" class="neo-preset" data-neo-preset="pop">Pop</button>
        <button type="button" class="neo-preset" data-neo-preset="bubblegum">Bubblegum</button>
        <button type="button" class="neo-preset" data-neo-preset="lime">Lime</button>
        <button type="button" class="neo-preset" data-neo-preset="ocean">Ocean</button>
        <button type="button" class="neo-preset" data-neo-preset="night">Night</button>
      </div>
      <button type="button" class="neo-reset-palette" id="neo-reset-palette">Reset warna</button>
    `;
    group.prepend(card);

    card.querySelectorAll('[data-neo-color]').forEach((input) => {
      input.addEventListener('input', () => {
        const key = input.dataset.neoColor;
        if (key === 'accent') setAccent(input.value);
        else {
          setStored(key, input.value);
          applyPalette();
        }
      });
    });

    const presets = {
      pop:       { accent: '#FFE14A', background: '#FFF8E7', surface: '#FFFFFF', ink: '#171717', secondary: '#FF8A65' },
      bubblegum: { accent: '#FF70B8', background: '#FFF0F7', surface: '#FFFFFF', ink: '#281321', secondary: '#8DDBFF' },
      lime:      { accent: '#C7FF4A', background: '#F5FFE5', surface: '#FFFFFF', ink: '#19230B', secondary: '#A18BFF' },
      ocean:     { accent: '#59C8FF', background: '#EEF9FF', surface: '#FFFFFF', ink: '#102333', secondary: '#FFD166' },
      night:     { accent: '#FFE14A', background: '#181818', surface: '#252525', ink: '#FFF8E7', secondary: '#FF7B61' },
    };
    card.querySelectorAll('[data-neo-preset]').forEach((button) => {
      button.addEventListener('click', () => {
        const preset = presets[button.dataset.neoPreset];
        if (!preset) return;
        Object.entries(preset).forEach(([key, value]) => {
          if (key === 'accent') setStored('accent', value);
          else setStored(key, value);
        });
        const legacyPicker = document.getElementById('settings-custom-color-input');
        if (legacyPicker) {
          legacyPicker.value = preset.accent;
          legacyPicker.dispatchEvent(new Event('input', { bubbles: true }));
        }
        applyPalette();
      });
    });

    const reset = card.querySelector('#neo-reset-palette');
    reset.addEventListener('click', () => {
      ['background', 'surface', 'ink', 'secondary'].forEach((key) => {
        try { localStorage.removeItem(KEYS[key]); } catch (_) {}
      });
      setAccent(COLORS.light.accent);
      applyPalette();
    });
  }

  function addSpotifyNavigation() {
    const sidebar = document.getElementById('sidebar');
    if (!sidebar) return;
    sidebar.classList.add('neo-sidebar');

    // The mobile build emits this navigation in the HTML so it is visible on the very first
    // frame. Desktop/dev builds can still create it here when no static nav exists.
    let nav = sidebar.querySelector('.neo-bottom-nav');
    if (!nav) {
      nav = document.createElement('nav');
      nav.className = 'neo-bottom-nav';
      nav.setAttribute('aria-label', 'Navigasi utama');
      nav.innerHTML = `
      <button type="button" class="neo-tab active" data-tab="home" aria-label="Home">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/></svg><span>Home</span>
      </button>
      <button type="button" class="neo-tab" data-tab="search" aria-label="Search">
        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 5 5"/></svg><span>Search</span>
      </button>
      <button type="button" class="neo-tab" data-tab="library" aria-label="Koleksi">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4v16M9 4v16M14 4v16M19 4v16"/></svg><span>Koleksi</span>
      </button>
      <button type="button" class="neo-tab" data-tab="settings" aria-label="Tema"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 1 0 0 18h1.5a2.5 2.5 0 0 0 0-5H13a1 1 0 0 1 0-2h2.5A5.5 5.5 0 0 0 21 8.5C21 5.46 17 3 12 3Z"/><circle cx="7.5" cy="10" r="1"/><circle cx="11" cy="7.5" r="1"/><circle cx="15" cy="8" r="1"/></svg><span>Tema</span>
      </button>`;
      sidebar.appendChild(nav);
    }

    const setActive = (tab) => nav.querySelectorAll('.neo-tab').forEach((button) => {
      const active = button.dataset.tab === tab;
      button.classList.toggle('active', active);
      if (active) button.setAttribute('aria-current', 'page');
      else button.removeAttribute('aria-current');
      button.setAttribute('aria-pressed', String(active));
    });
    setActive('home');
    const clickExisting = (id) => { const button = document.getElementById(id); if (button) button.click(); };
    const searchInput = document.getElementById('search-input');
    let searchMode = false;

    nav.querySelector('[data-tab="home"]').addEventListener('click', () => {
      searchMode = false;
      if (searchInput && searchInput.value) clickExisting('search-clear-btn');
      clickExisting('nav-discover');
      setActive('home');
      if (document.activeElement === searchInput && searchInput) searchInput.blur();
    });
    nav.querySelector('[data-tab="search"]').addEventListener('click', () => {
      searchMode = true;
      clickExisting('nav-discover');
      setActive('search');
      if (searchInput) {
        try { searchInput.focus({ preventScroll: true }); } catch (_) { searchInput.focus(); }
        searchInput.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      }
    });
    nav.querySelector('[data-tab="library"]').addEventListener('click', () => {
      searchMode = false;
      // The previous handler only toggled the playlist drawer. When the drawer closed,
      // the current view (often Settings) remained underneath while Library looked selected.
      // Route to the app's real library landing view (Liked Songs/Favorites) instead.
      const drawer = document.getElementById('rail-drawer');
      if (drawer && !drawer.classList.contains('hidden')) clickExisting('btn-close-rail-drawer');
      clickExisting('nav-favorites');
      if (document.activeElement === searchInput && searchInput) searchInput.blur();
      setActive('library');
      // switchView runs on the next animation frame; scroll the newly activated view to its top
      // and expose a small Library hub so this tab is not merely an alias for Favorites.
      requestAnimationFrame(() => {
        const main = document.getElementById('main-content');
        if (main) main.scrollTop = 0;
        ensureLibraryHub();
        setActive('library');
      });
    });
    nav.querySelector('[data-tab="settings"]').addEventListener('click', () => {
      searchMode = false;
      clickExisting('nav-settings');
      // The fourth tab is a visual-theme shortcut. The in-page back control still exposes
      // the settings category list, including Interface and About/Updates.
      requestAnimationFrame(() => {
        const themeButton = document.querySelector('#settings-nav .settings-nav-btn[data-cat="theme"]');
        if (themeButton) themeButton.click();
        setActive('settings');
      });
    });

    const drawer = document.getElementById('rail-drawer');
    if (drawer && !drawer.querySelector('.neo-library-shortcuts')) {
      const shortcuts = document.createElement('div');
      shortcuts.className = 'neo-library-shortcuts';
      shortcuts.innerHTML = `
        <button type="button" data-open-view="favorites"><span class="neo-shortcut-icon">♥</span><span><b>Liked songs</b><small>Favorit kamu</small></span></button>
        <button type="button" data-open-view="albums"><span class="neo-shortcut-icon">▣</span><span><b>Albums</b><small>Koleksi album</small></span></button>
        <button type="button" data-open-view="artists"><span class="neo-shortcut-icon">♫</span><span><b>Artists</b><small>Artis yang diikuti</small></span></button>
        <button type="button" data-open-view="local"><span class="neo-shortcut-icon">▤</span><span><b>On this device</b><small>Musik lokal</small></span></button>
        <button type="button" data-open-view="history"><span class="neo-shortcut-icon">◷</span><span><b>Recently played</b><small>Riwayat dengar</small></span></button>`;
      const playlistSection = drawer.querySelector('#drawer-section-playlists');
      if (playlistSection) drawer.insertBefore(shortcuts, playlistSection);
      shortcuts.querySelectorAll('[data-open-view]').forEach((button) => {
        button.addEventListener('click', () => {
          const view = button.dataset.openView;
          clickExisting('btn-close-rail-drawer');
          setActive('library');
          const targetId = ({ favorites: 'nav-favorites', albums: 'nav-albums', artists: 'nav-artists', local: 'nav-local', history: 'nav-history' })[view];
          if (targetId) clickExisting(targetId);
          setActive('library');
        });
      });
    }

    // Keep the custom tab selection in sync with the app's existing view controller.
    ['nav-discover', 'nav-favorites', 'nav-albums', 'nav-artists', 'nav-local', 'nav-history', 'nav-settings'].forEach((id) => {
      const button = document.getElementById(id);
      if (!button) return;
      button.addEventListener('click', () => {
        if (id === 'nav-discover') setActive(searchMode ? 'search' : 'home');
        else if (id === 'nav-settings') setActive('settings');
        else setActive('library');
      });
    });
    if (searchInput) {
      searchInput.addEventListener('focus', () => { if (searchMode) setActive('search'); });
      searchInput.addEventListener('input', () => { if (searchInput.value.trim()) { searchMode = true; setActive('search'); } else if (searchMode && document.activeElement === searchInput) setActive('search'); });
    }
    const drawerTitle = document.getElementById('rail-drawer-title');
    const refreshDrawerTitle = () => {
      if (drawerTitle && drawer && !drawer.classList.contains('drawer-presets-mode') && !drawer.classList.contains('hidden') && drawerTitle.textContent !== 'Your Library') drawerTitle.textContent = 'Your Library';
    };
    if (drawer) new MutationObserver(refreshDrawerTitle).observe(drawer, { attributes: true, attributeFilter: ['class'] });
    if (drawerTitle) new MutationObserver(refreshDrawerTitle).observe(drawerTitle, { childList: true, characterData: true, subtree: true });
  }

  function ensureLibraryHub() {
    const view = document.getElementById('view-favorites');
    if (!view) return;
    const clickExisting = (id) => { const button = document.getElementById(id); if (button) button.click(); };
    let hub = view.querySelector('.neo-library-hub');
    if (hub) {
      hub.hidden = false;
      refreshLibraryPlaylists(hub);
      return;
    }
    hub = document.createElement('section');
    hub.className = 'neo-library-hub';
    hub.setAttribute('aria-label', 'Your Library');
    hub.innerHTML = `
      <div class="neo-library-hub-head"><h2>Your Library</h2><span>COLLECTIONS</span></div>
      <div class="neo-library-hub-grid">
        <button type="button" data-open-view="favorites"><span class="neo-hub-icon">♥</span><span><b>Liked songs</b><small>Saved favorites</small></span></button>
        <button type="button" data-open-view="albums"><span class="neo-hub-icon">▣</span><span><b>Albums</b><small>Saved albums</small></span></button>
        <button type="button" data-open-view="artists"><span class="neo-hub-icon">♫</span><span><b>Artists</b><small>Followed artists</small></span></button>
        <button type="button" data-open-view="local"><span class="neo-hub-icon">▤</span><span><b>On this device</b><small>Local music</small></span></button>
        <button type="button" data-open-view="history"><span class="neo-hub-icon">◷</span><span><b>Recently played</b><small>Listening history</small></span></button>
      </div>
      <section class="neo-library-playlists" aria-label="Your playlists">
        <div class="neo-library-playlists-head"><h3>Your playlists</h3><span class="neo-library-playlist-count">0</span></div>
        <div class="neo-library-playlist-list" aria-live="polite"></div>
      </section>`;
    const header = view.querySelector('.view-header');
    if (header) view.insertBefore(hub, header);
    else view.prepend(hub);
    hub.querySelectorAll('.neo-library-hub-grid [data-open-view]').forEach((button) => {
      button.addEventListener('click', () => {
        const viewName = button.dataset.openView;
        if (viewName === 'favorites') {
          hub.hidden = true;
          const main = document.getElementById('main-content');
          requestAnimationFrame(() => {
            const h = view.querySelector('.view-header');
            if (main && h) main.scrollTop = Math.max(0, h.offsetTop - 8);
          });
          return;
        }
        const targetId = ({ albums: 'nav-albums', artists: 'nav-artists', local: 'nav-local', history: 'nav-history' })[viewName];
        if (targetId) clickExisting(targetId);
      });
    });
    refreshLibraryPlaylists(hub);
  }

  function getUserPlaylists() {
    const core = window.MurielCore;
    if (core && core.state && Array.isArray(core.state.playlists)) {
      return core.state.playlists.filter((playlist) => playlist && typeof playlist === 'object' && playlist.id != null);
    }
    try {
      const saved = JSON.parse(localStorage.getItem('devsize_playlists') || '[]');
      return Array.isArray(saved) ? saved.filter((playlist) => playlist && typeof playlist === 'object' && playlist.id != null) : [];
    } catch (_) {
      return [];
    }
  }

  function getPlaylistArtwork(playlist) {
    const core = window.MurielCore;
    let source = typeof playlist.cover === 'string' ? playlist.cover.trim() : '';
    if (!source) {
      const track = Array.isArray(playlist.tracks) ? playlist.tracks.find(Boolean) : null;
      if (track) {
        try { source = core && typeof core.thumb === 'function' ? (core.thumb(track) || '') : (track.thumbnail || track.localThumbnail || ''); }
        catch (_) { source = track.thumbnail || track.localThumbnail || ''; }
      }
    }
    return /^(https?:|data:image\/|blob:|file:)/i.test(source) ? source : '';
  }

  function refreshLibraryPlaylists(hub = document.querySelector('.neo-library-hub')) {
    if (!hub) return;
    const list = hub.querySelector('.neo-library-playlist-list');
    const count = hub.querySelector('.neo-library-playlist-count');
    if (!list) return;
    const playlists = getUserPlaylists();
    if (count) count.textContent = String(playlists.length);
    list.replaceChildren();

    if (!playlists.length) {
      const empty = document.createElement('p');
      empty.className = 'neo-library-playlist-empty';
      empty.textContent = 'Your playlists will appear here after you create one.';
      list.appendChild(empty);
      return;
    }

    const core = window.MurielCore;
    playlists.forEach((playlist) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'neo-library-playlist-item';
      button.dataset.playlistId = String(playlist.id);
      button.setAttribute('aria-label', `Open playlist ${playlist.name || 'Untitled playlist'}`);

      const artwork = document.createElement('span');
      artwork.className = 'neo-library-playlist-art';
      const source = getPlaylistArtwork(playlist);
      if (source) {
        const image = document.createElement('img');
        image.src = source;
        image.alt = '';
        image.loading = 'lazy';
        image.decoding = 'async';
        image.addEventListener('error', () => { artwork.replaceChildren(); artwork.textContent = '♫'; }, { once: true });
        artwork.appendChild(image);
      } else {
        artwork.textContent = '♫';
      }

      const info = document.createElement('span');
      info.className = 'neo-library-playlist-info';
      const name = document.createElement('b');
      name.textContent = playlist.name || 'Untitled playlist';
      const meta = document.createElement('small');
      const trackCount = Array.isArray(playlist.tracks) ? playlist.tracks.length : 0;
      meta.textContent = `${trackCount} ${trackCount === 1 ? 'track' : 'tracks'}`;
      info.append(name, meta);

      const openIcon = document.createElement('span');
      openIcon.className = 'neo-library-playlist-open';
      openIcon.setAttribute('aria-hidden', 'true');
      openIcon.textContent = '›';
      button.append(artwork, info, openIcon);
      button.addEventListener('click', () => {
        if (core && typeof core.openPlaylist === 'function') {
          core.openPlaylist(playlist.id);
        } else {
          const drawer = document.getElementById('rail-drawer');
          const existing = drawer && Array.from(drawer.querySelectorAll('.playlist-item')).find((item) => item.dataset.playlistId === String(playlist.id));
          if (existing) existing.click();
        }
      });
      list.appendChild(button);
    });
  }

  function refreshVisibleLibraryPlaylists() {
    const hub = document.querySelector('.neo-library-hub');
    if (hub) refreshLibraryPlaylists(hub);
  }

  function optimizeContentImages() {
    const critical = '#titlebar, .playbar, #right-panel, #splash, .profile-menu';
    const tune = (img) => {
      if (!(img instanceof HTMLImageElement)) return;
      if (!img.closest(critical)) {
        if (!img.hasAttribute('loading')) img.loading = 'lazy';
        if (!img.hasAttribute('decoding')) img.decoding = 'async';
        if (!img.hasAttribute('fetchpriority')) img.fetchPriority = 'low';
      } else if (!img.hasAttribute('decoding')) {
        img.decoding = 'async';
      }
    };
    document.querySelectorAll('img').forEach(tune);
    const target = document.getElementById('main-content') || document.body;
    if (!target || !('MutationObserver' in window)) return;
    const observer = new MutationObserver((records) => {
      for (const record of records) {
        for (const node of record.addedNodes) {
          if (node instanceof HTMLImageElement) tune(node);
          else if (node && node.querySelectorAll) node.querySelectorAll('img').forEach(tune);
        }
      }
    });
    observer.observe(target, { childList: true, subtree: true });
  }

  function finishInit() {
    addPaletteCustomizer();
    addVisualThemeSelector();
    addSpotifyNavigation();
    optimizeContentImages();
    window.addEventListener('prics:playlists-updated', refreshVisibleLibraryPlaylists);
    window.addEventListener('muriel:library', refreshVisibleLibraryPlaylists);
    window.addEventListener('storage', (event) => {
      if (!event.key || event.key === 'devsize_playlists') refreshVisibleLibraryPlaylists();
    });

    // Existing theme controls remain compatible with the new palette.
    document.querySelectorAll('.theme-swatch').forEach((button) => button.addEventListener('click', () => setTimeout(applyPalette, 0)));
    const legacyPicker = document.getElementById('settings-custom-color-input');
    if (legacyPicker) legacyPicker.addEventListener('input', applyPalette);
    const hueSlider = document.getElementById('slider-theme-hue');
    if (hueSlider) hueSlider.addEventListener('change', () => setTimeout(applyPalette, 0));
    document.querySelectorAll('.theme-mode-btn[data-theme-mode]').forEach((button) => button.addEventListener('click', () => setTimeout(applyPalette, 0)));

    let lastMode = document.body.classList.contains('theme-dark') ? 'dark' : 'light';
    new MutationObserver(() => {
      const nextMode = document.body.classList.contains('theme-dark') ? 'dark' : 'light';
      if (nextMode !== lastMode) { lastMode = nextMode; applyPalette(); }
    }).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  }

  function init() {
    setVisualTheme(normalizeVisualTheme(localStorage.getItem(VISUAL_THEME_KEY)));
    applyPalette();
    if (window.MurielCore) finishInit();
    else window.addEventListener('muriel:ready', finishInit, { once: true });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
