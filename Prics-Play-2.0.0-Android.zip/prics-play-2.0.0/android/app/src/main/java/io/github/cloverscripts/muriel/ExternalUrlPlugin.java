package io.github.cloverscripts.muriel;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Opens trusted HTTPS release/download links in Android's external browser. */
@CapacitorPlugin(name = "PricsExternalUrl")
public class ExternalUrlPlugin extends Plugin {
    @PluginMethod
    public void open(PluginCall call) {
        String raw = call.getString("url", "");
        Uri uri;
        try { uri = Uri.parse(raw); }
        catch (Exception e) { call.reject("Invalid URL"); return; }
        String scheme = uri.getScheme();
        String host = uri.getHost();
        if (!"https".equalsIgnoreCase(scheme) || host == null ||
                !(host.equalsIgnoreCase("github.com") || host.equalsIgnoreCase("api.github.com") ||
                  host.equalsIgnoreCase("release-assets.githubusercontent.com") ||
                  host.equalsIgnoreCase("objects.githubusercontent.com"))) {
            call.reject("Only trusted HTTPS GitHub URLs can be opened");
            return;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { getContext().startActivity(intent); call.resolve(); }
        catch (ActivityNotFoundException e) { call.reject("No browser is available to open the download link", e); }
        catch (Exception e) { call.reject("Could not open the download link", e); }
    }
}
