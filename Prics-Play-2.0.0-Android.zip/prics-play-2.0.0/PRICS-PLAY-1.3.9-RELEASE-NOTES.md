# Prics Play 1.3.9

- Added a saved visual-theme selector: Neubrutalism (default) and Liquid Glass.
- Theme selection is applied in the mobile first-paint bootstrap and persists across launches.
- Settings > About > Updates compares the installed version/build against the latest public GitHub Release and opens the APK asset for download. Android still requires the user to confirm APK installation.
- Android `applicationId` remains `io.github.cloverscripts.muriel` to preserve the existing app identity.
- Android versionCode is derived from semantic version plus build number so 1.3.9 sorts above earlier 1.3.8 builds.

Important: in-place APK updates require the same signing certificate. The existing workflow produces debug-signed APKs; if the signing key differs from the installed APK, Android will reject an in-place update. Do not delete app data until you have backed it up.
