# Prics Play — startup performance and mini-player controls

## Changes

- Mobile body scripts are emitted with `defer` in their original order, so the static CSS/HTML shell can paint before application scripts run. `profiles-core.js` stays synchronous in the head to initialize profile-scoped storage before the first-paint theme bootstrap.
- The first-paint bootstrap marks Android explicitly so Android does not double-count the status-bar safe-area inset. The top logo/profile bar is locked to a compact 34 px content height, the search/source row to 44 px, and the content inset matches those dimensions.
- App initialization yields across animation frames, defers theme calculation and non-critical home/library rendering to idle callbacks, and no longer blocks mobile event-handler setup while awaiting the in-app server port.
- The mobile bridge starts its in-app server after the initial frames, allowing the static shell to render before the server bundle is loaded. API-backed startup work waits for the bridge readiness promise.
- Mini-player swipe-to-skip listeners and animations were removed. The existing Previous, Play/Pause, and Next transport buttons are displayed in that order, with matching Neo-Brutalism borders and ellipsized track text.
- The mobile loading overlay and playbar spinner are hidden to prevent a buffering spinner from peeking out behind the mini player. The bar uses a solid background, isolated stacking context, and stable z-index; the pause icon remains visible during buffering.

## Checks

- `node --check` passed for the changed JavaScript files.
- Targeted tests passed: `node --test test/mobile-neubrutalism.test.js test/prics-startup-controls.test.js test/prics-library-ui.test.js` (16 tests).
- APK build and cold-start interaction have not been verified on a physical Android device. Use the existing GitHub Actions workflow to build the APK, then verify startup, previous/play/next controls, and background playback on the target phone.
