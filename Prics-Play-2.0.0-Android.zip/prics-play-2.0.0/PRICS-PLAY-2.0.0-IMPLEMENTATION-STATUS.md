# Prics Play 2.0.0 implementation status

This archive contains the first source-code implementation pass for the 2.0.0 plan.

Implemented in source:
- Updated package/lock version metadata to 2.0.0 while keeping the Android application ID unchanged.
- Replaced visible header/splash/About/launcher branding with the user-provided P.A PLAY mark.
- Removed the legacy My Wave carousel, its settings controls, old carousel event listeners, and the obsolete startup request chain.
- Prevented the removed My Wave carousel's `/api/vibe` → `/api/hot` request chain from running during startup.
- Kept Made for You Daily Mixes separate and delayed its noncritical requests while playback is resolving or buffering.
- Changed the four visible bottom tabs to Home, Search, Koleksi, and Tema; the Tema tab opens Settings > Theme while the category list still exposes About/Updates.
- Added a scoped Liquid Glass floating/convex bottom navigation treatment with a reduced-blur fallback.
- Updated the updater to use a separate Download now action.
- Changed Android CI publishing to immutable versioned releases without deleting previous releases.
- Added deterministic source-archive selection: validate the ZIP filename against its internal package version, then choose the highest semantic version; use root source if it is newer or no ZIP exists.
- Added privacy-safe playback timing events for stream resolution and actual audio start, plus source-level regression tests for the 2.0.0 implementation.

Validation performed in this environment:
- JavaScript syntax checks passed for `app.js`, `server.js`, `mobile/build.mjs`, `mobile/mobile-ui.js`, `mobile/neubrutalism.js`, and `update-notifier.js`.
- Focused regression tests passed: 22/22.
- The full test suite reported 273 passing tests and 3 test-file failures because `electron` and `youtubei.js/web` were unavailable. `npm ci` could not finish because the package registry requests returned DNS `EAI_AGAIN`.
- Workflow YAML parsed successfully.
- The mobile bundle could not be built locally because `esbuild` was unavailable after the failed dependency install. No APK was produced in this environment.

Still requiring CI/device verification:
- Install dependencies and rerun the full test suite.
- Build the mobile bundle and signed Android APK in GitHub Actions.
- Verify the release signing certificate matches the installed 1.3.9 APK.
- Test playback latency, both themes, navigation, playlists, and upgrade behavior on a physical Android device.
- Publish the v2.0.0 release on the GitHub repository. This archive does not push commits or publish releases automatically.
