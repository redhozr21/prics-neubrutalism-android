'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const mobileUi = fs.readFileSync(path.join(root, 'mobile', 'neubrutalism.js'), 'utf8');
const mobileCss = fs.readFileSync(path.join(root, 'mobile', 'mobile.css'), 'utf8');
const appJs = fs.readFileSync(path.join(root, 'app.js'), 'utf8');

test('Library hub includes a dynamic section for saved user playlists', () => {
  assert.match(mobileUi, /class="neo-library-playlist-list"/);
  assert.match(mobileUi, /core\.state\.playlists/);
  assert.match(mobileUi, /localStorage\.getItem\('devsize_playlists'\)/);
  assert.match(mobileUi, /core\.openPlaylist\(playlist\.id\)/);
});

test('playlist create, rename, delete and refresh flows notify the mobile Library hub', () => {
  assert.match(appJs, /window\.dispatchEvent\(new Event\('prics:playlists-updated'\)\)/);
  assert.match(mobileUi, /addEventListener\('prics:playlists-updated', refreshVisibleLibraryPlaylists\)/);
});

test('playlist detail has mobile neo-brutalist padding and safe action wrapping', () => {
  assert.match(mobileCss, /#view-playlist-detail \.playlist-meta[\s\S]*?padding: 12px !important/);
  assert.match(mobileCss, /#view-playlist-detail \.playlist-actions[\s\S]*?flex-wrap: wrap !important/);
  assert.match(mobileCss, /#playlist-detail-desc\.playlist-inline-desc[\s\S]*?margin: 0 !important/);
});
