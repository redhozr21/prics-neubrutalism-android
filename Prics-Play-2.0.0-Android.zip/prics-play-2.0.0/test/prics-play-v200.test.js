const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');

test('release version is 2.0.0 while the Android package identity remains stable', () => {
  const pkg = JSON.parse(read('package.json'));
  const lock = JSON.parse(read('package-lock.json'));
  const cap = JSON.parse(read('capacitor.config.json'));
  const gradle = read('android/app/build.gradle');
  assert.equal(pkg.version, '2.0.0');
  assert.equal(lock.version, '2.0.0');
  assert.equal(lock.packages[''].version, '2.0.0');
  assert.equal(cap.appId, 'io.github.cloverscripts.muriel');
  assert.match(gradle, /versionName pricsVersionName/);
  assert.match(gradle, /pricsVersionBaseCode/);
});

test('theme selector provides Neubrutalism by default and Liquid Glass, and persists choice', () => {
  const build = read('mobile/build.mjs');
  const bridge = read('mobile/bridge.js');
  const skin = read('mobile/neubrutalism.js');
  const css = read('mobile/mobile.css');
  assert.match(build, /prics-visual-theme-bootstrap/);
  assert.ok(build.indexOf('src="profiles-core.js"') < build.indexOf('prics-visual-theme-bootstrap'));
  assert.match(build, /prics_play_visual_theme/);
  assert.match(bridge, /prics_play_visual_theme/);
  assert.match(skin, /data-prics-visual-theme="neubrutalism"/);
  assert.match(skin, /data-prics-visual-theme="liquid-glass"/);
  assert.match(skin, /localStorage\.setItem\(VISUAL_THEME_KEY, theme\)/);
  assert.match(skin, /theme === 'neubrutalism'/);
  assert.match(skin, /theme === 'liquid-glass'/);
  assert.match(css, /html\.is-mobile\.liquid-glass-theme/);
  assert.match(css, /backdrop-filter:blur\(var\(--glass-blur\)\)/);
});

test('About updater checks the owned public release and opens the APK through Android external browser', () => {
  const updater = read('update-notifier.js');
  const java = read('android/app/src/main/java/io/github/cloverscripts/muriel/ExternalUrlPlugin.java');
  const activity = read('android/app/src/main/java/io/github/cloverscripts/muriel/MainActivity.java');
  assert.match(updater, /api\.github\.com\/repos\/\$\{REPO\}\/releases\/latest/);
  assert.match(updater, /function compareVersions/);
  assert.match(updater, /browser_download_url/);
  assert.match(updater, /Download now/);
  assert.match(updater, /window\.PricsExternalUrl\.open\(url\)/);
  assert.match(java, /Intent\.ACTION_VIEW/);
  assert.match(java, /Only trusted HTTPS GitHub URLs/);
  assert.match(activity, /registerPlugin\(ExternalUrlPlugin\.class\)/);
  assert.match(updater, /is up to date/);
});


test('update button downloads a newer APK but does not reopen the same installed build', async () => {
  const updater = read('update-notifier.js');
  async function run(build, release) {
    const opened = [];
    const handlers = {};
    const statusEl = { textContent: '', classList: { toggle() {} } };
    const checkBtn = { textContent: 'Check now', addEventListener(name, fn) { handlers[name] = fn; } };
    const aboutVersion = { textContent: '' };
    const storage = new Map();
    const context = {
      window: {
        MURIEL_BUILD: build,
        Capacitor: { getPlatform: () => 'android', isNativePlatform: () => true },
        PricsExternalUrl: { open: async (url) => { opened.push(url); } },
        location: { href: '' },
        open() {},
      },
      document: {
        hidden: false,
        getElementById(id) { return id === 'update-status' ? statusEl : id === 'btn-check-updates' ? checkBtn : id === 'about-version' ? aboutVersion : null; },
        addEventListener() {},
      },
      localStorage: { getItem(k) { return storage.get(k) || null; }, setItem(k, v) { storage.set(k, v); } },
      fetch: async () => ({ ok: true, json: async () => release }),
      AbortController: class { constructor() { this.signal = {}; } abort() {} },
      setTimeout: () => 1,
      clearTimeout() {},
      Date,
      Promise,
    };
    vm.runInNewContext(updater, context);
    await context.window.PricsPlayUpdates.check();
    return { opened, statusEl, checkBtn, aboutVersion, handlers };
  }
  const asset = { name: 'Prics-Play.apk', browser_download_url: 'https://github.com/redhozr21/prics-neubrutalism-android/releases/download/v2.0.0/Prics-Play.apk' };
  const release = (version, build) => ({
    draft: false, prerelease: false, html_url: 'https://github.com/redhozr21/prics-neubrutalism-android/releases/tag/v2.0.0',
    tag_name: 'v2.0.0', name: 'Prics Play v2.0.0',
    body: `Prics Play ${version} · Build ${build}. <!-- prics-play-version: ${version} --><!-- prics-play-build: ${build} -->`,
    assets: [asset],
  });
  const same = await run({ version: '2.0.0', run: 14 }, release('2.0.0', 14));
  assert.equal(same.opened.length, 0);
  assert.match(same.statusEl.textContent, /up to date/i);
  const older = await run({ version: '1.3.9', run: 14 }, release('2.0.0', 15));
  assert.equal(older.opened.length, 0, 'checking for an update must not start a download automatically');
  assert.match(older.statusEl.textContent, /Update available/);
  assert.equal(older.checkBtn.textContent, 'Download now');
  await older.handlers.click();
  assert.deepEqual(older.opened, [asset.browser_download_url]);
});


test('My Wave is removed from the rendered app and no longer triggers its legacy startup request chain', () => {
  const html = read('index.html');
  const app = read('app.js');
  assert.doesNotMatch(html, /My Wave|btn-play-my-wave|section-my-wave/);
  assert.match(app, /async function loadHomePage\(\) \{[\s\S]*?loadForYou\(\);\s*return false;\s*\}/);
  assert.doesNotMatch(app, /My Wave|myWaveActive|btn-play-my-wave|home-vibe-grid/);
  assert.match(app, /prics:playback-metric/);
  assert.doesNotMatch(app.slice(app.indexOf('function renderMadeForYou()'), app.indexOf('// ---- Trending now')), /title: state\.isHotPicks[\s\S]*?My Wave/);
});

test('Android release workflow creates versioned releases without deleting old releases', () => {
  const workflow = read('.github/workflows/android.yml');
  assert.match(workflow, /tag="v\$ver"/);
  assert.match(workflow, /gh release create "\$tag"/);
  assert.doesNotMatch(workflow, /gh release delete/);
});

test('Liquid Glass nav uses a scoped convex glass surface and safe fallback', () => {
  const css = read('mobile/mobile.css');
  assert.match(css, /html\.is-mobile\.liquid-glass-theme \.sidebar\.neo-sidebar::before/);
  assert.match(css, /html\.is-mobile\.liquid-glass-theme \.neo-tab\.active::after/);
  assert.match(css, /@supports not \(\(backdrop-filter: blur\(1px\)\)/);
});


test('fourth bottom tab is Tema and opens the theme category while retaining the settings category list', () => {
  const build = read('mobile/build.mjs');
  const skin = read('mobile/neubrutalism.js');
  assert.match(build, /aria-label="Tema" aria-pressed="false"/);
  assert.match(build, /<span>Koleksi<\/span>/);
  assert.match(build, /<span>Tema<\/span>/);
  assert.match(skin, /settings-nav-btn\[data-cat="theme"\]/);
  assert.match(skin, /clickExisting\('nav-settings'\)/);
});


test('Android workflow passes a monotonic build number into versionCode', () => {
  const workflow = read('.github/workflows/android.yml');
  assert.match(workflow, /MURIEL_VERSION_NAME=.*package\.json/);
  assert.match(workflow, /MURIEL_VERSION_CODE="\$\{\{ github\.run_number \}\}"/);
});


test('CI selects a version-validated source archive and does not rely on ZIP modification time', () => {
  const selector = read('tools/select-source-archive.py');
  const workflow = read('.github/workflows/android.yml');
  assert.match(selector, /VERSIONED_ARCHIVE = re\.compile/);
  assert.match(selector, /package\.get\("version"/);
  assert.match(selector, /root_version_key > latest_archive\[0\]/);
  assert.match(workflow, /python3 tools\/select-source-archive\.py/);
  assert.match(workflow, /working-directory: \$\{\{ env\.PRICS_SOURCE_DIR \}\}/);
});
