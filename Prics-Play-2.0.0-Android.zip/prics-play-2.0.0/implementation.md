# Prics Play — Implementation Plan

**Dokumen:** `implementation.md`  
**Status:** Implementasi awal diterapkan pada source 2.0.0; build, signing, perangkat, dan GitHub masih perlu diverifikasi  
**Target versi:** `2.0.0`  
**Versi sebelumnya:** `1.3.9`  
**Repository:** <https://github.com/redhozr21/prics-neubrutalism-android>  
**GitHub Releases API:** <https://api.github.com/repos/redhozr21/prics-neubrutalism-android/releases/latest>

> **Status perubahan:** Source code dan ZIP kerja versi 2.0.0 telah diperbarui secara lokal. Repository GitHub belum di-push, dan APK belum dinyatakan siap sampai build, signing, serta pengujian perangkat diverifikasi.

---

## 1. Tujuan

Membuat Prics Play menjadi aplikasi pemutar musik Android yang konsisten, responsif, mudah digunakan, memiliki dua tema visual, dan dapat diperbarui dari dalam aplikasi. Perubahan harus mempertahankan fungsi pemutar musik yang sudah ada dan menghindari regresi pada navigasi, playlist, antrean, atau playback.

Prioritas tertinggi:

1. Pemutaran musik responsif dan stabil.
2. Semua tombol dan navigasi benar-benar berfungsi.
3. UI konsisten pada tema Neubrutalism dan Liquid Glass.
4. Startup tidak menampilkan UI lama atau membeku.
5. Pembaruan dari versi lama ke versi baru tidak merusak data atau instalasi.
6. Build dan pengujian harus berhasil sebelum rilis dinyatakan siap.

## 2. Aturan versi, arsip, dan kompatibilitas

- Versi target berikutnya adalah **2.0.0**, bukan 1.3.9.
- `versionName` harus menjadi `2.0.0`; `versionCode` harus lebih tinggi daripada APK yang sudah dirilis.
- Pertahankan `applicationId` yang digunakan aplikasi terpasang, kecuali ada keputusan eksplisit untuk membuat aplikasi baru.
- **Jangan menghapus ZIP versi lama.** Simpan arsip lama sebagai riwayat dan gunakan nama file berbeda untuk source versi baru, misalnya `Prics-Play-2.0.0-Android.zip`.
- Workflow harus memilih arsip yang benar secara eksplisit. Jangan memilih ZIP berdasarkan tebakan nama, urutan file, atau versi yang tidak tervalidasi.
- Build/release harus otomatis setelah source ZIP versi 2.0.0 di-commit ke branch yang ditentukan. Tujuannya agar tidak perlu menekan **Run workflow** secara manual untuk setiap rilis.
- Aplikasi hanya dapat mengunduh APK yang sudah dibangun dan dipublikasikan. Tombol updater di HP tidak menggantikan proses kompilasi dan publikasi rilis di sisi pengembang.

### 2.1 Persyaratan tanda tangan APK

Pemasangan 2.0.0 di atas 1.3.9 hanya dapat berhasil tanpa uninstall jika `applicationId` dan sertifikat penandatanganan APK cocok. `versionCode` juga harus meningkat.

- Sebelum rilis, periksa sertifikat APK 1.3.9 yang saat ini digunakan.
- Gunakan signing key rilis yang persisten dan disimpan secara aman, misalnya melalui GitHub Actions Secrets; jangan menyimpan keystore atau kata sandi di source code atau ZIP.
- Jangan mengklaim kompatibilitas pembaruan sebelum pengujian upgrade dari APK 1.3.9 benar-benar berhasil.
- Jika sertifikat 1.3.9 tidak cocok atau tidak tersedia, hentikan rencana pemasangan langsung dan dokumentasikan dampaknya terlebih dahulu. Jangan menyarankan penghapusan aplikasi tanpa peringatan, pencadangan, dan persetujuan pengguna.
- Simpan backup playlist/data yang diperlukan sebelum pengujian upgrade atau migrasi.

## 3. Branding dan logo

- Nama yang ditampilkan kepada pengguna adalah **Prics Play**.
- Gunakan gambar logo **P.A PLAY** yang diberikan pengguna sebagai referensi identitas visual.
- Terapkan logo secara konsisten pada:
  - ikon launcher Android;
  - header aplikasi;
  - splash screen, jika ada;
  - halaman Settings/About;
  - aset atau metadata branding yang terlihat pengguna.
- Siapkan varian aset dengan ukuran dan format yang sesuai untuk Android serta tampilan web/mobile.
- Jangan meregangkan logo; pertahankan rasio aspek, ruang aman, dan keterbacaan pada ukuran kecil.
- Bersihkan teks “Muriel” yang masih terlihat oleh pengguna, tetapi jangan mengganti nama internal, namespace, atau ID paket secara membabi buta jika berisiko merusak kompatibilitas. Setiap referensi internal harus diperiksa konteksnya terlebih dahulu.

## 4. Penghapusan My Wave

### 4.1 Keputusan produk

Hilangkan **My Wave** dari UI karena kartu/tombolnya tidak memberikan respons yang dapat diandalkan. Jangan sekadar menyembunyikannya dengan CSS.

### 4.2 Pembersihan aman

- Hapus kartu, tombol, dan markup My Wave dari Home.
- Hapus event handler yang hanya digunakan oleh My Wave.
- Hapus CSS, selector, teks, dan referensi khusus yang menjadi tidak terpakai.
- Audit semua pemanggilan `getElementById`, selector, dan handler terkait agar tidak ada referensi ke elemen yang sudah dihapus.
- Jangan menghapus audio engine, fungsi antrean, riwayat, rekomendasi umum, atau fungsi lain yang juga dipakai komponen lain.
- Jika endpoint backend hanya digunakan My Wave, verifikasi semua pemakainya sebelum memutuskan untuk menghapus endpoint tersebut.
- Jangan menghidupkan kembali komponen HTML lama yang sengaja dihapus oleh proses build mobile.

### 4.3 Validasi

- Tidak ada kartu atau tombol My Wave pada hasil build Android.
- Tidak ada error JavaScript akibat elemen My Wave yang tidak ditemukan.
- Home tetap dapat dibuka, daftar lagu tetap tampil, dan pemutaran lagu tetap berjalan.
- Tidak ada permintaan API khusus My Wave yang berjalan tanpa kebutuhan.

## 5. Sistem tema

Aplikasi memiliki dua tema:

1. **Neubrutalism — tema default untuk instalasi baru.**
2. **Liquid Glass — tema alternatif.**

Tema yang dipilih harus disimpan dan dipulihkan ketika aplikasi dibuka kembali. Pergantian tema tidak boleh me-reload halaman, menghentikan lagu, mengosongkan antrean, mengubah posisi seekbar, atau mereset navigasi.

### 5.1 Satu struktur UI, dua lapisan visual

- Gunakan struktur komponen, event handler, ukuran, dan aturan layout yang sama untuk kedua tema.
- Terapkan perbedaan visual melalui design tokens/CSS variables dan kelas tema yang eksplisit.
- Semua efek Liquid Glass harus dibatasi pada kelas tema Liquid Glass, misalnya `.theme-liquid-glass`.
- Jangan menambahkan selector global yang membuat Neubrutalism ikut transparan, blur, atau cembung.
- Hindari duplikasi halaman atau logika pemutar hanya untuk tema kedua.

### 5.2 Neubrutalism

- Border hitam tegas dan bayangan keras.
- Kartu solid, kontras tinggi, dan aksen warna yang dapat dikustomisasi.
- Tombol dan tab aktif memakai warna aksen yang konsisten.
- Padding, gap, radius, ukuran teks, dan area sentuh tetap konsisten di seluruh halaman.

### 5.3 Liquid Glass

Tujuan visualnya adalah permukaan kaca yang transparan, berlapis, cembung, dan terasa mengambang seperti bahasa desain Liquid Glass modern.

- Panel dapat menggunakan transparansi, blur latar, tepi kaca tipis, highlight halus, dan bayangan berlapis.
- Navigasi bawah memiliki efek kaca cembung/floating; tab aktif terlihat menonjol melalui highlight dan kedalaman yang halus.
- Search bar, kartu, panel lirik, Mini Player, dan kontrol tertentu menggunakan lapisan kaca yang konsisten.
- Album art harus tetap tajam; jangan memburamkan gambar album itu sendiri.
- Pastikan teks, ikon, indikator progres, dan tombol tetap memiliki kontras yang cukup.
- Efek kaca tidak boleh menangkap sentuhan atau menutupi elemen interaktif.
- Batasi `backdrop-filter` dan blur pada area yang benar-benar penting. Hindari blur besar pada seluruh daftar panjang atau seluruh halaman.
- Sediakan fallback transparansi/warna solid ketika `backdrop-filter` tidak tersedia atau terlalu berat.
- Hormati preferensi pengurangan gerakan bila tersedia; animasi harus singkat dan tidak wajib untuk mengoperasikan aplikasi.
- Tidak boleh ada efek Liquid Glass aktif ketika tema Neubrutalism dipilih.

## 6. Desain dan layout seluruh aplikasi

Gunakan gambar referensi pengguna sebagai arah visual: UI musik mobile yang kompak, rapi, berkontras tinggi, dan mudah dipindai.

### 6.1 Header dan pencarian

- Header logo/profil harus compact dan ukurannya tetap setelah aplikasi selesai dimuat.
- Hitung safe area hanya sekali; jangan menambahkan `safe-area-inset` ganda.
- Hilangkan markup UI lama yang menyebabkan flash saat cold start, termasuk komponen lama seperti “My Wave” jika masih ada di output mobile.
- Search bar memiliki area sentuh yang nyaman dan tidak menampilkan outline fokus kuning yang tidak disengaja.
- Input tetap memiliki indikator fokus yang aksesibel, bukan menghilangkan seluruh indikasi fokus keyboard secara membabi buta.
- Header, search bar, dan pemilih sumber musik tidak boleh membesar setelah inisialisasi.

### 6.2 Home

- Tampilkan bagian yang berguna, misalnya koleksi ringkas, populer/hits, jelajah artis/kategori, dan daftar lagu.
- Hilangkan My Wave sepenuhnya dari tampilan.
- Gunakan kartu lagu yang konsisten dengan cover, judul, artis, dan tombol aksi.
- Judul lagu/artis menggunakan ellipsis ketika ruang terbatas.
- Padding internal dan jarak antar-kartu konsisten; teks tidak boleh menempel pada border.
- Pemuatan rekomendasi atau gambar tidak boleh menghalangi pemutaran lagu.

### 6.3 Search

- Sediakan input pencarian yang jelas dan tombol/aksi pencarian yang berfungsi.
- Hasil pencarian ditampilkan sebagai kartu lagu yang konsisten dengan Home.
- Filter seperti Semua, Cari, Lirik, atau FX hanya ditampilkan jika fungsi sebenarnya tersedia dan telah diuji.
- Status loading, kosong, error, dan hasil harus jelas.
- Pengguna dapat memulai pemutaran tanpa menunggu gambar, lirik, atau informasi tambahan selesai dimuat.

### 6.4 Now Playing

- Cover album besar dan tetap tajam.
- Judul, artis, favorit, durasi, dan seekbar tertata dengan ruang yang cukup.
- Kontrol utama: Shuffle, Previous, Play/Pause, Next, Repeat.
- Seekbar mendukung sentuhan/drag untuk audio scrubbing dan menampilkan posisi serta durasi secara akurat.
- Panel lirik dan kontrol Karaoke/EQ/FX hanya tampil sesuai fitur yang benar-benar didukung.
- Kontrol tidak boleh tertutup panel, overlay, keyboard, atau efek kaca.

### 6.5 Library/Koleksi

- Playlist pengguna yang baru dibuat harus langsung muncul dan dapat dibuka.
- Perubahan nama, penghapusan, impor, sinkronisasi, dan pembuatan playlist harus memperbarui tampilan Library.
- Hubungkan UI dengan sumber state/database yang benar; jangan mengandalkan fallback yang bisa menimpa data utama.
- Pertahankan favorit, album, artis, musik lokal, dan riwayat yang memang didukung aplikasi.
- Detail playlist harus memiliki padding dan jarak antar-tombol yang cukup.

### 6.6 Navigasi bawah

Target navigasi empat tab berdasarkan referensi desain: **Home, Search, Koleksi, Tema**. Jika implementasi produk yang ada memakai label Library/Settings, petakan fungsi lama secara eksplisit agar tidak ada akses yang hilang: halaman Tema harus tetap menyediakan akses ke pengaturan umum dan About/Updates.

- Semua tab harus merespons sentuhan secara konsisten.
- Perubahan tema tidak boleh memutus event handler navigasi.
- Tab aktif harus jelas pada kedua tema.
- Navigasi harus memiliki safe area yang benar, tidak menutupi konten, dan tidak berubah tinggi setelah startup.
- Semua kontrol harus memiliki area sentuh yang layak dan state aktif/fokus yang terlihat.

### 6.7 Mini Player

- Posisi tetap di atas navigasi bawah.
- Kontrol berurutan: **Previous — Play/Pause — Next**.
- Hapus seluruh listener swipe horizontal khusus Mini Player (`touchstart`, `touchmove`, `touchend`) sesuai keputusan terakhir.
- Tap pada area informasi lagu boleh membuka Now Playing; tap pada tombol harus hanya menjalankan aksi tombol.
- Judul/artis menggunakan ellipsis dan tidak bertabrakan dengan kontrol.
- Sembunyikan spinner/overlay buffering yang tidak semestinya muncul di belakang Mini Player.
- Pada Neubrutalism, gunakan permukaan solid dengan border/shadow sesuai tema. Pada Liquid Glass, gunakan panel kaca.
- Mini Player harus tetap memiliki stacking order yang benar dan tidak menangkap sentuhan milik halaman yang berada di belakangnya.

## 7. Startup dan inisialisasi

- Render struktur UI awal dari HTML/CSS statis sebelum menjalankan pekerjaan nonkritis.
- Jangan menampilkan UI lama lalu menimpanya dengan script/CSS setelah halaman dimuat.
- Terapkan kelas tema dan ukuran header awal secara konsisten sejak render pertama.
- Pisahkan pekerjaan nonkritis—rekomendasi, gambar, metadata, sinkronisasi—dari jalur render awal.
- Gunakan pemuatan asynchronous dan penjadwalan bertahap jika sesuai dengan arsitektur yang ada.
- Jangan memindahkan pekerjaan ke background dengan cara yang merusak urutan inisialisasi atau event handler.
- Tangani error startup dengan aman; kegagalan satu fitur nonkritis tidak boleh menghentikan semua tombol.
- Pastikan setiap fungsi yang dipanggil memang didefinisikan dengan nama yang benar. Tes tidak boleh menggunakan nama helper yang sudah usang.
- Tidak boleh ada referensi DOM ke elemen yang sudah dihapus tanpa guard atau penggantian implementasi yang benar.

## 8. Performa pemutaran musik — berlaku universal

Ketentuan ini berlaku pada **semua halaman dan kedua tema**. Tema hanya memengaruhi visual, bukan audio engine atau jalur jaringan.

### 8.1 Respons saat lagu dipilih

- Saat pengguna mengetuk lagu, UI segera menunjukkan bahwa pilihan diterima.
- Jangan menunggu gambar album, lirik, rekomendasi, atau metadata tambahan sebelum memulai jalur audio.
- Pisahkan resolusi sumber audio dari pekerjaan tampilan.
- Hindari operasi sinkron atau parsing berat pada main thread.
- Cegah klik ganda menghasilkan permintaan playback ganda yang saling bertabrakan.
- Jika lagu gagal dimulai, tampilkan status error yang jelas dan opsi coba lagi.

### 8.2 Jaringan dan server

- Ukur waktu dari klik lagu sampai permintaan playback dimulai dan sampai audio benar-benar terdengar.
- Jangan mengirim permintaan API yang sama berulang kali tanpa alasan.
- Gunakan cache metadata yang sesuai; jangan menggunakan URL streaming kedaluwarsa.
- Jalankan pekerjaan yang independen secara paralel jika aman, bukan secara berurutan.
- Terapkan timeout, pembatalan request yang sudah tidak relevan, dan retry terbatas dengan backoff.
- Hindari retry tak terbatas atau fallback yang membuat pengguna menunggu tanpa batas.
- Kegagalan rekomendasi tidak boleh memblokir pemutaran lagu yang dipilih langsung.
- Jangan menambah permintaan server hanya untuk mengganti tema atau menjalankan animasi.
- Jangan menyimpan token/credential rahasia di aplikasi.
- Catat metrik diagnostik tanpa menyimpan data pribadi yang tidak diperlukan.

### 8.3 Next, Previous, Shuffle, dan antrean

- Previous/Next memicu perpindahan lagu dengan segera dan memperbarui state player secara konsisten.
- Shuffle harus benar-benar mengacak urutan antrean, mempertahankan lagu aktif, dan menggunakan antrean hasil acak untuk lagu berikutnya.
- Jika aman dan didukung, siapkan metadata atau sumber lagu berikutnya lebih awal tanpa menghabiskan kuota berlebihan.
- Pastikan prefetch tidak menyebabkan dua audio diputar bersamaan atau state antrean menjadi tidak sinkron.
- Seekbar harus mengikuti waktu audio aktual, bukan hanya animasi UI.
- Pemutaran latar belakang harus tetap berjalan dan tidak terganggu oleh pergantian tema atau navigasi.

### 8.4 Target pengukuran

Jangan mengklaim “instan” hanya karena tombol berubah warna. Catat setidaknya:

- waktu dari tap sampai UI merespons;
- waktu resolusi sumber audio;
- waktu dari tap sampai audio mulai terdengar;
- waktu pergantian Next/Previous sampai audio berikutnya terdengar;
- jumlah request jaringan per tindakan;
- error rate dan timeout;
- penggunaan CPU/memori dan kelancaran scroll pada perangkat kelas menengah.

Tetapkan target numerik setelah baseline diukur pada perangkat dan jaringan yang representatif. Kecepatan penyedia audio dan jaringan eksternal tidak bisa dijamin oleh aplikasi, tetapi overhead yang disebabkan kode aplikasi harus diminimalkan.

## 9. Settings, About, dan updater

### 9.1 Versi

- About menampilkan nama Prics Play, versi `2.0.0`, dan build yang benar.
- Hilangkan teks branding Muriel yang terlihat oleh pengguna.
- Pertahankan informasi legal yang relevan dan jangan membuat klaim afiliasi yang tidak benar.

### 9.2 Check now / Download now

Gunakan GitHub Releases API:

`https://api.github.com/repos/redhozr21/prics-neubrutalism-android/releases/latest`

Perilaku yang diharapkan:

1. **Check now** mengambil rilis terbaru dan memvalidasi respons.
2. Bandingkan versi rilis dengan versi aplikasi terpasang.
3. Tampilkan “sudah terbaru”, “pembaruan tersedia”, atau pesan error yang bisa dipahami.
4. Jika tersedia, **Download now** membuka/mengunduh aset APK yang benar dari rilis tersebut.
5. Validasi bahwa aset APK ada; jangan mengarahkan pengguna ke halaman kosong atau file yang salah.
6. Setelah unduhan, gunakan alur installer Android yang didukung dan jelaskan bahwa pengguna tetap harus menyetujui instalasi.
7. Jangan pernah mencoba memasang APK diam-diam atau meminta pengguna menonaktifkan perlindungan keamanan.
8. Tangani koneksi terputus, rate limit API, rilis tanpa APK, versi sama, dan versi lebih lama.

Repository rilis harus publik agar API dapat diakses tanpa token. Jika source code ingin privat, gunakan repository rilis publik terpisah atau layanan perantara yang aman. Jangan menanam personal access token ke dalam APK.

### 9.3 Otomatisasi rilis

- Commit source ZIP versi 2.0.0 memicu workflow build secara otomatis.
- Workflow harus membangun APK, menjalankan pemeriksaan, memberi nama aset yang konsisten, dan menerbitkan GitHub Release hanya jika build sukses.
- Rilis gagal tidak boleh menggantikan rilis stabil yang sedang digunakan.
- Pertahankan ZIP versi lama; simpan ZIP baru dengan nama berversi.
- Rilis harus menggunakan versi dan `versionCode` yang konsisten dengan source.
- Dokumentasikan cara rollback bila build baru gagal.
- Updater di HP hanya mengunduh rilis yang sudah tersedia; proses build dan publikasi tetap berlangsung di CI.

## 10. Rencana pengujian wajib

Tidak boleh menyatakan aplikasi siap rilis hanya berdasarkan pemeriksaan sintaks atau tes mock.

### 10.1 Pemeriksaan source dan build

- [ ] Semua file JavaScript/MJS/CJS yang relevan lolos pemeriksaan sintaks.
- [ ] Tidak ada referensi ke elemen DOM yang dihapus.
- [ ] Tidak ada fungsi yang dipanggil dengan nama yang tidak didefinisikan.
- [ ] Tidak ada error CSS/HTML yang kritis.
- [ ] Semua tes unit dan integrasi yang tersedia dijalankan; tes yang terhambat dependensi harus dilaporkan, bukan dihitung sebagai lulus.
- [ ] Dependency lockfile konsisten.
- [ ] Build mobile bundle berhasil.
- [ ] Sinkronisasi Android/Capacitor berhasil.
- [ ] Gradle menghasilkan APK debug dan APK rilis yang dituju tanpa error.
- [ ] Artifact dan release berisi APK yang benar.
- [ ] Tidak ada secret atau keystore yang ikut terunggah ke ZIP/artifact.

### 10.2 Pengujian fungsi

- [ ] Cold start: tidak ada UI lama/flash yang tidak diinginkan dan tidak ada freeze yang nyata.
- [ ] Semua tab dapat ditekan dan berpindah dengan benar.
- [ ] Search mengembalikan hasil, status kosong, dan error dengan benar.
- [ ] Lagu dapat diputar dari Home, Search, Library, playlist, dan antrean.
- [ ] Play/Pause, Previous, Next, Shuffle, Repeat, dan seekbar bekerja.
- [ ] Mini Player tidak menghalangi scroll atau tombol lain.
- [ ] Playlist baru langsung muncul di Library dan tetap ada setelah aplikasi dibuka kembali.
- [ ] Favorit, riwayat, dan antrean tidak hilang ketika tema diganti.
- [ ] Musik tetap berjalan saat layar terkunci jika fungsi background playback memang didukung.
- [ ] My Wave tidak tampil dan tidak meninggalkan error runtime.
- [ ] About menunjukkan versi yang benar.
- [ ] Check now dan Download now menangani rilis tersedia/tidak tersedia dengan benar.

### 10.3 Pengujian kedua tema

- [ ] Neubrutalism tetap menjadi default instalasi baru.
- [ ] Liquid Glass hanya aktif saat tema tersebut dipilih.
- [ ] Mengganti tema tidak me-reload aplikasi atau menghentikan musik.
- [ ] Ukuran header, jarak kartu, ukuran teks, dan posisi tombol tetap konsisten.
- [ ] Tidak ada teks tertutup, kartu terpotong, atau scroll horizontal yang tidak disengaja.
- [ ] Blur tidak menurunkan responsivitas secara berarti.
- [ ] Fallback tampilan tetap terbaca pada perangkat yang tidak mendukung blur.

### 10.4 Pengujian upgrade

- [ ] Periksa `applicationId`, `versionCode`, dan sertifikat tanda tangan APK 1.3.9.
- [ ] Uji instalasi 2.0.0 di atas 1.3.9 tanpa uninstall.
- [ ] Pastikan playlist, favorit, dan preferensi tetap ada.
- [ ] Jika pengujian upgrade tidak bisa dilakukan karena sertifikat berbeda, hentikan rilis update langsung dan dokumentasikan hambatannya.
- [ ] Uji alur Check now → Download now → installer Android.

## 11. Urutan implementasi

1. Audit source ZIP dan catat kondisi awal; jangan mengubah source selama tahap audit.
2. Verifikasi versi, `applicationId`, `versionCode`, signing, dan struktur build.
3. Perbaiki masalah startup dan event handler yang menjadi fondasi interaksi.
4. Hapus My Wave secara tuntas dan aman.
5. Rapikan struktur layout Home, Search, Now Playing, Library, Mini Player, dan navigasi.
6. Terapkan design tokens dan tema Neubrutalism.
7. Tambahkan Liquid Glass sebagai lapisan visual terisolasi.
8. Optimalkan jalur playback, jaringan, cache, dan antrean.
9. Implementasikan updater dan pipeline rilis otomatis.
10. Jalankan tes source, unit/integrasi, build, dan tes APK pada perangkat.
11. Periksa log error serta performa sebelum rilis.
12. Publikasikan 2.0.0 hanya setelah seluruh kriteria rilis terpenuhi.

Setiap tahap harus dibuat sebagai perubahan kecil yang bisa ditinjau. Jangan menggabungkan refactor besar pada audio engine dengan perubahan visual yang tidak terkait.

## 12. Kriteria selesai / acceptance criteria

Implementasi baru dapat dinyatakan siap apabila:

- [ ] Versi dan metadata rilis benar untuk 2.0.0.
- [ ] ZIP lama tetap ada dan ZIP baru memakai nama versi yang berbeda.
- [ ] APK berhasil dibangun dan artefaknya bisa diunduh.
- [ ] Upgrade dari 1.3.9 berhasil tanpa uninstall, atau keterbatasan tanda tangan dijelaskan secara eksplisit sebelum rilis.
- [ ] Tidak ada My Wave atau referensi UI lama yang menyebabkan error.
- [ ] Semua tombol, tab, daftar, playlist, dan kontrol pemutar berfungsi.
- [ ] Kedua tema memiliki layout yang sama dan tampilan yang sesuai spesifikasi masing-masing.
- [ ] Liquid Glass memiliki efek transparan/cembung yang dibatasi pada tema itu saja dan tetap responsif.
- [ ] Playback, seekbar, shuffle, Next/Previous, antrean, dan background playback lulus pengujian.
- [ ] Startup tidak membekukan UI karena pekerjaan nonkritis.
- [ ] Check now dan Download now mengarah ke rilis valid dan mengikuti aturan installer Android.
- [ ] Tes yang gagal/terhambat dilaporkan dengan jujur; tidak ada klaim semua tes lulus jika belum.
- [ ] APK diuji di perangkat Android nyata sebelum dinyatakan stabil.

## 13. Risiko dan hal yang tidak boleh dijanjikan

- Tidak ada aplikasi yang bisa menjamin audio selalu mulai seketika jika server sumber, URL streaming, atau koneksi pengguna lambat.
- CSS Liquid Glass dapat menambah beban GPU; blur harus dibatasi dan diuji di perangkat nyata.
- Android tidak mengizinkan pemasangan APK diam-diam melalui updater biasa.
- Pembaruan di atas instalasi lama memerlukan ID aplikasi dan sertifikat signing yang cocok.
- Tes statis tidak membuktikan bahwa semua event handler berjalan pada perangkat nyata.
- Jangan menghapus aplikasi lama, mengganti ID paket, mengganti signing key, menghapus ZIP arsip, atau memublikasikan rilis baru tanpa memeriksa dampaknya terlebih dahulu.

---

**Status akhir dokumen:** Rencana implementasi ditetapkan. Belum ada source code, ZIP, workflow, versi aplikasi, atau repository yang diubah oleh pembuatan dokumen ini.
