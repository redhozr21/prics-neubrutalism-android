// =====================================================================
// PRICS PLAY — SMART TV / ANDROID TV CONTROLLER & SPATIAL ENGINE
// 10-Foot Navigation, D-Pad Remote Control & Fullscreen TV Karaoke (v3.7.2)
// =====================================================================

(() => {
  'use strict';

  // Strict Singleton Guard — physically prevents duplicate execution
  if (window.__PRICS_TV_ENGINE_INITIALIZED__) {
    console.warn('[PricsTV] TV engine already initialized. Skipping duplicate.');
    return;
  }
  window.__PRICS_TV_ENGINE_INITIALIZED__ = true;

  function isTVMode() {
    if (typeof window === 'undefined') return false;
    const saved = localStorage.getItem('prics_tv_mode');
    if (saved === 'true') return true;
    if (saved === 'false') return false;

    // Native Android TV bridge check
    if (window.PricsAndroidDevice && typeof window.PricsAndroidDevice.isTelevision === 'function') {
      if (window.PricsAndroidDevice.isTelevision()) return true;
    }

    const ua = (typeof navigator !== 'undefined' && navigator.userAgent) || '';
    if (/PricsTV|Android TV|GoogleTV|SmartTV|Leanback/i.test(ua)) {
      return true;
    }

    // Android device in 16:9 widescreen landscape without touchscreen
    const isLandscape = window.innerWidth > window.innerHeight;
    const isLargeScreen = window.innerWidth >= 960;
    const isNoTouch = !('ontouchstart' in window) || (navigator.maxTouchPoints === 0);
    if (/Android/i.test(ua) && isLandscape && isLargeScreen && isNoTouch) {
      return true;
    }

    return false;
  }

  if (!isTVMode()) {
    return; // Leave mobile phone layout 100% untouched
  }

  // Activate TV styling on html root
  const rootEl = document.documentElement;
  rootEl.classList.add('is-tv', 'is-desktop');
  rootEl.classList.remove('is-mobile');

  let currentView = 'home';
  let focusedEl = null;
  let isKaraokeOpen = false;
  let activeLyricIndex = -1;
  let lastActiveLyricIndex = -1;
  let tvLyricOffset = 0;
  let tvSyncHudTimer = null;
  let lastBackPressTime = 0;
  let lastNavTime = 0;
  let lastSelectTime = 0;
  let lyricsRafId = null;
  const NAV_THROTTLE_MS = 100;

  function getCore() {
    return window.MurielCore || null;
  }

  function getAudioEl() {
    const core = getCore();
    if (core && core.audio) return core.audio;
    return document.getElementById('player') || document.querySelector('audio');
  }

  // =====================================================================
  // Single Focus Manager (Strict single-source-of-truth)
  // =====================================================================
  function clearAllFocus() {
    document.querySelectorAll('.tv-focusable').forEach((el) => {
      el.classList.remove('tv-focused', 'tv-pressed');
      el.tabIndex = -1;
    });
  }

  function setFocus(el) {
    if (!el || !el.classList || !el.classList.contains('tv-focusable')) return;

    clearAllFocus();
    focusedEl = el;
    el.classList.add('tv-focused');
    el.tabIndex = 0;

    try {
      el.focus({ preventScroll: true });
    } catch (_) {}

    // Smooth TV overscan scroll
    if (typeof el.scrollIntoView === 'function') {
      try {
        const main = document.getElementById('tv-main');
        if (el.closest('#tv-spotlight') || el.id === 'tv-btn-hero-play' || el.id === 'tv-btn-hero-lyrics') {
          if (main) main.scrollTo({ top: 0, behavior: 'smooth' });
        } else if (el.closest('.tv-shelf-scroll')) {
          el.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        } else {
          el.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'nearest' });
        }
      } catch (_) {}
    }
  }

  function safeEscape(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // =====================================================================
  // Curated Popular Starter Tracks for Smart TV (Banyak Lagu di Beranda)
  // =====================================================================
  const CURATED_TOP_HITS = [
    {
      title: 'Jangan Paksa Rindu',
      artist: 'Ifan Seventeen',
      thumbnail: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&h=300&fit=crop'
    },
    {
      title: 'Gala Bunga Matahari',
      artist: 'Sal Priadi',
      thumbnail: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop'
    },
    {
      title: 'Satu Bulan',
      artist: 'Bernadya',
      thumbnail: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop'
    },
    {
      title: 'Rayuan Perempuan Gila',
      artist: 'Nadin Amizah',
      thumbnail: 'https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=300&h=300&fit=crop'
    },
    {
      title: 'Mati-Matian',
      artist: 'Mahalini',
      thumbnail: 'https://images.unsplash.com/photo-1487180144351-b8472da7d491?w=300&h=300&fit=crop'
    },
    {
      title: 'Sialan',
      artist: 'Juicy Luicy',
      thumbnail: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&h=300&fit=crop'
    },
    {
      title: 'Bunga Maaf',
      artist: 'The Lantis',
      thumbnail: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300&h=300&fit=crop'
    },
    {
      title: 'Tak Segampang Itu',
      artist: 'Anggi Marito',
      thumbnail: 'https://images.unsplash.com/photo-1485579149621-3123dd979885?w=300&h=300&fit=crop'
    },
    {
      title: 'Komang',
      artist: 'Raim Laode',
      thumbnail: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=300&h=300&fit=crop'
    },
    {
      title: 'Penjaga Hati',
      artist: 'Nadhif Basalamah',
      thumbnail: 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=300&h=300&fit=crop'
    }
  ];

  const CURATED_ACOUSTIC = [
    {
      title: 'Ruang Sendiri (Akustik)',
      artist: 'Tulus',
      thumbnail: 'https://images.unsplash.com/photo-1510915361894-db8b60106cb1?w=300&h=300&fit=crop'
    },
    {
      title: 'Akad',
      artist: 'Payung Teduh',
      thumbnail: 'https://images.unsplash.com/photo-1445985543470-41fdd6ce388d?w=300&h=300&fit=crop'
    },
    {
      title: 'Zona Nyaman',
      artist: 'Fourtwnty',
      thumbnail: 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=300&h=300&fit=crop'
    },
    {
      title: 'Tentang Rumahku',
      artist: 'Dialog Dini Hari',
      thumbnail: 'https://images.unsplash.com/photo-1485579149621-3123dd979885?w=300&h=300&fit=crop'
    },
    {
      title: 'Cukup Bagiku',
      artist: 'Fiersa Besari',
      thumbnail: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=300&h=300&fit=crop'
    },
    {
      title: 'Resah Jadi Luka',
      artist: 'Daun Jatuh',
      thumbnail: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop'
    },
    {
      title: 'Sampai Jadi Debu',
      artist: 'Banda Neira',
      thumbnail: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop'
    },
    {
      title: 'Menghujam Jantungku',
      artist: 'Tompi',
      thumbnail: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&h=300&fit=crop'
    }
  ];

  const CURATED_VIRAL = [
    {
      title: 'Karna Su Sayang',
      artist: 'Near ft. Dian Sorowea',
      thumbnail: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300&h=300&fit=crop'
    },
    {
      title: 'Asmalibrasi',
      artist: 'Soegi Bornean',
      thumbnail: 'https://images.unsplash.com/photo-1487180144351-b8472da7d491?w=300&h=300&fit=crop'
    },
    {
      title: 'Runtuh',
      artist: 'Feby Putri ft. Fiersa Besari',
      thumbnail: 'https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=300&h=300&fit=crop'
    },
    {
      title: 'Bertaut',
      artist: 'Nadin Amizah',
      thumbnail: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop'
    },
    {
      title: 'Hati-Hati di Jalan',
      artist: 'Tulus',
      thumbnail: 'https://images.unsplash.com/photo-1510915361894-db8b60106cb1?w=300&h=300&fit=crop'
    },
    {
      title: 'Jiwa Yang Bersedih',
      artist: 'Ghea Indrawari',
      thumbnail: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&h=300&fit=crop'
    }
  ];

  // =====================================================================
  // TV Root DOM Scaffolding (10-Foot Widescreen Layout)
  // =====================================================================
  function createTVLayout() {
    if (document.getElementById('tv-root')) return;

    const tvRoot = document.createElement('div');
    tvRoot.id = 'tv-root';
    tvRoot.innerHTML = `
      <!-- TV Slim Sidebar Rail (~200px) -->
      <aside class="tv-rail" aria-label="Smart TV Navigation">
        <div>
          <div class="tv-rail-brand">
            <div class="tv-rail-logo">
              <img src="assets/prics-pa-play.png" alt="Prics" onerror="this.outerHTML='P'">
            </div>
            <div class="tv-rail-title-group">
              <span class="tv-rail-title">Prics Play</span>
              <span class="tv-rail-badge">Smart TV</span>
            </div>
          </div>
          <nav class="tv-rail-menu">
            <button type="button" class="tv-rail-item tv-focusable active" data-tv-tab="home" tabindex="0">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/></svg>
              <span>Beranda</span>
            </button>
            <button type="button" class="tv-rail-item tv-focusable" data-tv-tab="search" tabindex="-1">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.5" y2="16.5"/></svg>
              <span>Pencarian</span>
            </button>
            <button type="button" class="tv-rail-item tv-focusable" data-tv-tab="library" tabindex="-1">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M4 4v16M9 4v16M14 4v16M19 4v16"/></svg>
              <span>Koleksi</span>
            </button>
            <button type="button" class="tv-rail-item tv-focusable" data-tv-tab="settings" tabindex="-1">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
              <span>Setelan</span>
            </button>
          </nav>
        </div>
        <div class="tv-rail-footer">
          <div class="tv-clock-pill" id="tv-clock">--:--</div>
        </div>
      </aside>

      <!-- TV Main Viewport -->
      <main class="tv-main" id="tv-main">
        <!-- Home View -->
        <section class="tv-view" id="tv-view-home">
          <!-- Compact Spotlight Hero -->
          <div class="tv-spotlight" id="tv-spotlight">
            <img class="tv-spotlight-art" id="tv-spotlight-art" src="assets/prics-pa-play.png" alt="Spotlight Art">
            <div class="tv-spotlight-info">
              <span class="tv-spotlight-tag" id="tv-spotlight-tag">SEDANG DIPUTAR</span>
              <h1 class="tv-spotlight-title" id="tv-spotlight-title">Prics Play Smart TV</h1>
              <p class="tv-spotlight-artist" id="tv-spotlight-artist">Pilih lagu dari daftar di bawah untuk memutar</p>
              <div class="tv-spotlight-actions">
                <button type="button" class="tv-btn-primary tv-focusable" id="tv-btn-hero-play" tabindex="-1">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                  <span>Putar Sekarang</span>
                </button>
                <button type="button" class="tv-btn-secondary tv-focusable" id="tv-btn-hero-lyrics" tabindex="-1">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/></svg>
                  <span>Lirik TV (Karaoke)</span>
                </button>
              </div>
            </div>
          </div>

          <!-- Shelf 1: 🔥 Top Hits Indonesia (Banyak Lagu Mini) -->
          <div class="tv-shelf" id="tv-shelf-hits-wrap">
            <div class="tv-shelf-header">
              <h2 class="tv-shelf-title">🔥 Top Hits Indonesia Hari Ini</h2>
            </div>
            <div class="tv-shelf-scroll" id="tv-shelf-hits"></div>
          </div>

          <!-- Shelf 2: ☕ Musik Akustik & Santai -->
          <div class="tv-shelf" id="tv-shelf-acoustic-wrap">
            <div class="tv-shelf-header">
              <h2 class="tv-shelf-title">☕ Musik Akustik & Santai</h2>
            </div>
            <div class="tv-shelf-scroll" id="tv-shelf-acoustic"></div>
          </div>

          <!-- Shelf 3: ✨ Populer & Viral -->
          <div class="tv-shelf" id="tv-shelf-viral-wrap">
            <div class="tv-shelf-header">
              <h2 class="tv-shelf-title">✨ Populer & Viral</h2>
            </div>
            <div class="tv-shelf-scroll" id="tv-shelf-viral"></div>
          </div>

          <!-- Shelf 4: Terakhir Diputar -->
          <div class="tv-shelf hidden" id="tv-shelf-recent-wrap">
            <div class="tv-shelf-header">
              <h2 class="tv-shelf-title">Terakhir Diputar</h2>
            </div>
            <div class="tv-shelf-scroll" id="tv-shelf-recent"></div>
          </div>

          <!-- Shelf 5: Lagu Disukai -->
          <div class="tv-shelf hidden" id="tv-shelf-favorites-wrap">
            <div class="tv-shelf-header">
              <h2 class="tv-shelf-title">Lagu Disukai</h2>
            </div>
            <div class="tv-shelf-scroll" id="tv-shelf-favorites"></div>
          </div>

          <!-- Shelf 6: Playlist Kamu -->
          <div class="tv-shelf hidden" id="tv-shelf-playlists-wrap">
            <div class="tv-shelf-header">
              <h2 class="tv-shelf-title">Playlist Kamu</h2>
            </div>
            <div class="tv-shelf-scroll" id="tv-shelf-playlists"></div>
          </div>
        </section>

        <!-- Search View -->
        <section class="tv-view hidden" id="tv-view-search">
          <div class="tv-search-header">
            <div class="tv-search-input-wrap tv-focusable" id="tv-search-input-box" tabindex="0" focusable="true" clickable="true">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.5" y2="16.5"/></svg>
              <input type="text" class="tv-search-input" id="tv-search-input" placeholder="Ketik judul lagu atau artis..." autocomplete="off" inputmode="search" tabindex="0" focusable="true" clickable="true">
            </div>
            <div class="tv-search-platforms">
              <button type="button" class="tv-platform-pill active tv-focusable" data-platform="ytmusic" tabindex="-1">YouTube Music</button>
              <button type="button" class="tv-platform-pill tv-focusable" data-platform="youtube" tabindex="-1">YouTube Video</button>
            </div>
          </div>
          <div class="tv-grid" id="tv-search-results">
            <div style="grid-column: 1 / -1; padding: 20px 0; color: #666; font-weight: 700; font-size: 15px;">
              Tekan OK untuk membuka keyboard virtual remote Smart TV.
            </div>
          </div>
        </section>

        <!-- Library View -->
        <section class="tv-view hidden" id="tv-view-library">
          <div class="tv-shelf-header">
            <h2 class="tv-shelf-title">Koleksi Lagu & Playlist Saya</h2>
          </div>
          <div class="tv-grid" id="tv-library-grid"></div>
        </section>

        <!-- Settings View (Clean, No Refresh Rate!) -->
        <section class="tv-view hidden" id="tv-view-settings">
          <div class="tv-settings-container">
            <!-- Setting 1: Kualitas Audio Streaming -->
            <div class="tv-settings-group">
              <h2 class="tv-setting-group-title">Kualitas Audio Streaming</h2>
              <div class="tv-setting-cards-row">
                <div class="tv-setting-card tv-focusable" id="tv-set-audio-low" data-quality="low" tabindex="-1">
                  <h3 class="tv-setting-card-title">Hemat Kuota</h3>
                  <p class="tv-setting-card-desc">Bitrate ~50-64 kbps (~20 MB/jam). Paling ringan.</p>
                </div>
                <div class="tv-setting-card active tv-focusable" id="tv-set-audio-normal" data-quality="normal" tabindex="-1">
                  <h3 class="tv-setting-card-title">Normal / Standar</h3>
                  <p class="tv-setting-card-desc">Bitrate ~128 kbps (~50 MB/jam). Jernih & seimbang.</p>
                </div>
                <div class="tv-setting-card tv-focusable" id="tv-set-audio-high" data-quality="high" tabindex="-1">
                  <h3 class="tv-setting-card-title">Kualitas Tinggi</h3>
                  <p class="tv-setting-card-desc">Bitrate ~160 kbps (~70 MB/jam). Detail vokal maksimal.</p>
                </div>
              </div>
            </div>

            <!-- Setting 2: Tema Warna Tampilan -->
            <div class="tv-settings-group">
              <h2 class="tv-setting-group-title">Tema Visual</h2>
              <div class="tv-setting-cards-row">
                <div class="tv-setting-card active tv-focusable" id="tv-set-theme-neo" data-theme="neubrutalism" tabindex="-1">
                  <h3 class="tv-setting-card-title">Neubrutalism</h3>
                  <p class="tv-setting-card-desc">Gaya khas Prics Play dengan kontras tinggi & tegas.</p>
                </div>
                <div class="tv-setting-card tv-focusable" id="tv-set-theme-dark" data-theme="dark" tabindex="-1">
                  <h3 class="tv-setting-card-title">Dark Cinema</h3>
                  <p class="tv-setting-card-desc">Latar gelap nyaman untuk bioskop kamar.</p>
                </div>
              </div>
            </div>

              <!-- Setting 3: Informasi Versi -->
            <div class="tv-settings-group">
              <h2 class="tv-setting-group-title">Tentang Aplikasi</h2>
              <div class="tv-setting-card" style="cursor: default;">
                <h3 class="tv-setting-card-title">Prics Play Smart TV Edition v3.7.2</h3>
                <p class="tv-setting-card-desc">Dioptimalkan khusus untuk Android TV & Xiaomi Smart TV (D-Pad 10-Foot UI).</p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <!-- TV Bottom Player Bar (Persistent Horizontal Dock) -->
      <footer class="tv-player-bar" id="tv-player-bar">
        <div class="tv-bar-track-info">
          <img class="tv-bar-art" id="tv-bar-art" src="assets/prics-pa-play.png" alt="Album Art">
          <div class="tv-bar-text">
            <span class="tv-bar-title" id="tv-bar-title">Tidak ada lagu diputar</span>
            <span class="tv-bar-artist" id="tv-bar-artist">Pilih lagu dari beranda atau pencarian</span>
          </div>
        </div>
        <div class="tv-bar-controls">
          <button type="button" class="tv-control-btn tv-focusable" id="tv-btn-prev" tabindex="-1" title="Sebelumnya">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><polygon points="19 20 9 12 19 4 19 20"/><line x1="5" y1="19" x2="5" y2="5" stroke="currentColor" stroke-width="2.5"/></svg>
          </button>
          <button type="button" class="tv-control-btn primary tv-focusable" id="tv-btn-play" tabindex="-1" title="Putar / Jeda">
            <svg class="tv-icon-play" id="tv-icon-play" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="6 4 20 12 6 20 6 4"/></svg>
            <svg class="tv-icon-pause hidden" id="tv-icon-pause" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
          </button>
          <button type="button" class="tv-control-btn tv-focusable" id="tv-btn-next" tabindex="-1" title="Berikutnya">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 4 15 12 5 20 5 4"/><line x1="19" y1="5" x2="19" y2="19" stroke="currentColor" stroke-width="2.5"/></svg>
          </button>
          <button type="button" class="tv-control-btn tv-focusable" id="tv-btn-karaoke-bar" tabindex="-1" title="Lirik Karaoke">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="22"/></svg>
          </button>
        </div>
      </footer>

      <!-- Fullscreen TV Karaoke Overlay -->
      <div class="tv-karaoke-overlay hidden" id="tv-karaoke-overlay">
        <div class="tvk-back-hint">Tekan [Kembali] pada remote untuk menutup</div>
        <div class="tvk-sync-hud hidden" id="tvk-sync-hud"></div>
        <div class="tvk-controls-bar">
          <span class="tvk-controls-pill"><b>▲ / ▼</b> Baris Lirik</span>
          <span class="tvk-controls-pill"><b>◄ / ►</b> Sinkron (±0.5s)</span>
          <span class="tvk-controls-pill"><b>OK</b> Putar/Jeda</span>
        </div>
        <div class="tvk-left-stage">
          <img class="tvk-disc-art" id="tvk-disc" src="assets/prics-pa-play.png" alt="Vinyl Art">
          <h2 class="tvk-track-title" id="tvk-title">Pilih Lagu</h2>
          <span class="tvk-track-artist" id="tvk-artist">Prics Play TV</span>
        </div>
        <div class="tvk-right-lyrics" id="tvk-lyrics-box">
          <div class="tvk-line active">Pilih lagu untuk bernyanyi karaoke...</div>
        </div>
      </div>
    `;

    document.body.prepend(tvRoot);
    startTVClock();
    setupTabSwitching();
    setupPlaybackControls();
    setupSettingsCards();
    setupSearchFeatures();
  }

  function startTVClock() {
    function updateClock() {
      const el = document.getElementById('tv-clock');
      if (!el) return;
      const now = new Date();
      const hh = String(now.getHours()).padStart(2, '0');
      const mm = String(now.getMinutes()).padStart(2, '0');
      el.textContent = `${hh}:${mm}`;
    }
    updateClock();
    setInterval(updateClock, 10000);
  }

  // =====================================================================
  // Tab Switching Logic
  // =====================================================================
  function switchTVTab(tabName) {
    if (!tabName) return;
    currentView = tabName;

    // Update rail active state
    document.querySelectorAll('.tv-rail-item').forEach((item) => {
      const isTarget = item.dataset.tvTab === tabName;
      item.classList.toggle('active', isTarget);
    });

    // Update view sections visibility
    document.querySelectorAll('.tv-view').forEach((sec) => {
      sec.classList.add('hidden');
    });
    const targetSec = document.getElementById(`tv-view-${tabName}`);
    if (targetSec) {
      targetSec.classList.remove('hidden');
    }

    if (tabName === 'home') {
      hydrateHomeContent();
    } else if (tabName === 'library') {
      hydrateLibraryContent();
    } else if (tabName === 'search') {
      // Auto-focus search input immediately when switching to search tab
      setTimeout(() => {
        const searchBox = document.getElementById('tv-search-input-box');
        if (searchBox) setFocus(searchBox);
      }, 50);
    }
  }

  function setupTabSwitching() {
    document.querySelectorAll('.tv-rail-item').forEach((btn) => {
      btn.addEventListener('click', () => {
        switchTVTab(btn.dataset.tvTab);
        setFocus(btn);
      });
    });
  }

  // =====================================================================
  // Real-Time Synced TV Karaoke Mode (Maju-Mundur Lirik & Lightweight)
  // =====================================================================
  function showKaraokeHUD(text) {
    const hud = document.getElementById('tvk-sync-hud');
    if (!hud) return;
    hud.textContent = text;
    hud.classList.remove('hidden');
    clearTimeout(tvSyncHudTimer);
    tvSyncHudTimer = setTimeout(() => {
      hud.classList.add('hidden');
    }, 1800);
  }

  function openTVKaraoke() {
    const overlay = document.getElementById('tv-karaoke-overlay');
    if (!overlay) return;
    overlay.classList.remove('hidden');
    isKaraokeOpen = true;
    tvLyricOffset = 0;
    activeLyricIndex = -1;
    lastActiveLyricIndex = -1;

    const core = getCore();
    if (core && core.state) core.state.isTvKaraokeOpen = true;

    syncNowPlayingUI();
    renderTVLyrics();

    const audio = getAudioEl();
    if (audio && !audio.paused) {
      document.documentElement.classList.add('playing');
    }

    cancelAnimationFrame(lyricsRafId);
    startTVLyricsLoop();
  }

  function closeTVKaraoke() {
    const overlay = document.getElementById('tv-karaoke-overlay');
    if (!overlay) return;
    overlay.classList.add('hidden');
    isKaraokeOpen = false;

    cancelAnimationFrame(lyricsRafId);
    const core = getCore();
    if (core && core.state) core.state.isTvKaraokeOpen = false;
  }

  function startTVLyricsLoop() {
    if (!isKaraokeOpen) return;
    updateTVActiveLyric();
    lyricsRafId = requestAnimationFrame(startTVLyricsLoop);
  }

  function renderTVLyrics() {
    const box = document.getElementById('tvk-lyrics-box');
    if (!box) return;

    const core = getCore();
    const track = core && core.state && core.state.currentTrack;
    if (!track) {
      box.innerHTML = '<div class="tvk-line active">Pilih lagu untuk bernyanyi karaoke...</div>';
      return;
    }

    const lyricsList = (core.state && core.state.syncedLyrics) || [];
    const lyricsContainer = document.getElementById('lyrics-container');
    const isLyricsEmpty = lyricsContainer && lyricsContainer.classList.contains('lyrics-empty');
    if (!Array.isArray(lyricsList) || !lyricsList.length) {
      box.innerHTML = isLyricsEmpty
        ? '<div class="tvk-line active">Lirik tidak tersedia untuk lagu ini</div>'
        : '<div class="tvk-line active">Memuat lirik dari server...</div>';
      return;
    }

    activeLyricIndex = -1;
    lastActiveLyricIndex = -1;
    box.replaceChildren();

    lyricsList.forEach((line, idx) => {
      const lineEl = document.createElement('div');
      lineEl.className = 'tvk-line' + (idx === 0 ? ' active' : '');
      lineEl.dataset.idx = String(idx);
      lineEl.dataset.time = String(typeof line.time === 'number' ? line.time : (parseFloat(line.time) || -1));
      lineEl.textContent = line.text || '...';
      box.appendChild(lineEl);
    });

    updateTVActiveLyric(true);
  }

  function updateTVActiveLyric(forceScroll) {
    if (!isKaraokeOpen) return;
    const box = document.getElementById('tvk-lyrics-box');
    if (!box) return;

    const audio = getAudioEl();
    if (!audio) return;

    // Apply manual sync offset (±0.5s increments)
    const currentTime = (audio.currentTime || 0) + tvLyricOffset;
    const core = getCore();
    const lyricsList = (core && core.state && core.state.syncedLyrics) || [];
    if (!lyricsList.length) return;

    let foundIdx = -1;
    for (let i = 0; i < lyricsList.length; i++) {
      const item = lyricsList[i];
      const itemTime = typeof item.time === 'number' ? item.time : (parseFloat(item.time) || -1);
      if (itemTime >= 0 && itemTime <= currentTime + 0.3) {
        foundIdx = i;
      } else if (itemTime > currentTime + 0.3) {
        break;
      }
    }

    if (foundIdx === -1 && currentTime > 0 && (parseFloat(lyricsList[0].time) || 0) < 0) {
      foundIdx = 0;
    } else if (foundIdx === -1 && currentTime >= (parseFloat(lyricsList[lyricsList.length - 1].time) || 0)) {
      foundIdx = lyricsList.length - 1;
    }

    // Ultra-optimized DOM mutation: update ONLY the old and new active lyric elements
    if (foundIdx !== -1 && (foundIdx !== activeLyricIndex || forceScroll)) {
      if (activeLyricIndex >= 0 && activeLyricIndex !== foundIdx) {
        const oldActive = box.querySelector(`.tvk-line[data-idx="${activeLyricIndex}"]`);
        if (oldActive) oldActive.classList.remove('active');
      }

      activeLyricIndex = foundIdx;
      lastActiveLyricIndex = foundIdx;

      const newActive = box.querySelector(`.tvk-line[data-idx="${foundIdx}"]`);
      if (newActive) {
        newActive.classList.add('active');
        newActive.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }

  // =====================================================================
  // Search & Play Immediately (Starter & Smart Play)
  // =====================================================================
  async function searchAndPlay(query) {
    const core = getCore();
    if (!core) return;
    if (core.toast) core.toast(`Mencari: ${query}...`, 'info');

    try {
      const base = (typeof core.base === 'function') ? core.base() : 'http://127.0.0.1:3000';
      const res = await fetch(`${base}/api/search?q=${encodeURIComponent(query)}&platform=ytmusic&limit=10`);
      const data = await res.json();
      const tracks = (data && data.tracks) || (Array.isArray(data) ? data : []);
      if (tracks.length > 0) {
        core.playTrack(tracks[0], tracks, 0);
        if (core.toast) core.toast(`Memutar: ${tracks[0].title}`, 'info');
      } else {
        const resYt = await fetch(`${base}/api/search?q=${encodeURIComponent(query)}&platform=youtube&limit=10`);
        const dataYt = await resYt.json();
        const ytTracks = (dataYt && dataYt.tracks) || (Array.isArray(dataYt) ? dataYt : []);
        if (ytTracks.length > 0) {
          core.playTrack(ytTracks[0], ytTracks, 0);
          if (core.toast) core.toast(`Memutar: ${ytTracks[0].title}`, 'info');
        }
      }
    } catch (e) {
      console.warn('[PricsTV] searchAndPlay failed:', e);
      if (core.toast) core.toast(`Mencari ${query} di YouTube...`, 'info');
      const input = document.getElementById('tv-search-input');
      if (input) {
        input.value = query;
        switchTVTab('search');
        performTVSearch();
      }
    }
  }

  // =====================================================================
  // TV Card Component (Tracks & Playlists) — Compact Size
  // =====================================================================
  function createTVCard(track, tracksList, index) {
    const card = document.createElement('div');
    card.className = 'tv-card tv-focusable';
    card.tabIndex = -1;

    let thumb = 'assets/prics-pa-play.png';
    const core = getCore();
    if (core && typeof core.thumb === 'function') {
      thumb = core.thumb(track) || thumb;
    } else if (track.thumbnail) {
      thumb = track.thumbnail;
    }

    if (typeof thumb === 'string') {
      thumb = thumb.replace(/\/maxresdefault\.jpg|\/hqdefault\.jpg|\/sddefault\.jpg/, '/mqdefault.jpg');
    }

    const title = safeEscape(track.title || 'Unknown Track');
    const artist = safeEscape(track.artist || 'Unknown Artist');

    card.innerHTML = `
      <img class="tv-card-art" src="${thumb}" alt="${title}" loading="lazy" decoding="async" onerror="this.src='assets/prics-pa-play.png'">
      <h3 class="tv-card-title">${title}</h3>
      <span class="tv-card-desc">${artist}</span>
    `;

    card.addEventListener('click', () => {
      if (core && typeof core.playTrack === 'function' && tracksList && tracksList.length) {
        core.playTrack(track, tracksList, index);
        if (core.toast) core.toast(`Memutar: ${track.title || 'Lagu'}`, 'info');
      } else {
        searchAndPlay(`${track.title} ${track.artist}`);
      }
    });

    return card;
  }

  // =====================================================================
  // Dynamic Content Hydration (Beranda dengan Banyak Lagu Mini)
  // =====================================================================
  function hydrateHomeContent() {
    const core = getCore();
    if (!core) return;

    // Track focused element before DOM re-renders to prevent focus loss
    const wasFocused = focusedEl;
    const wasFocusedId = wasFocused && wasFocused.id;
    const wasFocusedTitle = wasFocused && wasFocused.querySelector && wasFocused.querySelector('.tv-card-title') && wasFocused.querySelector('.tv-card-title').textContent;

    // 1. Shelf: 🔥 Top Hits Indonesia (Curated Instant)
    const hitsShelf = document.getElementById('tv-shelf-hits');
    if (hitsShelf && !hitsShelf.children.length) {
      CURATED_TOP_HITS.forEach((t, idx) => {
        hitsShelf.appendChild(createTVCard(t, CURATED_TOP_HITS, idx));
      });
    }

    // 2. Shelf: ☕ Musik Akustik & Santai
    const acousticShelf = document.getElementById('tv-shelf-acoustic');
    if (acousticShelf && !acousticShelf.children.length) {
      CURATED_ACOUSTIC.forEach((t, idx) => {
        acousticShelf.appendChild(createTVCard(t, CURATED_ACOUSTIC, idx));
      });
    }

    // 3. Shelf: ✨ Populer & Viral
    const viralShelf = document.getElementById('tv-shelf-viral');
    if (viralShelf && !viralShelf.children.length) {
      CURATED_VIRAL.forEach((t, idx) => {
        viralShelf.appendChild(createTVCard(t, CURATED_VIRAL, idx));
      });
    }

    // 4. Shelf: Terakhir Diputar (Dynamic History)
    const recentShelf = document.getElementById('tv-shelf-recent');
    const recentWrap = document.getElementById('tv-shelf-recent-wrap');
    if (recentShelf && recentWrap) {
      recentShelf.replaceChildren();
      const history = Array.isArray(core.state.history) ? core.state.history.slice(0, 20) : [];
      if (!history.length) {
        recentWrap.classList.add('hidden');
      } else {
        recentWrap.classList.remove('hidden');
        history.forEach((track, idx) => {
          recentShelf.appendChild(createTVCard(track, history, idx));
        });
      }
    }

    // 5. Shelf: Lagu Disukai
    const favShelf = document.getElementById('tv-shelf-favorites');
    const favWrap = document.getElementById('tv-shelf-favorites-wrap');
    if (favShelf && favWrap) {
      favShelf.replaceChildren();
      const favs = Array.isArray(core.state.favorites) ? core.state.favorites.slice(0, 20) : [];
      if (!favs.length) {
        favWrap.classList.add('hidden');
      } else {
        favWrap.classList.remove('hidden');
        favs.forEach((track, idx) => {
          favShelf.appendChild(createTVCard(track, favs, idx));
        });
      }
    }

    // 6. Shelf: Playlist Kamu
    const plShelf = document.getElementById('tv-shelf-playlists');
    const plWrap = document.getElementById('tv-shelf-playlists-wrap');
    if (plShelf && plWrap) {
      plShelf.replaceChildren();
      const playlists = Array.isArray(core.state.playlists) ? core.state.playlists : [];
      if (!playlists.length) {
        plWrap.classList.add('hidden');
      } else {
        plWrap.classList.remove('hidden');
        playlists.forEach((pl) => {
          const card = document.createElement('div');
          card.className = 'tv-card tv-focusable';
          card.tabIndex = -1;
          const firstTrack = pl.tracks && pl.tracks[0];
          const thumb = firstTrack && core.thumb(firstTrack) ? core.thumb(firstTrack) : 'assets/prics-pa-play.png';
          card.innerHTML = `
            <img class="tv-card-art" src="${thumb}" alt="${safeEscape(pl.name)}" loading="lazy" onerror="this.src='assets/prics-pa-play.png'">
            <h3 class="tv-card-title">${safeEscape(pl.name)}</h3>
            <span class="tv-card-desc">${(pl.tracks && pl.tracks.length) || 0} lagu</span>
          `;
          card.addEventListener('click', () => {
            if (pl.tracks && pl.tracks.length && core.playTrack) {
              core.playTrack(pl.tracks[0], pl.tracks, 0);
              if (core.toast) core.toast(`Memutar playlist: ${pl.name}`, 'info');
            }
          });
          plShelf.appendChild(card);
        });
      }
    }

    syncSpotlightHero();

    // Prevent D-Pad Focus Lock: If the focused element was detached during shelf rebuild, safely restore
    if (wasFocused && !document.body.contains(wasFocused)) {
      let restored = null;
      if (wasFocusedId) restored = document.getElementById(wasFocusedId);
      if (!restored && wasFocusedTitle) {
        restored = Array.from(document.querySelectorAll('#tv-view-home .tv-card')).find((c) => {
          const t = c.querySelector('.tv-card-title');
          return t && t.textContent === wasFocusedTitle;
        });
      }
      if (!restored) {
        restored = document.querySelector('#tv-view-home .tv-card.tv-focusable') ||
                   document.getElementById('tv-btn-hero-play') ||
                   document.getElementById('tv-btn-play');
      }
      if (restored) setFocus(restored);
    }
  }

  function hydrateLibraryContent() {
    const core = getCore();
    const grid = document.getElementById('tv-library-grid');
    if (!core || !grid) return;

    grid.replaceChildren();
    const items = [];

    if (Array.isArray(core.state.favorites) && core.state.favorites.length) {
      items.push(...core.state.favorites);
    }
    if (Array.isArray(core.state.history) && core.state.history.length) {
      items.push(...core.state.history);
    }

    if (!items.length) {
      grid.innerHTML = '<div style="grid-column: 1 / -1; padding: 40px 0; color: #777; font-weight: 700; font-size: 16px;">Belum ada lagu di koleksi Anda. Putar lagu dari beranda untuk mengisi daftar ini.</div>';
      return;
    }

    const seen = new Set();
    const unique = items.filter((it) => {
      const key = `${it.title}__${it.artist}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

    unique.forEach((track, idx) => {
      grid.appendChild(createTVCard(track, unique, idx));
    });
  }

  // =====================================================================
  // Spotlight Hero & Now Playing Sync
  // =====================================================================
  function syncSpotlightHero() {
    const core = getCore();
    const track = core && core.state && core.state.currentTrack;

    const titleEl = document.getElementById('tv-spotlight-title');
    const artistEl = document.getElementById('tv-spotlight-artist');
    const artEl = document.getElementById('tv-spotlight-art');
    const tagEl = document.getElementById('tv-spotlight-tag');
    const playBtnText = document.querySelector('#tv-btn-hero-play span');

    if (track) {
      if (titleEl) titleEl.textContent = track.title || 'Lagu Sedang Diputar';
      if (artistEl) artistEl.textContent = track.artist || 'Artis';
      if (artEl) artEl.src = (core.thumb && core.thumb(track)) || track.thumbnail || 'assets/prics-pa-play.png';
      if (tagEl) tagEl.textContent = 'SEDANG DIPUTAR';
      if (playBtnText) {
        const isPlaying = core.audio && !core.audio.paused;
        playBtnText.textContent = isPlaying ? 'Jeda Lagu' : 'Lanjutkan Lagu';
      }
    } else {
      if (titleEl) titleEl.textContent = 'Prics Play Smart TV';
      if (artistEl) artistEl.textContent = 'Pilih salah satu lagu di bawah untuk memutar musik';
      if (artEl) artEl.src = 'assets/prics-pa-play.png';
      if (tagEl) tagEl.textContent = 'REKOMENDASI HITS';
      if (playBtnText) playBtnText.textContent = 'Putar Sekarang';
    }
  }

  function syncNowPlayingUI() {
    const core = getCore();
    const track = core && core.state && core.state.currentTrack;
    const isPlaying = core && core.audio && !core.audio.paused;

    // Bottom Bar sync
    const barArt = document.getElementById('tv-bar-art');
    const barTitle = document.getElementById('tv-bar-title');
    const barArtist = document.getElementById('tv-bar-artist');
    const iconPlay = document.getElementById('tv-icon-play');
    const iconPause = document.getElementById('tv-icon-pause');

    if (track) {
      if (barTitle) barTitle.textContent = track.title || 'Unknown Title';
      if (barArtist) barArtist.textContent = track.artist || 'Unknown Artist';
      if (barArt) barArt.src = (core.thumb && core.thumb(track)) || track.thumbnail || 'assets/prics-pa-play.png';
    }

    if (iconPlay && iconPause) {
      if (isPlaying) {
        iconPlay.classList.add('hidden');
        iconPause.classList.remove('hidden');
        document.documentElement.classList.add('playing');
      } else {
        iconPlay.classList.remove('hidden');
        iconPause.classList.add('hidden');
        document.documentElement.classList.remove('playing');
      }
    }

    // Karaoke Modal sync
    const kTitle = document.getElementById('tvk-title');
    const kArtist = document.getElementById('tvk-artist');
    const kDisc = document.getElementById('tvk-disc');
    if (track) {
      if (kTitle) kTitle.textContent = track.title;
      if (kArtist) kArtist.textContent = track.artist;
      if (kDisc) kDisc.src = (core.thumb && core.thumb(track)) || track.thumbnail || 'assets/prics-pa-play.png';
    }

    syncSpotlightHero();
  }

  // =====================================================================
  // Playback Controls Wire-up
  // =====================================================================
  function handleSmartPlay() {
    const core = getCore();
    if (!core) return;

    if (core.state && core.state.currentTrack) {
      core.togglePlay();
      syncNowPlayingUI();
      return;
    }

    // Play from history, favorites, or curated hits
    if (core.state && core.state.history && core.state.history.length) {
      core.playTrack(core.state.history[0], core.state.history, 0);
      return;
    }
    if (core.state && core.state.favorites && core.state.favorites.length) {
      core.playTrack(core.state.favorites[0], core.state.favorites, 0);
      return;
    }
    searchAndPlay(CURATED_TOP_HITS[0].title);
  }

  function setupPlaybackControls() {
    const core = getCore();
    const btnPlay = document.getElementById('tv-btn-play');
    const btnPrev = document.getElementById('tv-btn-prev');
    const btnNext = document.getElementById('tv-btn-next');
    const btnKaraokeToggle = document.getElementById('tv-btn-karaoke-bar');

    const heroPlay = document.getElementById('tv-btn-hero-play');
    const heroLyrics = document.getElementById('tv-btn-hero-lyrics');

    if (btnPlay) {
      btnPlay.addEventListener('click', handleSmartPlay);
    }
    if (heroPlay) {
      heroPlay.addEventListener('click', handleSmartPlay);
    }
    if (btnPrev) {
      btnPrev.addEventListener('click', () => {
        if (core && core.prev) core.prev();
      });
    }
    if (btnNext) {
      btnNext.addEventListener('click', () => {
        if (core && core.next) core.next();
      });
    }
    if (btnKaraokeToggle) {
      btnKaraokeToggle.addEventListener('click', openTVKaraoke);
    }
    if (heroLyrics) {
      heroLyrics.addEventListener('click', openTVKaraoke);
    }

    const audio = getAudioEl();
    if (audio) {
      audio.addEventListener('play', syncNowPlayingUI);
      audio.addEventListener('pause', syncNowPlayingUI);
    }

    window.addEventListener('muriel:track', () => {
      syncNowPlayingUI();
      if (isKaraokeOpen) renderTVLyrics();
    });
    window.addEventListener('muriel:lyrics', () => {
      if (isKaraokeOpen) renderTVLyrics();
    });
    window.addEventListener('muriel:library', hydrateHomeContent);
  }

  // =====================================================================
  // Settings Cards Interaction & Theme Management
  // =====================================================================
  function applyTVTheme(theme) {
    const isDark = theme === 'dark';
    document.documentElement.dataset.theme = isDark ? 'dark' : 'light';
    document.documentElement.classList.toggle('theme-dark', isDark);
    document.documentElement.classList.toggle('theme-light', !isDark);
    try {
      localStorage.setItem('muriel_theme', theme);
      localStorage.setItem('prics_tv_theme', theme);
    } catch (_) {}
    const neoCard = document.getElementById('tv-set-theme-neo');
    const darkCard = document.getElementById('tv-set-theme-dark');
    if (neoCard) neoCard.classList.toggle('active', !isDark);
    if (darkCard) darkCard.classList.toggle('active', isDark);
  }

  function setupSettingsCards() {
    const core = getCore();

    // Audio Quality
    const audioCards = [
      document.getElementById('tv-set-audio-low'),
      document.getElementById('tv-set-audio-normal'),
      document.getElementById('tv-set-audio-high')
    ];
    audioCards.forEach((card) => {
      if (!card) return;
      card.addEventListener('click', () => {
        audioCards.forEach((c) => c && c.classList.remove('active'));
        card.classList.add('active');
        const q = card.dataset.quality;
        localStorage.setItem('muriel_audio_quality', q);
        if (core && core.toast) core.toast(`Kualitas audio diatur ke: ${q}`, 'info');
      });
    });

    // Visual Theme (Neubrutalism vs Dark Cinema)
    const savedTheme = localStorage.getItem('prics_tv_theme') || localStorage.getItem('muriel_theme') || 'neubrutalism';
    applyTVTheme(savedTheme);

    const themeCards = [
      document.getElementById('tv-set-theme-neo'),
      document.getElementById('tv-set-theme-dark')
    ];
    themeCards.forEach((card) => {
      if (!card) return;
      card.addEventListener('click', () => {
        const theme = card.dataset.theme;
        applyTVTheme(theme);
        if (core && core.toast) core.toast(`Tema diatur ke: ${theme === 'dark' ? 'Dark Cinema' : 'Neubrutalism'}`, 'info');
      });
    });
  }

  // =====================================================================
  // Search Features
  // =====================================================================
  function setupSearchFeatures() {
    const pills = document.querySelectorAll('.tv-platform-pill');
    pills.forEach((p) => {
      p.addEventListener('click', () => {
        pills.forEach((x) => x.classList.remove('active'));
        p.classList.add('active');
        performTVSearch();
      });
    });

    const input = document.getElementById('tv-search-input');
    if (input) {
      let debounceTimer = null;
      input.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(performTVSearch, 400);
      });
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          performTVSearch();
          input.blur();
        }
      });
    }
  }

  async function performTVSearch() {
    const input = document.getElementById('tv-search-input');
    const query = input ? input.value.trim() : '';
    const resultsGrid = document.getElementById('tv-search-results');
    if (!resultsGrid) return;

    if (!query) {
      resultsGrid.innerHTML = '<div style="grid-column: 1 / -1; padding: 20px 0; color: #666; font-weight: 700; font-size: 15px;">Ketik judul lagu atau nama artis untuk mencari.</div>';
      return;
    }

    resultsGrid.innerHTML = '<div style="grid-column: 1 / -1; padding: 20px 0; color: #FF482C; font-weight: 800; font-size: 16px;">Mencari lagu di YouTube...</div>';

    const activePill = document.querySelector('.tv-platform-pill.active');
    const platform = activePill ? activePill.dataset.platform : 'ytmusic';

    try {
      const core = getCore();
      const base = (core && typeof core.base === 'function') ? core.base() : 'http://127.0.0.1:3000';
      const res = await fetch(`${base}/api/search?q=${encodeURIComponent(query)}&platform=${platform}&limit=24`);
      const data = await res.json();
      const tracks = (data && data.tracks) || (Array.isArray(data) ? data : []);

      resultsGrid.replaceChildren();
      if (!tracks.length) {
        resultsGrid.innerHTML = '<div style="grid-column: 1 / -1; padding: 20px 0; color: #666; font-weight: 700;">Tidak ditemukan hasil untuk: ' + safeEscape(query) + '</div>';
        return;
      }

      tracks.forEach((track, idx) => {
        resultsGrid.appendChild(createTVCard(track, tracks, idx));
      });
    } catch (e) {
      resultsGrid.innerHTML = '<div style="grid-column: 1 / -1; padding: 20px 0; color: #FF482C; font-weight: 700;">Gagal memuat hasil pencarian. Periksa koneksi internet Smart TV Anda.</div>';
    }
  }

  // =====================================================================
  // Native Android D-Pad Spatial Navigation Dispatcher
  // =====================================================================
  function handleTVNav(dir) {
    const now = Date.now();
    if (now - lastNavTime < NAV_THROTTLE_MS) return;
    lastNavTime = now;

    const isUp = dir === 'up';
    const isDown = dir === 'down';
    const isLeft = dir === 'left';
    const isRight = dir === 'right';

    // Mode Karaoke Navigation: Maju / Mundur Lirik & Koreksi Sinkronisasi
    if (isKaraokeOpen) {
      const audio = getAudioEl();
      const core = getCore();
      const lyricsList = (core && core.state && core.state.syncedLyrics) || [];

      if (isUp || isDown) {
        if (lyricsList.length > 0 && audio) {
          let targetIdx = activeLyricIndex;
          if (isDown) {
            targetIdx = Math.min(lyricsList.length - 1, (activeLyricIndex < 0 ? 0 : activeLyricIndex) + 1);
          } else if (isUp) {
            targetIdx = Math.max(0, (activeLyricIndex < 0 ? 0 : activeLyricIndex) - 1);
          }
          const line = lyricsList[targetIdx];
          if (line) {
            const t = typeof line.time === 'number' ? line.time : (parseFloat(line.time) || 0);
            try {
              audio.currentTime = Math.max(0, t);
            } catch (_) {}
            activeLyricIndex = targetIdx;
            updateTVActiveLyric(true);
            const previewText = (line.text || '').trim().slice(0, 28);
            showKaraokeHUD(`Lompat baris ${targetIdx + 1}/${lyricsList.length}: "${previewText}..."`);
          }
        }
        return;
      }

      if (isLeft || isRight) {
        if (isRight) {
          tvLyricOffset += 0.5;
        } else if (isLeft) {
          tvLyricOffset -= 0.5;
        }
        const sign = tvLyricOffset > 0 ? '+' : '';
        showKaraokeHUD(`Sinkronisasi Lirik: ${sign}${tvLyricOffset.toFixed(1)}s`);
        updateTVActiveLyric(true);
        return;
      }
      return;
    }

    // Single Source of Truth Focus: Pastikan elemen yang difokuskan masih ada di DOM aktif
    let current = (focusedEl && document.body.contains(focusedEl)) ? focusedEl : document.querySelector('.tv-focusable.tv-focused');

    if (!current || !document.body.contains(current) || !current.classList || !current.classList.contains('tv-focusable')) {
      // Pemulihan otomatis jika elemen fokus sebelumnya terhapus akibat pemutaran lagu / re-render
      const activeView = document.getElementById(`tv-view-${currentView}`);
      let fallback = null;
      if (activeView) {
        fallback = activeView.querySelector('.tv-card.tv-focusable') ||
                   activeView.querySelector('.tv-focusable');
      }
      if (!fallback) {
        fallback = document.getElementById('tv-btn-play') ||
                   document.querySelector('.tv-rail-item.active') ||
                   document.querySelector('.tv-rail-item');
      }
      if (fallback) {
        setFocus(fallback);
        current = fallback;
      } else {
        return;
      }
    }

    // Rule A: Currently on Left Rail
    if (current.classList.contains('tv-rail-item')) {
      const railItems = Array.from(document.querySelectorAll('.tv-rail-item'));
      const idx = railItems.indexOf(current);

      if (isDown) {
        if (idx < railItems.length - 1) {
          const nextItem = railItems[idx + 1];
          switchTVTab(nextItem.dataset.tvTab);
          setFocus(nextItem);
        }
      } else if (isUp) {
        if (idx > 0) {
          const prevItem = railItems[idx - 1];
          switchTVTab(prevItem.dataset.tvTab);
          setFocus(prevItem);
        }
      } else if (isRight) {
        const activeView = document.getElementById(`tv-view-${currentView}`);
        if (activeView) {
          let target = null;
          if (currentView === 'home') {
            target = document.getElementById('tv-btn-hero-play') || activeView.querySelector('.tv-card');
          } else if (currentView === 'search') {
            target = document.getElementById('tv-search-input-box') || activeView.querySelector('.tv-platform-pill');
          } else if (currentView === 'library') {
            target = activeView.querySelector('.tv-card');
          } else if (currentView === 'settings') {
            target = document.getElementById('tv-set-audio-low') || activeView.querySelector('.tv-setting-card.tv-focusable');
          }
          if (target) setFocus(target);
        }
      }
      return;
    }

    // Rule B: Inside a Horizontal Shelf
    const currentShelf = current.closest('.tv-shelf-scroll');
    if (currentShelf) {
      const cards = Array.from(currentShelf.querySelectorAll('.tv-card'));
      const idx = cards.indexOf(current);

      if (isRight) {
        if (idx < cards.length - 1) {
          setFocus(cards[idx + 1]);
        }
      } else if (isLeft) {
        if (idx > 0) {
          setFocus(cards[idx - 1]);
        } else {
          const railItem = document.querySelector('.tv-rail-item.active') || document.querySelector('.tv-rail-item');
          if (railItem) setFocus(railItem);
        }
      } else if (isDown) {
        const allShelves = Array.from(document.querySelectorAll('#tv-view-home .tv-shelf:not(.hidden) .tv-shelf-scroll'));
        const sIdx = allShelves.indexOf(currentShelf);
        if (sIdx < allShelves.length - 1) {
          const nextShelf = allShelves[sIdx + 1];
          const nextCards = nextShelf.querySelectorAll('.tv-card');
          const target = nextCards[Math.min(idx, nextCards.length - 1)] || nextCards[0];
          if (target) setFocus(target);
        } else {
          const playBtn = document.getElementById('tv-btn-play');
          if (playBtn) setFocus(playBtn);
        }
      } else if (isUp) {
        const allShelves = Array.from(document.querySelectorAll('#tv-view-home .tv-shelf:not(.hidden) .tv-shelf-scroll'));
        const sIdx = allShelves.indexOf(currentShelf);
        if (sIdx > 0) {
          const prevShelf = allShelves[sIdx - 1];
          const prevCards = prevShelf.querySelectorAll('.tv-card');
          const target = prevCards[Math.min(idx, prevCards.length - 1)] || prevCards[0];
          if (target) setFocus(target);
        } else {
          const heroBtn = document.getElementById('tv-btn-hero-play');
          if (heroBtn) {
            setFocus(heroBtn);
            const main = document.getElementById('tv-main');
            if (main) main.scrollTo({ top: 0, behavior: 'smooth' });
          }
        }
      }
      return;
    }

    // Rule C: Inside Spotlight Hero
    if (current.id === 'tv-btn-hero-play' || current.id === 'tv-btn-hero-lyrics') {
      if (isLeft) {
        if (current.id === 'tv-btn-hero-lyrics') {
          setFocus(document.getElementById('tv-btn-hero-play'));
        } else {
          const railItem = document.querySelector('.tv-rail-item.active');
          if (railItem) setFocus(railItem);
        }
      } else if (isRight && current.id === 'tv-btn-hero-play') {
        setFocus(document.getElementById('tv-btn-hero-lyrics'));
      } else if (isDown) {
        const firstShelf = document.querySelector('#tv-view-home .tv-shelf:not(.hidden) .tv-shelf-scroll');
        if (firstShelf) {
          const firstCard = firstShelf.querySelector('.tv-card');
          if (firstCard) setFocus(firstCard);
          else {
            const playBtn = document.getElementById('tv-btn-play');
            if (playBtn) setFocus(playBtn);
          }
        }
      }
      return;
    }

    // Rule D: Inside Bottom Player Bar
    if (current.closest('.tv-player-bar')) {
      const controls = [
        document.getElementById('tv-btn-prev'),
        document.getElementById('tv-btn-play'),
        document.getElementById('tv-btn-next'),
        document.getElementById('tv-btn-karaoke-bar')
      ].filter(Boolean);
      const cIdx = controls.indexOf(current);

      if (isLeft) {
        if (cIdx > 0) {
          setFocus(controls[cIdx - 1]);
        } else {
          const railItem = document.querySelector('.tv-rail-item.active');
          if (railItem) setFocus(railItem);
        }
      } else if (isRight) {
        if (cIdx < controls.length - 1) {
          setFocus(controls[cIdx + 1]);
        }
      } else if (isUp) {
        if (currentView === 'home') {
          const allShelves = Array.from(document.querySelectorAll('#tv-view-home .tv-shelf:not(.hidden) .tv-shelf-scroll'));
          if (allShelves.length) {
            const lastShelf = allShelves[allShelves.length - 1];
            const cards = lastShelf.querySelectorAll('.tv-card');
            if (cards.length) setFocus(cards[0]);
          } else {
            const heroBtn = document.getElementById('tv-btn-hero-play');
            if (heroBtn) setFocus(heroBtn);
          }
        } else if (currentView === 'library') {
          const cards = document.querySelectorAll('#tv-library-grid .tv-card');
          if (cards.length) setFocus(cards[cards.length - 1]);
        } else if (currentView === 'settings') {
          const target = document.getElementById('tv-set-theme-dark') || document.getElementById('tv-set-theme-neo');
          if (target) setFocus(target);
        }
      }
      return;
    }

    // Rule E: Inside Settings (2D Natural D-Pad Grid)
    if (current.classList.contains('tv-setting-card')) {
      const row1 = ['tv-set-audio-low', 'tv-set-audio-normal', 'tv-set-audio-high'].map((id) => document.getElementById(id)).filter(Boolean);
      const row2 = ['tv-set-theme-neo', 'tv-set-theme-dark'].map((id) => document.getElementById(id)).filter(Boolean);

      const inRow1 = row1.includes(current);
      const inRow2 = row2.includes(current);

      if (inRow1) {
        const idx = row1.indexOf(current);
        if (isRight) {
          if (idx < row1.length - 1) setFocus(row1[idx + 1]);
        } else if (isLeft) {
          if (idx > 0) {
            setFocus(row1[idx - 1]);
          } else {
            // Jump smoothly to rail menu
            const railItem = document.querySelector('.tv-rail-item[data-tv-tab="settings"]') || document.querySelector('.tv-rail-item.active');
            if (railItem) setFocus(railItem);
          }
        } else if (isDown) {
          const target2 = idx === 2 ? row2[1] || row2[0] : row2[0];
          if (target2) setFocus(target2);
        }
        return;
      }

      if (inRow2) {
        const idx = row2.indexOf(current);
        if (isRight) {
          if (idx < row2.length - 1) setFocus(row2[idx + 1]);
        } else if (isLeft) {
          if (idx > 0) {
            setFocus(row2[idx - 1]);
          } else {
            const railItem = document.querySelector('.tv-rail-item[data-tv-tab="settings"]') || document.querySelector('.tv-rail-item.active');
            if (railItem) setFocus(railItem);
          }
        } else if (isUp) {
          const target1 = idx === 1 ? row1[row1.length - 1] : row1[0];
          if (target1) setFocus(target1);
        } else if (isDown) {
          const playBtn = document.getElementById('tv-btn-play');
          if (playBtn) setFocus(playBtn);
        }
        return;
      }
      return;
    }

    // Rule F: Inside Search
    if (current.id === 'tv-search-input-box') {
      if (isDown) {
        const activePill = document.querySelector('.tv-platform-pill.active') || document.querySelector('.tv-platform-pill');
        if (activePill) setFocus(activePill);
      } else if (isLeft) {
        const railItem = document.querySelector('.tv-rail-item.active');
        if (railItem) setFocus(railItem);
      }
      return;
    }

    if (current.classList.contains('tv-platform-pill')) {
      const pills = Array.from(document.querySelectorAll('.tv-platform-pill'));
      const pIdx = pills.indexOf(current);
      if (isLeft) {
        if (pIdx > 0) setFocus(pills[pIdx - 1]);
        else {
          const railItem = document.querySelector('.tv-rail-item.active');
          if (railItem) setFocus(railItem);
        }
      } else if (isRight && pIdx < pills.length - 1) {
        setFocus(pills[pIdx + 1]);
      } else if (isUp) {
        setFocus(document.getElementById('tv-search-input-box'));
      } else if (isDown) {
        const firstCard = document.querySelector('#tv-search-results .tv-card');
        if (firstCard) setFocus(firstCard);
      }
      return;
    }

    // Rule G: Inside Grid (Search Results or Library)
    const currentGrid = current.closest('.tv-grid');
    if (currentGrid) {
      const cards = Array.from(currentGrid.querySelectorAll('.tv-card'));
      const cIdx = cards.indexOf(current);
      const cols = 5;

      if (isRight) {
        if (cIdx < cards.length - 1) setFocus(cards[cIdx + 1]);
      } else if (isLeft) {
        if (cIdx % cols === 0) {
          const railItem = document.querySelector('.tv-rail-item.active');
          if (railItem) setFocus(railItem);
        } else if (cIdx > 0) {
          setFocus(cards[cIdx - 1]);
        }
      } else if (isDown) {
        if (cIdx + cols < cards.length) setFocus(cards[cIdx + cols]);
        else {
          const playBtn = document.getElementById('tv-btn-play');
          if (playBtn) setFocus(playBtn);
        }
      } else if (isUp) {
        if (cIdx - cols >= 0) setFocus(cards[cIdx - cols]);
        else {
          const activePill = document.querySelector('.tv-platform-pill.active') || document.querySelector('.tv-platform-pill');
          if (activePill) setFocus(activePill);
          else {
            const railItem = document.querySelector('.tv-rail-item.active');
            if (railItem) setFocus(railItem);
          }
        }
      }
      return;
    }
  }

  // =====================================================================
  // Selection / OK Click Execution
  // =====================================================================
  function handleTVSelect() {
    const now = Date.now();
    if (now - lastSelectTime < 250) return;
    lastSelectTime = now;

    // OK di Layar Karaoke: Jeda / Lanjutkan Lagu
    if (isKaraokeOpen) {
      handleSmartPlay();
      const audio = getAudioEl();
      const isPaused = audio ? audio.paused : false;
      showKaraokeHUD(isPaused ? '⏸ Jeda (Paused)' : '▶ Memutar (Playing)');
      return;
    }

    const current = focusedEl || document.querySelector('.tv-focusable.tv-focused');
    if (!current) return;

    current.classList.add('tv-pressed');
    setTimeout(() => {
      current.classList.remove('tv-pressed');
    }, 120);

    // D-Pad OK pada Kotak Pencarian: Fokus & Panggil Keyboard Virtual (IME) TV
    if (current.id === 'tv-search-input-box' || current.id === 'tv-search-input') {
      const input = document.getElementById('tv-search-input');
      if (input) {
        input.focus();
        input.click();
        if (window.PricsAndroidDevice && typeof window.PricsAndroidDevice.showKeyboard === 'function') {
          window.PricsAndroidDevice.showKeyboard();
        }
      }
      return;
    }

    try {
      current.click();
    } catch (e) {
      console.warn('[PricsTV] click failed:', e);
    }
  }

  // =====================================================================
  // TV Remote Back Button Logic
  // =====================================================================
  function handleTVBack() {
    if (isKaraokeOpen) {
      closeTVKaraoke();
      return;
    }

    const input = document.getElementById('tv-search-input');
    if (document.activeElement === input) {
      input.blur();
      if (window.PricsAndroidDevice && typeof window.PricsAndroidDevice.hideKeyboard === 'function') {
        window.PricsAndroidDevice.hideKeyboard();
      }
      setFocus(document.getElementById('tv-search-input-box'));
      return;
    }

    if (currentView !== 'home') {
      switchTVTab('home');
      const homeRail = document.querySelector('.tv-rail-item[data-tv-tab="home"]');
      if (homeRail) setFocus(homeRail);
      return;
    }

    const current = focusedEl || document.querySelector('.tv-focusable.tv-focused');
    const isHomeRail = current && current.classList && current.classList.contains('tv-rail-item') && current.dataset.tvTab === 'home';

    if (!isHomeRail) {
      const homeRail = document.querySelector('.tv-rail-item[data-tv-tab="home"]');
      if (homeRail) setFocus(homeRail);
      return;
    }

    // Double-press Back to exit app on TV
    const now = Date.now();
    if (now - lastBackPressTime >= 400 && now - lastBackPressTime <= 2500) {
      if (window.PricsAndroidDevice && typeof window.PricsAndroidDevice.exitApp === 'function') {
        window.PricsAndroidDevice.exitApp();
      } else {
        window.close();
      }
      return;
    }

    lastBackPressTime = now;
    const core = getCore();
    if (core && core.toast) {
      core.toast('Tekan [Kembali] sekali lagi untuk keluar dari Prics Play TV', 'info');
    }
  }

  // =====================================================================
  // Public Native Bridge (window.PricsTV)
  // =====================================================================
  window.PricsTV = {
    handleNav: (dir) => handleTVNav(dir),
    handleSelect: () => handleTVSelect(),
    handleBack: () => handleTVBack(),
    handleMediaPlayPause: () => handleSmartPlay(),
    handleMediaNext: () => {
      const core = getCore();
      if (core && core.next) core.next();
    },
    handleMediaPrev: () => {
      const core = getCore();
      if (core && core.prev) core.prev();
    },
    handleMediaKey: (action) => {
      const core = getCore();
      if (!core) return;
      if (action === 'playpause') handleSmartPlay();
      else if (action === 'next' && core.next) core.next();
      else if (action === 'prev' && core.prev) core.prev();
    },
    searchAndPlay: (query) => searchAndPlay(query),
    openKaraoke: () => openTVKaraoke(),
    closeKaraoke: () => closeTVKaraoke(),
    adjustLyricOffset: (delta) => {
      tvLyricOffset += delta;
      showKaraokeHUD(`Sinkronisasi Lirik: ${tvLyricOffset > 0 ? '+' : ''}${tvLyricOffset.toFixed(1)}s`);
      updateTVActiveLyric(true);
    }
  };

  // Keyboard Fallback for Browser DevTools
  function initRemoteNavigation() {
    const defaultFocus = document.querySelector('.tv-rail-item.active') || document.querySelector('.tv-rail-item');
    if (defaultFocus) setFocus(defaultFocus);

    window.addEventListener('keydown', (e) => {
      const key = e.key;
      const code = e.keyCode;

      const isUp = key === 'ArrowUp' || code === 38;
      const isDown = key === 'ArrowDown' || code === 40;
      const isLeft = key === 'ArrowLeft' || code === 37;
      const isRight = key === 'ArrowRight' || code === 39;
      const isEnter = key === 'Enter' || code === 13 || code === 23;
      const isBack = key === 'Escape' || key === 'Backspace' || code === 4 || code === 27;

      if (!isUp && !isDown && !isLeft && !isRight && !isEnter && !isBack) {
        return;
      }

      const input = document.getElementById('tv-search-input');
      if (document.activeElement === input && (isLeft || isRight)) {
        return; // Allow typing in search input
      }

      e.preventDefault();
      e.stopPropagation();

      if (isBack) {
        handleTVBack();
        return;
      }
      if (isEnter) {
        handleTVSelect();
        return;
      }

      const dir = isUp ? 'up' : isDown ? 'down' : isLeft ? 'left' : 'right';
      handleTVNav(dir);
    }, true);
  }

  // =====================================================================
  // Initialization Lifecycle
  // =====================================================================
  function boot() {
    createTVLayout();
    initRemoteNavigation();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  window.addEventListener('load', () => {
    hydrateHomeContent();
    syncNowPlayingUI();
  });

})();
