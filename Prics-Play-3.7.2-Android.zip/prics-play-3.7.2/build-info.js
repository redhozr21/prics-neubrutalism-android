window.MURIEL_BUILD = {"sha":"dev","version":"3.7.2","run":0,"repo":"redhozr21/prics-neubrutalism-android","builtAt":"2026-11-03T09:00:00.000Z","channel":"tv"};
