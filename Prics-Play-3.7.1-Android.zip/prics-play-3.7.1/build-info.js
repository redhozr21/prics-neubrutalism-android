window.MURIEL_BUILD = {"sha":"dev","version":"3.7.1","run":0,"repo":"redhozr21/prics-neubrutalism-android","builtAt":"2026-11-03T08:20:00.000Z","channel":"tv"};
