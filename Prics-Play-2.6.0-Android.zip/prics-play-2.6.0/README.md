# Prics Play 2.6.0 — Mobile UI and Now Playing refresh

This source archive is the **2.6.0** update, based on the audited 2.5.0 source and the stable 2.3.3 application foundation.

## What changed in 2.6.0

- Rebuilt the mobile header with a larger left-aligned Prics Play brand, a matching profile avatar on the right, and a more balanced header height.
- Standardized the Search and provider shortcut cards so YouTube, YouTube Music and SoundCloud share the same border, radius, height and shadow geometry.
- Rebuilt mobile Now Playing as a single vertical layout: artwork, track information, progress, transport controls, output label, and compact lyrics card.
- Added a real mobile player header with back and actions controls; the actions menu invokes existing queue, edit-lyrics, share and download actions.
- Moved the original playbar controls into the Now Playing sheet only while it is open, then restores the exact original nodes to the mini-player when closed. No second audio engine or duplicate playback controls are created.
- Reworked full lyrics into a scrollable card between the compact track header and the existing progress/transport controls.
- Removed the legacy mobile cover-swipe and toolbar relocation behavior that conflicted with the new player layout.
- Preserved the Neubrutalism and Liquid Glass theme systems, integrations, About, profiles, storage, queue, playlist, favorites, and the original audio engine.

## Version and build

- `package.json` and `package-lock.json`: `2.6.0`
- Android Gradle fallback `versionName`: `2.6.0`
- Android application ID: `io.github.cloverscripts.muriel`
- Source archive: `Prics-Play-2.6.0-Android.zip`
- Use the existing repository `build-apk.yml` workflow. No additional workflow is required.

## Validation and installation

Automated source tests and the mobile bundle build must pass before release. A source-level test or successful APK build does not prove visual correctness, battery performance, Android install compatibility or signing-certificate compatibility. The Actions cache was previously observed empty; verify the APK signing certificate before installing over an existing app. Do not uninstall or clear app data to bypass a signature mismatch.
