window.MURIEL_BUILD = {"sha":"dev","version":"3.6.2","run":0,"repo":"redhozr21/prics-neubrutalism-android","builtAt":"2026-11-02T16:00:00.000Z","channel":""};
