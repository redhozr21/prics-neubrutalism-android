window.MURIEL_BUILD = {"sha":"dev","version":"3.6.0","run":0,"repo":"redhozr21/prics-neubrutalism-android","builtAt":"2026-11-02T15:30:00.000Z","channel":""};
