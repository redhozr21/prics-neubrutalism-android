// =====================================================================
// PRICS PLAY — SMART TV / ANDROID TV CONTROLLER & SPATIAL ENGINE
// 10-Foot Navigation, D-Pad Remote Control & TV Karaoke Overlay
// =====================================================================

(() => {
  'use strict';

  function isTVMode() {
    if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
    if (localStorage.getItem('prics_tv_mode') === 'true') return true;
    const ua = navigator.userAgent || '';
    return /PricsTV|Android TV|GoogleTV|SmartTV|Leanback|Large Screen|BRAVIA|AFTT|AFTM|Nexus Player/i.test(ua);
  }

  if (!isTVMode()) {
    return; // Leave standard mobile/desktop layout untouched
  }

  // Activate TV styling on html root
  const rootEl = document.documentElement;
  rootEl.classList.add('is-tv', 'is-desktop');
  rootEl.classList.remove('is-mobile');

  let currentView = 'home';
  let focusedEl = null;

  function safeEscape(str) {
    if (typeof str !== 'string') return '';
    return str.replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m]);
  }

  function getCore() {
    return window.MurielCore || null;
  }

  function setFocus(el) {
    if (!el) return;
    if (focusedEl && focusedEl !== el) {
      focusedEl.classList.remove('tv-focused');
    }
    focusedEl = el;
    el.classList.add('tv-focused');
    try {
      el.focus({ preventScroll: true });
    } catch (_) {
      el.focus();
    }
    // Ensure element is visible in view
    if (el.classList.contains('tv-card')) {
      el.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
    } else {
      el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }

  // =====================================================================
  // TV Layout Generator
  // =====================================================================
  function createTVLayout() {
    if (document.getElementById('tv-root')) return;

    const tvRoot = document.createElement('div');
    tvRoot.id = 'tv-root';
    tvRoot.innerHTML = `
      <!-- TV Sidebar Rail -->
      <aside class="tv-rail" aria-label="Smart TV Navigation">
        <div>
          <div class="tv-rail-brand">
            <div class="tv-rail-logo">
              <img src="assets/prics-pa-play.png" alt="Prics" onerror="this.outerHTML='P'">
            </div>
            <div class="tv-rail-title-group">
              <span class="tv-rail-title">Prics Play</span>
              <span class="tv-rail-badge">Smart TV Edition</span>
            </div>
          </div>
          <nav class="tv-rail-menu">
            <button type="button" class="tv-rail-item tv-focusable active" data-tv-tab="home" tabindex="0">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/></svg>
              <span>Beranda</span>
            </button>
            <button type="button" class="tv-rail-item tv-focusable" data-tv-tab="search" tabindex="0">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.5" y2="16.5"/></svg>
              <span>Pencarian</span>
            </button>
            <button type="button" class="tv-rail-item tv-focusable" data-tv-tab="library" tabindex="0">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M4 4v16M9 4v16M14 4v16M19 4v16"/></svg>
              <span>Koleksi</span>
            </button>
            <button type="button" class="tv-rail-item tv-focusable" data-tv-tab="karaoke" tabindex="0">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="22"/></svg>
              <span>Lirik TV</span>
            </button>
            <button type="button" class="tv-rail-item tv-focusable" data-tv-tab="settings" tabindex="0">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
              <span>Setelan</span>
            </button>
          </nav>
        </div>
        <div class="tv-rail-footer">
          <div class="tv-clock-pill" id="tv-clock">--:--</div>
          <div class="tv-fps-pill" id="tv-fps-indicator">120Hz Ultra</div>
        </div>
      </aside>

      <!-- TV Main Viewport -->
      <main class="tv-main" id="tv-main">
        <!-- Home View -->
        <section class="tv-view" id="tv-view-home">
          <!-- Spotlight Hero -->
          <div class="tv-spotlight" id="tv-spotlight">
            <img class="tv-spotlight-art" id="tv-spotlight-art" src="assets/prics-pa-play.png" alt="Spotlight Art">
            <div class="tv-spotlight-info">
              <span class="tv-spotlight-tag" id="tv-spotlight-tag">SEDANG DIPUTAR</span>
              <h1 class="tv-spotlight-title" id="tv-spotlight-title">Prics Play TV</h1>
              <p class="tv-spotlight-artist" id="tv-spotlight-artist">Pilih lagu untuk memulai hiburan di layar TV Anda</p>
              <div class="tv-spotlight-actions">
                <button type="button" class="tv-btn-primary tv-focusable" id="tv-btn-hero-play" tabindex="0">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                  <span>Putar Sekarang</span>
                </button>
                <button type="button" class="tv-btn-secondary tv-focusable" id="tv-btn-hero-lyrics" tabindex="0">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/></svg>
                  <span>Lirik TV (Karaoke)</span>
                </button>
              </div>
            </div>
          </div>

          <!-- Shelf 1: Terakhir Diputar -->
          <div class="tv-shelf" id="tv-shelf-recent-wrap">
            <div class="tv-shelf-header">
              <h2 class="tv-shelf-title">Terakhir Diputar</h2>
            </div>
            <div class="tv-shelf-scroll" id="tv-shelf-recent"></div>
          </div>

          <!-- Shelf 2: Lagu Disukai -->
          <div class="tv-shelf" id="tv-shelf-favorites-wrap">
            <div class="tv-shelf-header">
              <h2 class="tv-shelf-title">Lagu Disukai</h2>
            </div>
            <div class="tv-shelf-scroll" id="tv-shelf-favorites"></div>
          </div>

          <!-- Shelf 3: Playlist Kamu -->
          <div class="tv-shelf" id="tv-shelf-playlists-wrap">
            <div class="tv-shelf-header">
              <h2 class="tv-shelf-title">Playlist Kamu</h2>
            </div>
            <div class="tv-shelf-scroll" id="tv-shelf-playlists"></div>
          </div>
        </section>

        <!-- Search View -->
        <section class="tv-view hidden" id="tv-view-search">
          <div class="tv-search-header">
            <div class="tv-search-input-wrap tv-focusable" id="tv-search-input-box" tabindex="0">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.5" y2="16.5"/></svg>
              <input type="text" class="tv-search-input" id="tv-search-input" placeholder="Ketik judul lagu atau artis..." autocomplete="off">
            </div>
            <div class="tv-platform-pills">
              <button type="button" class="tv-platform-pill tv-focusable active" data-platform="ytmusic" tabindex="0">YouTube Music</button>
              <button type="button" class="tv-platform-pill tv-focusable" data-platform="youtube" tabindex="0">YouTube</button>
              <button type="button" class="tv-platform-pill tv-focusable" data-platform="soundcloud" tabindex="0">SoundCloud</button>
            </div>
          </div>
          <div class="tv-grid" id="tv-search-results"></div>
        </section>

        <!-- Collection View -->
        <section class="tv-view hidden" id="tv-view-library">
          <div class="tv-shelf-header">
            <h2 class="tv-shelf-title">Semua Playlist &amp; Koleksi</h2>
          </div>
          <div class="tv-grid" id="tv-library-grid"></div>
        </section>

        <!-- Settings View -->
        <section class="tv-view hidden" id="tv-view-settings">
          <div class="tv-settings-group">
            <h2 class="tv-settings-title">Kecepatan Refresh Layar (FPS / Hz)</h2>
            <div class="tv-settings-row">
              <div class="tv-setting-card tv-focusable" id="tv-set-fps-60" tabindex="0">
                <h3 class="tv-setting-card-title">60 Hz (Standar)</h3>
                <p class="tv-setting-card-desc">Kecepatan standar, paling hemat daya dan stabil untuk TV.</p>
              </div>
              <div class="tv-setting-card tv-focusable active" id="tv-set-fps-120" tabindex="0">
                <h3 class="tv-setting-card-title">120 Hz (Ultra Halus)</h3>
                <p class="tv-setting-card-desc">Animasi dan perpindahan kartu super mulus untuk Smart TV modern.</p>
              </div>
            </div>
          </div>

          <div class="tv-settings-group">
            <h2 class="tv-settings-title">Kualitas Audio Streaming</h2>
            <div class="tv-settings-row">
              <div class="tv-setting-card tv-focusable" id="tv-set-audio-low" tabindex="0">
                <h3 class="tv-setting-card-title">Hemat Kuota (~64 kbps)</h3>
                <p class="tv-setting-card-desc">Ringan dan cepat dimuat pada jaringan Wi-Fi lambat.</p>
              </div>
              <div class="tv-setting-card tv-focusable active" id="tv-set-audio-normal" tabindex="0">
                <h3 class="tv-setting-card-title">Normal / Standar (~128 kbps)</h3>
                <p class="tv-setting-card-desc">Keseimbangan terbaik antara kualitas suara jernih dan kecepatan.</p>
              </div>
              <div class="tv-setting-card tv-focusable" id="tv-set-audio-high" tabindex="0">
                <h3 class="tv-setting-card-title">Kualitas Tinggi (~160 kbps)</h3>
                <p class="tv-setting-card-desc">Detail instrumen dan bass maksimal untuk soundbar / home theater.</p>
              </div>
            </div>
          </div>

          <div class="tv-settings-group">
            <h2 class="tv-settings-title">Mode Tampilan</h2>
            <div class="tv-settings-row">
              <div class="tv-setting-card tv-focusable" id="tv-set-theme-light" tabindex="0">
                <h3 class="tv-setting-card-title">Mode Terang (Warm Cream)</h3>
                <p class="tv-setting-card-desc">Warna Neubrutalism khas Prics Play yang ceria.</p>
              </div>
              <div class="tv-setting-card tv-focusable" id="tv-set-theme-dark" tabindex="0">
                <h3 class="tv-setting-card-title">Mode Malam (Dark Cinema)</h3>
                <p class="tv-setting-card-desc">Latar belakang gelap pekat yang nyaman di mata saat ruangan redup.</p>
              </div>
            </div>
          </div>

          <div class="tv-settings-group">
            <h2 class="tv-settings-title">Tentang Prics Play Smart TV</h2>
            <div class="tv-settings-row">
              <div class="tv-setting-card">
                <h3 class="tv-setting-card-title">Prics Play Smart TV Edition v3.6.0</h3>
                <p class="tv-setting-card-desc">Dikembangkan khusus untuk pengalaman 10-kaki di TV Anda dengan remote D-pad.</p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <!-- Persistent Bottom TV Player Bar -->
      <footer class="tv-player-bar" id="tv-player-bar">
        <div class="tv-player-left">
          <img class="tv-player-art" id="tv-bar-art" src="assets/prics-pa-play.png" alt="Now Playing">
          <div class="tv-player-meta">
            <h4 class="tv-player-title" id="tv-bar-title">Tidak ada lagu diputar</h4>
            <span class="tv-player-artist" id="tv-bar-artist">Pilih lagu dari beranda atau pencarian</span>
          </div>
        </div>
        <div class="tv-player-controls">
          <button type="button" class="tv-control-btn tv-focusable" id="tv-btn-prev" title="Sebelumnya" tabindex="0">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><polygon points="19 20 9 12 19 4 19 20"/><line x1="5" y1="19" x2="5" y2="5" stroke="currentColor" stroke-width="2.5"/></svg>
          </button>
          <button type="button" class="tv-control-btn tv-control-btn-play tv-focusable" id="tv-btn-play" title="Putar / Jeda" tabindex="0">
            <svg id="tv-icon-play" width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            <svg id="tv-icon-pause" class="hidden" width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
          </button>
          <button type="button" class="tv-control-btn tv-focusable" id="tv-btn-next" title="Berikutnya" tabindex="0">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 4 15 12 5 20 5 4"/><line x1="19" y1="5" x2="19" y2="19" stroke="currentColor" stroke-width="2.5"/></svg>
          </button>
          <button type="button" class="tv-control-btn tv-focusable" id="tv-btn-karaoke-toggle" title="Buka Lirik Karaoke" tabindex="0">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="22"/></svg>
          </button>
        </div>
      </footer>

      <!-- Fullscreen TV Karaoke Overlay -->
      <div class="tv-karaoke-overlay hidden" id="tv-karaoke-overlay">
        <div class="tvk-back-hint">Tekan [Kembali] pada remote untuk menutup</div>
        <div class="tvk-left-stage">
          <img class="tvk-disc-art" id="tvk-disc-art" src="assets/prics-pa-play.png" alt="Vinyl Disc">
          <h2 class="tvk-track-title" id="tvk-title">Judul Lagu</h2>
          <span class="tvk-track-artist" id="tvk-artist">Nama Artis</span>
        </div>
        <div class="tvk-right-lyrics" id="tvk-lyrics-box">
          <div class="tvk-line active">Memuat lirik lagu...</div>
        </div>
      </div>
    `;

    document.body.appendChild(tvRoot);

    // Initial focus on Home menu item
    const homeBtn = tvRoot.querySelector('[data-tv-tab="home"]');
    if (homeBtn) setFocus(homeBtn);

    initClock();
    setupTabSwitching();
    setupPlaybackControls();
    setupSettingsCards();
    setupSearch();
    hydrateHomeContent();
  }

  // =====================================================================
  // Clock and FPS indicator
  // =====================================================================
  function initClock() {
    const clockEl = document.getElementById('tv-clock');
    const updateTime = () => {
      if (!clockEl) return;
      const now = new Date();
      const h = String(now.getHours()).padStart(2, '0');
      const m = String(now.getMinutes()).padStart(2, '0');
      clockEl.textContent = `${h}:${m}`;
    };
    updateTime();
    setInterval(updateTime, 30000);

    const fpsEl = document.getElementById('tv-fps-indicator');
    if (fpsEl) {
      const prefHz = localStorage.getItem('prics_preferred_fps') || '120';
      fpsEl.textContent = prefHz === '60' ? '60Hz Hemat' : '120Hz Ultra';
    }
  }

  // =====================================================================
  // Tab Switching
  // =====================================================================
  function switchTVTab(tabName) {
    if (currentView === tabName && tabName !== 'karaoke') return;

    if (tabName === 'karaoke') {
      openTVKaraoke();
      return;
    }

    currentView = tabName;

    // Update rail active state
    document.querySelectorAll('.tv-rail-item').forEach((item) => {
      const isActive = item.dataset.tvTab === tabName;
      item.classList.toggle('active', isActive);
    });

    // Show active view
    const views = ['home', 'search', 'library', 'settings'];
    views.forEach((v) => {
      const el = document.getElementById(`tv-view-${v}`);
      if (el) el.classList.toggle('hidden', v !== tabName);
    });

    // Refresh view content
    if (tabName === 'home') hydrateHomeContent();
    else if (tabName === 'library') hydrateLibraryContent();

    // Auto-focus first element in the view
    requestAnimationFrame(() => {
      const activeViewEl = document.getElementById(`tv-view-${tabName}`);
      if (activeViewEl) {
        const firstFocusable = activeViewEl.querySelector('.tv-focusable');
        if (firstFocusable) setFocus(firstFocusable);
      }
    });
  }

  function setupTabSwitching() {
    document.querySelectorAll('.tv-rail-item').forEach((item) => {
      item.addEventListener('click', () => {
        const tab = item.dataset.tvTab;
        if (tab) switchTVTab(tab);
      });
    });
  }

  // =====================================================================
  // TV Karaoke Fullscreen Mode
  // =====================================================================
  let isKaraokeOpen = false;

  function openTVKaraoke() {
    const overlay = document.getElementById('tv-karaoke-overlay');
    if (!overlay) return;
    overlay.classList.remove('hidden');
    isKaraokeOpen = true;

    // Sync current track
    syncNowPlayingUI();
    syncLyrics();

    // Let root show playing state for disc animation
    const core = getCore();
    if (core && core.audio && !core.audio.paused) {
      document.documentElement.classList.add('playing');
    }
  }

  function closeTVKaraoke() {
    const overlay = document.getElementById('tv-karaoke-overlay');
    if (!overlay) return;
    overlay.classList.add('hidden');
    isKaraokeOpen = false;

    // Return focus to karaoke rail button
    const karaokeBtn = document.querySelector('.tv-rail-item[data-tv-tab="karaoke"]');
    if (karaokeBtn) setFocus(karaokeBtn);
  }

  // =====================================================================
  // Hydrate Shelves & Cards
  // =====================================================================
  function createTVCard(track, tracksList, index) {
    const card = document.createElement('div');
    card.className = 'tv-card tv-focusable';
    card.tabIndex = 0;

    let thumb = 'assets/prics-pa-play.png';
    const core = getCore();
    if (core && typeof core.thumb === 'function') {
      thumb = core.thumb(track) || thumb;
    } else if (track.thumbnail) {
      thumb = track.thumbnail;
    }

    const title = safeEscape(track.title || 'Unknown Track');
    const artist = safeEscape(track.artist || 'Unknown Artist');

    card.innerHTML = `
      <img class="tv-card-art" src="${thumb}" alt="${title}" loading="lazy" decoding="async">
      <h3 class="tv-card-title">${title}</h3>
      <span class="tv-card-desc">${artist}</span>
    `;

    card.addEventListener('click', () => {
      if (core && typeof core.playTrack === 'function') {
        core.playTrack(track, tracksList, index);
      }
    });

    return card;
  }

  function hydrateHomeContent() {
    const core = getCore();
    if (!core || !core.state) return;

    // 1. Shelf: Terakhir Diputar (History)
    const recentShelf = document.getElementById('tv-shelf-recent');
    const recentWrap = document.getElementById('tv-shelf-recent-wrap');
    if (recentShelf && recentWrap) {
      recentShelf.replaceChildren();
      const history = Array.isArray(core.state.history) ? core.state.history.slice(0, 15) : [];
      if (!history.length) {
        recentWrap.classList.add('hidden');
      } else {
        recentWrap.classList.remove('hidden');
        history.forEach((track, idx) => {
          recentShelf.appendChild(createTVCard(track, history, idx));
        });
      }
    }

    // 2. Shelf: Lagu Disukai (Favorites)
    const favShelf = document.getElementById('tv-shelf-favorites');
    const favWrap = document.getElementById('tv-shelf-favorites-wrap');
    if (favShelf && favWrap) {
      favShelf.replaceChildren();
      const favs = Array.isArray(core.state.favorites) ? core.state.favorites.slice(0, 15) : [];
      if (!favs.length) {
        favWrap.classList.add('hidden');
      } else {
        favWrap.classList.remove('hidden');
        favs.forEach((track, idx) => {
          favShelf.appendChild(createTVCard(track, favs, idx));
        });
      }
    }

    // 3. Shelf: Playlist Kamu
    const plShelf = document.getElementById('tv-shelf-playlists');
    const plWrap = document.getElementById('tv-shelf-playlists-wrap');
    if (plShelf && plWrap) {
      plShelf.replaceChildren();
      const playlists = Array.isArray(core.state.playlists) ? core.state.playlists : [];
      if (!playlists.length) {
        plWrap.classList.add('hidden');
      } else {
        plWrap.classList.remove('hidden');
        playlists.forEach((pl) => {
          const card = document.createElement('div');
          card.className = 'tv-card tv-focusable';
          card.tabIndex = 0;
          const firstTrack = pl.tracks && pl.tracks[0];
          const thumb = firstTrack && core.thumb(firstTrack) ? core.thumb(firstTrack) : 'assets/prics-pa-play.png';
          card.innerHTML = `
            <img class="tv-card-art" src="${thumb}" alt="${safeEscape(pl.name)}" loading="lazy">
            <h3 class="tv-card-title">${safeEscape(pl.name)}</h3>
            <span class="tv-card-desc">${(pl.tracks && pl.tracks.length) || 0} lagu</span>
          `;
          card.addEventListener('click', () => {
            if (pl.tracks && pl.tracks.length && core.playTrack) {
              core.playTrack(pl.tracks[0], pl.tracks, 0);
            }
          });
          plShelf.appendChild(card);
        });
      }
    }

    // Spotlight Sync
    syncSpotlightHero();
  }

  function hydrateLibraryContent() {
    const core = getCore();
    const grid = document.getElementById('tv-library-grid');
    if (!core || !core.state || !grid) return;

    grid.replaceChildren();
    const playlists = Array.isArray(core.state.playlists) ? core.state.playlists : [];
    playlists.forEach((pl) => {
      const card = document.createElement('div');
      card.className = 'tv-card tv-focusable';
      card.tabIndex = 0;
      const firstTrack = pl.tracks && pl.tracks[0];
      const thumb = firstTrack && core.thumb(firstTrack) ? core.thumb(firstTrack) : 'assets/prics-pa-play.png';
      card.innerHTML = `
        <img class="tv-card-art" src="${thumb}" alt="${safeEscape(pl.name)}" loading="lazy">
        <h3 class="tv-card-title">${safeEscape(pl.name)}</h3>
        <span class="tv-card-desc">${(pl.tracks && pl.tracks.length) || 0} lagu</span>
      `;
      card.addEventListener('click', () => {
        if (pl.tracks && pl.tracks.length && core.playTrack) {
          core.playTrack(pl.tracks[0], pl.tracks, 0);
        }
      });
      grid.appendChild(card);
    });
  }

  // =====================================================================
  // Spotlight Hero Synchronization
  // =====================================================================
  function syncSpotlightHero() {
    const core = getCore();
    const track = (core && core.state && core.state.currentTrack) ||
                  (core && core.state && core.state.history && core.state.history[0]) ||
                  null;

    const artEl = document.getElementById('tv-spotlight-art');
    const titleEl = document.getElementById('tv-spotlight-title');
    const artistEl = document.getElementById('tv-spotlight-artist');
    const tagEl = document.getElementById('tv-spotlight-tag');

    if (!track) {
      if (titleEl) titleEl.textContent = 'Prics Play TV';
      if (artistEl) artistEl.textContent = 'Pilih lagu untuk memulai hiburan di layar TV Anda';
      return;
    }

    if (tagEl) {
      const isCurrent = core.state.currentTrack && core.isSameTrack && core.isSameTrack(core.state.currentTrack, track);
      tagEl.textContent = isCurrent ? 'SEDANG DIPUTAR' : 'REKOMENDASI UNTUKMU';
    }
    if (artEl) {
      const thumb = (core.thumb && core.thumb(track)) || track.thumbnail || 'assets/prics-pa-play.png';
      artEl.src = thumb;
    }
    if (titleEl) titleEl.textContent = track.title || 'Unknown Track';
    if (artistEl) artistEl.textContent = track.artist || 'Unknown Artist';
  }

  // =====================================================================
  // Bottom Player Bar & Now Playing Synchronization
  // =====================================================================
  function syncNowPlayingUI() {
    const core = getCore();
    if (!core || !core.state) return;

    const track = core.state.currentTrack;
    const isPlaying = core.audio && !core.audio.paused;

    document.documentElement.classList.toggle('playing', !!isPlaying);

    // Bottom Bar
    const barArt = document.getElementById('tv-bar-art');
    const barTitle = document.getElementById('tv-bar-title');
    const barArtist = document.getElementById('tv-bar-artist');
    const iconPlay = document.getElementById('tv-icon-play');
    const iconPause = document.getElementById('tv-icon-pause');

    if (iconPlay && iconPause) {
      iconPlay.classList.toggle('hidden', isPlaying);
      iconPause.classList.toggle('hidden', !isPlaying);
    }

    if (track) {
      const thumb = (core.thumb && core.thumb(track)) || track.thumbnail || 'assets/prics-pa-play.png';
      if (barArt) barArt.src = thumb;
      if (barTitle) barTitle.textContent = track.title || 'Unknown Track';
      if (barArtist) barArtist.textContent = track.artist || 'Unknown Artist';

      // Fullscreen Karaoke Disc
      const tvkDisc = document.getElementById('tvk-disc-art');
      const tvkTitle = document.getElementById('tvk-title');
      const tvkArtist = document.getElementById('tvk-artist');
      if (tvkDisc) tvkDisc.src = thumb;
      if (tvkTitle) tvkTitle.textContent = track.title || 'Unknown Track';
      if (tvkArtist) tvkArtist.textContent = track.artist || 'Unknown Artist';
    }

    syncSpotlightHero();
  }

  function setupPlaybackControls() {
    const core = getCore();

    const btnPlay = document.getElementById('tv-btn-play');
    const btnPrev = document.getElementById('tv-btn-prev');
    const btnNext = document.getElementById('tv-btn-next');
    const btnKaraokeToggle = document.getElementById('tv-btn-karaoke-toggle');

    const heroPlay = document.getElementById('tv-btn-hero-play');
    const heroLyrics = document.getElementById('tv-btn-hero-lyrics');

    if (btnPlay) {
      btnPlay.addEventListener('click', () => {
        if (core && core.togglePlay) core.togglePlay();
      });
    }
    if (btnPrev) {
      btnPrev.addEventListener('click', () => {
        if (core && core.prev) core.prev();
      });
    }
    if (btnNext) {
      btnNext.addEventListener('click', () => {
        if (core && core.next) core.next();
      });
    }
    if (btnKaraokeToggle) {
      btnKaraokeToggle.addEventListener('click', openTVKaraoke);
    }
    if (heroPlay) {
      heroPlay.addEventListener('click', () => {
        if (core && core.togglePlay) core.togglePlay();
      });
    }
    if (heroLyrics) {
      heroLyrics.addEventListener('click', openTVKaraoke);
    }

    // Listen to native audio events
    const audio = document.querySelector('audio');
    if (audio) {
      audio.addEventListener('play', syncNowPlayingUI);
      audio.addEventListener('pause', syncNowPlayingUI);
      audio.addEventListener('timeupdate', () => {
        if (isKaraokeOpen) syncLyrics();
      });
    }

    window.addEventListener('muriel:track', syncNowPlayingUI);
    window.addEventListener('muriel:library', hydrateHomeContent);
  }

  // =====================================================================
  // Synced Lyrics in TV Karaoke
  // =====================================================================
  function syncLyrics() {
    const box = document.getElementById('tvk-lyrics-box');
    if (!box) return;

    // Check if app.js lyricsContainer has rendered lines
    const mainLyrics = document.getElementById('lyrics-container');
    if (!mainLyrics || !mainLyrics.children.length) {
      box.innerHTML = '<div class="tvk-line active">Menikmati alunan musik...</div>';
      return;
    }

    const lines = Array.from(mainLyrics.querySelectorAll('.lyric-line, .synced-line'));
    if (!lines.length) return;

    box.replaceChildren();
    lines.forEach((l) => {
      const lineEl = document.createElement('div');
      lineEl.className = 'tvk-line' + (l.classList.contains('active') ? ' active' : '');
      lineEl.textContent = l.textContent || '';
      box.appendChild(lineEl);
      if (l.classList.contains('active')) {
        lineEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    });
  }

  // =====================================================================
  // Settings Options Management
  // =====================================================================
  function setupSettingsCards() {
    // 1. Refresh Rate / FPS
    const set60 = document.getElementById('tv-set-fps-60');
    const set120 = document.getElementById('tv-set-fps-120');
    const prefHz = localStorage.getItem('prics_preferred_fps') || '120';

    const updateHzUI = (hz) => {
      if (set60) set60.classList.toggle('active', hz === '60');
      if (set120) set120.classList.toggle('active', hz === '120');
      const fpsEl = document.getElementById('tv-fps-indicator');
      if (fpsEl) fpsEl.textContent = hz === '60' ? '60Hz Hemat' : '120Hz Ultra';
    };

    updateHzUI(prefHz);

    const applyHz = (hz) => {
      localStorage.setItem('prics_preferred_fps', hz);
      updateHzUI(hz);
      if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.DisplayRefreshRate) {
        window.Capacitor.Plugins.DisplayRefreshRate.setPreferredRefreshRate({ hz: parseInt(hz, 10) }).catch(() => {});
      }
    };

    if (set60) set60.addEventListener('click', () => applyHz('60'));
    if (set120) set120.addEventListener('click', () => applyHz('120'));

    // 2. Audio Quality Streaming
    const qLow = document.getElementById('tv-set-audio-low');
    const qNorm = document.getElementById('tv-set-audio-normal');
    const qHigh = document.getElementById('tv-set-audio-high');
    const curQ = localStorage.getItem('prics_audio_quality') || 'normal';

    const updateAudioUI = (q) => {
      if (qLow) qLow.classList.toggle('active', q === 'low');
      if (qNorm) qNorm.classList.toggle('active', q === 'normal');
      if (qHigh) qHigh.classList.toggle('active', q === 'high');
    };
    updateAudioUI(curQ);

    const applyAudioQ = (q) => {
      localStorage.setItem('prics_audio_quality', q);
      updateAudioUI(q);
      const core = getCore();
      if (core && core.toast) core.toast(`Kualitas audio streaming: ${q.toUpperCase()}`, 'info');
    };

    if (qLow) qLow.addEventListener('click', () => applyAudioQ('low'));
    if (qNorm) qNorm.addEventListener('click', () => applyAudioQ('normal'));
    if (qHigh) qHigh.addEventListener('click', () => applyAudioQ('high'));

    // 3. Theme Light / Dark
    const thLight = document.getElementById('tv-set-theme-light');
    const thDark = document.getElementById('tv-set-theme-dark');

    const updateThemeUI = (isDark) => {
      if (thLight) thLight.classList.toggle('active', !isDark);
      if (thDark) thDark.classList.toggle('active', isDark);
      document.body.classList.toggle('theme-dark', isDark);
    };

    const isDark = document.body.classList.contains('theme-dark') || localStorage.getItem('muriel_theme_mode') === 'dark';
    updateThemeUI(isDark);

    if (thLight) {
      thLight.addEventListener('click', () => {
        localStorage.setItem('muriel_theme_mode', 'light');
        updateThemeUI(false);
      });
    }
    if (thDark) {
      thDark.addEventListener('click', () => {
        localStorage.setItem('muriel_theme_mode', 'dark');
        updateThemeUI(true);
      });
    }
  }

  // =====================================================================
  // TV Search Handling
  // =====================================================================
  function setupSearch() {
    const input = document.getElementById('tv-search-input');
    const resultsGrid = document.getElementById('tv-search-results');
    if (!input || !resultsGrid) return;

    let debounceTimer = null;
    input.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        const query = input.value.trim();
        if (!query) {
          resultsGrid.replaceChildren();
          return;
        }

        // Bridge search with core app.js input
        const mainInput = document.getElementById('search-input');
        if (mainInput) {
          mainInput.value = query;
          mainInput.dispatchEvent(new Event('input', { bubbles: true }));
          mainInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
        }

        // Poll search results from core state
        setTimeout(() => {
          const core = getCore();
          if (core && core.state && Array.isArray(core.state.searchResults)) {
            resultsGrid.replaceChildren();
            core.state.searchResults.forEach((track, idx) => {
              resultsGrid.appendChild(createTVCard(track, core.state.searchResults, idx));
            });
          }
        }, 800);
      }, 500);
    });
  }

  // =====================================================================
  // D-PAD REMOTE CONTROL SPATIAL NAVIGATION ENGINE
  // Up, Down, Left, Right, OK/Enter, Back, Media Controls
  // =====================================================================
  function initRemoteNavigation() {
    window.addEventListener('keydown', (e) => {
      const key = e.key;
      const code = e.keyCode;

      // 1. Back Button Handling
      if (key === 'Escape' || key === 'GoBack' || code === 27 || code === 8 || code === 10009 || code === 461) {
        if (isKaraokeOpen) {
          e.preventDefault();
          closeTVKaraoke();
          return;
        }
        if (currentView !== 'home') {
          e.preventDefault();
          switchTVTab('home');
          return;
        }
        // Jump focus to Rail
        const activeRail = document.querySelector('.tv-rail-item.active') || document.querySelector('.tv-rail-item');
        if (activeRail) {
          e.preventDefault();
          setFocus(activeRail);
          return;
        }
      }

      // 2. Media Keys Handling
      const core = getCore();
      if (key === 'MediaPlayPause' || code === 179) {
        e.preventDefault();
        if (core && core.togglePlay) core.togglePlay();
        return;
      }
      if (key === 'MediaTrackNext' || code === 176) {
        e.preventDefault();
        if (core && core.next) core.next();
        return;
      }
      if (key === 'MediaTrackPrevious' || code === 177) {
        e.preventDefault();
        if (core && core.prev) core.prev();
        return;
      }

      // 3. Directional D-Pad Spatial Navigation
      const isUp = key === 'ArrowUp' || code === 38;
      const isDown = key === 'ArrowDown' || code === 40;
      const isLeft = key === 'ArrowLeft' || code === 37;
      const isRight = key === 'ArrowRight' || code === 39;
      const isEnter = key === 'Enter' || code === 13 || key === 'NumpadEnter';

      if (!isUp && !isDown && !isLeft && !isRight && !isEnter) return;

      const current = focusedEl || document.activeElement;
      if (!current) {
        const first = document.querySelector('.tv-focusable');
        if (first) setFocus(first);
        return;
      }

      // Handle Enter
      if (isEnter) {
        current.click();
        return;
      }

      // Spatial Movement:
      e.preventDefault();

      // Case A: Currently on Left Rail
      if (current.classList.contains('tv-rail-item')) {
        const railItems = Array.from(document.querySelectorAll('.tv-rail-item'));
        const idx = railItems.indexOf(current);

        if (isDown && idx < railItems.length - 1) {
          setFocus(railItems[idx + 1]);
        } else if (isUp && idx > 0) {
          setFocus(railItems[idx - 1]);
        } else if (isRight) {
          // Move from Rail to active View's first interactive element
          const activeView = document.getElementById(`tv-view-${currentView}`);
          if (activeView) {
            const firstInView = activeView.querySelector('.tv-focusable');
            if (firstInView) setFocus(firstInView);
          }
        }
        return;
      }

      // Case B: Inside a Horizontal Shelf
      const currentShelf = current.closest('.tv-shelf-scroll');
      if (currentShelf) {
        const cards = Array.from(currentShelf.querySelectorAll('.tv-card'));
        const idx = cards.indexOf(current);

        if (isRight && idx < cards.length - 1) {
          setFocus(cards[idx + 1]);
        } else if (isLeft) {
          if (idx > 0) {
            setFocus(cards[idx - 1]);
          } else {
            // Jump back to Left Rail
            const railItem = document.querySelector('.tv-rail-item.active') || document.querySelector('.tv-rail-item');
            if (railItem) setFocus(railItem);
          }
        } else if (isDown) {
          // Jump to next shelf below, or to bottom player bar
          const shelves = Array.from(document.querySelectorAll('#tv-view-home .tv-shelf:not(.hidden) .tv-shelf-scroll'));
          const sIdx = shelves.indexOf(currentShelf);
          if (sIdx < shelves.length - 1) {
            const nextShelf = shelves[sIdx + 1];
            const nextCards = nextShelf.querySelectorAll('.tv-card');
            const target = nextCards[Math.min(idx, nextCards.length - 1)] || nextCards[0];
            if (target) setFocus(target);
          } else {
            // Move to Bottom Player Bar
            const playBtn = document.getElementById('tv-btn-play');
            if (playBtn) setFocus(playBtn);
          }
        } else if (isUp) {
          // Jump to shelf above, or to Spotlight buttons
          const shelves = Array.from(document.querySelectorAll('#tv-view-home .tv-shelf:not(.hidden) .tv-shelf-scroll'));
          const sIdx = shelves.indexOf(currentShelf);
          if (sIdx > 0) {
            const prevShelf = shelves[sIdx - 1];
            const prevCards = prevShelf.querySelectorAll('.tv-card');
            const target = prevCards[Math.min(idx, prevCards.length - 1)] || prevCards[0];
            if (target) setFocus(target);
          } else {
            const heroBtn = document.getElementById('tv-btn-hero-play');
            if (heroBtn) setFocus(heroBtn);
          }
        }
        return;
      }

      // Case C: Inside Hero Spotlight
      if (current.id === 'tv-btn-hero-play' || current.id === 'tv-btn-hero-lyrics') {
        if (isLeft) {
          if (current.id === 'tv-btn-hero-lyrics') {
            setFocus(document.getElementById('tv-btn-hero-play'));
          } else {
            const railItem = document.querySelector('.tv-rail-item.active');
            if (railItem) setFocus(railItem);
          }
        } else if (isRight && current.id === 'tv-btn-hero-play') {
          setFocus(document.getElementById('tv-btn-hero-lyrics'));
        } else if (isDown) {
          const firstShelf = document.querySelector('#tv-view-home .tv-shelf:not(.hidden) .tv-shelf-scroll');
          if (firstShelf) {
            const firstCard = firstShelf.querySelector('.tv-card');
            if (firstCard) setFocus(firstCard);
          }
        }
        return;
      }

      // Case D: Inside Bottom Player Bar
      if (current.closest('.tv-player-bar')) {
        const barBtns = Array.from(document.querySelectorAll('.tv-player-bar .tv-control-btn'));
        const idx = barBtns.indexOf(current);
        if (isRight && idx < barBtns.length - 1) {
          setFocus(barBtns[idx + 1]);
        } else if (isLeft) {
          if (idx > 0) setFocus(barBtns[idx - 1]);
          else {
            const railItem = document.querySelector('.tv-rail-item.active');
            if (railItem) setFocus(railItem);
          }
        } else if (isUp) {
          // Jump back up to the active view's last cards or elements
          const activeCards = document.querySelectorAll('#tv-view-home .tv-shelf:not(.hidden) .tv-card');
          if (activeCards.length) {
            setFocus(activeCards[activeCards.length - 1]);
          } else {
            const railItem = document.querySelector('.tv-rail-item.active');
            if (railItem) setFocus(railItem);
          }
        }
        return;
      }

      // Case E: Grid View (Search or Library) or Settings Cards
      const focusables = Array.from(document.querySelectorAll(`#tv-view-${currentView} .tv-focusable`));
      const idx = focusables.indexOf(current);
      if (idx !== -1) {
        if (isRight && idx < focusables.length - 1) setFocus(focusables[idx + 1]);
        else if (isLeft) {
          if (idx > 0) setFocus(focusables[idx - 1]);
          else {
            const railItem = document.querySelector('.tv-rail-item.active');
            if (railItem) setFocus(railItem);
          }
        } else if (isDown && idx + 4 < focusables.length) {
          setFocus(focusables[idx + 4]);
        } else if (isUp && idx - 4 >= 0) {
          setFocus(focusables[idx - 4]);
        }
      }
    });
  }

  // =====================================================================
  // Initialization Lifecycle
  // =====================================================================
  function boot() {
    createTVLayout();
    initRemoteNavigation();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  // Also hook after window load to ensure MurielCore is ready
  window.addEventListener('load', () => {
    hydrateHomeContent();
    syncNowPlayingUI();
  });

})();
