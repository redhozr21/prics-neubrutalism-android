package io.github.cloverscripts.muriel;

import android.app.UiModeManager;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    static {
        try {
            // Prioritize IPv4 on Wi-Fi dual-stack networks (prevents DNS and TCP connection hangs
            // on ISPs like IndiHome/Biznet where broken IPv6 routes drop Google/YouTube CDN packets)
            System.setProperty("java.net.preferIPv4Stack", "true");
            System.setProperty("java.net.preferIPv6Addresses", "false");
            System.setProperty("http.keepAlive", "true");
            System.setProperty("http.maxConnections", "10");
        } catch (Throwable ignored) {}
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // plugins that live in the app itself (not in an npm package) are registered by hand
        registerPlugin(MediaControlsPlugin.class);
        registerPlugin(ExternalUrlPlugin.class);
        registerPlugin(PricsUpdatePlugin.class);
        registerPlugin(DisplayRefreshRatePlugin.class);
        super.onCreate(savedInstanceState);

        try {
            boolean isTelevision = isTVDevice();
            WebView webView = getBridge().getWebView();
            if (webView != null) {
                WebSettings settings = webView.getSettings();
                String ua = settings.getUserAgentString();
                if (isTelevision && !ua.contains("PricsTV")) {
                    settings.setUserAgentString(ua + " PricsTV/1.0");
                }
            }
        } catch (Throwable ignored) {}
    }

    private boolean isTVDevice() {
        try {
            UiModeManager uiModeManager = (UiModeManager) getSystemService(UI_MODE_SERVICE);
            if (uiModeManager != null && uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION) {
                return true;
            }
            return getPackageManager().hasSystemFeature(PackageManager.FEATURE_LEANBACK);
        } catch (Throwable ignored) {
            return false;
        }
    }
}
