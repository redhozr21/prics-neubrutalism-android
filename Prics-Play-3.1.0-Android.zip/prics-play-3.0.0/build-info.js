window.MURIEL_BUILD = {"sha":"dev","version":"3.1.0","run":0,"repo":"redhozr21/prics-neubrutalism-android","builtAt":"2026-11-01T13:51:00.000Z","channel":""};
