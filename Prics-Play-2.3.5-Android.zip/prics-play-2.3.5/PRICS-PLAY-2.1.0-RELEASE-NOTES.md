# Prics Play 2.1.0 — Release Notes

## Changes

- Added a persistent mobile streaming-quality preference: Data Saver, Low, Normal, High, Very High, and Automatic.
- Source selection now chooses the closest supported YouTube Opus rendition at or below the requested target when available, and chooses an available HLS audio rendition as a fallback.
- SoundCloud rendition selection uses explicit bitrate metadata only when the provider exposes it; otherwise the existing source preference is preserved.
- Added theoretical per-hour data estimates and a last-resolved-source bitrate status to mobile Playback settings.
- Removed the automatic battery-optimization exemption prompt from the `playing` event. Users can still request the exemption manually from Settings → Tracks → Playback.
- Limited mobile prefetch to the immediate next track and disabled speculative prefetch in Data Saver mode.
- Released the Wi-Fi lock when playback is from the cached file, retaining the CPU wake lock needed for background playback and using the Wi-Fi lock while a track is loading.
- Bumped package, lockfile, and default Android version metadata to 2.1.0 without changing the application ID.

## Important limitations

- The quality values are target bitrates, not guarantees. Providers expose a limited set of renditions; for example, a 24 kbps target may resolve to a higher minimum available source, and 320 kbps may resolve to the provider's maximum available rendition.
- No on-device transcoding was added. If a provider does not expose bitrate metadata, the app reports that the actual bitrate could not be verified.
- Existing cached songs retain their existing file quality. The selected preference applies when a song must be resolved/downloaded again.
- Per-hour figures are theoretical estimates at the target bitrate and exclude protocol overhead and metadata/artwork requests.
- Physical-device background playback, battery usage, and data usage still require testing on the target Android phone.
