# GitHub Actions Build Checklist — Prics Play 2.3.4

1. Keep the currently installed app and its data. Do not uninstall or clear storage.
2. Upload `Prics-Play-2.3.4-Rebuilt-From-2.3.3-Android.zip` to the repository root as `Prics-Play-2.3.4-Android.zip` (or replace the existing source archive only after keeping a backup).
3. In GitHub → Actions, run **Build Prics Play Android (debug artifact)** with input version `2.3.4`.
4. If the workflow reports that the debug signing key was not restored, stop. Do not remove the cache guard and do not generate a new keystore. Restore the original 2.3.3 keystore securely first.
5. Inspect the `SHA256:` fingerprint printed by the workflow. Compare it with the certificate on the 2.3.3 APK. The new APK must match the installed certificate exactly.
6. Download the workflow artifact and verify `Prics-Play.apk.sha256` before copying/installing it.
7. Only after the signing fingerprint matches, install the APK over 2.3.3. Keep the old app installed until the update is confirmed working.

The source ZIP has been validated, but the APK has not yet been built in this environment. The Actions workflow is responsible for the actual bundle, Gradle build and APK artifact.
