# Prics Play 2.3.4 — Rebuild from 2.3.3 Baseline

**Base:** Prics Play 2.3.3 source archive  
**Target:** 2.3.4  
**Scope:** restore the known-good 2.3.3 application core and safely reapply the coral Now Playing / lyrics UI.

## What changed

1. Recreated the 2.3.4 source tree from the 2.3.3 source archive, rather than continuing from the previous 2.3.4 tree.
2. Kept `app.js`, `mobile/build.mjs`, `mobile/bridge.js`, `mobile/neubrutalism.js`, and Android `PlaybackService.java` byte-for-byte identical to 2.3.3. A regression test pins their SHA-256 hashes.
3. Reapplied the coral Now Playing design, real playback controls, short lyric preview and expandable full-lyrics mode from the previous 2.3.4 work.
4. Changed the new Now Playing UI initialization to wait for `muriel:ready`. `app.js` dispatches this event after its async initialization has created the app core and bound the main controls. The UI layer no longer reparents player controls before that point.
5. Wrapped the optional Now Playing UI initialization in an error boundary. If that presentation layer fails, it logs the error rather than interrupting the already-initialized player core.
6. Kept the 2.3.3 mobile performance work, Settings cleanup, integrations, theme editor, profiles, storage, About, foreground playback service and data paths.
7. Bumped package and Android version metadata to 2.3.4. Application ID remains `io.github.cloverscripts.muriel`.

## Signing workflow hardening

Both Android debug workflows now use `actions/cache/restore@v4` and require the existing `prics-play-debug-keystore-v1` cache to be restored. They stop if the cache is missing. They no longer silently create and save a replacement debug keystore on a cache miss.

This prevents another accidental signing-key rotation. **It does not prove that the currently cached key matches the certificate on the user's installed 2.3.3 APK.** That fingerprint must still be compared before installing the rebuilt APK. The previously uploaded 2.3.4 debug APK had SHA-256 certificate fingerprint:

`49:C3:0B:E6:AC:38:9C:88:9A:73:1F:21:31:46:6E:8F:81:38:2C:C2:B1:26:71:A3:CA:CF:48:CC:E4:D4:4D:6A`

Do not assume this is the 2.3.3 certificate.

## Validation completed

| Check | Result |
|---|---:|
| JavaScript/MJS/CJS syntax | 133/133 pass |
| CSS parsing | 5/5 files, zero parse errors |
| GitHub Actions YAML parsing | 2/2 pass |
| AndroidManifest.xml and Info.plist | 2/2 parse successfully |
| Node test suite excluding Electron-only `library-import.test.js` | 340/340 pass |
| Existing mobile workload simulation | PASS |
| 2.3.3 core-file hash regression | PASS |

## Not completed in this environment

- `npm ci` did not finish; the build dependency installation timed out.
- `node mobile/build.mjs` was not run successfully because `esbuild` is not installed.
- Android Gradle/APK build was not run because Android SDK/ADB are not available here.
- No physical-device startup, playback, battery or thermal test was performed.

Therefore this deliverable is a **rebuilt 2.3.4 source archive ready for GitHub Actions**, not a newly built APK. Build the APK in the repository's GitHub Actions workflow, verify its certificate fingerprint against the installed 2.3.3 certificate, and only then install it as an update. Do not uninstall the old app or clear its data.
