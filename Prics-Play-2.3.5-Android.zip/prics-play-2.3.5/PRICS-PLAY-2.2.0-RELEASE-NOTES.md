# Prics Play 2.2.0 — Release Notes

## UI and navigation
- Bottom navigation labels now read Home, Search, Library, and Settings. The Settings tab opens the Settings landing/category list rather than forcing the Theme category.
- Returning to the Settings category list clears the category highlight and no longer persists the last category just for its visual state.
- Music Card titles clamp to two lines; artist names use a dedicated truncatable span with ellipsis.

## Lyrics
- Added a dedicated Hide/Show Lyrics control that switches between lyrics and cover-focused layout without closing Now Playing or touching playback state.
- Added an LRC parser for repeated timestamps and `[offset:+/-milliseconds]` metadata.
- Custom lyric timestamps now use the timestamp recorded by the sync editor directly instead of shifting the first line four seconds earlier and using each prior line's timestamp.
- Removed custom-lyrics-only look-ahead from line/word highlighting so the current audio time remains the timing reference.

## Audio/cache performance
- Mobile Opus range downloads and HLS fallback now write in ordered batches of at most four chunks to temporary cache instead of keeping the complete audio plus a concatenated copy in memory.
- Partial cache files are removed on failed downloads; existing retry/fallback behavior and complete-file cache semantics remain.
- Last-source status records source-resolution time, cache-download time, and downloaded byte count when available.
- Existing audio quality selection, Data Saver prefetch rules, manual battery exemption action, and background playback path are retained.

## Limitations
- Mobile playback remains cache-first: on a cold uncached song, `/api/stream-info` still waits for the full file to be cached before playback begins. This update reduces peak memory and improves diagnostics, but does not prove or promise that cold-start time-to-audio is fixed. Progressive playback would require a separate streaming-path design and real-device validation.
- Target bitrates remain source-selection targets, not guaranteed transcoded bitrates. Existing cached tracks retain their existing quality.
- APK build, real-device playback, battery usage, network timing, and upgrade-signature compatibility must be verified through CI and on an Android device.
