# Prics Play 2.2.0 — Implementation Plan and Status

This file supersedes the active implementation checklist for source version 2.2.0. It combines Settings/Library navigation, Music Card overflow, Lyrics visibility and timing, audio-quality retention, battery-safe playback, and buffering/cache performance.

## Applied source changes
- Settings opens at its landing state; category highlights are cleared on return; the last category is no longer persisted for visual state.
- Bottom tabs are Home, Search, Library, Settings. Internal view IDs and collection storage are preserved.
- Music Card titles use two-line clamping and artist text has a dedicated ellipsis target.
- Lyrics has an independent hide/show toggle. The audio player, playback position, and play/pause state are not modified by this toggle.
- LRC parsing supports repeated timestamps and standard offset metadata. Custom timestamps are no longer artificially shifted.
- Mobile Opus/HLS downloads use bounded ordered writes to the temporary cache, with partial-file cleanup and timing diagnostics.
- Version metadata targets 2.2.0.

## Retained constraints
- Audio quality is a source-selection target; no universal bitrate or transcoding is promised.
- Cold uncached mobile playback remains cache-first and may wait for the full file before starting. The change reduces memory pressure but does not by itself implement progressive playback.
- Background playback, notification controls, existing cache semantics, battery exemption as a manual action, and the stable Android application ID are retained.

## Release gate
Do not claim release-ready until the full test suite, mobile bundle build, Android APK build, update-signature compatibility, and real-device tests have been completed. Test Play/Pause/Resume/Stop/Seek/Next/Previous/Shuffle/Repeat, Library/playlist state, both themes, Lyrics open/close and sync, background playback, network interruption/retry, and cache hit/miss behavior. Record measured stream timings and battery/data measurements when hardware and source services are available.
