# Prics Play 2.3.2 — Performance Edition

## Mobile performance
- Mobile Performance mode is enabled by default when no previous preference exists. Existing user choices are preserved.
- Now Playing UI work is throttled to 12 FPS on mobile instead of running callbacks at the screen refresh rate.
- Gradient lyric animation is stopped in Performance mode.
- Daily Mix no longer runs recommendation requests automatically on mobile Home. It can be generated manually and is limited to two mixes per request.
- Next-song prefetch is off by default on mobile. It can be enabled in Tracks → Playback settings.
- Public Android Downloads are indexed on demand; cached tracks avoid the Downloads lookup.
- Startup skips recursive scans of desktop-only plugin, binary-tool, log and temporary folders. Existing files are not deleted.
- Lyrics text and the YouTube/SoundCloud extractor are loaded only when needed.
- Cache-limit scanning is debounced after downloads.
- Trending cache timestamps are honored across restarts; followed-artist metadata is fetched only when Artists is opened on mobile.
- Repeated Liquid Glass mobile cards no longer use backdrop blur.

## Compatibility
- Android app ID, iOS bundle ID, signing identity, deep links, data paths, audio engine, background playback service, media controls, queue, playlists, lyrics, downloads, local music, sync and backup are retained.
- Android wake-lock behavior is intentionally unchanged pending physical screen-off playback tests.

## Verification status
- Source tests and syntax checks pass as documented in `PRICS-PLAY-2.3.2-PERFORMANCE-REPORT.md`.
- Android APK build and physical-device battery/thermal tests remain required before public distribution.
