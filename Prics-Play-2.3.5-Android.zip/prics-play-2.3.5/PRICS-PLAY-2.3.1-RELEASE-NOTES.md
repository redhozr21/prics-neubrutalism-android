# Prics Play 2.3.1 — Release Notes

## Mobile experience
- Reworked the Android/iOS mobile navigation to three primary destinations: Home, Search and Collection.
- Added a dedicated Search landing screen with genre shortcuts that submit queries through the existing search engine and currently selected music source.
- Added a dedicated Collection landing screen with shortcuts to liked songs, albums, followed artists, local music and listening history, plus a live list of saved playlists.
- Added a Settings entry to the mobile profile menu; Integration, Theme, About, Profiles, Backup and Sync remain available in the existing Settings system.
- Added a compact Home introduction and a recently played row powered by the current profile history.

## Visual system
- Updated the default Neubrutalism palette to cream `#FFF8EF`, coral `#FF482C`, yellow `#FFE568`, purple `#C9B4FF` and ink `#0F0F0F`.
- Applied the new palette to navigation, cards, Home, Search, Collection and Now Playing while retaining the Liquid Glass option.
- Preserved the original Prics Play logo asset.

## Compatibility and scope
- Retained the Android application ID, iOS bundle ID, deep-link scheme, localStorage keys, data folders, native media controls and updater identity.
- Desktop-only Plugin management is hidden from the mobile Settings UI; desktop functionality remains unchanged.
- Podcast browsing and a non-functional mobile Equalizer are not advertised as available features. Existing desktop audio processing and mobile speed/sleep controls are retained.
- No music source, playback engine, local media or user collection data was intentionally removed.

## Verification
- Source syntax, targeted regression tests, workflow syntax and mobile build transformation are checked in this source revision.
- A signed APK build and physical Android visual/playback/update tests must still pass in GitHub Actions or a configured Android environment before distribution.
