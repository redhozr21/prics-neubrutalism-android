# Prics Play 2.3.3 — Mobile Workload Simulation

**Type:** deterministic source-guard simulation; not a physical battery benchmark.

Command:

```bash
node tools/simulate-mobile-power.mjs
```

Scenarios:
1. Idle Home for 15 minutes with fresh local recommendation/chart caches.
2. Music playback for 60 minutes with screen on and a cached track.
3. Music playback for 60 minutes with the screen locked and a streaming track.

The script checks that mobile Daily Mix and Sync work are absent, next-track prefetch is disabled, the visualizer scheduler exits when no visualizer is visible, plain mobile audio remains in use, and Android media playback service remains present.

Expected modeled behavior:
- Idle: no audio stream, no Daily Mix/Sync tasks, no visualizer callbacks, no app-owned wake lock.
- Screen-on playback: one current audio stream, no next-song prefetch, no app-owned CPU/Wi-Fi lock.
- Screen-off playback: foreground media service remains; partial CPU lock is scoped to screen-off playback; Wi-Fi lock is scoped to the track download only.

This simulation cannot calculate battery percentage/mAh, CPU temperature or GPU temperature. Hardware codec efficiency, WebView, Android power policy, volume, screen brightness and mobile-radio conditions require physical-device measurement.
