# Prics Play 2.3.2 — Performance Audit and Implementation Report

**Baseline:** Prics Play 2.3.1 source archive  
**Target:** 2.3.2 Performance Edition  
**Scope:** mobile CPU, battery, startup I/O, network and GPU workload  
**Code changes:** implemented in this source tree  
**Physical-device measurements:** pending

## Executive summary

The audit found avoidable background work in mobile recommendations, startup storage indexing, artist metadata refresh, cache maintenance and UI animation scheduling. The 2.3.2 source applies low-risk changes to those paths while preserving the audio engine, Android foreground playback service, media controls, data folders and user collections.

The source tree does not prove that the phone will no longer heat up or that battery use will be lower than a game. That must be measured after building and installing the APK on the affected phone.

## Changes applied

| Area | 2.3.1 behavior | 2.3.2 behavior |
|---|---|---|
| Mobile Performance mode | Off unless manually enabled | On by default for new/unset mobile preferences; saved user choice is preserved |
| Now Playing frame work | RAF callbacks follow screen refresh; mobile processing cap applied inside the loop | 12 FPS timer-based updates on mobile; desktop retains RAF |
| Gradient lyrics | Animation loop can continue while playing | Gradient RAF is stopped/blocked in Performance mode |
| Daily Mix | Automatic mobile generation after Home opens | User-initiated on mobile; at most two mixes per request; desktop unchanged |
| Next-song prefetch | Whole next track may download before current song ends | Off by default on mobile; optional switch in Tracks → Playback |
| Storage startup scan | Recursive walk through all app-data directories and public Downloads | Indexes feature-critical app folders; skips recursive desktop-only folders; public Downloads deferred |
| Public Downloads | Recursive scan during startup | Direct-child scan on demand; cached private track avoids this lookup |
| Lyrics files | All `.lrc` text read during startup | LRC contents read when the lyrics endpoint first needs them |
| Extractor | YouTube/SoundCloud extractor module loaded at startup | Lazy require on first relevant search/stream request |
| Cache maintenance | Full cache-limit scan after each completed download | Debounced 4-second scan; manual limit changes still enforce immediately |
| Trending | Saved timestamp not used on cold start | Fresh one-hour persistent cache is honored |
| Followed artists | Up to eight metadata lookups could run from Home | No automatic mobile Home lookup; up to three per batch when Artists is opened |
| Liquid Glass | Repeated mobile cards each use backdrop blur | Repeated cards retain translucent styling but use no backdrop blur |

## Files changed

- `app.js` — mobile Daily Mix behavior, Trending cache, followed artist metadata, prefetch gate, 12 FPS mobile update loop, default mobile Performance mode and gradient-loop stop.
- `mobile/mobile-ui.js` — opt-in next-song prefetch switch.
- `mobile/mobile.css` — removes repeated backdrop blur from Liquid Glass mobile cards.
- `mobile/shims/store.js` — selective startup scan and deferred/direct-child public Downloads indexing.
- `mobile/shims/fs.js` — on-demand public Downloads index and lazy LRC text reads.
- `mobile/shims/child_process.js` — lazy extractor initialization and debounced cache-limit call.
- `mobile/cache-limit.js` — scheduled/debounced cache-limit enforcement while retaining the immediate API.
- `server.js` — skips downloaded-file lookup when the private cache already contains the track.
- `index.html`, `README.md`, `update-notifier.js`, `android/app/build.gradle`, `package.json`, `package-lock.json` — version and release metadata updated to 2.3.2.
- Tests updated and a new `test/prics-play-v232-performance.test.js` added.

## Features deliberately retained

No changes were made to the core audio engine, Android `PlaybackService`, Android `MediaControlsPlugin`, media notification, lock-screen controls, foreground service, partial wake lock, queue, lyrics timing, playlist data, local music folders, download storage paths, profile storage, backup, restore or sync.

The Android wake lock was not removed. It is tied to background playback reliability; removing it without testing screen-off playback could make songs stop when the display turns off. The battery-optimization exemption remains a user-initiated setting, not a default action.

## Test results

| Verification | Result |
|---|---:|
| JavaScript/MJS/CJS syntax | 130/130 passed |
| Tests excluding Electron-dependent `library-import.test.js` | 324/324 passed |
| Full Node test suite | 325 passed, 1 failed due missing `electron` package |
| Android public/private download store tests | Passed |
| SoundCloud HLS and YouTube Opus playback tests | Passed |
| Mobile performance regression tests | Passed |
| iOS Info.plist XML parse | Passed |

The only full-suite failure is environment-related: `test/library-import.test.js` cannot load `electron` because dependencies are not installed in this runtime.

## Build and device-test limitations

- `node mobile/build.mjs` could not run because the `esbuild` package is absent.
- Android SDK and ADB are not configured in this environment, so no APK was built or installed.
- No physical-device CPU, battery, wake-lock or temperature measurements are available.

## Required validation before public release

Run `npm ci`, `node mobile/build.mjs`, `npx cap sync android` and `./gradlew assembleDebug` in a network-enabled Android build environment. Then compare 2.3.0/2.3.1 against 2.3.2 on the same phone with identical brightness, volume, network, audio source and test duration:

1. 15 minutes Home idle, no music.
2. 15 minutes music playing, screen on, mini-player only.
3. 15 minutes music playing with Now Playing open.
4. 15 minutes music playing with screen locked.
5. Search and Collection scrolling in Neubrutalism and Liquid Glass.
6. One downloaded song, one cached song, one public Downloads song and one local-library song.
7. Queue next-track behavior with prefetch off and on.

Record battery percentage, Android per-app battery use, CPU activity, network traffic, device temperature and screen-off playback continuity. Do not publish a claim such as “uses less battery than a game” until those measurements support it.
