# Prics Play 2.3.0 — Implementation Status

**Target:** `2.3.0`  
**Baseline:** `2.2.0`  
**Status:** Source implementation and focused source-level tests completed; full dependency-backed build and physical Android verification remain pending.  
**Scope:** In-app Android APK updater and Liquid Glass layout parity only.

The 2.2.0 navigation, Library, Music Card overflow, Lyrics timing/toggle, audio source selection, cache writing, battery action, and background playback work is retained. See [`PRICS-PLAY-2.2.0-IMPLEMENTATION-REPORT.md`](PRICS-PLAY-2.2.0-IMPLEMENTATION-REPORT.md) for that historical scope and [`PRICS-PLAY-2.3.0-IMPLEMENTATION-REPORT.md`](PRICS-PLAY-2.3.0-IMPLEMENTATION-REPORT.md) for this release's changes and verification limits.

## 1. In-app updater

- Reuses the official GitHub Releases API for `redhozr21/prics-neubrutalism-android` and accepts only a stable `X.Y.Z`/`vX.Y.Z` release tag.
- Selects only the official `Prics-Play.apk` asset; debug and unrelated APK names are not candidates.
- Requires a SHA-256 value from the GitHub asset digest or the matching `Prics-Play.apk.sha256` release asset.
- On Android, downloads into app-private cache, displays progress, limits download size, validates the APK ZIP header and SHA-256, and removes incomplete downloads.
- Before showing the installer, rechecks the cached hash, application ID, increasing version code, and signing-certificate compatibility. It uses Android's normal installer and never claims or attempts silent installation.
- Android's “install unknown apps” permission is requested only when the user chooses Install update. A user must return from Settings and press Install update again.
- The versioned `android.yml` workflow is the only workflow that publishes permanent GitHub Releases. It reuses the existing `prics-play-debug-keystore-v1` cache used by earlier installed debug builds and fails closed if the cache is missing. `build-apk.yml` produces a workflow artifact only and does not publish releases.

## 2. Liquid Glass layout parity

- Keeps glass surfaces, blur, highlights, rounded corners, and soft shadows as theme styling.
- Aligns shared mobile geometry for the top navigation, Home sections/cards, track rows, playlist detail, mini-player transport controls, progress indicator, and bottom navigation with Neubrutalism.
- Corrects the track-row margins/width and mini-player progress-line inset/height so the theme does not independently change those layout measurements.
- Adds source-level regression assertions for the shared geometry. Real computed-style/bounding-box comparison and screenshots still require a browser or Android runtime.

## 3. Release/version safety

- `package.json`, `package-lock.json`, Android `versionName` fallback, and build metadata target `2.3.0`.
- The Android application ID remains `io.github.cloverscripts.muriel`.
- Fixes the source selector's semantic-version regex so a checked-out 2.3.0 source tree correctly outranks an older 2.2.0 archive.
- Keeps previous source archives and permanent release tags untouched.

## 4. Verification status

- Focused updater, source-selection, layout-parity, and native-updater safety tests: **26/26 passed**.
- Full `npm test`: **308/309 passed**; the only failure is the Electron-dependent library-import test because `electron` could not be installed. Excluding that file, the rest passed **307/307**.
- JavaScript syntax checks and both workflow YAML parsing checks passed.
- `npm ci` timed out after registry/DNS trouble; the stalled install was stopped and its incomplete `node_modules` directory removed.
- The Android SDK is not configured in this environment. A signed APK build, package/signature inspection of the produced APK, physical installer handoff, app-data preservation, and on-device theme screenshots remain unverified.

Do not label this release production-ready until dependency installation, mobile bundle build, Capacitor sync, signed Android build, compatible signing-key validation, and real-device update/theme tests pass in CI/device testing.
