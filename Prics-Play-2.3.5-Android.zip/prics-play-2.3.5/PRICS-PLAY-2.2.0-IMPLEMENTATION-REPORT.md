# Prics Play 2.2.0 — Implementation and Verification Report

**Status:** Source changes implemented in a working copy; final APK and device validation are not yet confirmed.
**Base source:** Prics Play 2.1.0 archive.
**Target version:** 2.2.0.

## Changes made
- `package.json`, `package-lock.json`, `android/app/build.gradle`, `build-info.js`, `update-notifier.js`, `index.html`: version metadata updated to 2.2.0. Android application ID and namespace are unchanged.
- `mobile/build.mjs`, `mobile/neubrutalism.js`: bottom navigation now labels Library and Settings correctly; Settings no longer automatically opens Theme.
- `app.js`: Settings opens at Interface/list state rather than a saved category; returning to the category list clears category active styling and removes the legacy stored category key. Music Card artist text has a dedicated truncatable span. Lyrics can be hidden/shown independently of the Now Playing drawer. Custom lyric timestamps are read as recorded, and lyric highlight timing uses audio currentTime without a custom-only lead.
- `styles.css`, `mobile/mobile.css`: card titles clamp to two lines, artist names truncate safely, and collapsed Lyrics reuses the cover-focused layout while retaining the drawer.
- `lyrics-sources.js`: added an LRC parser for repeated leading timestamps and `[offset:+/-milliseconds]`, while preserving untimed lines as untimed.
- `mobile/shims/store.js`, `mobile/shims/child_process.js`: Opus ranges and HLS segments are written to cache in bounded ordered batches, reducing peak memory compared with retaining and concatenating a whole-song buffer. Failed partial files are removed. Timing metadata is recorded for source resolution and cache download.
- Tests: updated version/navigation assertions and added tests for LRC offsets/repeated timestamps, lyrics visibility, and bounded audio writes.

## Findings and limitations
- Battery Details auto-prompt was already disabled in the 2.1.0 source. The manual `allowBackground()` action and Android permission path are retained.
- Audio quality choices and source-selection logic already existed in 2.1.0 and were preserved. Exact target bitrates are not guaranteed because the app selects available source renditions rather than transcoding every stream.
- The mobile playback architecture remains cache-first. `/api/stream-info` waits for the whole uncached song to be cached before the audio element receives a local URL. The 2.2.0 changes reduce peak memory and add diagnostics, but cold-cache time-to-first-audio has not been proven improved. A true progressive streaming path would be a higher-risk separate design requiring Android/iOS real-device testing.
- No GitHub push or release has been performed by this implementation.

## Verification status
- Baseline before changes: 291/292 tests passed; the existing failure was `test/library-import.test.js` requiring the unavailable `electron` module.
- Verification rerun on the continuation copy: 295/296 tests passed. The only failure remains `test/library-import.test.js`, which cannot load `google-library.js` because the `electron` package is unavailable. All other tests passed, including the 12 version/navigation/lyrics/cache tests in `test/prics-play-v220.test.js` and the focused HLS/Opus tests.
- JavaScript syntax checks passed for 12 changed runtime/test files.
- Both the source archive Android workflow and the standalone repository `build-apk.yml` parsed as YAML; all 13 workflow shell `run` blocks passed `bash -n`. This validates syntax only, not a live GitHub Actions run.
- Dependency installation was retried once and stopped with npm's `Exit handler never called!`; the log reports registry DNS `EAI_AGAIN`. The partial `node_modules` created by that failed attempt was removed from this temporary continuation copy. No npm, test, Gradle, or bundle-build process remains running.
- Mobile bundle build and Android APK build remain unverified because dependencies could not be installed in this environment.
- No physical Android device or external audio service was available for measured battery, data, stream latency, or playback regression testing. The cache-first path still waits for a full uncached audio file before playback; bounded writes reduce peak memory but do not prove lower cold-start latency.
- No GitHub push or release has been performed by this implementation.
