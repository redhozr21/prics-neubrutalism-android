# Prics Play 2.3.1 — Implementation Report

**Baseline:** 2.3.0 uploaded source archive  
**Target:** 2.3.1  
**Scope:** Mobile UX redesign and visual system refinement.

## Changes
- Changed the mobile bottom navigation to Home, Search and Collection.
- Added a real mobile Search landing view. Genre buttons reuse the existing search input, selected source and `performSearch` event path.
- Added a standalone Collection landing view. It reads the current profile's playlists from `MurielCore.state.playlists` (with the existing localStorage fallback) and routes collection shortcuts to the existing Favorites, Albums, Artists, Local and History views.
- Added a Settings action to the mobile profile menu without replacing profile switching or profile management. Existing Integration, Theme and About settings remain in the original Settings view.
- Added Home introduction and recently played cards bound to `MurielCore.state.history` and `MurielCore.playTrack`.
- Updated the default Neubrutalism palette to the approved Prics Play palette and styled the Now Playing screen with the coral accent. Liquid Glass remains available.
- Hid the desktop-only Plugin management category from mobile Settings. It remains available on desktop.
- Bumped package, build and Android version metadata to 2.3.1.

## Compatibility preserved
- Android/iOS application identifiers, Android signing setup, deep-link scheme, storage keys, profile scoping, local media folders, native media controls, updater and playback engine were not renamed or replaced.
- Existing playlist, favorite, album, artist, history, lyrics, sync, backup, integration and update flows remain the source of truth.

## Known limitations
- The mobile Equalizer remains hidden because the current mobile audio initialization deliberately bypasses Web Audio to protect background playback behavior. Exposing it without Android device verification would present controls that may not affect sound. Desktop EQ remains unchanged.
- Podcast browsing is not implemented and is not shown as a search category.
- Live GitHub branch state, CI release publication, signed APK installation and physical device playback are not verified by this local source operation.

## Release gate
Run `npm ci`, `npm test`, `node mobile/build.mjs`, `npx cap sync android` and `./gradlew assembleDebug` in a network-enabled environment with Android SDK. Then test Home/Search/Collection navigation, profile-menu Settings, both themes, playback transport, lyrics, queue, background playback, data persistence, updater signature compatibility and app upgrade on a physical device.

## Additional site and share-link alignment

- Updated the website's GitHub API target and Android download resolution to the current repository and its stable `Prics-Play.apk` plus SHA-256 release asset.
- Updated Sync and shared-playlist web destinations to the current GitHub Pages project path.
- Kept compact playlist URLs under the existing length target by using a short root hash and redirecting it to the web-player route; old `#p=` playlist links continue to decode.
- Updated the iOS display name to Prics Play without changing the bundle ID or `muriel://` URL scheme.

## Verification performed for this source revision

- Focused mobile navigation, palette, version, site-release, and share-link tests: **36/36 passed**.
- Full `node --test`: **313/314 passed**. The only failing test is the pre-existing Electron-dependent `test/library-import.test.js`, which cannot load `electron` because dependencies could not be installed in this environment.
- JavaScript/MJS/CJS syntax: **123 files passed** `node --check`.
- Python tools: 3 files compile successfully.
- All 6 GitHub Actions workflow YAML files parse; workflow shell `run:` blocks and `.github/carry-downloads.sh` pass `bash -n`.
- Main HTML documents parse, the `welcome.html` inline script passes `node --check`, and the iOS `Info.plist` parses successfully.
- `npm ci --no-audit --no-fund` timed out because npm registry requests failed with DNS `EAI_AGAIN`. The partial `node_modules` directory was removed.
- `node mobile/build.mjs` cannot run because `esbuild` is unavailable without dependency installation.
- Android SDK/`adb` are not configured in this environment. No APK, signed installer, or physical-device validation is claimed.
