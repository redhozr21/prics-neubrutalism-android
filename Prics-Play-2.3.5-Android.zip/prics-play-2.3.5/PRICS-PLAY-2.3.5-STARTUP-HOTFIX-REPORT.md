# Prics Play 2.3.5 — Startup Hotfix Audit

**Baseline:** uploaded Prics Play 2.3.3 and 2.3.4 APKs, plus the 2.3.4 source rebuild  
**Release target:** 2.3.5 (Android version code is generated from the GitHub Actions run number)  
**Scope:** startup freeze, Now Playing observer, APK signing compatibility  
**Status:** source hotfix prepared; APK build and physical-device validation remain pending

## 1. Direct APK comparison

The two uploaded APKs are structurally valid and contain the same 514 ZIP entries. Their application ID is unchanged: `io.github.cloverscripts.muriel`.

Build metadata:
- 2.3.3: commit `3b7eec8171fdde243e8750fa34386a3ba341d4ad`, workflow run 34.
- 2.3.4: commit `f664765c96db98ad64f260962889d3b156d137b3`, workflow run 37.

Only five APK entries differ:
- `AndroidManifest.xml` (release metadata)
- `assets/public/build-info.js`
- `assets/public/mobile-ui.js`
- `assets/public/mobile.css`
- `assets/public/update-notifier.js`

The core `app.js`, `mobile-bridge.js`, `neubrutalism.js`, native DEX files, Capacitor plugins and other packaged assets are byte-identical. The functional changes are therefore isolated to the new Now Playing JavaScript and its CSS.

## 2. Confirmed 2.3.4 freeze

In 2.3.4, `mobile-ui.js` installs a `MutationObserver` on `#right-panel` and observes its `class` attribute. Its callback calls `sync()`. When the panel is closed, `sync()` unconditionally executed:

```js
panel.classList.remove('np-full-lyrics');
```

The token is normally already absent on first launch. Chromium/WebView can still enqueue an attribute mutation record for this no-op class-list write. That mutation calls the observer again, which repeats the same no-op write. The page becomes trapped in a MutationObserver microtask loop, starving timers, input and touch events. This matches the blank Home shell and unresponsive buttons.

The behavior was reproduced in Chromium using the same no-op class removal pattern. A controlled reproduction reached repeated observer callbacks even though the class remained absent.

## 3. Hotfix applied

`mobile/mobile-ui.js` now uses `setPanelFullLyricsClass(full)`:
- Reads the current `np-full-lyrics` state.
- Writes the class attribute only when the requested state differs.
- Uses the same guarded helper for the closed-panel path.
- Runs the initial `sync()` before attaching the observer.

This prevents a no-op class write from recursively retriggering the observer. It preserves the coral Now Playing layout, real playback controls, compact lyric preview, and full-lyrics mode.

## 4. Browser regression test

The patched sync behavior was exercised in Chromium:
- Initial closed state: 1 initial sync, no observer loop.
- Open panel: one observer callback.
- Enter full lyrics: one observer callback.
- Close panel: two callbacks (close plus one guarded cleanup).
- After another 100 ms: callback count remained unchanged at 5.

The previous buggy pattern repeatedly invoked the observer. The patched pattern remains stable after state transitions.

## 5. Signing-certificate findings

The two supplied APKs use different Android Debug signing certificates:

| APK | SHA-256 certificate fingerprint |
|---|---|
| 2.3.3 (uploaded as 3.3.0) | `dad59c432b9c71753b6c0edffb3ff20717ffd64c71cacda476c6e348c9748310` |
| 2.3.4 (uploaded as 3.4.0) | `a31f0fe0d1c4f95c4d368432e12ae37591998bd8172086bffaced9b731dacc2c` |

Both certificates identify as `CN=Android Debug`, but their certificate and public-key fingerprints differ. A 2.3.5 APK intended to update the currently installed 2.3.4 must use the second fingerprint, not the 2.3.3 fingerprint.

Both GitHub Actions workflows now restore the existing debug keystore and verify that its SHA-256 certificate fingerprint equals the 2.3.4 fingerprint above. If the cache is missing or contains the 2.3.3/another key, the workflow fails safely before building. It does not generate or save a replacement key.

## 6. Validation status

- APK ZIP integrity: both uploaded APKs PASS.
- APK content comparison: complete.
- Chromium MutationObserver regression: PASS. The patched closed/open/full-lyrics/close sequence stabilizes at 5 observer callbacks after 100 ms; no continuing callback loop.
- JavaScript syntax: 134/134 files pass `node --check`.
- Node regression tests: 343/343 pass across 46 test files (the Electron-only `library-import.test.js` was excluded because Electron is not installed in this environment).
- `mobile.css`: zero top-level CSS parse errors.
- Both GitHub Actions workflow YAML files parse successfully.
- GitHub Actions keystore fingerprint: cannot be inspected from the APK alone; workflow enforces it at build time.
- Android APK build: not run in this environment (Android SDK/dependencies unavailable).
- Hotfix source ZIP: PASS, 314 entries, ZIP integrity verified.
- GitHub workflow patch ZIP: PASS, 3 entries, ZIP integrity verified.
- Android APK build: not run in this environment (Android SDK/dependencies unavailable).
- Real-device Home/Search/Collection/playback test: pending.

## 7. Installation safety

Do not uninstall the currently installed 2.3.4 app or clear its data. The 2.3.5 build must first pass the GitHub Actions signing-fingerprint check. Only install the resulting APK if its certificate matches the installed 2.3.4 certificate.
