# Prics Play 2.1.0 — Implementation and Verification Report

## Scope

This source update addresses the issues found in the 2.0.0 source audit, using focused changes rather than an app rewrite.

## Files changed

- `package.json`, `package-lock.json`: version metadata set to 2.1.0.
- `android/app/build.gradle`: default version name set to 2.1.0; application ID and namespace unchanged.
- `mobile/media-controls.js`: removed the automatic battery exemption and island notification prompts from the audio `playing` event. The explicit Settings actions remain available.
- `android/app/src/main/java/io/github/cloverscripts/muriel/MediaControlsPlugin.java`: Wi-Fi lock is held while media is loading, then released during local cached playback; CPU wake-lock behavior remains in place for background playback.
- `mobile/extract.js`: added quality target parsing and source rendition selection for YouTube Opus/HLS and SoundCloud when explicit bitrate metadata is available.
- `mobile/shims/child_process.js`: records the source bitrate when it can be determined; it does not invent a bitrate if the provider does not report one.
- `mobile/mobile-ui.js`: added persistent streaming-quality selection and theoretical data-per-hour estimates to the mobile Playback settings.
- `app.js`: removed eager prefetch of two complete tracks; Data Saver disables speculative mobile prefetch and other modes only prefetch the immediate next track later in the current song.
- `test/media-controls.test.js`, `test/youtube-opus.test.js`: added/updated regression tests for explicit battery opt-in and source-quality selection.
- `README.md`: points to this version's report.

## Quality semantics

The choices are targets: Data Saver 24 kbps, Low 48 kbps, Normal 96 kbps, High 160 kbps, Very High 320 kbps, and Automatic. The selector chooses the highest known rendition at or below a target; if none is below the target, it uses the lowest known rendition. Automatic selects the best available rendition. Actual source bitrates vary by provider and track.

Estimated data use at target bitrate, using decimal MB and ignoring network overhead:

| Mode | Target | Theoretical data/hour |
|---|---:|---:|
| Data Saver | 24 kbps | 10.8 MB |
| Low | 48 kbps | 21.6 MB |
| Normal | 96 kbps | 43.2 MB |
| High | 160 kbps | 72 MB |
| Very High | 320 kbps | 144 MB |
| Automatic | Provider-selected | Varies |

Existing cached tracks are not automatically deleted or re-encoded when the preference changes. They keep their cached quality, protecting offline availability and avoiding destructive cache invalidation.

## Verification status

- Focused regression tests: **38/38 passed** (battery opt-in, version/update metadata, YouTube quality selection, HLS fallback, and SoundCloud bitrate metadata).
- Full test suite: **291/292 passed**. The one remaining failure is environmental: `test/library-import.test.js` cannot load the `electron` dev dependency because `npm ci` did not finish in this environment. No assertion failed in that test.
- JavaScript syntax checks passed for the changed JS files.
- The mobile bundle and APK could not be built here: dependency installation timed out before `esbuild` was available. The GitHub Actions build and physical-device tests remain necessary.
- APK build, installation/update signature compatibility, actual background playback, battery measurements, and network-data measurements have not been verified on a physical Android device in this environment.
- Do not describe the APK as release-ready until CI build, signing, and device tests succeed.
