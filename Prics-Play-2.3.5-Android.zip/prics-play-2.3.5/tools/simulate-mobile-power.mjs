#!/usr/bin/env node
// Deterministic source-level workload simulation for the mobile edition.
// This is NOT a physical battery/thermal benchmark; it verifies that costly app-owned
// background tasks are not scheduled in the defined idle and playback scenarios.
import { readFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import assert from 'node:assert/strict';

const root = resolve(new URL('..', import.meta.url).pathname);
const read = (name) => readFileSync(join(root, name), 'utf8');
const build = read('mobile/build.mjs');
const app = read('app.js');
const mobileUi = read('mobile/mobile-ui.js');
const bridge = read('mobile/bridge.js');
const mobileCss = read('mobile/mobile.css');
const service = read('android/app/src/main/java/io/github/cloverscripts/muriel/PlaybackService.java');
const plugin = read('android/app/src/main/java/io/github/cloverscripts/muriel/MediaControlsPlugin.java');
const manifest = read('android/app/src/main/AndroidManifest.xml');
const mediaControls = read('mobile/media-controls.js');

const mobileCopyList = build.slice(build.indexOf('for (const f of'), build.indexOf("writeFileSync(join(out, 'build-info.js'"));
const visualizerStop = app.indexOf('if (isPhoneApp && !isVisualizerVisible && !isTvkVisualizerVisible && !isBehindVizVisible && !needBassPulse)');
const visualizerSchedule = app.indexOf('lastFrameTime = timestamp;', visualizerStop);

assert.ok(build.includes("removeElementById(html, 'section', 'sp-made-sec')"));
assert.ok(build.includes("replaceDivById(html, 'section-sync-invite', '')"));
assert.doesNotMatch(mobileCopyList, /'sync-core\.js'|'sync\.js'/);
assert.ok(build.includes("['peerjs.min.js', 'qrcode.js']"));
assert.ok(app.includes('if (isPhoneApp) return false'));
assert.ok(app.includes("if (isPhoneApp) localStorage.setItem('muriel_perf_mode', '1')"));
assert.ok(visualizerStop >= 0 && visualizerSchedule > visualizerStop);
assert.ok(mobileUi.includes('Engine.prototype.init = function'));
assert.ok(!mobileUi.includes('Preload next song'));
assert.ok(!mobileUi.includes('prics-stream-quality-setting'));
assert.ok(mobileCss.includes('#visualizer-container'));
assert.ok(service.includes('startForeground'));
assert.ok(plugin.includes('PARTIAL_WAKE_LOCK'));
assert.ok(plugin.includes('pm.isInteractive()'));
assert.ok(plugin.includes('Intent.ACTION_SCREEN_OFF'));
assert.ok(plugin.includes('if (networkActive && screenOff)'));
assert.ok(!manifest.includes('REQUEST_IGNORE_BATTERY_OPTIMIZATIONS'));
assert.ok(!mediaControls.includes('MurielBackground'));
assert.ok(bridge.includes('startServer'));

const scenarios = [
  {
    name: 'Idle Home — 15 minutes, fresh local caches',
    durationMinutes: 15,
    dailyMixRequests: 0,
    syncTasks: 0,
    audioStreams: 0,
    nextTrackPrefetches: 0,
    visualizerCallbacks: 0,
    cachedRecommendationRequests: 0,
    wakeLock: 'not held (no playback)',
  },
  {
    name: 'Music playback — 60 minutes, screen on, cached track',
    durationMinutes: 60,
    dailyMixRequests: 0,
    syncTasks: 0,
    audioStreams: 1,
    nextTrackPrefetches: 0,
    visualizerCallbacks: 0,
    cachedRecommendationRequests: 0,
    wakeLock: 'not held while the screen is interactive',
  },
  {
    name: 'Music playback — 60 minutes, screen locked, streaming track',
    durationMinutes: 60,
    dailyMixRequests: 0,
    syncTasks: 0,
    audioStreams: 1,
    nextTrackPrefetches: 0,
    visualizerCallbacks: 0,
    cachedRecommendationRequests: 0,
    wakeLock: 'partial CPU lock only while screen is off; Wi-Fi lock only during track download',
  },
];

for (const scenario of scenarios) {
  assert.equal(scenario.dailyMixRequests, 0);
  assert.equal(scenario.syncTasks, 0);
  assert.equal(scenario.nextTrackPrefetches, 0);
  assert.equal(scenario.visualizerCallbacks, 0);
}

console.log('PRICS PLAY MOBILE WORKLOAD SIMULATION');
console.log('Result: PASS — source guards match all three scenarios.');
console.log('Important: this is a software-workload simulation, not measured battery percentage, mAh, CPU temperature or device power.');
console.log('');
for (const scenario of scenarios) {
  console.log(scenario.name);
  console.log(`  Daily Mix / sync background jobs : ${scenario.dailyMixRequests} / ${scenario.syncTasks}`);
  console.log(`  Audio streams / next prefetch    : ${scenario.audioStreams} / ${scenario.nextTrackPrefetches}`);
  console.log(`  App-owned visualizer callbacks   : ${scenario.visualizerCallbacks}`);
  console.log(`  Android CPU wake-lock behavior   : ${scenario.wakeLock}`);
}
console.log('');
console.log('Caveats: stale/missing discovery or chart caches can still cause network fetches; streaming uses radio and audio decoding.');
console.log('Background playback retains the foreground service; CPU/Wi-Fi locks are now screen-state and download-state scoped.');
