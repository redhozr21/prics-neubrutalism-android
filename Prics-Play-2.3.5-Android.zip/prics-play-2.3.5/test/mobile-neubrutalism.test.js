const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');

test('mobile defaults preserve saved preferences while enabling Spotify home and Neubrutalism', () => {
  const bridge = read('mobile/bridge.js');
  assert.match(bridge, /if \(!localStorage\.getItem\('muriel_theme_mode'\)\) localStorage\.setItem\('muriel_theme_mode', 'light'\)/);
  assert.match(bridge, /if \(!localStorage\.getItem\('muriel_theme_accent'\)\) localStorage\.setItem\('muriel_theme_accent', '#FF482C'\)/);
  assert.match(bridge, /if \(!localStorage\.getItem\('muriel_home_layout'\)\) localStorage\.setItem\('muriel_home_layout', 'spotify'\)/);
  assert.match(bridge, /classList\.add\('is-mobile'\)/);
  assert.match(bridge, /classList\.toggle\('neo-theme', visualTheme === 'neubrutalism'\)/);
  assert.match(bridge, /classList\.toggle\('liquid-glass-theme', visualTheme === 'liquid-glass'\)/);
});

test('mobile bundle ships the Neubrutalism layer after the app and mobile behavior scripts', () => {
  const build = read('mobile/build.mjs');
  assert.match(build, /neubrutalism\.js/);
  const injection = build.slice(build.indexOf(".replace('<script src=\"app.js\""));
  assert.ok(injection.indexOf('mobile-ui.js') >= 0);
  assert.ok(injection.indexOf('mobile-ui.js') < injection.indexOf('neubrutalism.js'));
});

test('Neubrutalism supports independently saved accent, background, surface, ink, and secondary colors', () => {
  const skin = read('mobile/neubrutalism.js');
  for (const key of ['muriel_theme_accent', 'muriel_neo_background', 'muriel_neo_surface', 'muriel_neo_ink', 'muriel_neo_secondary']) {
    assert.ok(skin.includes(key), `missing palette key ${key}`);
  }
  assert.match(skin, /data-neo-preset="bubblegum"/);
  assert.match(skin, /data-neo-preset="night"/);
  assert.match(skin, /data-open-view="favorites"/);
});

test('mobile CSS styles the custom bottom navigation and hard-outline cards', () => {
  const css = read('mobile/mobile.css');
  assert.match(css, /\.neo-bottom-nav/);
  assert.match(css, /box-shadow: 4px 4px 0 var\(--neo-ink\)/);
  assert.match(css, /\.neo-theme-customizer/);
});


test('Prics Play branding and updater target the owned GitHub repository', () => {
  const html = read('index.html');
  const updater = read('update-notifier.js');
  const cap = read('capacitor.config.json');
  assert.match(html, /<title>Prics Play<\/title>/);
  assert.match(html, /class="prics-brand-mark" id="titlebar-logo-dot" src="assets\/prics-pa-play\.png"/);
  assert.match(html, /Prics Play is a free, independent player/);
  assert.match(updater, /const REPO = 'redhozr21\/prics-neubrutalism-android'/);
  assert.match(updater, /`https:\/\/api\.github\.com\/repos\/\$\{REPO\}\/releases\/latest`/);
  assert.match(updater, /asset\.name\.toLowerCase\(\) === 'prics-play\.apk'/);
  assert.match(updater, /prics-play\.apk\.sha256/);
  assert.match(read('mobile/neubrutalism.js'), /--neo-paper', colors\.background/);
  assert.equal(JSON.parse(cap).appName, 'Prics Play');
});

test('mobile seekbar supports pointer events and shuffle reorders the queue', () => {
  const app = read('app.js');
  const css = read('mobile/mobile.css');
  assert.match(app, /addEventListener\('pointerdown'/);
  assert.match(app, /addEventListener\('pointermove'/);
  assert.match(app, /state\.queue = current \? \[current, \.\.\.upcoming/);
  assert.match(css, /scrubber-track-container \{ touch-action: none/);
  assert.match(app, /prics_play_shuffle_queue_v1/);
});


test('Collection tab opens a dedicated Collection landing view and retains core library destinations', () => {
  const skin = read('mobile/neubrutalism.js');
  const libraryHandler = skin.slice(skin.indexOf("nav.querySelector('[data-tab=\"library\"]')"), skin.indexOf("pages.search.querySelectorAll"));
  assert.match(libraryHandler, /clickExisting\('nav-favorites'\)/);
  assert.match(libraryHandler, /showMobileLanding\('collection'\)/);
  assert.match(libraryHandler, /btn-close-rail-drawer/);
  assert.doesNotMatch(libraryHandler, /btn-toggle-playlists-drawer/);
  assert.match(skin, /aria-current/);
});

test('mobile fine-tuning compacts the header and adds safe inner spacing to recommendation cards', () => {
  const css = read('mobile/mobile.css');
  assert.match(css, /height: calc\(var\(--safe-top\) \+ 34px\)/);
  assert.match(css, /inset: calc\(var\(--safe-top\) \+ 82px\)/);
  assert.match(css, /\.fy-section[\s\S]*?padding: 12px !important/);
  assert.match(css, /\.fy-section \.suggestion-chips[\s\S]*?margin: 0 !important/);
});

test('mobile resource defaults cap downloaded audio cache and cache recommendations for six hours', () => {
  const cache = read('mobile/cache-limit.js');
  const mobileUi = read('mobile/mobile-ui.js');
  const app = read('app.js');
  const skin = read('mobile/neubrutalism.js');
  assert.match(cache, /muriel_cache_limit_mb'\) \|\| '512'/);
  assert.match(mobileUi, /\['512', '512 MB'\]/);
  assert.match(app, /prics_play_discover_cache_v1/);
  assert.match(app, /6 \* 60 \* 60 \* 1000/);
  assert.match(skin, /img\.loading = 'lazy'/);
  assert.match(skin, /img\.decoding = 'async'/);
  assert.match(skin, /neo-library-hub-grid/);
});

test('mobile build emits the Neo-Brutalism shell and three-tab navigation before first paint', () => {
  const build = read('mobile/build.mjs');
  assert.match(build, /class="is-mobile neo-theme"/);
  assert.match(build, /body class="no-nav-transition home-spotify"/);
  assert.match(build, /const staticBottomNav =/);
  assert.match(build, /replaceDivById\(html, 'home-hero'/);
  assert.match(build, /class="platform-btn active" data-platform="ytmusic"/);
  assert.match(build, /class="sidebar-nav" hidden aria-hidden="true"/);
  assert.match(build, /script src="profiles-core\.js"/);
});

test('mini player uses explicit previous/play/next controls and has no mini-bar swipe listeners', () => {
  const ui = read('mobile/mobile-ui.js');
  const css = read('mobile/mobile.css');
  const html = read('index.html');
  assert.doesNotMatch(ui, /playbar\.addEventListener\('touch(start|move|end)'/);
  assert.match(html, /id="btn-prev" title="Previous"/);
  assert.match(html, /id="btn-play-pause"/);
  assert.match(html, /id="btn-next" title="Next"/);
  assert.match(css, /#btn-prev,[\s\S]*?#btn-next[\s\S]*?display: inline-flex !important/);
  assert.match(css, /#track-loading-overlay,[\s\S]*?#playbar-spinner[\s\S]*?display: none !important/);
  assert.match(css, /--safe-top: env\(safe-area-inset-top, 0px\)/);
  assert.match(css, /is-android \{ --safe-top: 0px !important/);
  assert.match(read('mobile/bridge.js'), /requestAnimationFrame\(\(\) => requestAnimationFrame/);
  assert.match(read('mobile/build.mjs'), /<script defer\$1><\/script>/);
});


test('mobile startup uses the declared deferred-work helper so app initialization does not abort', () => {
  const app = read('app.js');
  assert.match(app, /const deferNonCriticalStartup =/);
  assert.doesNotMatch(app, /\bdeferNonCritical\s*\(/);
  assert.ok((app.match(/\bdeferNonCriticalStartup\s*\(/g) || []).length >= 7);
});


test('Liquid Glass preserves Neubrutalism geometry for home cards, track rows, and mini-player progress', () => {
  const css = read('mobile/mobile.css');
  assert.match(css, /html\.is-mobile\.neo-theme \.top-nav[\s\S]*?height: 44px !important/);
  assert.match(css, /html\.is-mobile\.liquid-glass-theme \.top-nav[\s\S]*?height: 44px !important/);
  assert.match(css, /html\.is-mobile\.neo-theme \.sp-home \{ gap: 20px !important; padding: 8px 0 30px !important; \}/);
  assert.match(css, /html\.is-mobile\.liquid-glass-theme \.sp-home \{[\s\S]*?gap: 20px !important;[\s\S]*?padding: 8px 0 30px !important/);
  assert.match(css, /html\.is-mobile\.liquid-glass-theme \.track-row \{ margin: 0 3px 11px !important; width: calc\(100% - 6px\) !important; box-sizing: border-box !important; \}/);
  assert.match(css, /html\.is-mobile\.liquid-glass-theme \.playbar::after \{ left:12px !important; right:12px !important; bottom:3px !important; height:3px !important;/);
  assert.match(css, /prefers-reduced-transparency: reduce[\s\S]*?liquid-glass-theme \.sidebar\.neo-sidebar::before[\s\S]*?backdrop-filter: none !important/);
});


test('Prics 2.3.4 exposes three mobile destinations and profile-menu Settings access', () => {
  const build = read('mobile/build.mjs');
  const skin = read('mobile/neubrutalism.js');
  const profiles = read('profiles.js');
  assert.match(build, /data-tab="home"/);
  assert.match(build, /data-tab="search"/);
  assert.match(build, /data-tab="library"/);
  assert.doesNotMatch(build, /data-tab="settings"/);
  assert.match(skin, /id = 'prics-search-view'/);
  assert.match(skin, /id = 'prics-collection-view'/);
  assert.match(skin, /runMobileSearch/);
  assert.match(profiles, /data-act="settings"/);
});

test('2.3.4 palette matches the approved Prics Play colors and retains Liquid Glass', () => {
  const skin = read('mobile/neubrutalism.js');
  const css = read('mobile/mobile.css');
  assert.match(skin, /accent: '#FF482C', background: '#FFF8EF'/);
  assert.match(skin, /secondary: '#FFE568', tertiary: '#C9B4FF'/);
  assert.match(css, /--neo-accent: #FF482C/);
  assert.match(css, /--neo-paper: #FFF8EF/);
  assert.match(css, /--neo-tertiary: #C9B4FF/);
  assert.match(css, /liquid-glass-theme/);
});
