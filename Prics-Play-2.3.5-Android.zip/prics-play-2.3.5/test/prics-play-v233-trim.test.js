'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');

test('mobile build removes the Made for You Daily Mix section before WebView first paint', () => {
  const build = read('mobile/build.mjs');
  const app = read('app.js');
  assert.match(build, /removeElementById\(html, 'section', 'sp-made-sec'\)/);
  assert.match(app, /function renderMadeForYou\(\)/);
  assert.match(app, /if \(!sec \|\| !row\) return/);
});

test('mobile build omits device sync scripts and sync-only vendor assets', () => {
  const build = read('mobile/build.mjs');
  const html = read('index.html');
  const copied = build.slice(build.indexOf('for (const f of'), build.indexOf("writeFileSync(join(out, 'build-info.js'"));
  assert.doesNotMatch(copied, /'sync-core\.js'|'sync\.js'/);
  assert.match(build, /peerjs\.min\.js', 'qrcode\.js/);
  assert.match(build, /replaceDivById\(html, 'section-sync-invite', ''\)/);
  assert.match(html, /<script src="sync\.js"><\/script>/); // desktop still retains its sync feature
});

test('mobile HTML transformation removes Daily Mix and sync UI/scripts while leaving desktop source intact', () => {
  const build = read('mobile/build.mjs');
  const start = build.indexOf('function replaceDivById');
  const end = build.indexOf('const staticBottomNav', start);
  const helperSource = build.slice(start, end);
  const sandbox = {};
  vm.runInNewContext(`${helperSource}\nthis.replaceDivById = replaceDivById; this.removeElementById = removeElementById;`, sandbox);
  let html = read('index.html');
  html = sandbox.removeElementById(html, 'section', 'sp-made-sec');
  html = sandbox.replaceDivById(html, 'section-sync-invite', '');
  html = html.replace(/\s*<script src="(?:assets\/peerjs\.min\.js|assets\/qrcode\.js|sync-core\.js|sync\.js)"><\/script>/g, '');
  assert.doesNotMatch(html, /id="sp-made-sec"|id="section-sync-invite"/);
  assert.doesNotMatch(html, /<script src="(?:assets\/peerjs\.min\.js|assets\/qrcode\.js|sync-core\.js|sync\.js)"><\/script>/);
  assert.match(read('index.html'), /<script src="sync\.js"><\/script>/); // desktop remains unchanged
});

test('mobile Settings keeps Theme, Integrations, Storage, Profiles and About only', () => {
  const skin = read('mobile/neubrutalism.js');
  const trim = skin.slice(skin.indexOf('function trimMobileSettings()'), skin.indexOf('function ensureMobileLandingViews()'));
  assert.match(trim, /new Set\(\['interface', 'tracks', 'advanced', 'plugins', 'sync'\]\)/);
  assert.match(trim, /settings-search-box/);
  assert.match(trim, /prics-visual-theme-setting/);
  assert.match(trim, /neo-theme-customizer/);
  assert.match(skin, /trimMobileSettings\(\)/);
});

test('mobile Theme keeps the screenshot controls and removes the other theme groups', () => {
  const skin = read('mobile/neubrutalism.js');
  const trim = skin.slice(skin.indexOf('function trimMobileSettings()'), skin.indexOf('function ensureMobileLandingViews()'));
  assert.match(trim, /m3-group\[data-group="colors"\]/);
  assert.match(trim, /if \(child !== colors\) child\.remove\(\)/);
  assert.match(skin, /data-prics-visual-theme/);
  assert.match(skin, /data-neo-preset="pop"/);
  assert.match(skin, /data-neo-preset="bubblegum"/);
  assert.match(skin, /data-neo-preset="lime"/);
  assert.match(skin, /data-neo-preset="ocean"/);
  assert.match(skin, /data-neo-preset="night"/);
});

test('mobile Settings opens to the retained Theme category and safely falls back to a visible category', () => {
  const app = read('app.js');
  assert.match(app, /const defaultSettingsCategory = \(\) => isPhoneApp \? 'theme' : 'interface'/);
  assert.match(app, /const first = document\.querySelector\('#settings-nav \.settings-nav-btn\[data-cat\]'\)/);
  assert.match(app, /showSettingsCategory\(defaultSettingsCategory\(\)\)/);
});

test('mobile visualizer stops its timer when no visualizer surface is visible', () => {
  const app = read('app.js');
  const stopAt = app.indexOf('if (isPhoneApp && !isVisualizerVisible && !isTvkVisualizerVisible && !isBehindVizVisible && !needBassPulse)');
  const scheduleAt = app.indexOf('lastFrameTime = timestamp;', stopAt);
  assert.ok(stopAt > 0);
  assert.ok(scheduleAt > stopAt);
  assert.match(app.slice(stopAt, scheduleAt), /setAnalyserEnabled\(false\)/);
});

test('background playback and plain native audio remain available after settings cleanup', () => {
  const ui = read('mobile/mobile-ui.js');
  const service = read('android/app/src/main/java/io/github/cloverscripts/muriel/PlaybackService.java');
  const plugin = read('android/app/src/main/java/io/github/cloverscripts/muriel/MediaControlsPlugin.java');
  assert.match(ui, /Engine\.prototype\.init = function/);
  assert.match(service, /startForeground/);
  assert.match(plugin, /PARTIAL_WAKE_LOCK/);
  assert.match(plugin, /holdLocks/);
});

test('Android releases CPU/Wi-Fi locks while screen-on and holds them only when background playback needs them', () => {
  const plugin = read('android/app/src/main/java/io/github/cloverscripts/muriel/MediaControlsPlugin.java');
  const manifest = read('android/app/src/main/AndroidManifest.xml');
  const controls = read('mobile/media-controls.js');
  assert.match(plugin, /pm\.isInteractive\(\)/);
  assert.match(plugin, /Intent\.ACTION_SCREEN_OFF/);
  assert.match(plugin, /if \(networkActive && screenOff\)/);
  assert.match(plugin, /releaseWakeLock\(\)/);
  assert.doesNotMatch(manifest, /REQUEST_IGNORE_BATTERY_OPTIMIZATIONS/);
  assert.doesNotMatch(controls, /MurielBackground/);
});

test('mobile build section-removal helper removes only the requested nested section', () => {
  const build = read('mobile/build.mjs');
  const start = build.indexOf('function removeElementById');
  const end = build.indexOf('const staticBottomNav', start);
  const helperSource = build.slice(start, end);
  const sandbox = {};
  vm.runInNewContext(`${helperSource}\nthis.removeElementById = removeElementById;`, sandbox);
  const html = '<main><section id="keep"><section id="sp-made-sec"><div>mix</div></section><p>keep</p></section></main>';
  const result = sandbox.removeElementById(html, 'section', 'sp-made-sec');
  assert.equal(result, '<main><section id="keep"><p>keep</p></section></main>');
});
