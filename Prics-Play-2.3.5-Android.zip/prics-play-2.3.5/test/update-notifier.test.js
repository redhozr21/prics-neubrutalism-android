'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'update-notifier.js'), 'utf8');
const HASH = 'a'.repeat(64);
const ASSET_URL = 'https://github.com/redhozr21/prics-neubrutalism-android/releases/download/v2.3.0/Prics-Play.apk';
const CHECKSUM_URL = `${ASSET_URL}.sha256`;

function element(initial = {}) {
  const listeners = {};
  const attributes = {};
  const classes = new Set();
  return {
    textContent: '',
    hidden: false,
    disabled: false,
    value: 0,
    listeners,
    attributes,
    classes,
    classList: {
      toggle(name, enabled) { if (enabled) classes.add(name); else classes.delete(name); },
      contains(name) { return classes.has(name); },
    },
    addEventListener(name, callback) { listeners[name] = callback; },
    setAttribute(name, value) { attributes[name] = String(value); },
    removeAttribute(name) { delete attributes[name]; },
    ...initial,
  };
}

function release({ tag = 'v2.3.0', assets, body } = {}) {
  return {
    draft: false,
    prerelease: false,
    html_url: 'https://github.com/redhozr21/prics-neubrutalism-android/releases/tag/v2.3.0',
    tag_name: tag,
    name: 'Prics Play v2.3.0',
    body: body ?? '<!-- prics-play-version: 2.3.0 --><!-- prics-play-build: 12 -->\nWhat is new in this release.',
    assets: assets ?? [{
      name: 'Prics-Play.apk',
      browser_download_url: ASSET_URL,
      digest: `sha256:${HASH}`,
      size: 10 * 1024 * 1024,
    }],
  };
}

function harness({
  publishedRelease = release(),
  installedVersion = '2.2.0',
  platform = 'android',
  nativePlugin = {},
} = {}) {
  const ids = [
    'update-status', 'btn-check-updates', 'about-version', 'update-details',
    'update-release-notes', 'update-progress-wrap', 'update-progress',
    'update-progress-label', 'btn-install-update',
  ];
  const elements = Object.fromEntries(ids.map((id) => [id, element()]));
  elements['update-details'].hidden = true;
  elements['update-progress-wrap'].hidden = true;
  elements['btn-install-update'].hidden = true;
  const opened = [];
  const storage = new Map();
  const defaultPlugin = {
    addListener: async () => ({ remove: async () => {} }),
    downloadApk: async () => ({ bytes: 10 * 1024 * 1024, sha256: HASH }),
    installApk: async () => ({ started: true }),
  };
  const window = {
    MURIEL_BUILD: { version: installedVersion, run: 0 },
    Capacitor: { getPlatform: () => platform, isNativePlatform: () => platform !== 'web' },
    PricsUpdate: { ...defaultPlugin, ...nativePlugin },
    PricsExternalUrl: { open: async (url) => { opened.push(url); } },
    location: { href: '' },
    open: (url) => { opened.push(url); },
  };
  const document = {
    hidden: false,
    getElementById: (id) => elements[id] || null,
    addEventListener() {},
  };
  const context = {
    window,
    document,
    localStorage: {
      getItem: (key) => storage.has(key) ? storage.get(key) : null,
      setItem: (key, value) => storage.set(key, String(value)),
    },
    fetch: async () => ({ ok: true, json: async () => publishedRelease }),
    AbortController,
    setTimeout: () => 1,
    clearTimeout() {},
    Date,
    Promise,
    Number,
    String,
    Math,
    RegExp,
    JSON,
    URL,
  };
  vm.runInNewContext(source, context, { filename: 'update-notifier.js' });
  return { window, document, elements, opened, storage };
}

test('version comparison is numeric and rejects non-semver labels', () => {
  const h = harness();
  const compare = h.window.PricsPlayUpdates.compareVersions;
  assert.equal(compare('2.10.0', '2.9.9'), 1);
  assert.equal(compare('2.3.0', '2.3.0'), 0);
  assert.equal(compare('2.2.9', '2.3.0'), -1);
  assert.equal(compare('latest', '2.3.0'), null);
  assert.equal(compare('v2.3.0', '2.2.0'), null);
});

test('latest stable release shows an update only for the official APK asset and a checksum', async () => {
  const h = harness();
  await h.window.PricsPlayUpdates.check();
  assert.match(h.elements['update-status'].textContent, /Update available: Prics Play 2\.3\.0/);
  assert.equal(h.elements['btn-check-updates'].textContent, 'Download update');
  assert.equal(h.elements['update-details'].hidden, false);
  assert.equal(h.elements['btn-install-update'].hidden, true);
  assert.match(h.elements['update-release-notes'].textContent, /What is new in this release/);
  assert.doesNotMatch(h.elements['update-release-notes'].textContent, /prics-play-build/);
});

test('release without a strict semantic version tag is blocked even if its title has a version', async () => {
  const h = harness({ publishedRelease: release({ tag: 'latest-release' }) });
  await h.window.PricsPlayUpdates.check();
  assert.match(h.elements['update-status'].textContent, /valid X\.Y\.Z version tag/);
  assert.equal(h.elements['btn-check-updates'].textContent, 'Check now');
  assert.equal(h.elements['update-details'].hidden, true);
});

test('debug or unrelated APK names are never selected for installation', async () => {
  const h = harness({ publishedRelease: release({ assets: [
    { name: 'app-debug.apk', browser_download_url: ASSET_URL, digest: `sha256:${HASH}` },
    { name: 'app-debug.apk.sha256', browser_download_url: CHECKSUM_URL },
  ] }) });
  await h.window.PricsPlayUpdates.check();
  assert.match(h.elements['update-status'].textContent, /release has no APK attached/);
  assert.equal(h.elements['btn-check-updates'].textContent, 'Check now');
  assert.equal(h.elements['btn-install-update'].hidden, true);
});

test('update download is blocked when neither the release digest nor checksum asset exists', async () => {
  const h = harness({ publishedRelease: release({ assets: [
    { name: 'Prics-Play.apk', browser_download_url: ASSET_URL, size: 1000 },
  ] }) });
  await h.window.PricsPlayUpdates.check();
  assert.match(h.elements['update-status'].textContent, /no SHA-256 checksum/);
  assert.equal(h.elements['btn-check-updates'].textContent, 'Check now');
});

test('checksum asset is accepted when the GitHub API does not expose an asset digest', async () => {
  const h = harness({ publishedRelease: release({ assets: [
    { name: 'Prics-Play.apk', browser_download_url: ASSET_URL, size: 1000 },
    { name: 'Prics-Play.apk.sha256', browser_download_url: CHECKSUM_URL, size: 80 },
  ] }) });
  await h.window.PricsPlayUpdates.check();
  assert.equal(h.elements['btn-check-updates'].textContent, 'Download update');
  let request;
  h.window.PricsUpdate.downloadApk = async (options) => {
    request = options;
    return { bytes: 1000, sha256: HASH };
  };
  await h.window.PricsPlayUpdates.downloadUpdate();
  assert.equal(request.checksumUrl, CHECKSUM_URL);
  assert.equal(request.sha256, '');
  assert.equal(h.elements['btn-install-update'].hidden, false);
});

test('verified download proceeds to the normal Android installer handoff', async () => {
  let installRequest;
  const h = harness({ nativePlugin: {
    downloadApk: async () => ({ bytes: 123456, sha256: HASH }),
    installApk: async (options) => { installRequest = options; return { started: true }; },
  } });
  await h.window.PricsPlayUpdates.check();
  await h.window.PricsPlayUpdates.downloadUpdate();
  assert.match(h.elements['update-status'].textContent, /downloaded and verified/);
  assert.equal(h.elements['update-progress'].value, 100);
  assert.equal(h.elements['btn-install-update'].hidden, false);
  await h.window.PricsPlayUpdates.installUpdate();
  assert.equal(installRequest.sha256, HASH);
  assert.match(h.elements['update-status'].textContent, /Android installer opened/);
});

test('a native download without a confirmed SHA-256 result cannot expose Install update', async () => {
  const h = harness({ nativePlugin: { downloadApk: async () => ({ bytes: 1000 }) } });
  await h.window.PricsPlayUpdates.check();
  await h.window.PricsPlayUpdates.downloadUpdate();
  assert.match(h.elements['update-status'].textContent, /download failed.*did not confirm APK checksum verification/i);
  assert.equal(h.elements['btn-install-update'].hidden, true);
});

test('web fallback opens the APK link externally instead of calling Android APIs', async () => {
  const h = harness({ platform: 'web' });
  await h.window.PricsPlayUpdates.check();
  await h.window.PricsPlayUpdates.downloadUpdate();
  assert.equal(h.opened[0], ASSET_URL);
});
