'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const root = path.resolve(__dirname, '..');
const selector = path.join(root, 'tools', 'select-source-archive.py');

function makeWorkspace() {
  const workspace = fs.mkdtempSync(path.join(os.tmpdir(), 'prics-source-selector-'));
  fs.writeFileSync(path.join(workspace, 'package.json'), JSON.stringify({ version: '2.3.0' }));
  const archive = path.join(workspace, 'Prics-Play-2.2.0-Android.zip');
  const py = String.raw`import json, sys, zipfile
with zipfile.ZipFile(sys.argv[1], 'w') as z:
  z.writestr('prics-play-2.2.0/package.json', json.dumps({'version':'2.2.0'}))
  z.writestr('prics-play-2.2.0/implementation.md', '# baseline')
`;
  execFileSync('python3', ['-c', py, archive]);
  return workspace;
}

test('checked-out 2.3.0 source outranks an older 2.2.0 archive', () => {
  const workspace = makeWorkspace();
  try {
    const output = execFileSync('python3', [selector], {
      cwd: workspace,
      env: { ...process.env, GITHUB_WORKSPACE: workspace, RUNNER_TEMP: path.join(workspace, 'runner-temp') },
      encoding: 'utf8',
    });
    assert.match(output, /Repository source 2\.3\.0 is newer than archived ZIP prics-play-2\.2\.0/);
    assert.match(output, new RegExp(`PRICS_SOURCE_DIR=${workspace.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`));
  } finally {
    fs.rmSync(workspace, { recursive: true, force: true });
  }
});
