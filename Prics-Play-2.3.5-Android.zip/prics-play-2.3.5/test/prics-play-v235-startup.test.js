'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');

test('Now Playing class helper does not write an unchanged class value', () => {
  const ui = read('mobile/mobile-ui.js');
  const start = ui.indexOf('const setPanelFullLyricsClass = (full) => {');
  assert.ok(start >= 0, 'guarded helper exists');
  const end = ui.indexOf('\n  };', start) + '\n  };'.length;
  assert.ok(end > start, 'helper block is complete');
  const helperSource = ui.slice(start, end);

  const classes = new Set();
  let attributeWrites = 0;
  const panel = {
    classList: {
      contains(name) { return classes.has(name); },
      toggle(name, force) {
        attributeWrites++;
        if (force) classes.add(name);
        else classes.delete(name);
      },
    },
  };
  const sandbox = { panel };
  vm.runInNewContext(`${helperSource}\nthis.setPanelFullLyricsClass = setPanelFullLyricsClass;`, sandbox);

  sandbox.setPanelFullLyricsClass(false);
  assert.equal(attributeWrites, 0, 'closed state must not rewrite the class attribute');
  sandbox.setPanelFullLyricsClass(true);
  assert.equal(attributeWrites, 1, 'entering full lyrics writes once');
  sandbox.setPanelFullLyricsClass(true);
  assert.equal(attributeWrites, 1, 'reapplying full lyrics does not write again');
  sandbox.setPanelFullLyricsClass(false);
  assert.equal(attributeWrites, 2, 'leaving full lyrics writes once');
  sandbox.setPanelFullLyricsClass(false);
  assert.equal(attributeWrites, 2, 'reapplying preview state does not write again');
});

test('MutationObserver sync does not mutate the observed class in a no-op closed state', () => {
  const ui = read('mobile/mobile-ui.js');
  const syncStart = ui.indexOf('const sync = () => {');
  const observerAt = ui.indexOf('new MutationObserver(sync).observe(panel', syncStart);
  const initialSyncAt = ui.indexOf('sync();', syncStart);
  assert.ok(syncStart >= 0 && observerAt > syncStart && initialSyncAt > syncStart);
  const syncSource = ui.slice(syncStart, observerAt);
  assert.match(syncSource, /setPanelFullLyricsClass\(false\)/);
  assert.doesNotMatch(syncSource, /panel\.classList\.remove\(['"]np-full-lyrics['"]\)/);
  assert.ok(initialSyncAt < observerAt, 'initial sync runs before observing panel class changes');
});

test('2.3.5 build refuses a signing key that does not match the installed 2.3.4 APK', () => {
  const expected = 'A31F0FE0D1C4F95C4D368432E12AE37591998BD8172086BFFACED9B731DACC2C';
  for (const file of ['.github/workflows/android.yml', '.github/workflows/build-apk.yml']) {
    const workflow = read(file);
    assert.ok(workflow.includes(expected), `${file} pins the 2.3.4 certificate fingerprint`);
    assert.match(workflow, /Signing certificate mismatch/);
    assert.match(workflow, /Refusing to build an APK/);
  }
});
