'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');

test('download page resolves releases from the Prics Play repository and stable Android APK asset', () => {
  const app = read('site/app.js');
  const html = read('site/index.html');
  assert.match(app, /const REPO = 'redhozr21\/prics-neubrutalism-android'/);
  assert.match(app, /x\.name === 'Prics-Play\.apk'/);
  assert.match(app, /x\.name === 'Prics-Play\.apk\.sha256'/);
  assert.doesNotMatch(app, /'android-latest': \{ file: 'Muriel\.apk'/);
  assert.match(html, /releases\/latest\/download\/Prics-Play\.apk/);
});

test('compact playlist share links redirect to the web player and legacy p= links remain supported', () => {
  const share = read('share-link.js');
  const site = read('site/app.js');
  assert.match(share, /const WEB = 'https:\/\/redhozr21\.github\.io\/prics-neubrutalism-android'/);
  assert.match(share, /const webLink = \(payload\) => `\$\{WEB\}#\$\{payload\}`/);
  assert.match(share, /tagged = \/\[#\?&\]p=/);
  assert.match(site, /const sharedPayload = location\.hash\.slice\(1\)/);
  assert.match(site, /basePath = location\.pathname\.replace/);
  assert.match(site, /target = new URL\(`\$\{basePath\}play\/`, location\.origin\)/);
});

test('sync and share pages use this repository Pages origin while keeping the muriel deep-link scheme', () => {
  assert.match(read('sync.js'), /https:\/\/redhozr21\.github\.io\/prics-neubrutalism-android\/link\.html/);
  assert.match(read('share-link.js'), /muriel:\/\/playlist\?p=/);
  assert.match(read('site/link.html'), /muriel:\/\/link\?code=/);
  assert.match(read('.github/workflows/pages.yml'), /'sync\.js'/);
});
