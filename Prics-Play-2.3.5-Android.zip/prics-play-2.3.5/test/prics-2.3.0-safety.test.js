'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');

test('native updater restricts downloads to versioned official APK/checksum assets', () => {
  const plugin = read('android/app/src/main/java/io/github/cloverscripts/muriel/PricsUpdatePlugin.java');
  assert.match(plugin, /RELEASE_ASSET_PATH = Pattern\.compile\("\^\/redhozr21\/prics-neubrutalism-android\/releases\/download/);
  assert.match(plugin, /Prics-Play\\\\\.apk\(\?:\\\\\.sha256\)\?/);
  assert.match(plugin, /url\.getPort\(\) == -1 \|\| url\.getPort\(\) == 443/);
  assert.match(plugin, /isApkAssetUrl\(assetUrl\)/);
  assert.match(plugin, /isChecksumAssetUrl\(checksumUrl\)/);
  assert.match(plugin, /actualHash\.equalsIgnoreCase\(expectedHash\)/);
  assert.match(plugin, /getContext\(\)\.getPackageName\(\)\.equals\(candidate\.packageName\)/);
  assert.match(plugin, /hasCompatibleSigningCertificate\(installed, candidate\)/);
});

test('Android installer handoff is user-confirmed and scoped to the private update cache', () => {
  const manifest = read('android/app/src/main/AndroidManifest.xml');
  const paths = read('android/app/src/main/res/xml/file_paths.xml');
  const plugin = read('android/app/src/main/java/io/github/cloverscripts/muriel/PricsUpdatePlugin.java');
  assert.match(manifest, /android\.permission\.REQUEST_INSTALL_PACKAGES/);
  assert.match(manifest, /androidx\.core\.content\.FileProvider/);
  assert.match(paths, /<cache-path name="update_apks" path="updates\/"\s*\/>/);
  assert.match(plugin, /Settings\.ACTION_MANAGE_UNKNOWN_APP_SOURCES/);
  assert.match(plugin, /Intent\.FLAG_GRANT_READ_URI_PERMISSION/);
  assert.doesNotMatch(plugin, /PackageInstaller\.Session/);
});

test('only the versioned Android workflow publishes releases and preserves the existing signing key', () => {
  const signedWorkflow = read('.github/workflows/android.yml');
  const debugWorkflow = read('.github/workflows/build-apk.yml');
  assert.match(signedWorkflow, /prics-play-debug-keystore-v1/);
  assert.match(signedWorkflow, /DEBUG_KEY_CACHE_HIT/);
  assert.match(signedWorkflow, /assembleDebug/);
  assert.doesNotMatch(signedWorkflow, /MURIEL_KEYSTORE_B64/);
  assert.match(signedWorkflow, /sha256sum Prics-Play\.apk > Prics-Play\.apk\.sha256/);
  assert.match(signedWorkflow, /gh release create/);
  assert.match(debugWorkflow, /contents: read/);
  assert.match(debugWorkflow, /Prics-Play-debug-apk/);
  assert.doesNotMatch(debugWorkflow, /gh release create/);
});
