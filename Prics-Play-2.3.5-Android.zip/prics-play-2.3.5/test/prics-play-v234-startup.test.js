'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = path.resolve(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');

test('2.3.4 retains the known-good 2.3.3 core files unchanged', () => {
  const expected = {
    'app.js': '83e49bb67239db647b3911535bc6293b253131a1e6dfd5c385bb3f565f3f4259',
    'mobile/build.mjs': '37340425f13f2f827161db993cb59ccf97d044c70f06a7e6b7895d678cb3f076',
    'mobile/bridge.js': '669262d13d0cb5c7529f073ae4a0a18898d3d37fd2c25b116158e7c9ab76a3f7',
    'mobile/neubrutalism.js': '4ca6f8cde9bea5d71db80774701d2cb04190bdea5ed6d38fc19eb59cb18b14d9',
    'android/app/src/main/java/io/github/cloverscripts/muriel/PlaybackService.java': '03fd918571c4e0417ab24277e1a3d5f29dce14ea9be4e0ceb01f91947291feea',
  };
  for (const [name, hash] of Object.entries(expected)) {
    const actual = crypto.createHash('sha256').update(fs.readFileSync(path.join(root, name))).digest('hex');
    assert.equal(actual, hash, `${name} must remain byte-for-byte identical to 2.3.3`);
  }
});

test('Now Playing DOM changes wait until app.js has dispatched muriel:ready', () => {
  const ui = read('mobile/mobile-ui.js');
  const block = ui.slice(ui.indexOf('const initializeNowPlaying'), ui.indexOf("// a write to the phone's storage failed"));
  assert.match(block, /window\.addEventListener\('muriel:ready', initializeNowPlaying, \{ once: true \}\)/);
  assert.match(block, /if \(window\.MurielCore\) initializeNowPlaying\(\)/);
  assert.match(block, /console\.error\('\[Prics Play\] Now Playing UI initialization failed:'/);
});

test('the original 2.3.3 audio-engine mobile override still runs before app startup', () => {
  const ui = read('mobile/mobile-ui.js');
  const override = ui.slice(0, ui.indexOf('const initializeNowPlaying'));
  assert.match(override, /Engine\.prototype\.init = function/);
  assert.match(override, /Engine\.prototype\._applyMasterVolume = function/);
});

test('debug APK workflow refuses to generate a replacement signing key', () => {
  const debug = read('.github/workflows/build-apk.yml');
  const release = read('.github/workflows/android.yml');
  assert.match(debug, /actions\/cache\/restore@v4/);
  assert.match(debug, /DEBUG_KEY_CACHE_HIT.*!= "true"/);
  assert.match(debug, /Refusing to generate a new debug certificate/);
  assert.match(release, /actions\/cache\/restore@v4/);
  assert.match(release, /DEBUG_KEY_CACHE_HIT.*!= "true"/);
});

test('the approved Now Playing screen and full lyrics styles are included', () => {
  const css = read('mobile/mobile.css');
  const ui = read('mobile/mobile-ui.js');
  assert.match(css, /Reference Now Playing screen/);
  assert.match(css, /#right-panel\.np-full-lyrics/);
  assert.match(ui, /np-lyrics-toggle/);
  assert.match(ui, /np-full-lyrics/);
  assert.match(ui, /Diputar di Android/);
});
