package io.github.cloverscripts.muriel;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.core.content.FileProvider;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Downloads a Prics Play APK into app-private cache, verifies its SHA-256 and package identity,
 * then opens Android's normal package installer after checking update compatibility.
 * Android user confirmation is always required; this plugin never silently installs an APK.
 */
@CapacitorPlugin(name = "PricsUpdate")
public class PricsUpdatePlugin extends Plugin {
    private static final String APK_MIME = "application/vnd.android.package-archive";
    private static final long MAX_APK_BYTES = 500L * 1024L * 1024L;
    private static final Pattern SHA_PATTERN = Pattern.compile("(?i)\\b([a-f0-9]{64})\\b");
    private static final Pattern RELEASE_ASSET_PATH = Pattern.compile("^/redhozr21/prics-neubrutalism-android/releases/download/v?\\d+\\.\\d+\\.\\d+/Prics-Play\\.apk(?:\\.sha256)?$");
    private static final Set<String> REDIRECT_HOSTS = new HashSet<String>() {{
        add("github.com");
        add("release-assets.githubusercontent.com");
        add("objects.githubusercontent.com");
        add("github-releases.githubusercontent.com");
    }};

    private final AtomicBoolean downloading = new AtomicBoolean(false);
    private final ExecutorService executor = Executors.newSingleThreadExecutor(runnable -> {
        Thread thread = new Thread(runnable, "prics-update");
        thread.setDaemon(true);
        return thread;
    });

    @PluginMethod
    public void downloadApk(PluginCall call) {
        final String assetUrl = call.getString("url", "");
        final String checksumUrl = call.getString("checksumUrl", "");
        final String suppliedHash = normalizeSha256(call.getString("sha256", ""));

        if (!isApkAssetUrl(assetUrl)) {
            call.reject("APK URL must be the official Prics-Play.apk asset from a versioned GitHub release.");
            return;
        }
        if (suppliedHash.isEmpty() && !isChecksumAssetUrl(checksumUrl)) {
            call.reject("This release does not provide a verifiable SHA-256 checksum.");
            return;
        }
        if (!downloading.compareAndSet(false, true)) {
            call.reject("An update download is already in progress.");
            return;
        }

        executor.execute(() -> {
            File partial = null;
            try {
                String expectedHash = suppliedHash.isEmpty() ? readChecksum(checksumUrl) : suppliedHash;
                if (expectedHash.isEmpty()) throw new IOException("The release checksum could not be read.");

                File updateDir = new File(getContext().getCacheDir(), "updates");
                if (!updateDir.exists() && !updateDir.mkdirs()) throw new IOException("Could not prepare the private update cache.");
                partial = new File(updateDir, "Prics-Play-update.apk.part");
                File target = new File(updateDir, "Prics-Play-update.apk");
                if (partial.exists() && !partial.delete()) throw new IOException("Could not clear an incomplete previous download.");

                HttpURLConnection connection = openTrusted(assetUrl);
                long contentLength = connection.getHeaderFieldLong("Content-Length", -1L);
                if (contentLength > MAX_APK_BYTES) {
                    connection.disconnect();
                    throw new IOException("APK is larger than the permitted 500 MB download limit.");
                }

                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                long received = 0L;
                long lastProgressAt = 0L;
                int lastPercent = -2;
                byte[] firstBytes = new byte[4];
                int firstCount = 0;
                try (InputStream input = connection.getInputStream(); FileOutputStream output = new FileOutputStream(partial)) {
                    byte[] buffer = new byte[64 * 1024];
                    int count;
                    while ((count = input.read(buffer)) != -1) {
                        received += count;
                        if (received > MAX_APK_BYTES) throw new IOException("APK exceeded the permitted 500 MB download limit.");
                        digest.update(buffer, 0, count);
                        output.write(buffer, 0, count);
                        if (firstCount < firstBytes.length) {
                            int copy = Math.min(firstBytes.length - firstCount, count);
                            System.arraycopy(buffer, 0, firstBytes, firstCount, copy);
                            firstCount += copy;
                        }
                        int percent = contentLength > 0 ? (int) Math.min(100L, (received * 100L) / contentLength) : -1;
                        long now = System.currentTimeMillis();
                        if (percent != lastPercent || now - lastProgressAt >= 250L) {
                            publishProgress(received, Math.max(0L, contentLength), percent);
                            lastPercent = percent;
                            lastProgressAt = now;
                        }
                    }
                    output.getFD().sync();
                } finally {
                    connection.disconnect();
                }

                if (received < 4 || firstBytes[0] != 0x50 || firstBytes[1] != 0x4b || firstBytes[2] != 0x03 || firstBytes[3] != 0x04) {
                    throw new IOException("The downloaded file is not a valid APK archive.");
                }
                String actualHash = toHex(digest.digest());
                if (!actualHash.equalsIgnoreCase(expectedHash)) {
                    throw new IOException("APK SHA-256 verification failed. The file was not kept for installation.");
                }
                if (target.exists() && !target.delete()) throw new IOException("Could not replace the previous temporary update file.");
                if (!partial.renameTo(target)) throw new IOException("Could not finalize the verified APK download.");
                partial = null;

                JSObject result = new JSObject();
                result.put("bytes", received);
                result.put("sha256", actualHash);
                result.put("fileName", target.getName());
                call.resolve(result);
                publishProgress(received, received, 100);
            } catch (Exception error) {
                if (partial != null && partial.exists()) partial.delete();
                call.reject(error.getMessage() == null ? "APK download failed." : error.getMessage(), error);
            } finally {
                downloading.set(false);
            }
        });
    }

    @PluginMethod
    public void installApk(PluginCall call) {
        final String expectedHash = normalizeSha256(call.getString("sha256", ""));
        if (expectedHash.isEmpty()) {
            call.reject("A verified SHA-256 value is required before installation.");
            return;
        }

        executor.execute(() -> {
            try {
                File apk = new File(new File(getContext().getCacheDir(), "updates"), "Prics-Play-update.apk");
                if (!apk.isFile() || apk.length() < 4) throw new IOException("No completed update APK is available. Download it again.");
                if (!expectedHash.equalsIgnoreCase(sha256File(apk))) throw new IOException("The cached APK no longer matches the verified checksum. Download it again.");

                PackageManager manager = getContext().getPackageManager();
                int flags = Build.VERSION.SDK_INT >= 28 ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES;
                PackageInfo installed = manager.getPackageInfo(getContext().getPackageName(), flags);
                PackageInfo candidate = manager.getPackageArchiveInfo(apk.getAbsolutePath(), flags);
                if (candidate == null || candidate.packageName == null) throw new IOException("Android could not inspect the downloaded APK.");
                if (!getContext().getPackageName().equals(candidate.packageName)) throw new IOException("The APK belongs to a different application and cannot update Prics Play.");
                if (versionCode(candidate) <= versionCode(installed)) throw new IOException("The downloaded APK is not newer than the installed application.");
                if (!hasCompatibleSigningCertificate(installed, candidate)) throw new IOException("The APK signing certificate does not match this installation. Update was blocked to protect your app data.");

                Activity activity = getActivity();
                if (activity == null) throw new IOException("The Android activity is not available to open the installer.");
                activity.runOnUiThread(() -> {
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !getContext().getPackageManager().canRequestPackageInstalls()) {
                            Intent settings = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                    Uri.parse("package:" + getContext().getPackageName()));
                            settings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            activity.startActivity(settings);
                            JSObject result = new JSObject();
                            result.put("permissionRequired", true);
                            call.resolve(result);
                            return;
                        }
                        Uri apkUri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", apk);
                        Intent installer = new Intent(Intent.ACTION_VIEW);
                        installer.setDataAndType(apkUri, APK_MIME);
                        installer.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                        activity.startActivity(installer);
                        JSObject result = new JSObject();
                        result.put("started", true);
                        call.resolve(result);
                    } catch (Exception error) {
                        call.reject(error.getMessage() == null ? "Could not open Android's package installer." : error.getMessage(), error);
                    }
                });
            } catch (Exception error) {
                call.reject(error.getMessage() == null ? "The APK could not be verified for installation." : error.getMessage(), error);
            }
        });
    }

    private void publishProgress(long received, long total, int percent) {
        JSObject progress = new JSObject();
        progress.put("receivedBytes", received);
        progress.put("totalBytes", total);
        progress.put("percent", percent);
        notifyListeners("downloadProgress", progress);
    }

    private String readChecksum(String checksumUrl) throws Exception {
        HttpURLConnection connection = openTrusted(checksumUrl);
        try (InputStream input = connection.getInputStream(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[1024];
            int count;
            while ((count = input.read(buffer)) != -1) {
                if (output.size() + count > 4096) throw new IOException("Checksum file is unexpectedly large.");
                output.write(buffer, 0, count);
            }
            Matcher matcher = SHA_PATTERN.matcher(output.toString("UTF-8"));
            if (!matcher.find()) throw new IOException("The release checksum file does not contain a SHA-256 value.");
            return matcher.group(1).toLowerCase(Locale.US);
        } finally {
            connection.disconnect();
        }
    }

    private HttpURLConnection openTrusted(String rawUrl) throws Exception {
        String current = rawUrl;
        for (int redirect = 0; redirect <= 5; redirect++) {
            if (redirect == 0) {
                if (!isReleaseAssetUrl(current)) throw new IOException("Only APK/checksum assets from the official Prics Play release are allowed.");
            } else if (!isAllowedRedirect(current)) {
                throw new IOException("The GitHub release redirected to an untrusted host.");
            }
            URL url = new URL(current);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("User-Agent", "Prics-Play-Android-Updater");
            connection.setRequestProperty("Accept", "application/octet-stream, text/plain;q=0.9, */*;q=0.8");
            int status = connection.getResponseCode();
            if (status == HttpURLConnection.HTTP_MOVED_PERM || status == HttpURLConnection.HTTP_MOVED_TEMP ||
                    status == HttpURLConnection.HTTP_SEE_OTHER || status == 307 || status == 308) {
                String location = connection.getHeaderField("Location");
                connection.disconnect();
                if (location == null || location.trim().isEmpty()) throw new IOException("GitHub returned a redirect without a destination.");
                current = new URL(url, location).toString();
                continue;
            }
            if (status != HttpURLConnection.HTTP_OK) {
                connection.disconnect();
                throw new IOException("GitHub asset download failed with HTTP " + status + ".");
            }
            return connection;
        }
        throw new IOException("Too many redirects while downloading the GitHub release asset.");
    }

    private boolean isApkAssetUrl(String raw) {
        try {
            URL url = new URL(raw);
            return isReleaseAssetUrl(raw) && url.getPath().endsWith("/Prics-Play.apk");
        } catch (Exception ignored) { return false; }
    }

    private boolean isChecksumAssetUrl(String raw) {
        try {
            URL url = new URL(raw);
            return isReleaseAssetUrl(raw) && url.getPath().endsWith("/Prics-Play.apk.sha256");
        } catch (Exception ignored) { return false; }
    }

    private boolean isReleaseAssetUrl(String raw) {
        try {
            URL url = new URL(raw);
            return "https".equalsIgnoreCase(url.getProtocol()) && "github.com".equalsIgnoreCase(url.getHost()) &&
                    (url.getPort() == -1 || url.getPort() == 443) && url.getUserInfo() == null && url.getPath() != null &&
                    RELEASE_ASSET_PATH.matcher(url.getPath()).matches();
        } catch (Exception ignored) { return false; }
    }

    private boolean isAllowedRedirect(String raw) {
        try {
            URL url = new URL(raw);
            return "https".equalsIgnoreCase(url.getProtocol()) && (url.getPort() == -1 || url.getPort() == 443) &&
                    url.getUserInfo() == null && REDIRECT_HOSTS.contains(url.getHost().toLowerCase(Locale.US));
        } catch (Exception ignored) { return false; }
    }

    private static String normalizeSha256(String raw) {
        if (raw == null) return "";
        String value = raw.trim().toLowerCase(Locale.US).replaceFirst("^sha256:", "");
        return value.matches("[a-f0-9]{64}") ? value : "";
    }

    private static String toHex(byte[] bytes) {
        StringBuilder result = new StringBuilder(bytes.length * 2);
        for (byte value : bytes) result.append(String.format(Locale.US, "%02x", value & 0xff));
        return result.toString();
    }

    private static String sha256File(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream input = new java.io.FileInputStream(file)) {
            byte[] buffer = new byte[64 * 1024];
            int count;
            while ((count = input.read(buffer)) != -1) digest.update(buffer, 0, count);
        }
        return toHex(digest.digest());
    }

    private static long versionCode(PackageInfo info) {
        return Build.VERSION.SDK_INT >= 28 ? info.getLongVersionCode() : info.versionCode;
    }

    private boolean hasCompatibleSigningCertificate(PackageInfo installed, PackageInfo candidate) {
        Set<String> installedSigners = currentSigners(installed);
        Set<String> candidateSigners = currentSigners(candidate);
        if (!installedSigners.isEmpty() && installedSigners.equals(candidateSigners)) return true;
        // Permit a legitimate Android signing-key rotation only when the candidate APK carries a lineage
        // proving the currently installed signer was part of its signing certificate history.
        if (Build.VERSION.SDK_INT >= 28 && candidate.signingInfo != null && !candidate.signingInfo.hasMultipleSigners()) {
            Set<String> history = signatureSet(candidate.signingInfo.getSigningCertificateHistory());
            return !installedSigners.isEmpty() && history.containsAll(installedSigners);
        }
        return false;
    }

    private Set<String> currentSigners(PackageInfo info) {
        if (Build.VERSION.SDK_INT >= 28 && info.signingInfo != null) return signatureSet(info.signingInfo.getApkContentsSigners());
        return signatureSet(info.signatures);
    }

    private static Set<String> signatureSet(Signature[] signatures) {
        Set<String> values = new HashSet<>();
        if (signatures != null) for (Signature signature : signatures) if (signature != null) values.add(signature.toCharsString());
        return values;
    }
}
