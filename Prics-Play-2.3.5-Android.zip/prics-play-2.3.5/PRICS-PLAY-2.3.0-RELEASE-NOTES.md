# Prics Play 2.3.0 — Release Notes

## In-app Android updater

- Check for a newer stable version from Settings → About → Updates.
- View the release notes and download progress inside Prics Play.
- Verify the APK with SHA-256 before showing the Install update action.
- Confirm the package ID, version code, and signing certificate before handing the APK to Android's installer.
- Android may ask for permission to install apps from Prics Play and always requires the user's confirmation. Updates are not installed silently.
- Releases without a verifiable checksum or the official `Prics-Play.apk` asset are blocked by the in-app Android updater.

## Liquid Glass layout

- Align the Home sections, cards, track rows, playlist detail, mini-player controls, progress indicator, and bottom navigation with the existing Neubrutalism layout geometry.
- Retain Liquid Glass translucent surfaces, blur, highlights, soft shadows, and rounded styling.

## Release pipeline

- Official GitHub Releases reuse the existing `prics-play-debug-keystore-v1` signing-key cache used by prior debug builds and include `Prics-Play.apk.sha256`. If that cache is unavailable, the workflow fails instead of generating a different key.
- The separate debug build workflow creates a workflow artifact only; the versioned release workflow publishes the checksum-verified APK without deleting earlier releases.
- The app keeps the existing Android application ID so a compatible, correctly signed APK can update the installed app without intentionally clearing its data.

## Verification note

The focused updater/source-selection/layout/native-safety tests passed 26/26. The full test suite passed 308/309; the single failure is the Electron-dependent library-import test because `electron` could not be installed after npm registry access timed out. The remaining tests passed 307/307 when that file was excluded. Mobile bundle/Android APK build, signing compatibility, physical installation, and visual screenshot comparison remain pending because dependency installation failed and the local environment has no configured Android SDK. Do not treat this source archive as a tested production APK until CI and device checks pass.
