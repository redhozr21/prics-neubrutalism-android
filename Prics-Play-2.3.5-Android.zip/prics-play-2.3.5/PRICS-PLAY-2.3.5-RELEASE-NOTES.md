# Prics Play 2.3.5 — Release Notes

## Startup freeze fixed
- Fixed a MutationObserver feedback loop in the mobile Now Playing screen.
- The player now changes the `np-full-lyrics` class only when the requested state differs.
- Initial Now Playing state synchronization runs before the class observer is attached.

## Preserved
- 2.3.3 application core, mobile bridge, native playback service and performance optimizations.
- 2.3.4 coral Now Playing design.
- Compact lyrics preview and expanded full-lyrics view.
- Existing Theme, Integrations, Storage, Profiles and About settings.

## Signing safety
- Android workflows verify the 2.3.4 APK's signing certificate fingerprint before building.
- Build stops if GitHub Actions restores a different or missing debug keystore.
- No automatic replacement signing key is generated.

## Validation
- APK comparison and Chromium observer regression test completed.
- Source regression tests and syntax checks are run as part of the hotfix audit.
- APK build and physical Android validation are still required before release.
