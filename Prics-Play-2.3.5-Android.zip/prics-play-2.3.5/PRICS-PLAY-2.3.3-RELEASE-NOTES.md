# Prics Play 2.3.3 — Release Notes

## Mobile cleanup
- Removed the Made for You / Daily Mix section from mobile Home.
- Removed Sync, Interface, Tracks, Advanced and Plugins from mobile Settings.
- Kept the screenshot Theme editor only: Neubrutalism/Liquid Glass, palette colors, presets and reset.
- Kept Integrations, Storage, Profiles and About.

## Battery and performance
- Disabled next-track prefetch on mobile.
- Forced mobile Performance Mode on.
- Stopped the visualizer timer when no visualizer is visible.
- Removed the mobile battery-optimization exemption prompt and permission.
- Android CPU wake lock is now screen-state aware: it is released while the screen is interactive and acquired for active playback when the screen is off.
- Wi-Fi lock is scoped to background track downloads while the screen is off.
- Background playback service, media session and notification controls are retained.

## Compatibility
- Existing application ID, bundle ID, signing identity, deep links, profile storage and music folders are unchanged.
- No local library, playlist, favourites, history or downloaded files are deleted.
- Desktop Sync and Daily Mix source remain available; this cleanup targets the mobile bundle.

## Validation
- 132/132 JavaScript/MJS/CJS syntax checks passed.
- 335/335 Node tests passed when excluding the Electron-only library import test file.
- Full suite: 336 passed, one failed because `electron` is not installed in the audit environment.
- Source-level mobile workload simulation passed.
- APK build and physical-device battery/thermal testing remain outstanding because Android SDK/ADB and project dependencies are unavailable in the build environment.
