# Prics Play 2.3.0 — Implementation Report

**Baseline:** Prics Play 2.2.0  
**Target:** Prics Play 2.3.0  
**Scope:** In-app APK updater and Liquid Glass layout parity  
**Result:** Source-level implementation is complete; release readiness is not yet proven because dependency installation and Android runtime/build verification are unavailable in this environment.

## 1. Work resumed and source preservation

The existing `prics-play-2.3.0-work` directory already contained the 2.3.0 version bump, initial updater UI, native updater plugin, Android manifest/FileProvider configuration, release checksum workflow, and a first pass at Liquid Glass geometry rules. The original 2.2.0 source directories were kept separate and were not overwritten. A compressed pre-resume snapshot was also created outside the project working directory before editing.

No Gradle, Node build, or archive process was running when work resumed. A dependency install attempt later timed out because npm registry requests failed with DNS error `EAI_AGAIN`; the stalled process was stopped and its incomplete `node_modules` directory removed.

## 2. In-app Android APK updater

### Implemented

- Uses the existing GitHub Releases API and rejects draft/prerelease releases.
- Requires a strict stable semantic version in the release tag rather than trusting a title or free-form release notes.
- Selects only the official `Prics-Play.apk` asset; debug or unrelated APK filenames are rejected.
- Accepts SHA-256 from the GitHub release asset digest or the matching `Prics-Play.apk.sha256` asset. A release without either checksum source cannot be downloaded through the in-app Android updater.
- Adds a progress UI, download state, release notes, a separate Install update action, retry/error states, and a browser fallback for non-Android use.
- Native Android download uses app-private cache, an explicit trusted-host redirect allowlist, connection/read timeouts, a 500 MB size cap, a ZIP/APK header check, and SHA-256 verification. Incomplete `.part` files are deleted on failure.
- Before invoking Android's installer, native code re-verifies the cached file's SHA-256, package/application ID, increasing `versionCode`, and signing-certificate compatibility. A signing mismatch blocks installation rather than risking the installed app's data.
- Uses `FileProvider` to grant read access to the private APK. If Android requires “install unknown apps” permission, the app opens the relevant Settings page and waits for the user to return and tap Install update again.
- Installation remains user-confirmed; no silent install is attempted or promised.

### Release pipeline safety

- `.github/workflows/android.yml` remains the only GitHub Release publisher and attaches both `Prics-Play.apk` and `Prics-Play.apk.sha256` to a permanent version tag. It reuses the existing `prics-play-debug-keystore-v1` cache used by the prior installed builds, and fails closed if that exact cache is unavailable rather than silently creating a new signing identity.
- `.github/workflows/build-apk.yml` now emits a debug-signed workflow artifact only. It does not create or modify GitHub Releases, preventing a second workflow from racing with the permanent versioned release.
- Fixed `tools/select-source-archive.py` semantic-version matching so checked-out source version `2.3.0` correctly outranks an older `2.2.0` archive. The explicit same-version archive remains preferred when present and validated.

### Signing constraint

The prior workflow supplied debug-signed APKs and cached the generated debug keystore as `prics-play-debug-keystore-v1`. The versioned release workflow now attempts to reuse that same key and deliberately stops if the cache is missing; it must not silently generate a replacement. This preserves compatibility with existing debug installs if the cached key is the same one they use. The native updater independently verifies the certificate and blocks any mismatch. This environment did not produce an APK, so the cache's availability in GitHub Actions and the certificate match against an installed device build remain unverified. This remains a debug/test distribution, not a Google Play production signing setup.

## 3. Liquid Glass layout parity

- Preserves Liquid Glass's translucent panels, blur, highlights, soft shadows, and rounded surface styling.
- Adds explicit geometry matching for the mobile top navigation, Home sections, quick tiles, cards, recommendation rows, playlist detail, mini-player controls, and bottom navigation.
- Corrects Liquid Glass track-row margin/width and mini-player progress-line inset/height to match the existing Neubrutalism layout rules.
- Adds source-level regression checks for the key shared dimensions and styles.

The workspace does not have a configured Android SDK or a usable browser rendering harness. Therefore, actual computed-style/bounding-box parity, screen captures at identical viewport sizes, reduced-transparency behavior on-device, and repeated live theme switching remain unverified. Source-level CSS assertions are not a substitute for those checks.

## 4. Test and build results

### Passed

The focused updater/source-selection/layout/native-safety command passed **26/26 tests**:

```bash
node --check update-notifier.js
node --test test/update-notifier.test.js test/select-source-archive.test.js test/mobile-neubrutalism.test.js test/prics-2.3.0-safety.test.js
```

Coverage includes numeric version comparison, strict release tags, official APK asset selection, missing checksum handling, checksum-asset fallback, successful mocked download/install handoff, refusal to expose Install update without a verified digest, source archive selection, Liquid Glass geometry assertions, and native updater safety guards.

### Blocked / not verified

- Full `npm test`: **308/309 tests passed**. The only failure is `test/library-import.test.js`, which cannot load the `electron` module because dependency installation is incomplete; it is not an updater or Liquid Glass test.
- Excluding the Electron-dependent `library-import.test.js` file, the remaining suite passed **307/307 tests**.
- `npm ci --no-audit --no-fund`: timed out while fetching dependencies; prior/current npm logs indicate registry DNS/network trouble (`EAI_AGAIN`). The stalled npm process was stopped and the partial `node_modules` directory created by the failed install was removed.
- `node --check` passed for the changed JavaScript and focused test files. Both Android workflow YAML files parsed successfully.
- `node mobile/build.mjs`, `npx cap sync android`, and the Android APK build remain unrun because dependencies could not be installed and no Android SDK is configured in this environment.
- Physical Android installer handoff, app-data preservation, background audio during update, signing-key compatibility, and visual screenshot comparison: not run.

## 5. Release gate

Source-level work is ready for CI validation, not for a claim of tested production release. Before publishing or installing over an existing app:

1. Run `npm ci`, `node mobile/build.mjs`, and `npx cap sync android` in a network-enabled build environment.
2. Run the full test suite and resolve any regression failures.
3. Confirm the existing `prics-play-debug-keystore-v1` Actions cache is available, then build the versioned APK using that exact signing identity.
4. Inspect package ID, `versionName=2.3.0`, monotonic `versionCode`, SHA-256, and signing certificate.
5. Test an update from a compatible previous APK on a physical Android device/emulator and confirm app data and playback state are preserved.
6. Capture both themes at the same viewport and compare bounding boxes, padding, gaps, safe areas, card/cover dimensions, text clipping, mini-player geometry, and bottom navigation.
7. Publish the permanent `v2.3.0` release only after these gates pass. Do not delete or replace historical releases or archives.


## Follow-up verification

- Revalidated the exact release ZIP after extraction: **307/307 tests passed** when excluding the single Electron-dependent `test/library-import.test.js` file. The complete suite remains **308/309 passed** because the `electron` module cannot be installed in this environment.
- A retry of `npm ci` remains blocked by network/DNS access to `registry.npmjs.org`; direct DNS/curl checks could not resolve the registry host. No partial `node_modules` directory remains.
