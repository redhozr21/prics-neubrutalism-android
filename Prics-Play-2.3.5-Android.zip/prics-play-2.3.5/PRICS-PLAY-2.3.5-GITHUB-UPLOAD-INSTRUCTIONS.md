# Prics Play 2.3.5 — GitHub Upload Instructions

This hotfix must be committed to the repository before building. The workflow files at the repository root are what GitHub Actions executes; changing only the workflow copies inside the source ZIP does not update those root workflows.

## Files to add/replace in `redhozr21/prics-neubrutalism-android`

1. Add `Prics-Play-2.3.5-Android.zip` to the repository root. Keep the previous 2.3.3 and 2.3.4 source ZIPs as history.
2. Replace the repository-root `.github/workflows/android.yml` with the file from this patch.
3. Replace the repository-root `.github/workflows/build-apk.yml` with the file from this patch.
4. Commit all three changes to `main`.

## What the workflows verify

Before Gradle builds an APK, both workflows restore `~/.android/debug.keystore` from the existing Actions cache and compare its SHA-256 certificate fingerprint with the uploaded 2.3.4 APK:

`A31F0FE0D1C4F95C4D368432E12AE37591998BD8172086BFFACED9B731DACC2C`

If the cache is missing or has a different certificate, the workflow stops. Do not remove the fingerprint guard and do not generate a new keystore. A mismatch means the signing key for the installed 2.3.4 APK has not been recovered.

## Build and installation

- The `android.yml` workflow should build version 2.3.5 and publish the new immutable `v2.3.5` release if the signing check passes.
- The `build-apk.yml` workflow uploads a test artifact and does not publish a release.
- Download the APK only from a successful run whose summary shows the expected signing fingerprint.
- Install it over the currently installed 2.3.4 app. Do not uninstall or clear app data.
- If Android reports a certificate mismatch, cancel installation and do not clear app data.

## Important

This build is compatible with the uploaded 2.3.4 APK signing certificate, not the uploaded 2.3.3 certificate. The 2.3.3 and 2.3.4 APKs use different debug signing keys.
