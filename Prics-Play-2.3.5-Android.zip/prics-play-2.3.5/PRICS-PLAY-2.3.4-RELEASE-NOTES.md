# Prics Play 2.3.4 — Rebuilt on the 2.3.3 Baseline

## Stability
- Rebuilt from the 2.3.3 source tree.
- Preserved the application core, mobile bridge, mobile build script, Neubrutalism layer and Android foreground playback service.
- Delayed Now Playing UI DOM changes until `muriel:ready`, after the app core has initialized.
- Added an error boundary around the optional Now Playing presentation layer.

## Now Playing
- Coral/red player surface based on the supplied reference.
- Large album artwork, title, artist, favorite and real playback controls.
- Compact lyric preview beneath the controls.
- Expandable full-lyrics mode.

## Preserved from 2.3.3
- Mobile Home and three-tab navigation.
- Settings cleanup and approved Theme controls.
- Integrations, Storage, Profiles and About.
- Existing playlists, favorites, history, offline files and profile data paths.
- Android foreground playback service and media controls.
- Previous performance optimizations.

## Signing safety
- Android debug workflows restore the existing keystore cache only.
- A missing cache causes the build to stop rather than generate a new signing certificate.
- Compare the new APK fingerprint with the installed 2.3.3 APK before installation.

## Validation
- 133/133 JS syntax checks passed.
- 340/340 Node tests passed (excluding the Electron-only library import test file).
- CSS, workflow YAML and XML parsing passed.
- APK build and physical-device test remain outstanding.
