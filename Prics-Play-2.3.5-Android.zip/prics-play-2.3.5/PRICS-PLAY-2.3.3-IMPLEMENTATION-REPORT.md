# Prics Play 2.3.3 — Mobile Slim & Performance Report

**Target:** Android/mobile build 2.3.3  
**Baseline:** Prics Play 2.3.2 source  
**Audit/implementation:** 31 October 2026  
**Code status:** Changes applied to source; no physical-device or APK validation  
**Scope:** Mobile Home cleanup, Settings reduction, mobile-only feature removal, idle/playback workload reduction, Android lock lifecycle.

## 1. Executive summary

Prics Play 2.3.3 reduces mobile-only background work and removes Settings sections that are not useful in the streamlined Android experience. The app keeps the existing audio element, local cache, playback server, playlist/library data, Android media session, foreground playback service, and lock-screen/notification controls.

The key battery-related native change is that the app no longer holds its own partial CPU wake lock while the display is interactive. It acquires the CPU wake lock only when the screen is off and playback/loading is active. The high-performance Wi-Fi lock is now limited to background track loading while the screen is off. The foreground media playback service remains in place.

This is a source-level optimization. It does **not** establish a measured battery percentage, mAh saving, temperature reduction, or real-device playback result.

## 2. Mobile UI cleanup

### Home
- Removed the `Made for You` / Daily Mix section from the generated mobile HTML before WebView first paint.
- Removed its refresh/generate card from the Android interface.
- The `renderMadeForYou()` code safely exits when the mobile section is absent, so it cannot start Daily Mix generation from mobile Home.
- Desktop source retains its existing Daily Mix implementation.
- The separate `For You` discovery area remains; it uses the existing `/api/discover` cache and is not the Daily Mix feature.

### Settings retained on mobile
- **Theme:** only the visual-theme selector and the Neubrutalism palette editor shown in the supplied screenshots.
  - Neubrutalism and Liquid Glass choices
  - Accent, background, card, text/outline and secondary colors
  - Pop, Bubblegum, Lime, Ocean and Night presets
  - Reset palette
- **Integrations:** Last.fm and playlist import integrations remain.
- **Storage:** offline library/cache, folders and backup/restore remain.
- **Profiles:** profile management remains.
- **About:** app information, update checker/installer, diagnostics and legal information remain.

### Settings removed from the mobile interface
- Interface (mobile-only UI controls now use fixed low-power defaults)
- Tracks
- Advanced
- Plugins
- Sync
- Settings search
- Legacy Theme controls for theme mode, hue/intensity, opacity, custom background, blur and home icon

The theme section keeps only the screenshot controls. The other desktop settings categories and their desktop source are not deleted.

## 3. Mobile-only feature trimming

- Device-to-device Sync scripts (`sync.js`, `sync-core.js`), PeerJS and QR-code vendor assets are no longer copied into the mobile bundle.
- The mobile Sync home invite and Settings category are omitted.
- Desktop Sync remains in the desktop source and desktop HTML.
- The mobile-only `Play in the background / ignore battery optimization` UI/API was removed, along with `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`. The app no longer encourages users to exempt it from Android battery optimization.
- Mobile streaming-quality and next-song-preload Settings rows were removed. Any previously saved source-quality preference is still respected by the extractor; new installations use the automatic default.
- Next-song prefetch is disabled on mobile regardless of any legacy `prics_mobile_prefetch_next` value. The next song is resolved when the user advances the queue; the current track still uses the existing cache-first playback flow.
- Existing Sync/profile/cache keys are not erased. No playlists, favourites, history, downloads or local files are deleted.

## 4. Performance changes

| Area | 2.3.3 mobile behavior |
|---|---|
| Daily Mix | Mobile Home section removed; no mobile generation request path |
| Sync | Sync scripts/vendor assets not shipped in mobile bundle |
| Next-track prefetch | Always disabled on mobile |
| Performance mode | Forced on for mobile to suppress decorative/high-cost effects |
| Visualizer scheduler | Stops when no visualizer canvas/effect is actually visible |
| Android CPU wake lock | Held only while screen is off and playback/loading is active |
| Android Wi-Fi lock | Held only for a background download while screen is off |
| Battery exemption | Permission, native request methods and Settings row removed |
| Foreground playback service | Retained while audio is playing |
| Media notification/session | Retained |
| Theme blur | Mobile remains on the existing no-backdrop-blur path |

### Android wake-lock lifecycle

`MediaControlsPlugin` registers for screen on/off broadcasts. While playback is active:
- Screen on: release the app-owned partial CPU wake lock and Wi-Fi lock.
- Screen off: acquire the partial CPU wake lock for playback.
- Screen off + track loading: acquire Wi-Fi lock while the download is active.
- Playback paused/stopped: release locks through the existing delayed-release/shutdown path.

This change preserves the foreground media service and background audio controls. It does not remove the CPU work required to decode and play audio.

## 5. Software workload simulation

Run:

```bash
node tools/simulate-mobile-power.mjs
```

Result in this environment: **PASS**. The script verifies source guards and prints three deterministic scenarios:

| Scenario | Daily Mix / Sync jobs | Audio stream | Next prefetch | App visualizer callbacks | App-owned wake lock |
|---|---:|---:|---:|---:|---|
| Idle Home, 15 min, fresh caches | 0 / 0 | 0 | 0 | 0 | No |
| Playback, 60 min, screen on, cached track | 0 / 0 | 1 | 0 | 0 | No |
| Playback, 60 min, screen locked, streaming track | 0 / 0 | 1 | 0 | 0 | CPU lock only screen-off; Wi-Fi lock only during download |

**Important:** this is a deterministic software-workload simulation, not a battery model. It does not estimate battery percentage or mAh and does not measure CPU/GPU temperature. Actual consumption still depends on the phone's audio codec, WebView/Android version, screen brightness, speaker/Bluetooth volume, radio signal and provider/network behavior. Discovery and chart endpoints may still fetch when their local caches are missing or stale.

## 6. Verification results

| Check | Result |
|---|---:|
| JavaScript/MJS/CJS syntax | 132/132 pass |
| Full Node test suite | 336 pass, 1 fail |
| Node tests excluding Electron-only `library-import.test.js` | 335/335 pass |
| Mobile trim-specific tests | 10/10 pass |
| Workload simulation | PASS |
| ZIP integrity | PASS (306 entries in final source archive) |
| `npm ci` / mobile bundle | Not run; `esbuild`/`node_modules` unavailable |
| Gradle/APK build | Not run; Android SDK/ADB unavailable |
| Java/Android compile | Not verified |
| Physical Android playback/battery/thermal test | Not run |

The one full-suite failure is `test/library-import.test.js`, which cannot load the `electron` module because project dependencies are not installed in this environment. It is unrelated to the mobile trim changes.

## 7. What remains unverified

- The native Java change has not been compiled against Android SDK in this environment.
- The APK has not been built or installed.
- Background playback after screen-off, Bluetooth/headset actions, incoming calls, pause/resume and long-duration playback still require device testing.
- No real battery or temperature comparison against 2.3.2 has been measured.

Before release, build the APK with the repository's Android GitHub Actions workflow, install it as an update over the previous version (do not uninstall), then run matched 2.3.2 vs 2.3.3 tests on the same device.

## 8. Compatibility safeguards

- Android application ID remains `io.github.cloverscripts.muriel`.
- iOS bundle identifier remains unchanged.
- Existing `muriel://` deep links and local storage/data directory names remain unchanged.
- No user library or downloaded audio files are deleted.
- Android media notification, foreground service and background playback path remain in place.
- Desktop source keeps its Sync and Daily Mix implementations; the trimming described here is applied to the mobile bundle.
