// Mobile layout behaviour: mini player <-> now-playing sheet, swipe to dismiss the sheet/cover,
// and the progress line on the mini player. The mini player itself uses explicit transport buttons.

// Background playback: iOS suspends Web Audio when the app is backgrounded or the screen locks,
// but keeps a plain <audio> element playing (and on the lock screen). So on iPhone the engine never
// routes the element through an AudioContext. Speed/pitch still work (they're element properties);
// EQ, reverb, distortion and the visualizer need the graph and are off. app.js builds the engine on
// DOMContentLoaded, which hasn't fired yet when this script runs.
(() => {
  // desktop's default text scale (1.25x) is sized for a monitor; phones start at 1.0x unless the user picked one
  if (!localStorage.getItem('muriel_font_scale')) localStorage.setItem('muriel_font_scale', '80');
  const Engine = window.MurielAudioEngine;
  if (!Engine) return;
  Engine.prototype.init = function (audioElement) { this.__element = audioElement || this.__element; };
  // iOS ignores element.volume (hardware buttons own it); mute still works
  Engine.prototype._applyMasterVolume = function () {
    if (this.__element) this.__element.muted = !!this.isMuted || this.volume === 0;
  };
})();

(() => {
  // app.js performs a multi-frame async startup and only emits muriel:ready after its
  // event handlers, playback state and navigation are initialized. Wait for that event
  // before moving any existing controls or adding the Now Playing UI. This keeps the
  // 2.3.3 startup path intact and prevents early DOM reparenting from racing app.js.
  const initializeNowPlaying = () => {
    try {

  const panel = document.getElementById('right-panel');
  const playbar = document.getElementById('playbar');
  const lyricsBtn = document.getElementById('btn-toggle-lyrics-panel');
  const audio = document.querySelector('audio');
  if (!panel || !playbar || !lyricsBtn) return;

  const drawerNow = document.getElementById('drawer-now');
  const drawerQueue = document.getElementById('drawer-queue');
  const lyricsSection = panel.querySelector('.lyrics-section');
  const playbarCenter = playbar.querySelector('.playbar-center');
  const playbarRight = playbar.querySelector('.playbar-right');

  // Build a dedicated Now Playing screen around the existing, stateful playback controls.
  // Moving the existing nodes keeps all app.js event handlers and audio/seek state intact.
  const topbar = document.createElement('div');
  topbar.className = 'np-topbar';
  topbar.innerHTML = `
    <button class="np-topbar-btn np-back" type="button" aria-label="Back" title="Back">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>
    </button>
    <div class="np-topbar-center">
      <span class="np-topbar-label">SEDANG DIPUTAR</span>
      <strong class="np-topbar-title"></strong>
      <small class="np-topbar-artist"></small>
    </div>
    <button class="np-topbar-btn np-more" type="button" aria-label="More options" aria-expanded="false" title="More options">
      <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/></svg>
    </button>`;
  panel.prepend(topbar);

  const moreMenu = document.createElement('div');
  moreMenu.className = 'np-more-menu';
  moreMenu.setAttribute('aria-hidden', 'true');
  const menuTools = panel.querySelector('.right-panel-header');
  if (menuTools) moreMenu.appendChild(menuTools);
  const menuActions = document.createElement('div');
  menuActions.className = 'np-menu-actions';
  ['btn-playbar-more', 'btn-edit-current-track', 'btn-playbar-share', 'btn-open-settings'].forEach((id) => {
    const node = document.getElementById(id);
    if (node) menuActions.appendChild(node);
  });
  const volumeGroup = playbar.querySelector('.volume-control-group');
  if (volumeGroup) menuActions.appendChild(volumeGroup);
  if (menuActions.children.length) moreMenu.appendChild(menuActions);
  panel.appendChild(moreMenu);

  const utilityRow = document.createElement('div');
  utilityRow.className = 'np-utility-row';
  utilityRow.innerHTML = `
    <span class="np-device-label"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="6" y="2.5" width="12" height="19" rx="2"/><path d="M10 18.5h4"/></svg><span>Diputar di Android</span></span>
    <span class="np-utility-spacer"></span>`;
  const queueButton = document.getElementById('btn-toggle-queue');
  if (queueButton) utilityRow.appendChild(queueButton);
  const deviceText = utilityRow.querySelector('.np-device-label span');
  if (deviceText) {
    const ua = navigator.userAgent || '';
    deviceText.textContent = /iPhone|iPad|iPod/i.test(ua) ? 'Diputar di iPhone' : 'Diputar di Android';
  }
  if (drawerNow && lyricsSection) drawerNow.insertBefore(utilityRow, lyricsSection);

  const lyricsHeader = lyricsSection && lyricsSection.querySelector('.lyrics-header');
  const lyricsToggle = document.createElement('button');
  lyricsToggle.className = 'np-lyrics-toggle';
  lyricsToggle.type = 'button';
  lyricsToggle.setAttribute('aria-expanded', 'false');
  lyricsToggle.innerHTML = `<span class="np-lyrics-heading">Lirik</span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 15 6-6 6 6"/></svg>`;
  if (lyricsHeader) lyricsHeader.appendChild(lyricsToggle);

  const lyricsEmpty = document.createElement('div');
  lyricsEmpty.className = 'np-no-lyrics';
  lyricsEmpty.textContent = 'Lirik belum tersedia untuk lagu ini';
  if (lyricsSection) lyricsSection.appendChild(lyricsEmpty);

  const closeSheet = () => { if (!panel.classList.contains('hidden')) document.getElementById('btn-close-right-panel').click(); };
  const openSheet = () => { if (panel.classList.contains('hidden')) lyricsBtn.click(); };

  // This class is observed by sync() below. Only write the class attribute when its
  // state actually changes; a no-op classList.remove/toggle can still emit a mutation
  // record in WebView and recursively retrigger the observer forever.
  const setPanelFullLyricsClass = (full) => {
    const shouldBeFull = !!full;
    if (panel.classList.contains('np-full-lyrics') !== shouldBeFull) {
      panel.classList.toggle('np-full-lyrics', shouldBeFull);
    }
  };

  const setFullLyrics = (full) => {
    setPanelFullLyricsClass(full);
    lyricsToggle.setAttribute('aria-expanded', String(!!full));
    lyricsToggle.querySelector('.np-lyrics-heading').textContent = full ? 'Lirik Penuh' : 'Lirik';
    lyricsToggle.querySelector('svg').innerHTML = full ? '<path d="m6 15 6-6 6 6"/>' : '<path d="m6 9 6 6 6-6"/>';
    if (full) {
      const container = document.getElementById('lyrics-container');
      if (container) container.scrollTop = 0;
    }
    requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
  };
  lyricsToggle.addEventListener('click', () => { if (!panel.classList.contains('lyrics-empty')) setFullLyrics(!panel.classList.contains('np-full-lyrics')); });
  if (lyricsHeader) lyricsHeader.addEventListener('click', (event) => {
    if (event.target.closest('.np-lyrics-toggle') || panel.classList.contains('lyrics-empty')) return;
    setFullLyrics(!panel.classList.contains('np-full-lyrics'));
  });
  if (lyricsSection) lyricsSection.addEventListener('click', (event) => {
    if (panel.classList.contains('np-full-lyrics') || event.target.closest('.lyric-line, .lyrics-action-btn')) return;
    if (event.target.closest('.lyrics-container')) setFullLyrics(true);
  });

  const backButton = topbar.querySelector('.np-back');
  backButton.addEventListener('click', () => {
    if (panel.classList.contains('np-full-lyrics')) {
      setFullLyrics(false);
    } else if (drawerQueue && !drawerQueue.classList.contains('hidden')) {
      const nowTab = panel.querySelector('.drawer-tab[data-drawer-tab="now"]');
      if (nowTab) nowTab.click();
    } else closeSheet();
  });
  const moreButton = topbar.querySelector('.np-more');
  const closeMore = () => {
    moreMenu.classList.remove('open');
    moreMenu.setAttribute('aria-hidden', 'true');
    moreButton.setAttribute('aria-expanded', 'false');
  };
  moreButton.addEventListener('click', () => {
    const open = !moreMenu.classList.contains('open');
    moreMenu.classList.toggle('open', open);
    moreMenu.setAttribute('aria-hidden', String(!open));
    moreButton.setAttribute('aria-expanded', String(open));
  });
  moreMenu.addEventListener('click', (event) => { if (event.target.closest('button')) closeMore(); });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeMore(); });

  const titleNode = document.getElementById('right-panel-title');
  const artistNode = document.getElementById('right-panel-artist');
  const topTitle = topbar.querySelector('.np-topbar-title');
  const topArtist = topbar.querySelector('.np-topbar-artist');
  let lastTopbarTrack = '';
  const syncTopbarMeta = () => {
    const nextTitle = titleNode ? (titleNode.textContent || '') : '';
    const nextArtist = artistNode ? (artistNode.textContent || '') : '';
    const trackKey = `${nextTitle}::${nextArtist}`;
    if (lastTopbarTrack && trackKey !== lastTopbarTrack && panel.classList.contains('np-full-lyrics')) setFullLyrics(false);
    lastTopbarTrack = trackKey;
    if (topTitle) topTitle.textContent = nextTitle;
    if (topArtist) topArtist.textContent = nextArtist;
  };
  if (titleNode) new MutationObserver(syncTopbarMeta).observe(titleNode, { childList: true, characterData: true, subtree: true });
  if (artistNode) new MutationObserver(syncTopbarMeta).observe(artistNode, { childList: true, characterData: true, subtree: true });
  syncTopbarMeta();

  // Reparent the real controls only while the mobile Now Playing screen is open. On close,
  // restore their original place in the mini-player so the compact player remains functional.
  let wasOpen = false;
  const sync = () => {
    const open = !panel.classList.contains('hidden');
    document.body.classList.toggle('np-open', open);
    if (open) {
      if (playbarCenter && drawerNow && playbarCenter.parentElement !== drawerNow && utilityRow) drawerNow.insertBefore(playbarCenter, utilityRow);
      if (!wasOpen) setFullLyrics(false);
    } else {
      if (playbarCenter && playbarCenter.parentElement !== playbar && playbarRight) playbar.insertBefore(playbarCenter, playbarRight);
      setPanelFullLyricsClass(false);
      closeMore();
      if (wasOpen) requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
    }
    wasOpen = open;
  };
  // Run the initial closed/open state sync before observing the class attribute.
  // Future observer callbacks are safe because sync() only changes np-full-lyrics
  // when the requested state differs from the current state.
  sync();
  new MutationObserver(sync).observe(panel, { attributes: true, attributeFilter: ['class'] });

  // tapping the mini player (but not its buttons) opens the sheet
  playbar.addEventListener('click', (e) => {
    if (document.body.classList.contains('np-open')) return;
    if (e.target.closest('button, input, .scrubber-track-container')) return;
    openSheet();
  });

  // swipe down on the sheet's top area to close it
  let startY = null;
  panel.addEventListener('touchstart', (e) => {
    const t = e.touches[0];
    const lyrics = document.getElementById('lyrics-container');
    startY = (lyrics && lyrics.contains(e.target) && lyrics.scrollTop > 0) ? null : t.clientY;
  }, { passive: true });
  // one transform write per frame, and no CSS transition while the finger drags (it lagged behind)
  let dragY = 0, dragRaf = 0;
  panel.addEventListener('touchmove', (e) => {
    if (startY === null) return;
    dragY = Math.max(0, e.touches[0].clientY - startY);
    if (dragY > 0 && !panel.classList.contains('is-dragging')) panel.classList.add('is-dragging');
    if (!dragRaf) dragRaf = requestAnimationFrame(() => { dragRaf = 0; if (startY !== null) panel.style.transform = dragY > 0 ? `translateY(${dragY}px)` : ''; });
  }, { passive: true });
  panel.addEventListener('touchend', (e) => {
    if (startY === null) return;
    const dy = e.changedTouches[0].clientY - startY;
    if (dragRaf) { cancelAnimationFrame(dragRaf); dragRaf = 0; }
    panel.classList.remove('is-dragging');
    panel.style.transform = '';
    startY = null;
    if (dy > 110) closeSheet();
  });

  // Picked images and videos (background, banner, song covers) are saved as file URLs, and those change when
  // iOS moves the app container (every update or reinstall). Rebuild each saved one from its file name, then
  // delete picks nothing uses any more (every pick is a new copy). Only the background was repaired before,
  // and picking a song cover made even that repair forget the background.
  const fixPickedMedia = async () => {
    const api = window.electronAPI;
    if (!api.fileUrl) return;
    const nameOf = (u) => { const m = typeof u === 'string' && !u.startsWith('blob:') && u.match(/\/backgrounds\/(bg_[\w.-]+)$/); return m ? m[1] : null; };
    const keep = new Set();
    const fresh = async (u) => {
      const name = nameOf(u);
      if (!name) return u;
      const url = await api.fileUrl(`/data/backgrounds/${name}`);
      if (url) keep.add(name);
      return url || u;
    };
    let bgChanged = false;
    for (const key of ['muriel_bg_url', 'muriel_banner_media', 'muriel_app_icon']) {
      const cur = localStorage.getItem(key);
      if (!cur) continue;
      const next = await fresh(cur);
      if (next !== cur) { localStorage.setItem(key, next); if (key === 'muriel_bg_url') bgChanged = true; }
    }
    let artOk = true;
    try {
      const art = JSON.parse(localStorage.getItem('muriel_track_art') || '{}');
      let dirty = false;
      for (const v of Object.values(art)) {
        for (const f of ['cover', 'banner']) {
          if (!v || !v[f]) continue;
          const next = await fresh(v[f]);
          if (next !== v[f]) { v[f] = next; dirty = true; }
        }
      }
      if (dirty) localStorage.setItem('muriel_track_art', JSON.stringify(art));
    } catch (e) { artOk = false; }
    localStorage.removeItem('muriel_bg_vpath');
    if (bgChanged) window.MurielCore.refreshBackground();
    if (artOk && api.pruneMedia) api.pruneMedia(keep);
  };
  if (window.MurielCore) fixPickedMedia(); else window.addEventListener('muriel:ready', fixPickedMedia, { once: true });

  // phones default to word-by-word karaoke (the Line/Word button still switches)
  const preferWordLyrics = () => {
    const st = window.MurielCore && window.MurielCore.state;
    const btn = document.getElementById('btn-lyrics-mode');
    if (st && btn && st.lyricsMode === 'line' && localStorage.getItem('muriel_adv_karaoke_words') !== 'false') btn.click();
  };
  if (window.MurielCore) preferWordLyrics(); else window.addEventListener('muriel:ready', preferWordLyrics, { once: true });

  // lyrics tools (edit / sync / translate / fullscreen) move up next to the Line/Word button,
  // so the lyrics get that row back; same buttons, so their handlers keep working
  const tools = panel.querySelector('.lyrics-header-actions');
  const topRow = panel.querySelector('.right-panel-header-actions');
  if (tools && topRow) { topRow.prepend(tools); tools.classList.add('np-tools-moved'); }

  // like button next to the title in Now Playing (the player bar's heart is hidden on phones);
  // it presses the real one and mirrors its state
  const realFav = document.getElementById('btn-toggle-fav');
  const favIcon = document.getElementById('fav-icon');
  const titleRow = panel.querySelector('.right-panel-title-row');
  if (realFav && favIcon && titleRow) {
    const like = document.createElement('button');
    like.id = 'np-like';
    like.type = 'button';
    like.setAttribute('data-i18n-attr', 'aria-label');
    like.setAttribute('aria-label', 'Like');
    like.innerHTML = favIcon.outerHTML.replace('id="fav-icon"', '');
    const mirror = () => { const on = favIcon.getAttribute('fill') === 'currentColor'; like.classList.toggle('on', on); like.querySelector('svg').setAttribute('fill', on ? 'currentColor' : 'none'); };
    like.addEventListener('click', () => {
      realFav.click();
      like.classList.remove('pop'); void like.offsetWidth; like.classList.add('pop');
      if (navigator.vibrate) navigator.vibrate(12);
    });
    new MutationObserver(mirror).observe(favIcon, { attributes: true, attributeFilter: ['fill'] });
    titleRow.appendChild(like);
    mirror();
  }

  // slowly drifting colour glow behind Now Playing (cover colours, plain gradients: cheap to draw)
  const ambient = document.createElement('div');
  ambient.className = 'np-ambient';
  ambient.innerHTML = '<i></i><i></i><i></i>';
  panel.prepend(ambient);

  // swipe the cover left/right to skip, with the cover following your finger
  const cover = document.getElementById('cover-container');
  if (cover) {
    let x0 = null, y0 = null, dx = 0, horizontal = null;
    cover.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; dx = 0; horizontal = null; cover.style.transition = 'none'; }, { passive: true });
    cover.addEventListener('touchmove', (e) => {
      if (x0 === null) return;
      dx = e.touches[0].clientX - x0;
      const dy = e.touches[0].clientY - y0;
      if (horizontal === null && (Math.abs(dx) > 8 || Math.abs(dy) > 8)) horizontal = Math.abs(dx) > Math.abs(dy);
      if (horizontal) cover.style.transform = `translateX(${dx}px) rotate(${dx / 40}deg)`;
    }, { passive: true });
    cover.addEventListener('touchend', () => {
      if (x0 === null) return;
      x0 = null;
      cover.style.transition = 'transform .32s cubic-bezier(.2,.8,.2,1), opacity .32s';
      if (horizontal && Math.abs(dx) > 70) {
        const dir = dx < 0 ? -1 : 1;
        cover.style.transform = `translateX(${dir * window.innerWidth}px) rotate(${dir * 12}deg)`;
        cover.style.opacity = '0';
        if (navigator.vibrate) navigator.vibrate(10);
        setTimeout(() => {
          if (dir < 0) document.getElementById('btn-next').click(); else document.getElementById('btn-prev').click();
          cover.style.transition = 'none';
          cover.style.transform = `translateX(${-dir * 60}px)`;
          requestAnimationFrame(() => { cover.style.transition = 'transform .38s cubic-bezier(.2,.8,.2,1), opacity .38s'; cover.style.transform = ''; cover.style.opacity = ''; });
        }, 220);
      } else {
        cover.style.transform = '';
      }
    });
  }

  // mini player progress line
  if (audio) {
    const tick = () => {
      if (document.hidden) return;
      const p = audio.duration ? audio.currentTime / audio.duration : 0;
      playbar.style.setProperty('--mini-progress', String(Math.max(0, Math.min(1, p))));
    };
    audio.addEventListener('timeupdate', tick);
    audio.addEventListener('emptied', tick);
    document.addEventListener('visibilitychange', tick);
  }

  // phone-only settings: the song storage limit (Storage → Offline songs) and sharing the error log (About)
  const storageGroup = document.querySelector('.settings-section[data-cat="storage"] .m3-group[data-group="offline"]') || document.querySelector('.settings-section[data-cat="storage"] .m3-group');
  const aboutGroup = document.querySelector('.settings-section[data-cat="about"] .m3-group');
  if (storageGroup) {
    const limits = [['256', '256 MB'], ['512', '512 MB'], ['1024', '1 GB'], ['2048', '2 GB'], ['5120', '5 GB'], ['10240', '10 GB']];
    const current = localStorage.getItem('muriel_cache_limit_mb') || '512';
    const limitRow = document.createElement('div');
    limitRow.className = 'setting-item';
    limitRow.innerHTML = `
      <div class="setting-item-top" style="align-items: center;">
        <div style="display: flex; flex-direction: column; gap: 2px;">
          <span class="setting-name" data-i18n>Song storage limit</span>
          <span style="font-size: calc(12px * var(--font-scale, 1)); color: var(--md-sys-color-outline);" data-i18n>Songs you play are kept for offline use (512 MB by default). Over this limit, the ones played longest ago are removed.</span>
        </div>
      </div>
      <div class="theme-mode-toggle" style="margin-top: 10px;">
        ${limits.map(([v, l]) => `<button class="fps-cap-btn${v === current ? ' active' : ''}" data-limit="${v}">${l}</button>`).join('')}
      </div>`;
    limitRow.querySelectorAll('[data-limit]').forEach((b) => b.addEventListener('click', () => {
      localStorage.setItem('muriel_cache_limit_mb', b.dataset.limit);
      limitRow.querySelectorAll('[data-limit]').forEach((x) => x.classList.toggle('active', x === b));
      // a lower limit applies now, not only after the next download
      if (window.MurielCache) window.MurielCache.enforceLimit();
    }));
    const logRow = document.createElement('div');
    logRow.className = 'setting-item';
    logRow.innerHTML = `
      <div class="setting-item-top" style="align-items: center;">
        <div style="display: flex; flex-direction: column; gap: 2px;">
          <span class="setting-name" data-i18n>Share error log</span>
          <span style="font-size: calc(12px * var(--font-scale, 1)); color: var(--md-sys-color-outline);" data-i18n>If something breaks, send this so it can be fixed.</span>
        </div>
        <button class="btn-pill-primary" type="button" data-i18n>Share</button>
      </div>`;
    logRow.querySelector('button').addEventListener('click', async () => {
      const res = await window.electronAPI.shareText('Prics Play error log', window.MurielLog ? window.MurielLog.text() : 'no log');
      if (res === 'copied' && window.MurielCore) window.MurielCore.toast((window.MurielI18n || { T: (x) => x, Tm: (x) => x }).Tm('Log copied to clipboard'), 'info');
    });
    storageGroup.append(limitRow);
    if (aboutGroup) aboutGroup.insertBefore(logRow, aboutGroup.lastElementChild); else storageGroup.append(logRow);
  }

  // the desktop placeholder doesn't fit beside the source buttons on a phone
  const searchInput = document.getElementById('search-input');
  if (searchInput) { searchInput.setAttribute('data-i18n-attr', 'placeholder'); searchInput.placeholder = 'Search songs, artists…'; }

  // settings that only make sense on desktop
  ['btn-hw-accel', 'btn-tray-on-close', 'btn-media-keys'].forEach((id) => {
    const row = document.getElementById(id) && document.getElementById(id).closest('.setting-item');
    if (row) row.style.display = 'none';
  });

    } catch (error) {
      console.error('[Prics Play] Now Playing UI initialization failed:', error);
    }
  };
  if (window.MurielCore) initializeNowPlaying();
  else window.addEventListener('muriel:ready', initializeNowPlaying, { once: true });
})();

// a write to the phone's storage failed (usually: storage full); say so instead of losing it silently
(() => {
  let last = 0;
  window.addEventListener('muriel:storage-error', () => {
    if (Date.now() - last < 30000 || !window.MurielCore || !window.MurielCore.toast) return;
    last = Date.now();
    window.MurielCore.toast((window.MurielI18n || { T: (x) => x, Tm: (x) => x }).Tm('Could not save to storage. Is your phone full?'), 'error');
  });
})();
