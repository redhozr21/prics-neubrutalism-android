'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');

test('legacy six-item navigation and plugin warning are hidden globally on mobile', () => {
  const css = read('mobile/mobile.css');
  assert.match(css, /html\.is-mobile \.neo-sidebar > \.sidebar-nav,[\s\S]*?display: none !important/);
  assert.match(css, /html\.is-mobile \.neo-sidebar > \.rail-action-group[\s\S]*?display: none !important/);
  assert.match(css, /settings-section\[data-cat="plugins"\] \.ct-head > div:first-child > \.setting-hint[\s\S]*?display: none !important/);
});

test('four-tab bottom navigation geometry is global, not limited to Neubrutalism', () => {
  const css = read('mobile/mobile.css');
  const start = css.indexOf('PRICS GLOBAL STRUCTURE FIX (all three themes)');
  assert.ok(start >= 0);
  const globalCss = css.slice(start);
  assert.match(globalCss, /html\.is-mobile \.neo-bottom-nav[\s\S]*?display: grid !important/);
  assert.match(globalCss, /grid-template-columns: repeat\(4, minmax\(0, 1fr\)\) !important/);
  assert.match(globalCss, /html\.is-mobile \.neo-bottom-nav \.neo-tab[\s\S]*?pointer-events: auto !important/);
  assert.match(globalCss, /html\.is-mobile\[data-ui-style="liquid-glass"\] \.neo-bottom-nav[\s\S]*?backdrop-filter: blur\(16px\)/);
  assert.match(globalCss, /html\.is-mobile\[data-ui-style="spotify-standard"\] \.neo-bottom-nav \{ background: #181818/);
});

test('Prics P logo is styled in all mobile UI styles', () => {
  const css = read('mobile/mobile.css');
  assert.match(css, /html\.is-mobile \.titlebar \.logo-star\.prics-logo \.logo-bg[\s\S]*?fill: var\(--neo-accent/);
  assert.match(css, /html\.is-mobile \.titlebar \.logo-star\.prics-logo \.logo-letter[\s\S]*?fill: var\(--neo-ink/);
});

test('Home contains visible static fallback content and retains the app-owned legacy DOM', () => {
  const html = read('index.html');
  const css = read('mobile/mobile.css');
  const app = read('app.js');
  assert.match(html, /id="home-hero"/);
  assert.match(html, /id="section-my-wave"/);
  assert.match(html, /id="sp-quick-sec"[\s\S]*?Liked songs/);
  assert.match(html, /id="sp-trend-sec"[\s\S]*?Trending tracks will appear/);
  assert.match(html, /id="section-home-playlists"[\s\S]*?Your playlists/);
  assert.match(css, /body\.home-spotify #home-hero,[\s\S]*?display: contents !important/);
  assert.match(css, /body\.home-spotify :is\(#section-my-wave, #section-jump-back, #home-hero-dots\)[\s\S]*?display: none !important/);
  assert.match(app, /window\.PricsEnsureHomeContent = \(\) =>/);
});
