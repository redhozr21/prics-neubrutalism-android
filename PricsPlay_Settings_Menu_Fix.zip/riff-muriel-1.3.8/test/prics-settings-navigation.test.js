'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');

test('mobile Settings always enters the top-level category list independent of matchMedia', () => {
  const app = read('app.js');
  assert.match(app, /const isMobileSettings = \(\) => document\.documentElement\.classList\.contains\('is-mobile'\) \|\| settingsNarrow\.matches/);
  assert.match(app, /function enterSettings\(\) \{[\s\S]*?if \(isMobileSettings\(\)\) \{[\s\S]*?showSettingsCategory\(last\);[\s\S]*?showSettingsList\(\);[\s\S]*?return;/);
  assert.match(app, /window\.PricsShowSettingsList = showSettingsList/);
});

test('mobile Settings tab explicitly returns to the top-level list when already on Settings', () => {
  const mobile = read('mobile/neubrutalism.js');
  assert.match(mobile, /bindTab\('settings',[\s\S]*?clickExisting\('nav-settings', 'view-settings'\);[\s\S]*?window\.PricsShowSettingsList\?\.\(\)/);
});

test('mobile Settings category buttons are normalized into the requested order after module mount', () => {
  const mobile = read('mobile/neubrutalism.js');
  assert.match(mobile, /function normalizeMobileSettingsMenu\(\)[\s\S]*?const order = \['interface', 'theme', 'tracks', 'integrations', 'profiles', 'sync', 'storage', 'advanced', 'about'\]/);
  assert.match(mobile, /normalizeMobileSettingsMenu\(\)/);
});

test('mobile category menu shows requested order and hides Plugins navigation entry', () => {
  const html = read('index.html');
  const profiles = read('profiles.js');
  const sync = read('sync.js');
  const css = read('mobile/mobile.css');
  const mainNav = html.slice(html.indexOf('<nav class="settings-nav"'), html.indexOf('</nav>', html.indexOf('<nav class="settings-nav"')));
  assert.match(mainNav, /data-cat="interface"[\s\S]*?data-cat="theme"[\s\S]*?data-cat="tracks"[\s\S]*?data-cat="integrations"[\s\S]*?data-cat="storage"[\s\S]*?data-cat="advanced"[\s\S]*?data-cat="plugins"[\s\S]*?data-cat="about"/);
  assert.match(profiles, /nav\.insertBefore\(btn, nav\.querySelector\('\[data-cat="sync"\]'\) \|\| nav\.querySelector\('\[data-cat="storage"\]'\)/);
  assert.match(sync, /nav\.insertBefore\(btn, nav\.querySelector\('\[data-cat="storage"\]'\)/);
  assert.match(css, /html\.is-mobile #view-settings #settings-nav > \.settings-nav-btn\[data-cat="plugins"\] \{ display: none !important; \}/);
  assert.match(css, /html\.is-mobile #view-settings\.settings-at-list:not\(\.settings-searching\) \.settings-pane \{ display: none !important; \}/);
  assert.match(css, /html\.is-mobile #view-settings:not\(\.settings-at-list\):not\(\.settings-searching\) \.settings-pane-head \{ display: flex !important; \}/);
});

test('back button returns to list and hides category panes until a category is selected', () => {
  const app = read('app.js');
  assert.match(app, /function showSettingsList\(\) \{[\s\S]*?settingsView\.classList\.add\('settings-at-list'\);[\s\S]*?settings-section'\)\.forEach\(\(section\) => section\.classList\.add\('cat-hidden'\)\)/);
  assert.match(app, /btnSettingsBack\.addEventListener\('click', showSettingsList\)/);
  assert.match(app, /if \(isMobileSettings\(\) && !settingsView\.classList\.contains\('settings-at-list'\)\) \{ showSettingsList\(\); return true; \}/);
});
