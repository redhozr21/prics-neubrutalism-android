# Prics Play — Global Theme Layout & Home Recovery

## Changes

- Made the four-tab mobile navigation layout global across Neubrutalism, Liquid Glass, and Spotify Standard. Theme selectors now change appearance rather than determining whether the layout exists.
- Permanently hides legacy mobile rail navigation (`.sidebar-nav`, `.rail-action-group`, rail dividers, and old active indicator) in all three styles.
- Hides the desktop-oriented Plugins warning text on mobile so it cannot leak into narrow layouts.
- Applies the Prics Play `P` logo mark globally, with fill/stroke colors driven by theme CSS variables.
- Keeps the legacy Home hero DOM and IDs available to the app scripts, while visually suppressing only its old My Wave/Jump Back children on the mobile Spotify-style Home.
- Adds useful static Home fallbacks (Liked songs, Trending now, Your playlists) that remain visible if app data initialization fails; normal app renderers replace them when they run.
- Adds a guarded `window.PricsEnsureHomeContent` recovery hook and calls it when the Home tab is selected.
- Avoids stacking two Liquid Glass blur layers on the bottom navigation.

## Validation

- JavaScript syntax checks passed for `app.js`, `mobile/neubrutalism.js`, `mobile/mobile-ui.js`, and `mobile/build.mjs`.
- 23 targeted mobile/theme/startup tests passed.
- Full suite: 272 passed, 3 failed because optional development dependencies are not installed in this environment (`electron` and `youtubei.js/web`).
- The Android APK has not been built or tested on a physical device in this environment; run the existing GitHub Actions workflow to create and test the APK.
