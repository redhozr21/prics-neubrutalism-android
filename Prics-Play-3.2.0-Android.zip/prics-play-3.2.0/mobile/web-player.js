// Web Player Engine for Prics Play on GitHub Pages & Web Browsers
// Provides seamless YouTube IFrame audio playback, transport syncing, and scrubber tracking.
(() => {
  const isNative = typeof window.Capacitor !== 'undefined' && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform();
  if (isNative) return; // Native Android APK uses native audio and Capacitor plugins

  let ytPlayer = null;
  let ytReady = false;
  let activeVideoId = null;
  let pollTimer = null;

  // Load YouTube IFrame API script
  if (!window.YT) {
    const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    document.head.appendChild(tag);
  }

  // Create YouTube Host Container with Neubrutalism Frame
  function ensureYtContainer() {
    let container = document.getElementById('prics-yt-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'prics-yt-container';
      container.style.cssText = [
        'position: fixed',
        'bottom: 96px',
        'right: 20px',
        'width: 280px',
        'height: 172px',
        'z-index: 9999',
        'border: 2.5px solid #0F0F0F',
        'border-radius: 12px',
        'box-shadow: 4px 4px 0 #0F0F0F',
        'background: #000000',
        'overflow: hidden',
        'transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
        'display: none'
      ].join(';');

      const bar = document.createElement('div');
      bar.id = 'prics-yt-bar';
      bar.style.cssText = [
        'height: 28px',
        'background: #FF482C',
        'border-bottom: 2px solid #0F0F0F',
        'display: flex',
        'align-items: center',
        'justify-content: space-between',
        'padding: 0 10px',
        'font-size: 11px',
        'font-weight: 900',
        'color: #FFFFFF',
        'letter-spacing: 0.5px',
        'user-select: none',
        'cursor: pointer'
      ].join(';');
      bar.innerHTML = '<span>PRICS WEB PLAYER</span><button id="btn-yt-min" type="button" style="border:none;background:transparent;color:#FFF;font-weight:900;cursor:pointer;font-size:16px;line-height:1;padding:0 2px;">–</button>';
      container.appendChild(bar);

      const host = document.createElement('div');
      host.id = 'prics-yt-host';
      host.style.cssText = 'width: 100%; height: calc(100% - 28px); background: #000;';
      container.appendChild(host);

      document.body.appendChild(container);

      let minimized = false;
      const minBtn = document.getElementById('btn-yt-min');
      bar.addEventListener('click', () => {
        minimized = !minimized;
        if (minimized) {
          container.style.height = '30px';
          container.style.width = '160px';
          host.style.display = 'none';
          minBtn.textContent = '+';
        } else {
          container.style.height = '172px';
          container.style.width = '280px';
          host.style.display = 'block';
          minBtn.textContent = '–';
        }
      });
    }
    return container;
  }

  window.onYouTubeIframeAPIReady = function() {
    ensureYtContainer();
    try {
      ytPlayer = new window.YT.Player('prics-yt-host', {
        width: '100%',
        height: '100%',
        playerVars: {
          autoplay: 1,
          controls: 1,
          modestbranding: 1,
          rel: 0,
          playsinline: 1
        },
        events: {
          onReady: () => {
            ytReady = true;
            if (activeVideoId) {
              ytPlayer.loadVideoById(activeVideoId);
              const container = document.getElementById('prics-yt-container');
              if (container) container.style.display = 'block';
            }
          },
          onStateChange: (e) => {
            const playBtn = document.getElementById('btn-play-pause');
            const isPlaying = e.data === window.YT.PlayerState.PLAYING;
            if (isPlaying) {
              document.body.classList.add('is-playing');
              if (playBtn) playBtn.classList.add('playing');
              startProgressPolling();
            } else if (e.data === window.YT.PlayerState.PAUSED) {
              document.body.classList.remove('is-playing');
              if (playBtn) playBtn.classList.remove('playing');
              stopProgressPolling();
            } else if (e.data === window.YT.PlayerState.ENDED) {
              document.body.classList.remove('is-playing');
              if (playBtn) playBtn.classList.remove('playing');
              stopProgressPolling();
              const nextBtn = document.getElementById('btn-next');
              if (nextBtn) nextBtn.click();
            }
          }
        }
      });
    } catch (err) {
      console.warn('[Web Player] YouTube API Init Warning:', err);
    }
  };

  function formatTime(s) {
    const sec = Math.floor(s || 0);
    const m = Math.floor(sec / 60);
    const rem = sec % 60;
    return `${m}:${rem < 10 ? '0' : ''}${rem}`;
  }

  function startProgressPolling() {
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(() => {
      if (!ytPlayer || typeof ytPlayer.getCurrentTime !== 'function') return;
      const cur = ytPlayer.getCurrentTime() || 0;
      const dur = ytPlayer.getDuration() || 0;

      // Update current and duration time labels
      const timeCur = document.getElementById('time-current');
      const timeDur = document.getElementById('time-duration');
      if (timeCur) timeCur.textContent = formatTime(cur);
      if (timeDur && dur > 0) timeDur.textContent = formatTime(dur);

      // Update scrubber track progress CSS variable (--np-progress)
      const scrubberTrack = document.getElementById('scrubber-track') || document.querySelector('.scrubber-track-container');
      if (scrubberTrack && dur > 0) {
        const pct = Math.min(100, Math.max(0, (cur / dur) * 100));
        scrubberTrack.style.setProperty('--np-progress', `${pct.toFixed(2)}%`);
      }
    }, 250);
  }

  function stopProgressPolling() {
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = null;
  }

  // Global YouTube playback trigger for Web
  window.__pricsPlayYt = function(videoId) {
    activeVideoId = videoId;
    ensureYtContainer();
    const container = document.getElementById('prics-yt-container');
    if (container) container.style.display = 'block';

    if (ytReady && ytPlayer && typeof ytPlayer.loadVideoById === 'function') {
      try {
        ytPlayer.loadVideoById(videoId);
      } catch (_) {}
    }
  };

  // Wire controls after DOM load
  window.addEventListener('DOMContentLoaded', () => {
    // Intercept play/pause button
    const playBtn = document.getElementById('btn-play-pause');
    if (playBtn) {
      playBtn.addEventListener('click', () => {
        if (!ytPlayer || typeof ytPlayer.getPlayerState !== 'function') return;
        const state = ytPlayer.getPlayerState();
        if (state === window.YT.PlayerState.PLAYING) {
          ytPlayer.pauseVideo();
        } else {
          ytPlayer.playVideo();
        }
      }, true);
    }

    // Scrubber click seeking
    const scrubber = document.getElementById('scrubber-track') || document.querySelector('.scrubber-track-container');
    if (scrubber) {
      scrubber.addEventListener('click', (e) => {
        if (!ytPlayer || typeof ytPlayer.getDuration !== 'function') return;
        const rect = scrubber.getBoundingClientRect();
        const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        const dur = ytPlayer.getDuration() || 0;
        if (dur > 0) {
          ytPlayer.seekTo(ratio * dur, true);
        }
      });
    }

    // Suppress unhandled HTML5 audio errors on web
    window.addEventListener('error', (e) => {
      if (e && e.message && /MEDIA_ELEMENT_ERROR|src_not_supported/i.test(e.message)) {
        e.preventDefault();
      }
    }, true);
  });
})();
