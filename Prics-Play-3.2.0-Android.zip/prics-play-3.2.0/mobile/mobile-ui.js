// Mobile layout behaviour: mini player <-> now-playing sheet, swipe to dismiss the sheet/cover,
// and the progress line on the mini player. The mini player itself uses explicit transport buttons.

// Mobile UI behaviours only run on mobile phones.
// On Desktop PC (Electron / is-desktop), desktop has its own persistent bottom playbar and side panels.
(() => {
  if (typeof navigator !== 'undefined' && (/Electron/i.test(navigator.userAgent) || document.documentElement.classList.contains('is-desktop'))) {
    return;
  }

// Background playback: iOS suspends Web Audio when the app is backgrounded or the screen locks,
// but keeps a plain <audio> element playing (and on the lock screen). So on iPhone the engine never
// routes the element through an AudioContext. Speed/pitch still work (they're element properties);
// EQ, reverb, distortion and the visualizer need the graph and are off. app.js builds the engine on
// DOMContentLoaded, which hasn't fired yet when this script runs.
(() => {
  // desktop's default text scale (1.25x) is sized for a monitor; phones start at 1.0x unless the user picked one
  if (!localStorage.getItem('muriel_font_scale')) localStorage.setItem('muriel_font_scale', '80');
  const Engine = window.MurielAudioEngine;
  if (!Engine) return;
  Engine.prototype.init = function (audioElement) { this.__element = audioElement || this.__element; };
  // iOS ignores element.volume (hardware buttons own it); mute still works
  Engine.prototype._applyMasterVolume = function () {
    if (this.__element) this.__element.muted = !!this.isMuted || this.volume === 0;
  };
})();

(() => {
  const panel = document.getElementById('right-panel');
  const playbar = document.getElementById('playbar');
  const lyricsBtn = document.getElementById('btn-toggle-lyrics-panel');
  const audio = document.querySelector('audio');
  if (!panel || !playbar || !lyricsBtn) return;

  let syncPlayerDock = () => {};

  // app.js owns the drawer state; mirror it onto <body> so the player bar can restyle itself
  const sync = () => {
    const open = !panel.classList.contains('hidden');
    document.body.classList.toggle('np-open', open);
    if (typeof syncPlayerDock === 'function') syncPlayerDock();
  };
  new MutationObserver(sync).observe(panel, { attributes: true, attributeFilter: ['class'] });
  sync();

  const openSheet = () => { if (panel.classList.contains('hidden')) lyricsBtn.click(); };
  const closeSheet = () => { if (!panel.classList.contains('hidden')) document.getElementById('btn-close-right-panel').click(); };

  // tapping the mini player (but not its buttons) opens the sheet
  playbar.addEventListener('click', (e) => {
    if (document.body.classList.contains('np-open')) return;
    if (e.target.closest('button, input, .scrubber-track-container')) return;
    openSheet();
  });

  // swipe down on the sheet's top area to close it
  let startY = null;
  panel.addEventListener('touchstart', (e) => {
    const t = e.touches[0];
    // 1. If touching inside the Queue drawer or list, DO NOT start swipe-to-dismiss!
    const queue = document.getElementById('drawer-queue');
    if (queue && !queue.classList.contains('hidden') && queue.contains(e.target)) {
      startY = null;
      return;
    }
    if (e.target.closest('#drawer-queue, #queue-tracks-list, .queue-current-section, .drawer-queue-head, .tracks-list, .track-row')) {
      startY = null;
      return;
    }
    // 2. If touching inside lyrics and scrolled down, DO NOT start swipe-to-dismiss!
    const lyrics = document.getElementById('lyrics-container');
    if (lyrics && lyrics.contains(e.target) && lyrics.scrollTop > 0) {
      startY = null;
      return;
    }
    // 3. Only swipe down if touching the top header area or non-scrollable player areas
    if (e.target.closest('.np-mobile-header, .right-panel-header, .right-panel-artwork-box, .drawer-handle')) {
      startY = t.clientY;
    } else {
      startY = null;
    }
  }, { passive: true });
  // one transform write per frame, and no CSS transition while the finger drags (it lagged behind)
  let dragY = 0, dragRaf = 0;
  panel.addEventListener('touchmove', (e) => {
    if (startY === null) return;
    dragY = Math.max(0, e.touches[0].clientY - startY);
    if (dragY > 0 && !panel.classList.contains('is-dragging')) panel.classList.add('is-dragging');
    if (!dragRaf) dragRaf = requestAnimationFrame(() => { dragRaf = 0; if (startY !== null) panel.style.transform = dragY > 0 ? `translateY(${dragY}px)` : ''; });
  }, { passive: true });
  panel.addEventListener('touchend', (e) => {
    if (startY === null) return;
    const dy = e.changedTouches[0].clientY - startY;
    if (dragRaf) { cancelAnimationFrame(dragRaf); dragRaf = 0; }
    panel.classList.remove('is-dragging');
    panel.style.transform = '';
    startY = null;
    if (dy > 110) {
      const queue = document.getElementById('drawer-queue');
      if (queue && !queue.classList.contains('hidden')) {
        window.dispatchEvent(new Event('muriel:show-now-playing'));
      } else {
        closeSheet();
      }
    }
  });

  // Picked images and videos (background, banner, song covers) are saved as file URLs, and those change when
  // iOS moves the app container (every update or reinstall). Rebuild each saved one from its file name, then
  // delete picks nothing uses any more (every pick is a new copy). Only the background was repaired before,
  // and picking a song cover made even that repair forget the background.
  const fixPickedMedia = async () => {
    const api = window.electronAPI;
    if (!api.fileUrl) return;
    const nameOf = (u) => { const m = typeof u === 'string' && !u.startsWith('blob:') && u.match(/\/backgrounds\/(bg_[\w.-]+)$/); return m ? m[1] : null; };
    const keep = new Set();
    const fresh = async (u) => {
      const name = nameOf(u);
      if (!name) return u;
      const url = await api.fileUrl(`/data/backgrounds/${name}`);
      if (url) keep.add(name);
      return url || u;
    };
    let bgChanged = false;
    for (const key of ['muriel_bg_url', 'muriel_banner_media', 'muriel_app_icon']) {
      const cur = localStorage.getItem(key);
      if (!cur) continue;
      const next = await fresh(cur);
      if (next !== cur) { localStorage.setItem(key, next); if (key === 'muriel_bg_url') bgChanged = true; }
    }
    let artOk = true;
    try {
      const art = JSON.parse(localStorage.getItem('muriel_track_art') || '{}');
      let dirty = false;
      for (const v of Object.values(art)) {
        for (const f of ['cover', 'banner']) {
          if (!v || !v[f]) continue;
          const next = await fresh(v[f]);
          if (next !== v[f]) { v[f] = next; dirty = true; }
        }
      }
      if (dirty) localStorage.setItem('muriel_track_art', JSON.stringify(art));
    } catch (e) { artOk = false; }
    localStorage.removeItem('muriel_bg_vpath');
    if (bgChanged) window.MurielCore.refreshBackground();
    if (artOk && api.pruneMedia) api.pruneMedia(keep);
  };
  if (window.MurielCore) fixPickedMedia(); else window.addEventListener('muriel:ready', fixPickedMedia, { once: true });

  // Prics Play 2.6.2: one mobile Now Playing layout built from the existing player controls.
  // The original playbar controls are moved into the sheet only while it is open, then restored.
  const drawerNow = document.getElementById('drawer-now');
  const drawerQueue = document.getElementById('drawer-queue');
  if (drawerQueue) {
    drawerQueue.addEventListener('touchstart', (e) => { e.stopPropagation(); }, { passive: true });
  }
  const artworkBox = panel.querySelector('.right-panel-artwork-box');
  const lyricsSection = panel.querySelector('.lyrics-section');
  const lyricsContainer = document.getElementById('lyrics-container');
  const playbarCenter = playbar.querySelector('.playbar-center');
  const playbarRight = playbar.querySelector('.playbar-right');
  const queueButton = document.getElementById('btn-toggle-queue');

  const playbackHome = document.createComment('Prics Play playback controls home');
  const queueHome = document.createComment('Prics Play queue button home');
  if (playbarCenter && playbarCenter.parentNode === playbar) playbar.insertBefore(playbackHome, playbarCenter);
  if (queueButton && playbarRight && queueButton.parentNode === playbarRight) playbarRight.insertBefore(queueHome, queueButton);

  const playbackHost = document.createElement('div');
  playbackHost.className = 'np-playback-host';
  const outputRow = document.createElement('div');
  outputRow.className = 'np-output-row';
  outputRow.innerHTML = `
    <span class="np-output-label">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 10v4h3l5 4V6l-5 4H4Z"/><path d="M16 9a5 5 0 0 1 0 6M18.5 6.5a8.5 8.5 0 0 1 0 11"/></svg>
      <span>Diputar di perangkat ini</span>
    </span>
    <span class="np-output-queue"></span>`;
  const outputQueueSlot = outputRow.querySelector('.np-output-queue');
  const queueActionLabel = document.createElement('span');
  queueActionLabel.className = 'np-output-queue-label';
  queueActionLabel.textContent = 'Antrean';
  if (outputQueueSlot) outputQueueSlot.appendChild(queueActionLabel);
  if (queueButton) {
    queueButton.title = 'Antrean pemutaran';
    queueButton.setAttribute('aria-label', 'Buka antrean pemutaran');
  }
  if (artworkBox && artworkBox.parentNode === drawerNow) {
    artworkBox.after(playbackHost);
    playbackHost.after(outputRow);
  }

  // Header and its menu use real app actions; no decorative, non-functional controls are added.
  const mobileHeader = document.createElement('div');
  mobileHeader.className = 'np-mobile-header';
  mobileHeader.innerHTML = `
    <button type="button" class="np-mobile-back" aria-label="Kembali ke aplikasi" title="Kembali">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>
    </button>
    <span class="np-mobile-heading">SEDANG DIPUTAR</span>
    <button type="button" class="np-mobile-more" aria-label="Opsi pemutaran" aria-expanded="false" title="Opsi lainnya">
      <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/></svg>
    </button>`;
  const drawerTabs = panel.querySelector('.drawer-tabs');
  panel.insertBefore(mobileHeader, drawerTabs || panel.firstChild);

  const moreMenu = document.createElement('div');
  moreMenu.className = 'np-mobile-menu';
  moreMenu.hidden = true;
  moreMenu.innerHTML = `
    <button type="button" data-np-action="now">Sedang diputar</button>
    <button type="button" data-np-action="queue">Antrean pemutaran</button>
    <button type="button" data-np-action="edit">Edit lirik</button>
    <button type="button" data-np-action="share">Bagikan lagu</button>
    <button type="button" data-np-action="download">Download lagu</button>`;
  document.body.appendChild(moreMenu);

  const mobileBack = mobileHeader.querySelector('.np-mobile-back');
  const mobileMore = mobileHeader.querySelector('.np-mobile-more');
  const mobileHeading = mobileHeader.querySelector('.np-mobile-heading');
  const queueMenuAction = moreMenu.querySelector('[data-np-action="queue"]');
  const nowMenuAction = moreMenu.querySelector('[data-np-action="now"]');

  const closeMoreMenu = () => {
    moreMenu.hidden = true;
    mobileMore.setAttribute('aria-expanded', 'false');
  };
  const positionMoreMenu = () => {
    const rect = mobileMore.getBoundingClientRect();
    const right = Math.max(12, window.innerWidth - rect.right);
    const top = Math.min(window.innerHeight - 240, rect.bottom + 8);
    moreMenu.style.right = `${right}px`;
    moreMenu.style.top = `${Math.max(12, top)}px`;
  };
  const updateMobileHeader = () => {
    const queueOpen = !!(drawerQueue && !drawerQueue.classList.contains('hidden'));
    mobileHeader.classList.toggle('is-queue-view', queueOpen);
    mobileHeading.textContent = queueOpen ? 'ANTREAN PEMUTARAN' : 'SEDANG DIPUTAR';
    mobileBack.setAttribute('aria-label', queueOpen ? 'Kembali ke Sedang Diputar' : 'Kembali ke aplikasi');
    mobileBack.title = queueOpen ? 'Kembali ke Sedang Diputar' : 'Kembali';
    nowMenuAction.textContent = queueOpen ? 'Kembali ke Sedang Diputar' : 'Sedang diputar';
    queueMenuAction.textContent = queueOpen ? 'Antrean sedang dibuka' : 'Antrean pemutaran';
    queueMenuAction.disabled = queueOpen;
    if (queueButton) {
      queueButton.setAttribute('aria-expanded', String(queueOpen));
      queueButton.setAttribute('aria-label', queueOpen ? 'Tutup antrean pemutaran' : 'Buka antrean pemutaran');
    }
  };
  mobileBack.addEventListener('click', () => {
    closeMoreMenu();
    // In the Queue view the back arrow returns to Now Playing; it must not dismiss the whole sheet.
    if (drawerQueue && !drawerQueue.classList.contains('hidden')) {
      window.dispatchEvent(new Event('muriel:show-now-playing'));
      updateMobileHeader();
    } else {
      closeSheet();
    }
  });
  if (drawerNow) new MutationObserver(updateMobileHeader).observe(drawerNow, { attributes: true, attributeFilter: ['class'] });
  if (drawerQueue) new MutationObserver(updateMobileHeader).observe(drawerQueue, { attributes: true, attributeFilter: ['class'] });
  updateMobileHeader();
  mobileMore.addEventListener('click', (event) => {
    event.stopPropagation();
    const opening = moreMenu.hidden;
    moreMenu.hidden = !opening;
    mobileMore.setAttribute('aria-expanded', String(opening));
    if (opening) positionMoreMenu();
  });
  moreMenu.addEventListener('click', (event) => {
    const action = event.target.closest('[data-np-action]')?.dataset.npAction;
    if (!action) return;
    closeMoreMenu();
    const actions = {
      now: () => { if (drawerNow?.classList.contains('hidden')) window.dispatchEvent(new Event('muriel:show-now-playing')); },
      queue: () => { if (!drawerQueue || drawerQueue.classList.contains('hidden')) queueButton?.click(); },
      edit: () => document.getElementById('btn-add-custom-lyrics')?.click(),
      share: () => document.getElementById('btn-playbar-share')?.click(),
      download: () => document.getElementById('btn-playbar-more')?.click(),
    };
    actions[action]?.();
  });
  document.addEventListener('click', (event) => {
    if (!mobileHeader.contains(event.target) && !moreMenu.contains(event.target)) closeMoreMenu();
  });
  window.addEventListener('resize', closeMoreMenu);
  document.addEventListener('scroll', (event) => {
    if (!moreMenu.contains(event.target)) closeMoreMenu();
  }, true);

  syncPlayerDock = () => {
    const open = !panel.classList.contains('hidden');
    if (open) {
      if (playbarCenter && playbackHost && playbarCenter.parentNode !== playbackHost) playbackHost.appendChild(playbarCenter);
      if (queueButton && outputQueueSlot && queueButton.parentNode !== outputQueueSlot) outputQueueSlot.appendChild(queueButton);
      updateMobileHeader();
    } else {
      if (playbarCenter && playbackHome.parentNode && playbarCenter.parentNode !== playbar) playbackHome.parentNode.insertBefore(playbarCenter, playbackHome.nextSibling);
      if (queueButton && queueHome.parentNode && queueButton.parentNode !== playbarRight) queueHome.parentNode.insertBefore(queueButton, queueHome.nextSibling);
      closeMoreMenu();
    }
  };
  panel.classList.add('np-layout-v260', 'np-lyrics-preview');
  syncPlayerDock();

  if (lyricsSection && lyricsContainer) {
    const expandLyrics = document.createElement('button');
    expandLyrics.id = 'np-lyrics-expand';
    expandLyrics.type = 'button';
    expandLyrics.className = 'np-lyrics-expand';
    expandLyrics.textContent = 'Lihat lirik lengkap';
    expandLyrics.setAttribute('aria-expanded', 'false');
    expandLyrics.setAttribute('aria-controls', 'lyrics-container');

    const romajiBtn = document.createElement('button');
    romajiBtn.id = 'np-lyrics-ro';
    romajiBtn.type = 'button';
    romajiBtn.className = 'np-lyrics-ro-button';
    romajiBtn.textContent = 'RO';
    romajiBtn.title = 'Lirik Romanized (Romaji / Hangul)';
    romajiBtn.setAttribute('aria-label', 'Toggle Romanized lyrics');
    const isRoActive = () => {
      try { return localStorage.getItem('muriel_romaji_enabled') !== 'false'; } catch (_) { return true; }
    };
    romajiBtn.classList.toggle('active', isRoActive());
    romajiBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      let next;
      if (typeof window.MurielCore?.toggleRomaji === 'function') {
        next = window.MurielCore.toggleRomaji();
      } else {
        const current = isRoActive();
        next = !current;
        try { localStorage.setItem('muriel_romaji_enabled', String(next)); } catch (_) {}
        if (window.MurielCore?.state) window.MurielCore.state.romajiEnabled = next;
        if (typeof window.MurielCore?.renderLyricsView === 'function') {
          window.MurielCore.renderLyricsView();
        } else {
          window.dispatchEvent(new Event('muriel:lyrics'));
        }
      }
      romajiBtn.classList.toggle('active', !!next);
      const desktopBtn = document.getElementById('btn-romaji-lyrics');
      if (desktopBtn) desktopBtn.classList.toggle('active', !!next);
    });

    const lyricsHeader = lyricsSection.querySelector('.lyrics-header');
    if (lyricsHeader) {
      lyricsHeader.appendChild(expandLyrics);
      lyricsHeader.appendChild(romajiBtn);
    } else {
      lyricsSection.insertBefore(expandLyrics, lyricsContainer);
      lyricsSection.insertBefore(romajiBtn, lyricsContainer);
    }

    // Tell the listener whether lyric rows are actually timestamped. Plain text lyrics
    // cannot jump to a chorus until the user syncs their lines to the audio.
    const syncControl = document.createElement('div');
    syncControl.className = 'np-lyrics-sync-control';
    syncControl.hidden = true;
    const syncStatus = document.createElement('span');
    syncStatus.className = 'np-lyrics-sync-status';
    const syncButton = document.createElement('button');
    syncButton.type = 'button';
    syncButton.className = 'np-lyrics-sync-button';
    syncButton.textContent = 'Sinkronkan';
    syncButton.addEventListener('click', () => document.getElementById('btn-sync-lyrics')?.click());
    syncControl.append(syncStatus, syncButton);
    if (lyricsHeader) lyricsHeader.appendChild(syncControl);

    const setLyricsExpanded = (expanded) => {
      panel.classList.toggle('np-full-lyrics', expanded);
      panel.classList.toggle('np-lyrics-preview', !expanded);
      expandLyrics.textContent = expanded ? 'Tutup lirik lengkap' : 'Lihat lirik lengkap';
      expandLyrics.setAttribute('aria-expanded', String(expanded));
      if (expanded) lyricsContainer.scrollTop = 0;
    };
    expandLyrics.addEventListener('click', () => setLyricsExpanded(!panel.classList.contains('np-full-lyrics')));

    const syncLyricsAvailability = () => {
      const lyricLines = Array.from(lyricsContainer.querySelectorAll('.lyric-line'));
      const hasLyrics = lyricLines.length > 0 || lyricsContainer.textContent.trim().length > 0;
      const timedCount = lyricLines.filter((line) => line.dataset.timed === 'true').length;
      const hasTimedLyrics = timedCount > 0;
      const syncState = hasTimedLyrics ? (timedCount < lyricLines.length ? 'partial' : 'synced') : (lyricsContainer.dataset.syncState || 'failed');
      const isPending = !hasTimedLyrics && syncState === 'pending';
      const isSynced = hasTimedLyrics || syncState === 'synced' || syncState === 'partial';
      expandLyrics.hidden = !hasLyrics;
      romajiBtn.hidden = !hasLyrics;
      syncControl.hidden = !hasLyrics;
      syncControl.classList.toggle('is-synced', isSynced);
      syncControl.classList.toggle('is-pending', isPending);
      syncStatus.textContent = syncState === 'partial'
        ? `${timedCount}/${lyricLines.length} baris tersinkron otomatis`
        : (isSynced ? 'Lirik mengikuti lagu · ketuk untuk lompat' : (isPending ? 'Mencari sinkronisasi otomatis…' : 'Lirik bertimestamp tidak ditemukan'));
      // Do not ask the listener to sync while the app is still trying LRCLIB/NetEase automatically.
      syncButton.hidden = syncState === 'synced' || isPending;
      syncButton.textContent = syncState === 'partial' ? 'Lengkapi sinkron' : 'Sinkronkan';
      if (!hasLyrics && panel.classList.contains('np-full-lyrics')) setLyricsExpanded(false);
    };
    syncLyricsAvailability();
    new MutationObserver(syncLyricsAvailability).observe(lyricsContainer, {
      childList: true, subtree: true, characterData: true, attributes: true,
      attributeFilter: ['data-timed', 'data-time', 'data-sync-state'],
    });

    // Start each newly selected track in the compact preview state.
    const titleNode = document.getElementById('right-panel-title');
    if (titleNode) {
      let previousTitle = titleNode.textContent;
      new MutationObserver(() => {
        const nextTitle = titleNode.textContent;
        if (nextTitle !== previousTitle) {
          previousTitle = nextTitle;
          setLyricsExpanded(false);
          lyricsContainer.scrollTop = 0;
        }
      }).observe(titleNode, { childList: true, subtree: true, characterData: true });
    }
  }

  // Favorite action is mirrored from the real playbar favorite button, so there is one source of truth.
  const realFav = document.getElementById('btn-toggle-fav');
  const favIcon = document.getElementById('fav-icon');
  const titleRow = panel.querySelector('.right-panel-title-row');
  if (realFav && favIcon && titleRow) {
    const like = document.createElement('button');
    like.id = 'np-like';
    like.type = 'button';
    like.setAttribute('aria-label', 'Like');
    like.innerHTML = favIcon.outerHTML.replace('id="fav-icon"', '');
    const mirror = () => {
      const on = favIcon.getAttribute('fill') === 'currentColor';
      like.classList.toggle('on', on);
      const svg = like.querySelector('svg');
      if (svg) svg.setAttribute('fill', on ? 'currentColor' : 'none');
    };
    like.addEventListener('click', () => {
      realFav.click();
      like.classList.remove('pop'); void like.offsetWidth; like.classList.add('pop');
      if (navigator.vibrate) navigator.vibrate(10);
    });
    new MutationObserver(mirror).observe(favIcon, { attributes: true, attributeFilter: ['fill'] });
    titleRow.appendChild(like);
    mirror();
  }

  // mini player progress line
  if (audio) {
    const tick = () => {
      if (document.hidden) return;
      const p = audio.duration ? audio.currentTime / audio.duration : 0;
      playbar.style.setProperty('--mini-progress', String(Math.max(0, Math.min(1, p))));
    };
    audio.addEventListener('timeupdate', tick);
    audio.addEventListener('emptied', tick);
    document.addEventListener('visibilitychange', tick);
  }

  // phone-only settings: the song storage limit (Storage → Offline songs) and sharing the error log (About)
  const storageGroup = document.querySelector('.settings-section[data-cat="storage"] .m3-group[data-group="offline"]') || document.querySelector('.settings-section[data-cat="storage"] .m3-group');
  const aboutGroup = document.querySelector('.settings-section[data-cat="about"] .m3-group');
  if (storageGroup) {
    const limits = [['256', '256 MB'], ['512', '512 MB'], ['1024', '1 GB'], ['2048', '2 GB'], ['5120', '5 GB'], ['10240', '10 GB']];
    const current = localStorage.getItem('muriel_cache_limit_mb') || '512';
    const limitRow = document.createElement('div');
    limitRow.className = 'setting-item';
    limitRow.innerHTML = `
      <div class="setting-item-top" style="align-items: center;">
        <div style="display: flex; flex-direction: column; gap: 2px;">
          <span class="setting-name" data-i18n>Song storage limit</span>
          <span style="font-size: calc(12px * var(--font-scale, 1)); color: var(--md-sys-color-outline);" data-i18n>Songs you play are kept for offline use (512 MB by default). Over this limit, the ones played longest ago are removed.</span>
        </div>
      </div>
      <div class="theme-mode-toggle" style="margin-top: 10px;">
        ${limits.map(([v, l]) => `<button class="fps-cap-btn${v === current ? ' active' : ''}" data-limit="${v}">${l}</button>`).join('')}
      </div>`;
    limitRow.querySelectorAll('[data-limit]').forEach((b) => b.addEventListener('click', () => {
      localStorage.setItem('muriel_cache_limit_mb', b.dataset.limit);
      limitRow.querySelectorAll('[data-limit]').forEach((x) => x.classList.toggle('active', x === b));
      // a lower limit applies now, not only after the next download
      if (window.MurielCache) window.MurielCache.enforceLimit();
    }));
    const logRow = document.createElement('div');
    logRow.className = 'setting-item';
    logRow.innerHTML = `
      <div class="setting-item-top" style="align-items: center;">
        <div style="display: flex; flex-direction: column; gap: 2px;">
          <span class="setting-name" data-i18n>Share error log</span>
          <span style="font-size: calc(12px * var(--font-scale, 1)); color: var(--md-sys-color-outline);" data-i18n>If something breaks, send this so it can be fixed.</span>
        </div>
        <button class="btn-pill-primary" type="button" data-i18n>Share</button>
      </div>`;
    logRow.querySelector('button').addEventListener('click', async () => {
      const res = await window.electronAPI.shareText('Prics Play error log', window.MurielLog ? window.MurielLog.text() : 'no log');
      if (res === 'copied' && window.MurielCore) window.MurielCore.toast((window.MurielI18n || { T: (x) => x, Tm: (x) => x }).Tm('Log copied to clipboard'), 'info');
    });
    storageGroup.append(limitRow);
    if (aboutGroup) aboutGroup.insertBefore(logRow, aboutGroup.lastElementChild); else storageGroup.append(logRow);
  }

  // the desktop placeholder doesn't fit beside the source buttons on a phone
  const searchInput = document.getElementById('search-input');
  if (searchInput) { searchInput.setAttribute('data-i18n-attr', 'placeholder'); searchInput.placeholder = 'Search songs, artists…'; }

  // settings that only make sense on desktop
  ['btn-hw-accel', 'btn-tray-on-close', 'btn-media-keys'].forEach((id) => {
    const row = document.getElementById(id) && document.getElementById(id).closest('.setting-item');
    if (row) row.style.display = 'none';
  });
})();

// a write to the phone's storage failed (usually: storage full); say so instead of losing it silently
(() => {
  let last = 0;
  window.addEventListener('muriel:storage-error', () => {
    if (Date.now() - last < 30000 || !window.MurielCore || !window.MurielCore.toast) return;
    last = Date.now();
    window.MurielCore.toast((window.MurielI18n || { T: (x) => x, Tm: (x) => x }).Tm('Could not save to storage. Is your phone full?'), 'error');
  });
})();
})();
