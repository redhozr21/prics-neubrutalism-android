/**
 * Prics Play Web Audio Bridge (Pure Browser Mode / GitHub Pages)
 * Enables official YouTube IFrame audio streaming & search fallback when running
 * in a web browser without a local Node.js proxy or Capacitor native stack.
 *
 * SAFETY GUARANTEE:
 * Does NOT run on Android APK, iOS IPA, or Desktop Electron (exits immediately).
 */
(function () {
  'use strict';

  // 1. Strict guard: ONLY active on pure web browser (e.g. GitHub Pages)
  if (typeof window === 'undefined') return;
  const isCapacitorNative = Boolean(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform());
  const isDesktopElectron = Boolean(navigator.userAgent && /Electron/i.test(navigator.userAgent));
  if (isCapacitorNative || isDesktopElectron) return;

  console.log('[PricsWebBridge] Initializing pure web browser audio engine for GitHub Pages');

  // 2. Hidden YouTube Player container
  let ytContainer = document.getElementById('prics-web-yt-bridge');
  if (!ytContainer) {
    ytContainer = document.createElement('div');
    ytContainer.id = 'prics-web-yt-bridge';
    ytContainer.style.cssText = 'position:fixed;bottom:-999px;right:-999px;width:200px;height:200px;opacity:0.001;pointer-events:none;z-index:-9999;';
    document.body.appendChild(ytContainer);
  }

  const frameHolder = document.createElement('div');
  frameHolder.id = 'prics-yt-iframe-target';
  ytContainer.appendChild(frameHolder);

  let ytPlayer = null;
  let isYtReady = false;
  let pendingAction = null;
  let tickTimer = null;
  let currentVideoDuration = 0;

  function loadYouTubeIframeApi() {
    if (window.YT && window.YT.Player) {
      initPlayer();
      return;
    }
    const prev = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = function () {
      if (typeof prev === 'function') prev();
      initPlayer();
    };
    const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    tag.async = true;
    document.head.appendChild(tag);
  }

  function initPlayer() {
    try {
      ytPlayer = new window.YT.Player('prics-yt-iframe-target', {
        height: '200',
        width: '200',
        playerVars: {
          autoplay: 1,
          controls: 0,
          disablekb: 1,
          fs: 0,
          rel: 0,
          playsinline: 1,
          enablejsapi: 1,
          origin: window.location.origin
        },
        events: {
          onReady: onPlayerReady,
          onStateChange: onPlayerStateChange,
          onError: onPlayerError
        }
      });
    } catch (e) {
      console.warn('[PricsWebBridge] Player init error:', e);
    }
  }

  function onPlayerReady() {
    isYtReady = true;
    console.log('[PricsWebBridge] YouTube IFrame Audio Engine ready');
    if (pendingAction) {
      pendingAction();
      pendingAction = null;
    }
  }

  function getNativeAudio() {
    return document.getElementById('native-audio') || (window.el && window.el.nativeAudio);
  }

  function onPlayerStateChange(event) {
    const state = event.data;
    const audio = getNativeAudio();

    // 1: PLAYING, 2: PAUSED, 0: ENDED, 3: BUFFERING
    if (state === 1) {
      if (window.state) window.state.isPlaying = true;
      document.body.classList.add('is-playing');
      if (typeof window.updatePlayPauseButton === 'function') window.updatePlayPauseButton(true, true);
      if (audio) {
        audio.dispatchEvent(new Event('play'));
        audio.dispatchEvent(new Event('playing'));
      }
      startTick();
    } else if (state === 2) {
      if (window.state) window.state.isPlaying = false;
      document.body.classList.remove('is-playing');
      if (typeof window.updatePlayPauseButton === 'function') window.updatePlayPauseButton(false, false);
      if (audio) {
        audio.dispatchEvent(new Event('pause'));
      }
      stopTick();
    } else if (state === 0) {
      stopTick();
      if (audio) {
        audio.dispatchEvent(new Event('ended'));
      } else {
        if (typeof window.playNextSong === 'function') window.playNextSong();
        else if (typeof window.playNext === 'function') window.playNext();
      }
    } else if (state === 3) {
      if (typeof window.updatePlayPauseButton === 'function') window.updatePlayPauseButton(true, true);
      if (audio) {
        audio.dispatchEvent(new Event('waiting'));
      }
    }
  }

  function onPlayerError(errCode) {
    console.warn('[PricsWebBridge] YouTube playback error code:', errCode);
    stopTick();
    const audio = getNativeAudio();
    if (audio) {
      audio.dispatchEvent(new Event('error'));
    } else {
      if (typeof window.showToast === 'function') {
        window.showToast('Lagu ini dibatasi pemutarannya, memutar lagu berikutnya...', 'info');
      }
      if (typeof window.playNextSong === 'function') window.playNextSong();
    }
  }

  function startTick() {
    stopTick();
    tickTimer = setInterval(() => {
      if (!ytPlayer || typeof ytPlayer.getCurrentTime !== 'function') return;
      try {
        const cur = ytPlayer.getCurrentTime() || 0;
        const dur = ytPlayer.getDuration() || currentVideoDuration || 0;
        if (dur > 0) currentVideoDuration = dur;

        const audio = getNativeAudio();
        if (audio) {
          audio.dispatchEvent(new Event('timeupdate'));
        }

        // Direct UI sync
        const bar = document.getElementById('track-progress-bar');
        if (bar && dur > 0) {
          bar.value = Math.min(100, Math.max(0, (cur / dur) * 100));
        }
        const timeElapsed = document.getElementById('time-elapsed');
        if (timeElapsed) {
          const m = Math.floor(cur / 60);
          const s = Math.floor(cur % 60);
          timeElapsed.textContent = `${m}:${s < 10 ? '0' : ''}${s}`;
        }
        const timeTotal = document.getElementById('time-total');
        if (timeTotal && dur > 0) {
          const m = Math.floor(dur / 60);
          const s = Math.floor(dur % 60);
          timeTotal.textContent = `${m}:${s < 10 ? '0' : ''}${s}`;
        }

        if (typeof window.updateSyncedLyricsHighlight === 'function') {
          window.updateSyncedLyricsHighlight(cur);
        }
      } catch (_) {}
    }, 250);
  }

  function stopTick() {
    if (tickTimer) {
      clearInterval(tickTimer);
      tickTimer = null;
    }
  }

  function playTarget({ videoId, searchQuery }) {
    const doPlay = () => {
      if (!ytPlayer) return;
      try {
        if (videoId) {
          ytPlayer.loadVideoById(videoId);
          ytPlayer.playVideo();
        } else if (searchQuery) {
          ytPlayer.loadPlaylist({
            listType: 'search',
            list: searchQuery
          });
          ytPlayer.playVideo();
        }
      } catch (e) {
        console.warn('[PricsWebBridge] playTarget error:', e);
      }
    };

    if (!isYtReady || !ytPlayer || typeof ytPlayer.loadVideoById !== 'function') {
      pendingAction = doPlay;
    } else {
      doPlay();
    }
  }

  // Hook transport buttons and el.nativeAudio in web mode
  function hookNativeAudio() {
    const audio = getNativeAudio();
    if (!audio || audio.__pricsHooked) return;
    audio.__pricsHooked = true;

    // Prevent loading dummy audio that would fail or end immediately
    Object.defineProperty(audio, 'src', {
      get() { return this.__pricsVirtualSrc || ''; },
      set(val) { this.__pricsVirtualSrc = val; },
      configurable: true
    });

    Object.defineProperty(audio, 'currentTime', {
      get() { return ytPlayer && typeof ytPlayer.getCurrentTime === 'function' ? ytPlayer.getCurrentTime() : 0; },
      set(val) { if (ytPlayer && typeof ytPlayer.seekTo === 'function') ytPlayer.seekTo(val, true); },
      configurable: true
    });

    Object.defineProperty(audio, 'duration', {
      get() {
        const d = ytPlayer && typeof ytPlayer.getDuration === 'function' ? ytPlayer.getDuration() : 0;
        return d > 0 ? d : (currentVideoDuration || (window.state && window.state.currentTrack && window.state.currentTrack.duration) || 0);
      },
      configurable: true
    });

    Object.defineProperty(audio, 'paused', {
      get() {
        if (!ytPlayer || typeof ytPlayer.getPlayerState !== 'function') return true;
        return ytPlayer.getPlayerState() !== 1;
      },
      configurable: true
    });

    Object.defineProperty(audio, 'volume', {
      get() { return ytPlayer && typeof ytPlayer.getVolume === 'function' ? ytPlayer.getVolume() / 100 : 1; },
      set(val) { if (ytPlayer && typeof ytPlayer.setVolume === 'function') ytPlayer.setVolume(Math.round(val * 100)); },
      configurable: true
    });

    audio.play = async function () {
      if (ytPlayer && typeof ytPlayer.playVideo === 'function') {
        ytPlayer.playVideo();
      }
      return Promise.resolve();
    };

    audio.pause = function () {
      if (ytPlayer && typeof ytPlayer.pauseVideo === 'function') {
        ytPlayer.pauseVideo();
      }
    };
  }

  document.addEventListener('click', (e) => {
    hookNativeAudio();
    const playBtn = e.target.closest('#btn-play-pause, #mobile-mini-play, .prics-play-trigger');
    if (playBtn && ytPlayer && typeof ytPlayer.getPlayerState === 'function') {
      try {
        const s = ytPlayer.getPlayerState();
        if (s === 1) ytPlayer.pauseVideo();
        else if (s === 2 || s === 5 || s === -1) ytPlayer.playVideo();
      } catch (_) {}
    }
  });

  // 3. Intercept window.fetch for /api/stream-info and /api/search in web mode
  const origFetch = window.fetch;
  window.fetch = async function (input, init = {}) {
    hookNativeAudio();
    const urlStr = typeof input === 'string' ? input : (input && input.url ? input.url : '');

    // A. Intercept /api/stream-info
    if (urlStr.includes('/api/stream-info')) {
      try {
        const u = new URL(urlStr, window.location.origin);
        let vid = u.searchParams.get('id') || '';
        const trackUrl = u.searchParams.get('url') || '';
        const title = u.searchParams.get('title') || '';
        const artist = u.searchParams.get('artist') || '';

        // Check if id is an 11-char YouTube ID
        if (vid && !/^[a-zA-Z0-9_-]{11}$/.test(vid)) {
          vid = '';
        }

        if (!vid && trackUrl) {
          const m = trackUrl.match(/(?:v=|youtu\.be\/|\/shorts\/|^)([\w-]{11})(?:[&?#]|$)/);
          if (m) vid = m[1];
        }

        if (!vid && window.state && window.state.currentTrack) {
          const ct = window.state.currentTrack;
          if (ct.id && /^[a-zA-Z0-9_-]{11}$/.test(ct.id)) vid = ct.id;
          else if (ct.url) {
            const m = ct.url.match(/(?:v=|youtu\.be\/|\/shorts\/|^)([\w-]{11})(?:[&?#]|$)/);
            if (m) vid = m[1];
          }
        }

        const searchQuery = `${artist} ${title} audio`.trim();
        playTarget({ videoId: vid, searchQuery: searchQuery || 'music' });

        return new Response(JSON.stringify({
          success: true,
          isLocal: false,
          streamUrl: 'https://web-player-active',
          isHls: false
        }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' }
        });
      } catch (err) {
        console.warn('[PricsWebBridge] stream-info intercept error:', err);
      }
    }

    // B. Intercept /api/search
    if (urlStr.includes('/api/search')) {
      try {
        const u = new URL(urlStr, window.location.origin);
        const q = u.searchParams.get('q') || '';
        if (q) {
          const itunesRes = await origFetch(`https://itunes.apple.com/search?term=${encodeURIComponent(q)}&entity=song&limit=25`);
          if (itunesRes.ok) {
            const itunesData = await itunesRes.json();
            const tracks = (itunesData.results || []).map((t) => ({
              id: String(t.trackId),
              title: t.trackName || 'Unknown Title',
              artist: t.artistName || 'Unknown Artist',
              album: t.collectionName || '',
              duration: Math.round((t.trackTimeMillis || 0) / 1000),
              thumbnail: (t.artworkUrl100 || '').replace('100x100bb', '400x400bb'),
              platform: 'youtube',
              url: `https://www.youtube.com/results?search_query=${encodeURIComponent((t.artistName || '') + ' ' + (t.trackName || ''))}`
            }));
            return new Response(JSON.stringify({ success: true, tracks }), {
              status: 200,
              headers: { 'Content-Type': 'application/json' }
            });
          }
        }
      } catch (err) {
        console.warn('[PricsWebBridge] search fallback error:', err);
      }
    }

    return origFetch(input, init);
  };

  // Start loading YouTube API
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      loadYouTubeIframeApi();
      hookNativeAudio();
    });
  } else {
    loadYouTubeIframeApi();
    hookNativeAudio();
  }
})();
