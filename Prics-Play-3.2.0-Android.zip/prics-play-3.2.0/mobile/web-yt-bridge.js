/**
 * Prics Play Web Audio Engine (Pure Browser Mode / GitHub Pages)
 * Seamless official YouTube audio player with Neubrutalism UI integration.
 *
 * SAFETY GUARANTEE:
 * Does NOT run on Android APK, iOS IPA, or Desktop Electron (exits immediately).
 */
(function () {
  'use strict';

  // 1. Strict guard: ONLY active on pure web browser (e.g. GitHub Pages)
  if (typeof window === 'undefined') return;
  const isCapacitorNative = Boolean(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform());
  const isDesktopElectron = Boolean(navigator.userAgent && /Electron/i.test(navigator.userAgent));
  if (isCapacitorNative || isDesktopElectron) return;

  console.log('[PricsWebBridge] Initializing pure web browser audio engine for GitHub Pages');

  let currentVideoId = null;
  let currentSearchQuery = null;
  let isPlaying = false;
  let currentTime = 0;
  let duration = 0;
  let tickTimer = null;

  function getIframe() {
    let container = document.getElementById('prics-web-yt-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'prics-web-yt-container';
      container.innerHTML = `
        <div id="prics-web-yt-bar" style="background:#FFE568;padding:4px 8px;font-family:monospace;font-size:11px;font-weight:900;border-bottom:2px solid #0F0F0F;display:flex;justify-content:space-between;align-items:center;user-select:none;">
          <span style="color:#0F0F0F;letter-spacing:0.5px;">⚡ PRICS WEB PLAYER</span>
          <button id="prics-web-yt-min" type="button" style="background:#FF482C;color:#FFF;border:1px solid #0F0F0F;border-radius:3px;font-size:10px;font-weight:bold;cursor:pointer;padding:1px 6px;">_</button>
        </div>
        <div id="prics-web-yt-frame-wrap" style="width:100%;height:124px;background:#000;">
          <iframe id="prics-yt-iframe" allow="autoplay; encrypted-media; picture-in-picture" style="width:100%;height:100%;border:none;display:block;"></iframe>
        </div>
      `;
      container.style.cssText = 'position:fixed;bottom:76px;right:16px;width:220px;border:2px solid #0F0F0F;border-radius:8px;box-shadow:4px 4px 0px #0F0F0F;background:#000;z-index:99999;overflow:hidden;transition:all 0.2s ease;';
      document.body.appendChild(container);

      const toggleBtn = document.getElementById('prics-web-yt-min');
      const wrap = document.getElementById('prics-web-yt-frame-wrap');
      if (toggleBtn && wrap) {
        toggleBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          const isHidden = wrap.style.display === 'none';
          wrap.style.display = isHidden ? 'block' : 'none';
          toggleBtn.textContent = isHidden ? '_' : '+';
        });
      }
    }
    return document.getElementById('prics-yt-iframe');
  }

  function sendCommand(func, args = '') {
    const iframe = document.getElementById('prics-yt-iframe');
    if (iframe && iframe.contentWindow) {
      try {
        iframe.contentWindow.postMessage(JSON.stringify({
          event: 'command',
          func: func,
          args: args
        }), '*');
      } catch (_) {}
    }
  }

  function getNativeAudio() {
    return document.getElementById('native-audio') || (window.el && window.el.nativeAudio);
  }

  function hookNativeAudio() {
    const audio = getNativeAudio();
    if (!audio || audio.__pricsHooked) return;
    audio.__pricsHooked = true;

    Object.defineProperty(audio, 'src', {
      get() { return this.__pricsVirtualSrc || ''; },
      set(val) { this.__pricsVirtualSrc = val; },
      configurable: true
    });

    Object.defineProperty(audio, 'currentTime', {
      get() { return currentTime; },
      set(val) {
        currentTime = Math.max(0, val);
        sendCommand('seekTo', [currentTime, true]);
      },
      configurable: true
    });

    Object.defineProperty(audio, 'duration', {
      get() {
        if (duration > 0) return duration;
        if (window.state && window.state.currentTrack && window.state.currentTrack.duration) {
          return window.state.currentTrack.duration;
        }
        return 0;
      },
      configurable: true
    });

    Object.defineProperty(audio, 'paused', {
      get() { return !isPlaying; },
      configurable: true
    });

    audio.play = async function () {
      sendCommand('playVideo');
      setPlayState(true);
      return Promise.resolve();
    };

    audio.pause = function () {
      sendCommand('pauseVideo');
      setPlayState(false);
    };
  }

  function setPlayState(playing) {
    isPlaying = playing;
    if (window.state) window.state.isPlaying = playing;
    if (playing) {
      document.body.classList.add('is-playing');
      if (typeof window.updatePlayPauseButton === 'function') window.updatePlayPauseButton(true, true);
      startTick();
      const audio = getNativeAudio();
      if (audio) {
        audio.dispatchEvent(new Event('play'));
        audio.dispatchEvent(new Event('playing'));
      }
    } else {
      document.body.classList.remove('is-playing');
      if (typeof window.updatePlayPauseButton === 'function') window.updatePlayPauseButton(false, false);
      stopTick();
      const audio = getNativeAudio();
      if (audio) {
        audio.dispatchEvent(new Event('pause'));
      }
    }
  }

  function startTick() {
    stopTick();
    tickTimer = setInterval(() => {
      if (!isPlaying) return;
      currentTime += 0.25;
      const curDur = (window.state && window.state.currentTrack && window.state.currentTrack.duration) || duration;
      if (curDur > 0 && currentTime >= curDur) {
        setPlayState(false);
        const audio = getNativeAudio();
        if (audio) audio.dispatchEvent(new Event('ended'));
        if (typeof window.playNextSong === 'function') window.playNextSong();
        else if (typeof window.playNext === 'function') window.playNext();
        return;
      }

      const audio = getNativeAudio();
      if (audio) audio.dispatchEvent(new Event('timeupdate'));

      // Direct Neubrutalism UI updates
      const bar = document.getElementById('track-progress-bar');
      if (bar && curDur > 0) {
        bar.value = Math.min(100, Math.max(0, (currentTime / curDur) * 100));
      }
      const timeElapsed = document.getElementById('time-elapsed');
      if (timeElapsed) {
        const m = Math.floor(currentTime / 60);
        const s = Math.floor(currentTime % 60);
        timeElapsed.textContent = `${m}:${s < 10 ? '0' : ''}${s}`;
      }
      const timeTotal = document.getElementById('time-total');
      if (timeTotal && curDur > 0) {
        const m = Math.floor(curDur / 60);
        const s = Math.floor(curDur % 60);
        timeTotal.textContent = `${m}:${s < 10 ? '0' : ''}${s}`;
      }
      if (typeof window.updateSyncedLyricsHighlight === 'function') {
        window.updateSyncedLyricsHighlight(currentTime);
      }
    }, 250);
  }

  function stopTick() {
    if (tickTimer) {
      clearInterval(tickTimer);
      tickTimer = null;
    }
  }

  // Primary entrypoint invoked by bridge.js on pure web
  window.__pricsPlayWebTrack = function ({ videoId, title, artist }) {
    hookNativeAudio();
    currentTime = 0;
    currentVideoId = videoId;
    currentSearchQuery = `${artist || ''} ${title || ''} audio`.trim();
    if (window.state && window.state.currentTrack && window.state.currentTrack.duration) {
      duration = window.state.currentTrack.duration;
    }

    const iframe = getIframe();
    if (iframe) {
      let embedUrl = '';
      if (videoId) {
        embedUrl = `https://www.youtube.com/embed/${videoId}?autoplay=1&enablejsapi=1&playsinline=1`;
      } else {
        embedUrl = `https://www.youtube.com/embed?listType=search&list=${encodeURIComponent(currentSearchQuery || 'music')}&autoplay=1&enablejsapi=1&playsinline=1`;
      }
      iframe.src = embedUrl;
      setPlayState(true);
    }
  };

  // Listen to postMessage from YouTube embed
  window.addEventListener('message', (event) => {
    try {
      if (!event.data || typeof event.data !== 'string') return;
      const data = JSON.parse(event.data);
      if (data.event === 'onStateChange') {
        // 1: PLAYING, 2: PAUSED, 0: ENDED, 3: BUFFERING
        if (data.info === 1) setPlayState(true);
        else if (data.info === 2) setPlayState(false);
        else if (data.info === 0) {
          setPlayState(false);
          const audio = getNativeAudio();
          if (audio) audio.dispatchEvent(new Event('ended'));
          if (typeof window.playNextSong === 'function') window.playNextSong();
          else if (typeof window.playNext === 'function') window.playNext();
        }
      } else if (data.event === 'infoDelivery' && data.info) {
        if (typeof data.info.currentTime === 'number') currentTime = data.info.currentTime;
        if (typeof data.info.duration === 'number' && data.info.duration > 0) duration = data.info.duration;
        if (data.info.playerState === 1) setPlayState(true);
        else if (data.info.playerState === 2) setPlayState(false);
      }
    } catch (_) {}
  });

  // Hook Play / Pause clicks
  document.addEventListener('click', (e) => {
    hookNativeAudio();
    const playBtn = e.target.closest('#btn-play-pause, #mobile-mini-play, .prics-play-trigger');
    if (playBtn) {
      if (isPlaying) {
        sendCommand('pauseVideo');
        setPlayState(false);
      } else {
        sendCommand('playVideo');
        setPlayState(true);
      }
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', hookNativeAudio);
  } else {
    hookNativeAudio();
  }
})();
