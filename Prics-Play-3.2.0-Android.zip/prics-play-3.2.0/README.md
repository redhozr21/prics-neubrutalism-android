# Prics Play 3.0.0 — Player, Queue & Lyrics Reliability Release

Prics Play 3.0.0 is a major reliability release based on the 2.6.4 source tree. It preserves the app identity, data stores, themes, integrations, header, Search/provider layout, Settings spacing, and the existing Android build configuration.

## Main changes
- Queue view now separates the current track from upcoming tracks and does not display played queue history as “Up Next”.
- The queue pane has an explicit back path to Now Playing, an accessible label/count, and clear-queue semantics that leave the current track playing.
- The mobile overflow menu is portalled to the document body and positioned against the viewport to avoid clipping behind artwork/lyrics.
- The Now Playing artist is a semantic button; opening an artist profile closes the player sheet so the artist page and song list are visible.
- Genius editorial/SEO snippets are removed from extracted lyrics.
- NetEase timed YRC is preferred, with line-timed LRC as a fallback. Plain lyrics are aligned to timed lyrics in sequence only when a sufficiently strong match exists; original displayed lyric text is retained.
- If text lyric providers return nothing, the player tries a verified timed NetEase result before showing an empty lyrics panel.
- Shuffle and Repeat states remain explicit and have visible mobile labels.

## Important limitations
- Automatic line synchronization depends on a valid timestamp source and a verified title/artist/duration match. The app does not invent timestamps. If providers have no usable timed lyrics, manual synchronization remains a fallback.
- Spotify playlist metadata is imported from public playlists; playback is resolved through supported search providers, not Spotify-protected audio. The YouTube Music Indonesia shelf remains a dated chart snapshot unless refreshed by a later release.
- This archive is source code, not an APK. GitHub Actions must build the Android package.
- An APK built with a different signing certificate cannot update an installed app in place. Recover the original signing key before distributing an update; do not uninstall or clear app data as a workaround.

## Build
Upload `Prics-Play-3.0.0-Android.zip` to the repository root and run the existing Android workflow with version `3.0.0`. Verify the APK signing certificate against the installed stable app before installation.
