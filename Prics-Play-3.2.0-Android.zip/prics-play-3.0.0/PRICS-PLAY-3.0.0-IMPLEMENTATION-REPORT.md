# Prics Play 3.0.0 — Implementation Report

## Release scope
Major reliability update based on the supplied 2.6.4 source tree. Existing app identity, user storage, profiles, themes, integrations, compact Search/provider controls, approved header, Settings spacing, and Home playlist shelves are retained.

## Fixes implemented

### Queue / Up Next
- Corrected the mobile drawer visibility cascade: a hidden Now Playing pane can no longer remain visible over the Queue pane.
- Added a direct `muriel:show-now-playing` action for the Queue back arrow; it no longer relies on clicking a hidden control.
- Queue display now separates the current track from the upcoming list. Played items and the current track are not repeated inside Up Next.
- Queue count reflects upcoming tracks, and the queue is rerendered when the current queue index changes.
- Clear queue empties upcoming tracks while leaving the current track playing and visible.
- Added a visible “Antrean” label and accessible button state.

### Lyrics
- Hardened Genius extraction against SEO/editorial descriptions such as the “Monster Mash LyricsQuite possibly…” text in the supplied screenshot.
- Added NetEase LRC fallback when word-timed YRC is unavailable.
- Improved NetEase candidate selection using title, artist, and duration; large duration mismatches are rejected.
- Added ordered line-to-timestamp alignment. Original displayed lyric text is preserved; timestamps are attached only to lines that match with sufficient confidence.
- Added timed NetEase fallback when text lyric providers return no usable lyrics.
- Decoupled plain-line automatic synchronization from the optional word-timing preference, so the “estimate” word mode no longer blocks line-level timestamp lookup.
- Partial automatic synchronization is reported as a count, and manual completion remains optional for unmatched lines.
- No timestamps are fabricated when no provider has a valid match.

### Player menu and artist navigation
- Portalled the overflow menu to `document.body` with fixed viewport positioning and a high stacking layer to avoid clipping behind artwork or lyrics.
- Changed the Now Playing artist name into a semantic, keyboard/touch-accessible button.
- Opening an artist profile closes the Now Playing sheet first, so the artist page and its track list are visible.

### Shuffle / Repeat / Home cards
- Added visible ON / ALL / 1 state labels for Shuffle, Repeat All, and Repeat One.
- Retained the existing Spotify public-playlist imports and YouTube Music Indonesia playlist shelf below Trending Now.
- Retained the existing compact track-card and On Repeat layout rules.

## Compatibility and data safety
- Android application ID remains `io.github.cloverscripts.muriel`.
- No local-storage namespace or profile data schema was intentionally changed.
- Third-party `package-lock.json` entries are unchanged from the 2.6.0 repository baseline; only the root package version is bumped to 3.0.0.
- The source ZIP does not contain a signing keystore.
- A different APK signing certificate cannot update the installed app in place. Do not uninstall the stable app or clear its data to work around a signature mismatch.

## Validation
- JavaScript syntax check: all project JavaScript files are checked with `node --check`.
- CSS parsing: `styles.css` and `mobile/mobile.css` are parsed for syntax errors.
- Focused regression tests: 63 passed. They cover queue state derivation, queue/back visibility, artist navigation, popup layering, Genius cleanup, NetEase YRC/LRC parsing, line alignment, release identity, lockfile invariance, and retained Home/Settings/header behavior.
- Full automated suite: 386 passed; 1 existing test is blocked because it requires the Electron package, which is not installed in this source-only environment. The source ZIP does not include `node_modules`; that test should run after GitHub Actions completes `npm ci`.
- `npm ci`, the esbuild mobile bundle, Gradle APK build, and real-device verification must still run in GitHub Actions / on the Android device. This report does not claim those have passed.

## Known external dependency limits
- Automatic lyric synchronization requires a timestamped provider result that matches the requested track. Songs with no compatible timed source remain unsynchronized and expose manual sync as a fallback.
- Spotify playlist metadata is imported from public playlists; Spotify-protected audio is not streamed directly. Playback resolution continues through supported providers.
- The YouTube Music chart shelf is a curated snapshot in the current source, not a live chart API guarantee.
