# Prics Play 3.0.0 — Permanent Release Signing Keystore

## Status Update (v3.0.0 Release Keystore Configured)
A permanent, production-ready PKCS12 release keystore has been created and configured in the project to resolve all future signature mismatch issues:

- **Location:** `android/keystores/prics-play-release.keystore`
- **Keystore Type:** `PKCS12`
- **Key Alias:** `pricsplay`
- **Key Password / Keystore Password:** `pricsplay2026`
- **Certificate Validity:** 30 years (Valid until November 2056)
- **SHA-256 Certificate Fingerprint:** `37:48:C8:92:0B:07:14:1C:0A:99:0E:13:61:DF:64:92:D3:9D:39:1A:1D:EB:93:5E:A2:FD:B3:9E:79:21:F5:41`

Both `build-apk.yml` and `android.yml` workflows, as well as `android/app/build.gradle` (for both `release` and `debug` buildTypes), are configured to use this permanent keystore. Every future build from v3.0.0 onwards will share this exact same certificate, allowing seamless in-place updates.

## Historical Signing Context (Previous Versions)
Previous builds in early 2.x versions relied on ephemeral GitHub Actions runner cache (`prics-play-debug-keystore-v1`), which caused varying random debug certificates across builds:
- `Prics-Play 3.3.0.apk`: `DAD59C432B9C71753B6C0EDFFB3FF20717FFD64C71CACDA476C6E348C9748310`
- `Prics-Play 3.4.0.apk`: `A31F0FE0D1C4F95C4D368432E12AE37591998BD8172086BFFACED9B731DACC2C`
- `Prics-Play.apk` (old test run): `49C30BE6AC389C889A731F2131466E8F81382CC2B12671A3CACF48CCE4D44D6A`

## Migration to 3.0.0
Because Android cryptographically enforces signature continuity, transitioning from the old random debug build to the permanent 3.0.0 release requires a one-time clean transition:
1. In the existing app on the phone: Go to **Settings > Storage > Export all playlists** and **Back up this profile** (save the JSON files).
2. Uninstall the old version from the phone (only needed this one time).
3. Install the 3.0.0 APK signed with the permanent keystore.
4. Go to **Settings > Storage > Import playlists / Restore profile** to restore all playlists and settings.
5. All future updates (3.0.1, 3.1.0, 4.0.0, etc.) will install directly over 3.0.0 with no uninstall needed!
