# Prics Play 2.6.2 — Compact Search / Provider Correction

## Scope
This is a focused UI correction on top of 2.6.1. The 2.6.1 header, audio timeline, lyric synchronization, and all other app behavior remain unchanged.

## Changes
- Search control height restored to 40 px.
- Provider pill height restored to 40 px.
- Search icon restored to 18 px and input font to 15 px.
- Provider selector uses a fixed 108 px width instead of expanding to 33–34% of the mobile navigation row.
- Provider buttons restored to 32 px and 16 px icons.
- Search wrapper continues to flex into the remaining navigation space.
- Search and provider cards retain the same border/background treatment and use matching shadows in both Neubrutalism and Liquid Glass themes.

## Preserved
- Smaller 2.6.1 mobile brand header.
- Native audio media events drive Android playback elapsed time and seek progress.
- Mobile lyrics update from the native audio clock and highlight the active line.
- Timestamped lyrics support tap-to-seek; untimed lyrics expose manual synchronization.
- Existing app ID `io.github.cloverscripts.muriel`.
- Existing GitHub Actions workflow.

## Validation
- 131 JavaScript files pass `node --check`.
- CSS parser reports zero errors in `styles.css` and `mobile/mobile.css`.
- All 28 focused 2.6.2 layout, playback, lyrics, and version regression tests pass.
- Full test suite: 353 passed, 1 blocked because the local environment does not include the `electron` package required by `test/library-import.test.js`.
- Full Android build and real-device visual verification must be completed by GitHub Actions and on the target Android device.

## Installation caution
A successful CI build does not prove that its APK can update an existing installation. Compare the APK signing certificate against the installed stable APK before installation. Do not uninstall the stable app or clear its data as a signing workaround.
