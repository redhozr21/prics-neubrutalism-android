// Pure queue view-model logic shared by the player UI and its regression tests.
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else if (root) root.MurielQueueView = api;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  function getQueueViewModel(queue, queueIndex, currentTrack, sameTrack) {
    const tracks = Array.isArray(queue) ? queue : [];
    const equals = typeof sameTrack === 'function'
      ? sameTrack
      : ((a, b) => !!a && !!b && ((a.id && b.id && a.id === b.id) || (a.title === b.title && a.artist === b.artist)));
    let index = Number.isInteger(queueIndex) ? queueIndex : -1;
    if (index < 0 || index >= tracks.length || (currentTrack && !equals(tracks[index], currentTrack))) {
      index = currentTrack ? tracks.findIndex(track => equals(track, currentTrack)) : -1;
    }
    const current = currentTrack || (index >= 0 ? tracks[index] : null);
    const upcoming = index >= 0 ? tracks.slice(index + 1) : tracks.slice();
    return { current, currentIndex: index, upcoming, upcomingCount: upcoming.length };
  }

  return { getQueueViewModel };
});
