# Prics Play 3.0.0 — Audit Notes

## User-reported defects mapped to causes

| Reported behavior | Audit finding | 3.0.0 treatment |
|---|---|---|
| Queue cannot return to Now Playing | Queue back relied on a hidden playback control, and CSS display specificity could keep `#drawer-now` visible while hidden | Explicit app event for back navigation; high-specificity hidden-pane override |
| Queue shows a confusing list | Previous render passed the whole playback queue, including current and already-played entries, as Up Next | Current track separated; Up Next starts after the current queue index |
| Clear is the only working queue action | Pane visibility and back action were coupled to the old drawer state | Back action directly opens Now Playing; Clear only clears queued upcoming items |
| Popup appears behind lyrics/artwork | Menu was nested inside the scroll/transform panel | Menu is portalled to body and fixed to the viewport |
| Lyrics text does not follow playback | Plain lyric text often had no timestamps; automatic lookup only parsed NetEase YRC, not its LRC response | YRC preferred, timed LRC fallback, verified line alignment, and a timed-source fallback when text providers return nothing |
| Genius description appears as lyric text | SEO description can be concatenated to the `Lyrics` heading without whitespace | First lyric rows now filter known editorial patterns, including joined `LyricsQuite` text |
| Artist tap does not show artist page | Artist target was a non-semantic text span; player drawer could continue covering the destination | Semantic artist button; close player drawer before switching to artist page |
| Shuffle / Repeat state unclear | Icon-only state is difficult to read on a touch screen | Explicit ON / ALL / 1 labels and accessible pressed state retained |

## Wider project areas checked

- **Identity and persistence:** application ID and profile/local-storage namespaces preserved.
- **Dependency/build inputs:** third-party lockfile entries compared with the 2.6.0 repository baseline; no dependency upgrades introduced.
- **Player state:** queue view model isolated and covered with pure unit tests for current/upcoming derivation and empty-queue behavior.
- **Lyrics:** extraction, LRC/YRC parsing, provider matching, and ordered line alignment have direct regression tests.
- **Navigation:** artist and Queue back actions have integration-level source checks.
- **Home:** Spotify and YouTube Music playlist shelves remain below Trending Now; removed Made for You shelf remains absent.
- **Settings and theme:** existing theme choices, Settings category spacing, header, Search and provider sizing remain in the source.
- **Android release:** package ID and versionCode scheme remain; signing key is intentionally not regenerated or embedded in this archive.

## Verification boundaries

This is a source-code and automated-test audit. It is not a substitute for running the generated APK on the user's Android phone. Network lyric availability differs by song and region. A full APK build, signing-certificate comparison, audio playback/seek test, Queue navigation test, and artist-page tap test must be completed before calling 3.0.0 production-ready.
