// `child_process.spawn` for the iOS build. iOS can't run processes; the only thing server.js spawns
// is yt-dlp, so this emulates the yt-dlp invocations it makes on top of the in-app extractor.
const { EventEmitter } = require('events');
const fs = require('./fs');
const store = require('./store');
let extractor = null;
const getExtractor = () => extractor || (extractor = require('../extract'));
const { segmentsToAac, stripId3 } = require('../ts2aac');
const cacheLimit = require('../cache-limit');
const scheduleEnforceCacheLimit = cacheLimit.scheduleEnforceCacheLimit || cacheLimit.enforceCacheLimit;

function fakeProcess(work) {
  const p = new EventEmitter();
  p.stdout = new EventEmitter();
  p.stderr = new EventEmitter();
  let killed = false;
  const ac = new AbortController();
  // like a killed process: stop the work and report the exit right away (server.js cleans up on 'close')
  p.kill = () => { if (killed) return; killed = true; ac.abort(); setTimeout(() => p.emit('close', null), 0); };
  setTimeout(async () => {
    try {
      const out = await work(ac.signal);
      if (killed) return;
      if (out) p.stdout.emit('data', out);
      p.emit('close', 0);
    } catch (e) {
      if (killed) return;
      p.stderr.emit('data', `ERROR: ${e && e.message || e}`);
      p.emit('close', 1);
    }
  }, 0);
  return p;
}

const opt = (args, name) => { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : undefined; };

function recordAudioQuality(audio, usedOpus, metrics = {}) {
  const q = audio && audio.qualityInfo || {};
  const actualBps = usedOpus ? (q.opusBps || null) : (q.hlsBps || q.sourceBps || null);
  const approximate = usedOpus ? !!q.opusApproximate : !!q.hlsApproximate;
  const result = {
    preference: q.preference || 'automatic',
    targetBps: q.targetBps || null,
    actualBps: Number(actualBps) || null,
    approximate,
    source: usedOpus ? 'YouTube Opus' : (audio && audio.kind === 'hls' ? 'HLS audio' : 'provider audio'),
    resolveMs: Number.isFinite(metrics.resolveMs) ? Math.max(0, Math.round(metrics.resolveMs)) : null,
    downloadMs: Number.isFinite(metrics.downloadMs) ? Math.max(0, Math.round(metrics.downloadMs)) : null,
    bytes: Number.isFinite(metrics.bytes) ? Math.max(0, Math.round(metrics.bytes)) : null,
    recordedAt: Date.now(),
  };
  try {
    if (globalThis.localStorage) globalThis.localStorage.setItem('prics_audio_quality_last', JSON.stringify(result));
    if (typeof globalThis.dispatchEvent === 'function' && typeof globalThis.Event === 'function') {
      globalThis.dispatchEvent(new Event('prics:audio-quality-status'));
    }
  } catch (_) {}
}

async function searchJson(target, limit) {
  let entries;
  let m = target.match(/^(yt|sc)search(\d*):(.*)$/);
  if (m) {
    const n = Number(m[2]) || limit || 20;
    entries = m[1] === 'sc' ? await getExtractor().soundcloudSearch(m[3], n) : await getExtractor().youtubeSearch(m[3], n);
  } else if ((m = target.match(/music\.youtube\.com\/search\?q=([^#&]+)/))) {
    entries = await getExtractor().ytMusicSearch(decodeURIComponent(m[1].replace(/\+/g, ' ')), limit || 20);
  } else if (/^https?:\/\//.test(target)) {
    // playlist / album / set link (link import)
    const pl = await getExtractor().playlist(target, limit || 500);
    return JSON.stringify({ title: pl.title, entries: pl.entries });
  } else {
    throw new Error(`unsupported search target ${target}`);
  }
  return JSON.stringify({ entries });
}

// Joins downloaded HLS segments into one playable file:
//  'aac'  (default, YouTube): packed audio / MPEG-TS → raw ADTS .aac
//  'mp3'  (SoundCloud): MP3 segments, ID3 tags stripped, frames appended → .mp3
//  'fmp4' (SoundCloud): init segment + moof/mdat fragments appended → fragmented .m4a
function joinSegments(parts, container) {
  if (container === 'aac' || !container) return segmentsToAac(parts);
  return concat(container === 'mp3' ? parts.map(stripId3) : parts);
}

function concat(pieces) {
  const out = new Uint8Array(pieces.reduce((n, x) => n + x.length, 0));
  let o = 0;
  for (const x of pieces) { out.set(x, o); o += x.length; }
  return out;
}

// Append ordered chunks to the temporary cache without retaining the whole song in memory.
async function appendChunk(out, chunk, bytesWritten) {
  if (!chunk || !chunk.length) return bytesWritten;
  if (bytesWritten === 0) await store.writeBytes(out, chunk);
  else await store.appendBytes(out, chunk);
  return bytesWritten + chunk.length;
}

// HLS fallback: process no more than four segments at a time and write them in playlist order.
async function downloadHlsToFile(playlistUrl, headers, signal, container, out) {
  const m3u = await (await globalThis.__murielFetch(playlistUrl, { headers, signal })).text();
  const lines = m3u.split('\n').map((l) => l.trim());
  const key = lines.find((l) => l.startsWith('#EXT-X-KEY') && !/METHOD=NONE/.test(l));
  if (key) throw new Error('this song is only available encrypted (DRM)');
  const urls = lines.filter((l) => l && !l.startsWith('#')).map((l) => new URL(l, playlistUrl).href);
  // fragmented MP4 needs its init segment in front of the first fragment
  const map = lines.map((l) => l.startsWith('#EXT-X-MAP') && (l.match(/URI="([^"]+)"/) || [])[1]).find(Boolean);
  if (map) urls.unshift(new URL(map, playlistUrl).href);
  if (!urls.length) throw new Error('empty HLS playlist');

  let bytesWritten = 0;
  try {
    for (let start = 0; start < urls.length; start += 4) {
      const parts = await fetchAll(urls.slice(start, start + 4), headers, signal);
      for (const part of parts) {
        const chunk = container === 'aac' || !container
          ? segmentsToAac([part])
          : container === 'mp3' ? stripId3(part) : part;
        bytesWritten = await appendChunk(out, chunk, bytesWritten);
      }
    }
    if (!bytesWritten) throw new Error('empty HLS audio');
    return bytesWritten;
  } catch (e) {
    try { await store.remove(out); } catch (_) {}
    throw e;
  }
}

// Fetches a bounded batch (at most two URLs concurrently for mobile/weak-signal stability) and returns bodies in order.
async function fetchAll(urls, headers, signal) {
  const parts = new Array(urls.length);
  let next = 0;
  let failed = null;
  const worker = async () => {
    while (next < urls.length && !failed) {
      if (signal && signal.aborted) throw (failed = new Error('download cancelled'));
      const i = next++;
      // a flaky segment shouldn't sink the whole song: retry with backoff on cellular/weak signal
      for (let attempt = 0; ; attempt++) {
        try {
          const r = await globalThis.__murielFetch(urls[i], { headers, signal });
          if (!r.ok) throw Object.assign(new Error(`segment ${i} failed: ${r.status}`), { status: r.status });
          parts[i] = new Uint8Array(await r.arrayBuffer());
          break;
        } catch (e) {
          if (attempt >= 3 || failed || (signal && signal.aborted) || (e.status >= 400 && e.status < 500 && e.status !== 408 && e.status !== 429)) {
            throw (failed = failed || e);
          }
          await new Promise((res) => setTimeout(res, 400 * Math.pow(1.5, attempt)));
        }
      }
    }
  };
  await Promise.all(Array.from({ length: Math.min(2, urls.length) }, worker));
  return parts;
}

// A Googlevideo file is fetched in 512 KiB ranges (2 concurrent ranges max) for smooth streaming and low buffering.
async function downloadRangesToFile(url, headers, signal, size, out) {
  const step = 512 * 1024;
  let written = 0;
  try {
    for (let start = 0; start < size; start += step * 2) {
      const ranges = [];
      for (let from = start; from < Math.min(size, start + step * 2); from += step) {
        const to = Math.min(size, from + step) - 1;
        ranges.push({ url: `${url}&range=${from}-${to}`, expected: to - from + 1 });
      }
      const parts = await fetchAll(ranges.map((r) => r.url), headers, signal);
      for (let i = 0; i < parts.length; i++) {
        if (!parts[i] || parts[i].length !== ranges[i].expected) {
          throw new Error(`incomplete audio range: ${(parts[i] && parts[i].length) || 0} of ${ranges[i].expected} bytes`);
        }
        written = await appendChunk(out, parts[i], written);
      }
    }
    if (written !== size) throw new Error(`incomplete download: ${written} of ${size} bytes`);
    return written;
  } catch (e) {
    try { await store.remove(out); } catch (_) {}
    throw e;
  }
}

// Android plays Opus (WebM) natively; set by bridge.js. iOS keeps the AAC stream.
const playsOpus = () => !!globalThis.__murielPlaysOpus;

async function download(args, target, signal) {
  const resolveStartedAt = Date.now();
  const audio = await getExtractor().resolveAudio(target);
  const resolveMs = Date.now() - resolveStartedAt;
  if (signal && signal.aborted) throw new Error('download cancelled');
  const template = opt(args, '-o');
  // yt-dlp templates: the user-facing download keeps the real container (no ffmpeg on iOS to convert)
  const named = (ext) => (template.includes('%(ext)s') ? template.replace('%(ext)s', ext) : template);
  let out = named(audio.ext);
  let size = 0;
  let usedOpus = false;
  const downloadStartedAt = Date.now();
  // Android's native Opus path is range-based. Write each batch to the temporary cache rather than
  // retaining the complete song in RAM; remove partial data before falling back to HLS.
  if (audio.opus && playsOpus()) {
    const opusOut = named('webm');
    try {
      size = await downloadRangesToFile(audio.opus.url, audio.headers, signal, audio.opus.size, opusOut);
      out = opusOut;
      usedOpus = true;
    } catch (e) {
      if (signal && signal.aborted) throw e;
      try { await store.remove(opusOut); } catch (_) {}
      console.warn('[muriel] Opus download failed, using AAC', e && e.message);
    }
  }
  if (!usedOpus) {
    try {
      if (audio.kind === 'hls') size = await downloadHlsToFile(audio.url, audio.headers, signal, audio.container, out);
      else size = await store.download(audio.url, out, audio.headers || { 'User-Agent': 'Mozilla/5.0' });
    } catch (e) {
      try { await store.remove(out); } catch (_) {}
      throw e;
    }
  }
  fs._register(out, size);
  scheduleEnforceCacheLimit();
  recordAudioQuality(audio, usedOpus, { resolveMs, downloadMs: Date.now() - downloadStartedAt, bytes: size });
  return '';
}

function spawn(bin, args) {
  args = args || [];
  // yt-dlp takes the target anywhere: server.js puts search terms first and URLs last
  const target = [...args].reverse().find((a) => /^(yt|sc)search\d*:|^https?:\/\//.test(a)) || args[args.length - 1];
  const limit = Number(opt(args, '--playlist-end')) || undefined;

  if (args.includes('-g')) return fakeProcess(async () => `${(await getExtractor().resolveAudio(target)).url}\n`);
  if (args.includes('--dump-single-json') || args.includes('-J')) return fakeProcess(() => searchJson(target, limit));
  if (args.includes('--print')) return fakeProcess(async () => `${(await getExtractor().resolveAudio(target)).artist || 'NA'}\n`);
  if (args.includes('-x')) return fakeProcess((signal) => download(args, target, signal));
  return fakeProcess(async () => { throw new Error(`unsupported yt-dlp call: ${args.join(' ')}`); });
}

module.exports = { joinSegments, spawn, execFile: () => { throw new Error('execFile is not available on iOS'); } };
