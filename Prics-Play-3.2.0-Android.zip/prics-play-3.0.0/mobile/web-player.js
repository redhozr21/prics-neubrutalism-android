// Web Player Engine for Prics Play on GitHub Pages & Web Browsers
// Plays direct audio streams through HTML5 audio with ZERO ADS, matching the Android APK experience.
(() => {
  const isNative = typeof window.Capacitor !== 'undefined' && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform();
  if (isNative) return; // Native Android uses Capacitor and native audio engine

  // Clean up any legacy YouTube player host or scripts
  const legacyHost = document.getElementById('prics-yt-host');
  if (legacyHost) legacyHost.remove();

  // Invidious stream hosts for failover
  const STREAM_HOSTS = [
    'https://yt.chocolatemoo53.com',
    'https://inv.bp.projectsegfau.lt',
    'https://invidious.projectsegfau.lt'
  ];

  let currentHostIndex = 0;

  // Unlock browser audio context / element on first user interaction (standard web requirement)
  function unlockAudio() {
    const audios = document.querySelectorAll('audio');
    audios.forEach((a) => {
      // Ensure crossOrigin is NOT set to avoid CORS restrictions on media element playback
      a.removeAttribute('crossorigin');
    });
    window.removeEventListener('pointerdown', unlockAudio);
    window.removeEventListener('keydown', unlockAudio);
  }
  window.addEventListener('pointerdown', unlockAudio, { passive: true });
  window.addEventListener('keydown', unlockAudio, { passive: true });

  // Stream error recovery: If a stream URL fails to load, try the next healthy host
  function setupStreamFailover() {
    const audios = document.querySelectorAll('audio');
    audios.forEach((a) => {
      if (a.__pricsFailoverHooked) return;
      a.__pricsFailoverHooked = true;

      a.addEventListener('error', () => {
        const src = a.src || '';
        const m = src.match(/latest_version\?id=([A-Za-z0-9_-]{11})&itag=(\d+)/);
        if (m) {
          const videoId = m[1];
          const itag = m[2] || '140';
          currentHostIndex = (currentHostIndex + 1) % STREAM_HOSTS.length;
          const nextHost = STREAM_HOSTS[currentHostIndex];
          const newSrc = `${nextHost}/latest_version?id=${videoId}&itag=${itag}`;
          console.warn(`[Web Player] Stream error on host, trying fallback: ${newSrc}`);
          setTimeout(() => {
            a.src = newSrc;
            a.play().catch(() => {});
          }, 300);
        }
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupStreamFailover, { once: true });
  } else {
    setupStreamFailover();
  }
  setInterval(setupStreamFailover, 2000);
})();
