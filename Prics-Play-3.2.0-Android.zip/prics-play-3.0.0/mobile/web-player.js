// Web Player Engine for Prics Play on GitHub Pages & Web Browsers
// Plays audio seamlessly via YouTube IFrame API without any visible floating windows or popups.
(() => {
  const isNative = typeof window.Capacitor !== 'undefined' && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform();
  if (isNative) return; // Native Android uses Capacitor and native audio engine

  let ytPlayer = null;
  let ytReady = false;
  let activeVideoId = null;
  let pollTimer = null;

  // Intercept and halt 'ended' event on nativeAudio so dummy audio never auto-skips tracks
  function silenceNativeAudioEnded() {
    const audios = document.querySelectorAll('audio');
    audios.forEach((a) => {
      if (a.__pricsEndedHooked) return;
      a.__pricsEndedHooked = true;
      a.addEventListener('ended', (e) => {
        // Stop propagation so app.js playNext() is not called prematurely
        e.stopImmediatePropagation();
        e.preventDefault();
      }, true);
    });
  }

  // Load YouTube IFrame API script
  if (!window.YT) {
    const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    document.head.appendChild(tag);
  }

  // Create an invisible host element positioned off-screen
  function ensureYtHost() {
    let host = document.getElementById('prics-yt-host');
    if (!host) {
      host = document.createElement('div');
      host.id = 'prics-yt-host';
      host.style.cssText = 'position:fixed;top:-9999px;left:-9999px;width:1px;height:1px;opacity:0.001;pointer-events:none;overflow:hidden;z-index:-9999;';
      document.body.appendChild(host);
    }
    const oldContainer = document.getElementById('prics-yt-container');
    if (oldContainer) oldContainer.remove();
    return host;
  }

  window.onYouTubeIframeAPIReady = function() {
    ensureYtHost();
    try {
      ytPlayer = new window.YT.Player('prics-yt-host', {
        width: '1',
        height: '1',
        host: 'https://www.youtube-nocookie.com',
        playerVars: {
          autoplay: 1,
          controls: 0,
          modestbranding: 1,
          rel: 0,
          playsinline: 1,
          iv_load_policy: 3,
          disablekb: 1,
          fs: 0
        },
        events: {
          onReady: () => {
            ytReady = true;
            if (activeVideoId && ytPlayer && typeof ytPlayer.loadVideoById === 'function') {
              try {
                ytPlayer.loadVideoById(activeVideoId);
              } catch (_) {}
            }
          },
          onStateChange: (e) => {
            const playBtn = document.getElementById('btn-play-pause');
            const isPlaying = e.data === window.YT.PlayerState.PLAYING;
            if (isPlaying) {
              document.body.classList.add('is-playing');
              if (playBtn) playBtn.classList.add('playing');
              startProgressPolling();
            } else if (e.data === window.YT.PlayerState.PAUSED) {
              document.body.classList.remove('is-playing');
              if (playBtn) playBtn.classList.remove('playing');
              stopProgressPolling();
            } else if (e.data === window.YT.PlayerState.ENDED) {
              document.body.classList.remove('is-playing');
              if (playBtn) playBtn.classList.remove('playing');
              stopProgressPolling();

              // ONLY advance if the track actually completed playing (duration > 15s and current >= duration - 4s)
              try {
                const cur = (ytPlayer && typeof ytPlayer.getCurrentTime === 'function') ? ytPlayer.getCurrentTime() : 0;
                const dur = (ytPlayer && typeof ytPlayer.getDuration === 'function') ? ytPlayer.getDuration() : 0;
                if (dur > 15 && cur >= dur - 4) {
                  const nextBtn = document.getElementById('btn-next');
                  if (nextBtn) nextBtn.click();
                }
              } catch (_) {}
            }
          }
        }
      });
    } catch (err) {
      console.warn('[Web Player] YouTube API Init Warning:', err);
    }
  };

  function formatTime(s) {
    const sec = Math.floor(s || 0);
    const m = Math.floor(sec / 60);
    const rem = sec % 60;
    return `${m}:${rem < 10 ? '0' : ''}${rem}`;
  }

  function startProgressPolling() {
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(() => {
      if (!ytPlayer || typeof ytPlayer.getCurrentTime !== 'function') return;

      const cur = ytPlayer.getCurrentTime() || 0;
      const dur = ytPlayer.getDuration() || 0;

      // Update current and duration time labels
      const timeCur = document.getElementById('time-current');
      const timeDur = document.getElementById('time-duration');
      if (timeCur) timeCur.textContent = formatTime(cur);
      if (timeDur && dur > 0) timeDur.textContent = formatTime(dur);

      // Update scrubber track progress CSS variable (--np-progress)
      const scrubberTrack = document.getElementById('scrubber-track') || document.querySelector('.scrubber-track-container');
      if (scrubberTrack && dur > 0) {
        const pct = Math.min(100, Math.max(0, (cur / dur) * 100));
        scrubberTrack.style.setProperty('--np-progress', `${pct.toFixed(2)}%`);
      }
    }, 250);
  }

  function stopProgressPolling() {
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = null;
  }

  // Global YouTube playback trigger for Web
  window.__pricsPlayYt = function(videoId) {
    if (!videoId) return;
    activeVideoId = videoId;
    ensureYtHost();

    silenceNativeAudioEnded();

    if (ytReady && ytPlayer && typeof ytPlayer.loadVideoById === 'function') {
      try {
        ytPlayer.loadVideoById(videoId);
      } catch (_) {}
    }
  };

  // Wire transport controls after DOM load
  const initControls = () => {
    silenceNativeAudioEnded();

    // Intercept play/pause button
    const playBtn = document.getElementById('btn-play-pause');
    if (playBtn && !playBtn.__pricsYtHooked) {
      playBtn.__pricsYtHooked = true;
      playBtn.addEventListener('click', () => {
        if (!ytPlayer || typeof ytPlayer.getPlayerState !== 'function') return;
        try {
          const state = ytPlayer.getPlayerState();
          if (state === window.YT.PlayerState.PLAYING) {
            ytPlayer.pauseVideo();
          } else {
            ytPlayer.playVideo();
          }
        } catch (_) {}
      }, true);
    }

    // Scrubber click seeking
    const scrubber = document.getElementById('scrubber-track') || document.querySelector('.scrubber-track-container');
    if (scrubber && !scrubber.__pricsYtHooked) {
      scrubber.__pricsYtHooked = true;
      scrubber.addEventListener('click', (e) => {
        if (!ytPlayer || typeof ytPlayer.getDuration !== 'function') return;
        try {
          const rect = scrubber.getBoundingClientRect();
          const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
          const dur = ytPlayer.getDuration() || 0;
          if (dur > 0) {
            ytPlayer.seekTo(ratio * dur, true);
          }
        } catch (_) {}
      });
    }

    // Wire volume slider and mute controls
    const volSlider = document.getElementById('volume-slider') || document.getElementById('tvk-volume-slider');
    if (volSlider && !volSlider.__pricsYtHooked) {
      volSlider.__pricsYtHooked = true;
      volSlider.addEventListener('input', (e) => {
        if (!ytPlayer || typeof ytPlayer.setVolume !== 'function') return;
        try {
          const val = Math.round(Number(e.target.value || 0) * 100);
          ytPlayer.setVolume(val);
          if (val > 0 && typeof ytPlayer.unMute === 'function') ytPlayer.unMute();
        } catch (_) {}
      });
    }
    const muteBtn = document.getElementById('btn-volume-mute');
    if (muteBtn && !muteBtn.__pricsYtHooked) {
      muteBtn.__pricsYtHooked = true;
      muteBtn.addEventListener('click', () => {
        if (!ytPlayer) return;
        try {
          if (typeof ytPlayer.isMuted === 'function' && ytPlayer.isMuted()) {
            if (typeof ytPlayer.unMute === 'function') ytPlayer.unMute();
          } else if (typeof ytPlayer.mute === 'function') {
            ytPlayer.mute();
          }
        } catch (_) {}
      });
    }

    // Suppress unhandled HTML5 audio errors on web
    window.addEventListener('error', (e) => {
      if (e && e.message && /MEDIA_ELEMENT_ERROR|src_not_supported/i.test(e.message)) {
        e.preventDefault();
      }
    }, true);
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initControls, { once: true });
  } else {
    initControls();
  }
  // Periodically hook nativeAudio in case app.js replaces it
  setInterval(silenceNativeAudioEnded, 1000);
})();
