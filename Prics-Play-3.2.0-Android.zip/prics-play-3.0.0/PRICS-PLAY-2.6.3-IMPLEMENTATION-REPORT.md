# Prics Play 2.6.3 — Settings Spacing Implementation Report

## Scope
A focused spacing correction to the mobile Settings category list, based on 2.6.2. Search and provider sizing are unchanged.

## Changes
- Increased the vertical gap between Settings category buttons to 10 px.
- Increased category-list inner padding to 10 px.
- Kept category buttons at a consistent minimum height of 52 px.
- Applies to Interface, Theme, Tracks, Integrations, Storage, About, and the other categories in the same list.
- Category order, labels, navigation actions, and settings content are unchanged.

## Preserved
- Compact Search and provider controls from 2.6.2 (40 px high).
- Fixed 108 px provider width and 16 px provider icons.
- Matching Search/provider shadows.
- 2.6.1 header, playback timeline, and synchronized lyrics.
- Existing app ID `io.github.cloverscripts.muriel` and Android workflow.

## Dependency lockfile correction
- Restored the `mime`, `native-run` (`tslib` range), and `temp` (`rimraf` range) lock entries to the exact values in the original 2.6.0 source.
- Kept the app root version at 2.6.3 in `package.json` and `package-lock.json`.
- Compared the package-lock package entries against 2.6.0: the only remaining package-entry difference is the app root version; third-party dependency entries are unchanged.

## Validation
- 132 JavaScript files pass `node --check`.
- CSS parser reports zero errors in `styles.css` and `mobile/mobile.css`.
- All 31 focused regression tests pass, including Settings spacing, compact Search/provider sizing, playback/lyrics behavior, and version metadata.
- Full suite: 356 passed, 1 blocked because the local environment does not include the `electron` package required by `test/library-import.test.js`.
- A local `npm ci` attempt could not complete because this environment could not resolve `registry.npmjs.org` (`EAI_AGAIN`); it did not report the earlier `mime@2.6.3` 404 after the lockfile repair.
- Full Android build and real-device visual verification must be completed by GitHub Actions and on the target Android device.

## Installation caution
Compare the APK signing certificate against the installed stable APK before installation. Do not uninstall the stable app or clear its data as a signing workaround.
