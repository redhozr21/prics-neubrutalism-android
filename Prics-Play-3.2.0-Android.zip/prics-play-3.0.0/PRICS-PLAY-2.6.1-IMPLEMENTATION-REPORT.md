# Prics Play 2.6.1 — Playback & Lyrics Correction

## Changes
- Reduced the mobile brand header from the oversized 2.6.0 pass: 68 px content row, 48 px brand mark and 46 px profile control (safe-area inset remains respected).
- Search and provider cards remain aligned as a shared design system.
- Replaced the 5 px seekbar hit area with a 28 px touch target and a slim event-driven progress line / thumb.
- Fixed the mobile playback timeline: current time, duration and progress now update from native audio media events while playing.
- Fixed lyric highlighting on phones. The 2.6.0 visualizer loop intentionally sleeps when visualizers are hidden; the player now updates lyrics directly from the audio `timeupdate` clock instead of relying on that loop.
- Added timestamp awareness to lyric rows. Timed rows can be tapped to seek to their timestamp; untimed rows are no longer accidentally interpreted as time zero (`Number(null) === 0`).
- When lyrics are not timestamped, the player shows a clear “Lirik belum tersinkron” state and a button that opens the existing manual lyric-sync workflow.
- Active lyric line receives a clear coral highlight in preview and full-lyrics mode.
- Hid the legacy desktop lyric micro-toolbar on mobile; the new expand and sync actions remain available.

## Playback architecture
- No second audio element or duplicate audio engine is created.
- The existing native audio element remains the source of truth.
- Timeline UI is updated on `timeupdate`, `seeked`, `loadedmetadata` and `durationchange` events. No permanent animation loop was added.
- Existing tap-to-seek on timestamped lyric lines is retained and made explicit.
- The seekbar keeps the original pointer-based seek handler but now has a 28 px touch target.

## Preserved
- Existing app ID `io.github.cloverscripts.muriel`.
- Home, Search, Collection, provider integrations, themes, About, playlists, favorites, queue and background playback.
- Existing GitHub Actions workflow is unchanged.

## Validation
- 350 automated tests discovered: 349 passed.
- One test could not load because the local environment does not include the `electron` package (`test/library-import.test.js`); this is an environment/dependency limitation, not an assertion failure.
- All 24 focused 2.6.1 layout/playback/version regression tests passed.
- JavaScript syntax checks and CSS parsing passed.
- Full dependency installation, Capacitor build and real-device testing have not been completed in this environment. GitHub Actions must perform the authoritative Android build.

## Signing and device testing
A successful CI build does not prove that its APK can update an existing installation. Compare the new APK signing certificate against the installed stable APK before installation. Do not uninstall the stable app or clear app data as a signing workaround.
