# Prics Play 2.6.3 — Android Build Guide

1. Upload `Prics-Play-2.6.3-Android.zip` to the repository root on `main`.
2. Commit the upload. The existing Android build workflow will detect the versioned ZIP.
3. Alternatively, run the existing workflow manually with version `2.6.3`.
4. Wait for GitHub Actions to finish and download the APK artifact.
5. Compare its signing certificate with the currently installed stable APK before installation.

Do not uninstall the stable app or clear its data to work around a signing mismatch.
