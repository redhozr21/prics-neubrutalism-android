# Prics Play 2.6.0 — Implementation Report

## Scope
This release combines the requested mobile header, provider-card and Now Playing redesign into one update. It is based on the supplied 2.5.0 source, itself based on the stable 2.3.3 application foundation.

## Header
- Replaces the undersized centered mobile mark with a left-aligned brand group: square logo, Prics Play wordmark and PLAY tagline.
- Keeps the profile switch at the right and scales it to a 58 px control (52 px on very narrow screens).
- Gives the titlebar a consistent cream surface and strong bottom rule.

## Search and providers
- Search and the YouTube / YouTube Music / SoundCloud shortcuts share a 56 px control height.
- The provider buttons live inside one common pill card, matching the search card's border, radius and hard shadow.
- Provider actions remain the original platform buttons and retain their IDs/data-platform attributes.

## Now Playing
- Rebuilds the mobile player sheet as a coral full-screen layout with a compact top bar, large album artwork, title/artist, favorite action, timeline and transport controls.
- Adds a compact lyrics preview and a separate full-lyrics state.
- Reuses the original playbar-center and queue button DOM nodes. They are moved into the sheet only while it is open and restored to their original locations when closed. Existing application event listeners therefore remain attached.
- No additional audio element, AudioContext, MediaSession or duplicate playback engine is created.
- The new player presentation does not use a continuously animated cover-colour background.

## Compatibility and preserved areas
- Application ID remains `io.github.cloverscripts.muriel`.
- Existing Home, Search, Collection, provider integrations, themes, About, playlist, favorite and playback code paths are retained.
- Package, lockfile, Android version metadata and About labels identify version 2.6.0.
- Existing GitHub Actions workflow is not changed.

## Validation
- 336 existing automated tests passed when run excluding `test/library-import.test.js`, which could not load the `electron` package in this local environment.
- Five additional 2.6.0 layout regression tests are included.
- All 128 JavaScript files passed `node --check` before adding the new test file.
- `styles.css` and `mobile/mobile.css` parsed with zero top-level CSS syntax errors.
- Full `npm ci` and `node mobile/build.mjs` could not be completed in this environment because dependency installation did not finish. GitHub Actions must perform the authoritative Capacitor/Android build.

## Signing and device testing
A successful CI build does not prove that its APK can update an existing installation. The repository Actions cache was previously observed empty. Compare the new APK signing certificate against the installed stable APK before installation. Do not uninstall the working app or clear app data as a signing workaround. Real-device touch, playback, queue, full-lyrics and battery tests remain required.
