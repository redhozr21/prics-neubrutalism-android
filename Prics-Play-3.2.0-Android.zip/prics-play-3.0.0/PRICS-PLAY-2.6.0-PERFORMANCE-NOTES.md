# Prics Play 2.6.0 — Performance Notes

- The redesigned Now Playing sheet does not create another audio element or Web Audio graph.
- Existing playback control DOM nodes are moved and restored; listeners are not rebound.
- The new screen has no continuously running cover-colour animation.
- Touch drag work is coalesced to one requestAnimationFrame while dragging.
- Lyrics observers watch the lyric container and track title; they do not poll on a timer.
- A single audio `timeupdate` listener updates the mini-player progress indicator and skips writes while the document is hidden.
- Source review is not a measured battery benchmark. Device testing is still needed with fixed brightness, volume, network and source.
