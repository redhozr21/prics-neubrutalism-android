const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');

const app = read('app.js');
const mobile = read('mobile/mobile-ui.js');
const css = read('mobile/mobile.css');
const html = read('index.html');
const server = read('server.js');

test('3.0.0 keeps the stable Android app ID and all legacy storage namespaces', () => {
  const pkg = JSON.parse(read('package.json'));
  const lock = JSON.parse(read('package-lock.json'));
  const cap = JSON.parse(read('capacitor.config.json'));
  const gradle = read('android/app/build.gradle');
  assert.equal(pkg.version, '3.0.0');
  assert.equal(lock.version, '3.0.0');
  assert.equal(lock.packages[''].version, '3.0.0');
  assert.equal(cap.appId, 'io.github.cloverscripts.muriel');
  assert.match(gradle, /applicationId "io\.github\.cloverscripts\.muriel"/);
  assert.match(app, /devsize_favorites/);
  assert.match(app, /muriel_repeat/);
  assert.match(app, /muriel_shuffle/);
});

test('3.0.0 does not change any third-party package lock entry from the 2.6.0 repository baseline', () => {
  const lock = JSON.parse(read('package-lock.json'));
  const pkg = JSON.parse(read('package.json'));
  const baselinePkg = JSON.parse(fs.readFileSync('/mnt/data/prics260-original/prics-play-2.6.0/package.json', 'utf8'));
  const baseline = JSON.parse(fs.readFileSync('/mnt/data/prics260-original/prics-play-2.6.0/package-lock.json', 'utf8'));
  assert.deepEqual(pkg.dependencies, baselinePkg.dependencies);
  assert.deepEqual(pkg.devDependencies, baselinePkg.devDependencies);
  const keys = new Set([...Object.keys(lock.packages), ...Object.keys(baseline.packages)]);
  const changed = [...keys].filter(key => key !== '' && JSON.stringify(lock.packages[key]) !== JSON.stringify(baseline.packages[key]));
  assert.deepEqual(changed, []);
});

test('Queue pane hides Now Playing completely when Queue is selected', () => {
  assert.match(app, /now\.classList\.toggle\('hidden', state\.drawerTab !== 'now'\)/);
  assert.match(app, /queue\.classList\.toggle\('hidden', state\.drawerTab !== 'queue'\)/);
  assert.match(css, /#drawer-now\.hidden,[\s\S]*?#drawer-queue\.hidden,[\s\S]*?display: none !important/);
  assert.match(html, /id="queue-current-track"/);
  assert.match(html, /id="queue-tracks-list"/);
  assert.match(app, /const upcoming = model\.upcoming/);
});

test('Queue back arrow returns to Now Playing and the queue button has a visible label', () => {
  assert.match(mobile, /if \(drawerQueue && !drawerQueue\.classList\.contains\('hidden'\)\) \{\s*window\.dispatchEvent\(new Event\('muriel:show-now-playing'\)\)/);
  assert.match(app, /window\.addEventListener\('muriel:show-now-playing', \(\) => openPanelDrawer\('now'\)\)/);
  assert.match(mobile, /queueActionLabel\.textContent = 'Antrean'/);
  assert.match(mobile, /Buka antrean pemutaran/);
  assert.match(html, /aria-expanded="false" aria-pressed="false"/);
});

test('Queue list keeps the current song separate and Clear queue leaves current playback state intact', () => {
  assert.match(app, /queue-current-row/);
  assert.match(app, /state\.queue = \[\];\s*state\.queueIndex = -1;\s*state\.queueHistory = \[\];\s*updateQueueBadge\(\);\s*renderQueueView\(\)/);
  assert.match(app, /const current = model\.current/);
  assert.match(app, /const upcoming = model\.upcoming/);
});

test('overflow menu is portalled to body and uses a fixed viewport layer', () => {
  assert.match(mobile, /document\.body\.appendChild\(moreMenu\)/);
  assert.match(mobile, /const positionMoreMenu = \(\) =>/);
  assert.match(mobile, /moreMenu\.contains\(event\.target\)/);
  assert.match(mobile, /if \(!moreMenu\.contains\(event\.target\)\) closeMoreMenu\(\)/);
  assert.match(css, /html\.is-mobile \.np-mobile-menu \{[\s\S]*?position: fixed !important;[\s\S]*?z-index: 100000 !important/);
});

test('Now Playing artist is a semantic button and opening a profile closes the player sheet', () => {
  assert.match(html, /<button class="right-panel-artist" id="right-panel-artist" type="button" disabled/);
  assert.match(app, /rightPanelArtist\.disabled = !String\(track\.artist \|\| ''\)\.trim\(\)/);
  assert.match(app, /if \(state\.isRightPanelOpen && typeof closePanelDrawer === 'function'\) closePanelDrawer\(\)/);
  assert.match(app, /openTrackArtist\(state\.currentTrack\)/);
});

test('lyrics use YRC then LRC timestamps and preserve the displayed lyric text during alignment', () => {
  const source = read('lyrics-sources.js');
  assert.match(source, /function parseNetEaseTimedLyrics\(payload\)/);
  assert.match(source, /function alignLineTimings\(shownLines, timedLines/);
  assert.match(server, /lyricsSources\.parseNetEaseTimedLyrics\(lyr\)/);
  assert.match(app, /Keep the displayed provider's exact lyric text/);
  assert.match(app, /loadTimedLyricsFallback\(title, artist, token\)/);
  assert.match(app, /word-timing preference must not disable automatic line-level sync/);
  assert.doesNotMatch(app, /source === 'estimate' \|\| !S/);
});

test('lyrics status distinguishes partial automatic synchronization from unavailable timing', () => {
  assert.match(mobile, /baris tersinkron otomatis/);
  assert.match(mobile, /Lirik bertimestamp tidak ditemukan/);
  assert.match(mobile, /syncButton\.hidden = syncState === 'synced' \|\| isPending/);
  assert.match(mobile, /syncState === 'partial' \? 'Lengkapi sinkron'/);
});

test('Genius editorial summaries are filtered before they can be displayed as lyrics', () => {
  const source = read('lyrics-sources.js');
  assert.match(source, /quite possibly\|arguably\|greatest/);
  assert.match(source, /Lyrics\(\?=/);
});

test('Shuffle and Repeat have distinct touch-visible active labels', () => {
  assert.match(css, /#btn-shuffle\.active::before[\s\S]*?content: "ON"/);
  assert.match(css, /#btn-repeat\.active:not\(\.repeat-one\)::before[\s\S]*?content: "ALL"/);
  assert.match(css, /#btn-repeat\.repeat-one::before[\s\S]*?content: "1"/);
});

test('viral Spotify and YouTube Music shelves remain below Trending Now', () => {
  assert.ok(html.indexOf('id="sp-viral-sec"') > html.indexOf('id="sp-trend-sec"'));
  assert.match(app, /spotify-top-50-indonesia/);
  assert.match(app, /spotify-hot-hits-indonesia/);
  assert.match(app, /ytmusic-top-songs-indonesia/);
});

test('3.0.0 preserves compact Search/provider, approved header, and Settings spacing', () => {
  assert.match(css, /height: 40px !important/);
  assert.match(css, /width: 108px !important/);
  assert.match(css, /gap: 10px !important/);
  assert.match(html, /Version 3\.0\.0/);
  assert.match(html, /v3\.0\.0/);
});
