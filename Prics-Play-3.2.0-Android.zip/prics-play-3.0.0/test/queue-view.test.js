const test = require('node:test');
const assert = require('node:assert/strict');
const { getQueueViewModel } = require('../queue-view');

const same = (a, b) => !!a && !!b && a.id === b.id;
const tracks = ['a', 'b', 'c', 'd', 'e'].map(id => ({ id, title: id.toUpperCase() }));

test('queue view shows only tracks after the current item as Up Next', () => {
  const model = getQueueViewModel(tracks, 2, tracks[2], same);
  assert.equal(model.current.id, 'c');
  assert.equal(model.currentIndex, 2);
  assert.deepEqual(model.upcoming.map(track => track.id), ['d', 'e']);
  assert.equal(model.upcomingCount, 2);
});

test('queue view repairs a stale index by finding the current track', () => {
  const model = getQueueViewModel(tracks, 0, tracks[3], same);
  assert.equal(model.currentIndex, 3);
  assert.deepEqual(model.upcoming.map(track => track.id), ['e']);
});

test('queue without a current item shows the entire queue as upcoming', () => {
  const model = getQueueViewModel(tracks, -1, null, same);
  assert.equal(model.current, null);
  assert.deepEqual(model.upcoming, tracks);
});

test('clearing the queue leaves the currently playing track visible but has no Up Next items', () => {
  const current = { id: 'playing', title: 'Still Playing' };
  const model = getQueueViewModel([], -1, current, same);
  assert.equal(model.current, current);
  assert.deepEqual(model.upcoming, []);
  assert.equal(model.upcomingCount, 0);
});
