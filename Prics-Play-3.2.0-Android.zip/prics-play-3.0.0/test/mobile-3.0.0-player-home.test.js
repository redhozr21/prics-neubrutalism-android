const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');
const app = read('app.js');
const server = read('server.js');
const mobile = read('mobile/mobile-ui.js');
const mobileCss = read('mobile/mobile.css');
const html = read('index.html');

test('Queue view has a real back path to Now Playing', () => {
  assert.match(mobile, /const drawerQueue = document\.getElementById\('drawer-queue'\)/);
  assert.match(mobile, /if \(drawerQueue && !drawerQueue\.classList\.contains\('hidden'\)\) \{\s*window\.dispatchEvent\(new Event\('muriel:show-now-playing'\)\)/);
  assert.match(mobile, /ANTREAN PEMUTARAN/);
  assert.match(mobile, /Kembali ke Sedang Diputar/);
});

test('Now Playing overflow menu stacks above artwork and lyrics', () => {
  assert.match(mobileCss, /np-mobile-header \{\s*position: relative !important;\s*z-index: 8000 !important/);
  assert.match(mobileCss, /html\.is-mobile \.np-mobile-menu \{[\s\S]*?z-index: 100000 !important/);
});

test('Shuffle and Repeat expose distinct visible and accessible states', () => {
  assert.match(app, /el\.btnShuffle\.setAttribute\('aria-pressed', String\(state\.isShuffle\)\)/);
  assert.match(app, /el\.btnRepeat\.dataset\.mode = state\.repeatMode/);
  assert.match(app, /el\.btnRepeat\.setAttribute\('aria-pressed', String\(state\.repeatMode !== 'off'\)\)/);
  assert.match(mobileCss, /#btn-shuffle\.active::after/);
  assert.match(mobileCss, /#btn-repeat\.repeat-one::before[\s\S]*?content: "1"/);
});

test('Plain lyrics trigger automatic timestamp lookup even in Line mode', () => {
  assert.match(app, /A plain lyric is always eligible for an automatic timed-line lookup in Line mode/);
  assert.match(mobile, /data-sync-state/);
  assert.match(mobile, /Mencari sinkronisasi otomatis/);
  assert.match(mobile, /syncButton\.hidden = syncState === 'synced' \|\| isPending/);
  assert.match(server, /hasSyncedTimestamps/);
  assert.match(server, /shouldRefreshPlainLrclib/);
});

test('Spotify and YouTube Music viral playlists are placed below Trending Now', () => {
  const trendingAt = html.indexOf('id="sp-trend-sec"');
  const viralAt = html.indexOf('id="sp-viral-sec"');
  assert.ok(trendingAt >= 0 && viralAt > trendingAt);
  assert.match(app, /spotify-top-50-indonesia/);
  assert.match(app, /spotify-hot-hits-indonesia/);
  assert.match(app, /ytmusic-top-songs-indonesia/);
  assert.match(app, /\/api\/spotify-import\?url=/);
  assert.match(app, /searchPlatform: 'ytmusic'/);
  assert.match(app, /album\.source === 'curated'/);
});

test('Home no longer renders the previously removed Made for You shelf', () => {
  const start = app.indexOf('function renderSpotifyHome()');
  const end = app.indexOf('function applyHomeLayout', start);
  const homeFn = app.slice(start, end);
  assert.doesNotMatch(homeFn, /renderMadeForYou\(\)/);
});

test('On Repeat and track rows have safe mobile gutters and text clipping', () => {
  assert.match(mobileCss, /\.onrepeat-row \{[\s\S]*?grid-template-columns: 22px 44px minmax\(0, 1fr\) 42px/);
  assert.match(mobileCss, /\.track-row \{[\s\S]*?padding: 8px 12px !important/);
  assert.match(mobileCss, /\.track-row-title,[\s\S]*?text-overflow: ellipsis/);
});

test('3.0.0 version metadata is consistent without changing the Android package identity', () => {
  const pkg = JSON.parse(read('package.json'));
  const lock = JSON.parse(read('package-lock.json'));
  const gradle = read('android/app/build.gradle');
  const html = read('index.html');
  const updater = read('update-notifier.js');
  assert.equal(pkg.version, '3.0.0');
  assert.equal(lock.version, '3.0.0');
  assert.equal(lock.packages[''].version, '3.0.0');
  assert.match(gradle, /"3\.0\.0"/);
  assert.match(html, /Version 3\.0\.0/);
  assert.match(updater, /build\.version \|\| '3\.0\.0'/);
  assert.match(gradle, /applicationId "io\.github\.cloverscripts\.muriel"/);
});
