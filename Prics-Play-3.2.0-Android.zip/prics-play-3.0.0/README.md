# Prics Play 3.2.0 – Android APK & Web PWA

Prics Play 3.2.0 brings authentic Neubrutalism design to Android and Web browsers (PWA).

## Highlights
- **Authentic Neubrutalism UI:** Crisp black borders, solid drop shadows, and high contrast typography.
- **Web PWA:** Full web playback experience on GitHub Pages for iOS Safari and PC/Desktop browsers.
- **Android APK:** High-performance native audio engine with offline caching and background playback.
- **Queue & Lyrics Reliability:** Separated current track and up next queue with synchronized timed lyrics.
