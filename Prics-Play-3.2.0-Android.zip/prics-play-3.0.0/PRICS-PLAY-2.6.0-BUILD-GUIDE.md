# Prics Play 2.6.0 — Build Guide

1. Keep the existing repository workflow file `build-apk.yml`; do not create a second workflow.
2. Upload `Prics-Play-2.6.0-Android.zip` to the repository root on `main`.
3. The existing workflow watches root-level ZIP files and should start automatically. Alternatively, run the existing workflow manually and enter `2.6.0` in its version input.
4. Wait for the build and download the APK artifact.
5. Before installing, compare its signing-certificate SHA-256 fingerprint with the currently installed APK. If it differs, do not install over the current app.

A successful build does not prove update compatibility. The repository Actions cache was previously observed empty, so the debug build may use a newly generated keystore. Do not uninstall or clear app data to bypass a signature mismatch.
