# Prics Play 2.6.1 — Release Notes

- Mobile header scaled down while keeping the left-aligned Prics Play brand and right-side profile.
- Search and YouTube / YouTube Music / SoundCloud cards retain consistent border and shadow geometry.
- Fixed Now Playing time and seek progress updates on Android.
- Fixed synced lyrics to follow the current audio position and visibly highlight the active line.
- Made the seekbar easier to drag and tap.
- Timed lyric lines can be tapped to jump directly to that part of the song.
- Untimed lyrics are identified as unsynced and can be synchronized with the existing manual sync tool.
- No second audio engine or always-running visualizer loop added.
