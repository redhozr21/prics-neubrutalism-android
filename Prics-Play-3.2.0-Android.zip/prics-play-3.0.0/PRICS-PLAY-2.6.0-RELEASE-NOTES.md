# Prics Play 2.6.0 — Release Notes

## Mobile design
- Larger, left-aligned Prics Play brand header.
- Profile avatar aligned to the right and scaled with the header.
- Search and YouTube / YouTube Music / SoundCloud shortcuts now use consistent card dimensions, borders and hard shadows.
- New coral Now Playing screen with large artwork, clear metadata and a balanced transport layout.
- Compact lyrics preview with a dedicated full-lyrics mode.

## Playback and compatibility
- Reuses the existing playback controls and audio engine.
- Preserves provider integrations, themes, About, playlists and favorites.
- Keeps the existing Android application ID.
- No new always-running visualizer or ambient animation is added.

## Important
The source ZIP is not an installable APK. Build it through the repository's existing GitHub Actions workflow. Verify APK signing compatibility before installing over an existing copy.
