window.MURIEL_BUILD = {"sha":"dev","version":"3.2.0","run":0,"repo":"redhozr21/prics-neubrutalism-android","builtAt":"2026-11-01T15:20:00.000Z","channel":""};
