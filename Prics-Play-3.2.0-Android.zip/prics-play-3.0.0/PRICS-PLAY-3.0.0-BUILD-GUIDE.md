# Prics Play 3.0.0 — Build Guide

1. The repository now contains the permanent release keystore at `android/keystores/prics-play-release.keystore`.
2. Upload `Prics-Play-3.0.0-Android.zip` to the repository root on `main`, or manually dispatch the existing workflow with version `3.0.0`.
3. GitHub Actions builds the APK signed with the permanent release keystore (SHA-256: `37:48:C8:92:0B:07:14:1C:0A:99:0E:13:61:DF:64:92:D3:9D:39:1A:1D:EB:93:5E:A2:FD:B3:9E:79:21:F5:41`).
4. Download `Prics-Play.apk` and its SHA-256 checksum from the release / workflow artifacts.
5. On the Android phone:
   - Export all playlists and backup profile from the existing app (**Settings > Storage**).
   - Perform a one-time clean uninstall of the older version.
   - Install the new `Prics-Play.apk` (v3.0.0).
   - Restore playlists and settings (**Settings > Storage**).
6. Moving forward, all future builds (v3.0.1, v3.1.0, etc.) will use this exact same keystore and will install as seamless in-place updates.
